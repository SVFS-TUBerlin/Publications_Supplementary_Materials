from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass, is_dataclass
from enum import Enum
from typing import Any, Protocol

from .contracts import stable_json


INTENT_CONTRACT_VERSION = "0.1"
INTENT_SYSTEM_INSTRUCTION_VERSION = "cnpw-intent-system-v0.1"
INTENT_SYSTEM_INSTRUCTION = """You are not a CNPW calculator. Classify one user request into exactly one label: MODE_A, MODE_B_SIMPLIFIED_RESULT_A_GL7, or UNSUPPORTED. Use MODE_A only when all active Results are requested to be treated equally with no protected criterion. Use MODE_B_SIMPLIFIED_RESULT_A_GL7 only when the user explicitly requests the first active Result A as a hard protected requirement before evaluating later Results. Use UNSUPPORTED for thresholds, retention, weights, multiple protected criteria, protecting Result B/C/etc., compatibility, recovery, sensitivity, optimization, new criteria, changed directions, unsupported criterion counts, or ambiguity. Do not calculate, rank candidates, recommend a terminal result, infer directions, rewrite data, or output any scientific parameter."""
INTENT_SYSTEM_PROMPT_HASH = hashlib.sha256(INTENT_SYSTEM_INSTRUCTION.encode("utf-8")).hexdigest()


class IntentLabel(str, Enum):
    MODE_A = "MODE_A"
    MODE_B_SIMPLIFIED_RESULT_A_GL7 = "MODE_B_SIMPLIFIED_RESULT_A_GL7"
    UNSUPPORTED = "UNSUPPORTED"


@dataclass(frozen=True)
class IntentContext:
    active_result_names: tuple[str, ...]
    directions_are_defined_by_input: bool = True


@dataclass(frozen=True)
class IntentProposal:
    intent_contract_version: str
    request_id: str
    intent: IntentLabel
    short_reason: str
    provider_identity: str
    model_identity: str
    raw_response_hash: str
    created_at: str
    confidence_label: str | None = None

    def to_json(self) -> str:
        return stable_json(self)

    @property
    def proposal_hash_sha256(self) -> str:
        return hashlib.sha256(self.to_json().encode("utf-8")).hexdigest()


class IntentModelClient(Protocol):
    def propose_intent(self, user_text: str, context: IntentContext) -> object:
        """Return only a structured intent proposal; never a scientific result."""


def proposal_from_mapping(value: object) -> IntentProposal:
    if isinstance(value, IntentProposal):
        return value
    if not isinstance(value, dict):
        raise ValueError("Intent provider response must be an object.")
    allowed = {"intent_contract_version", "request_id", "intent", "short_reason", "provider_identity", "model_identity", "raw_response_hash", "created_at", "confidence_label"}
    extras = set(value) - allowed
    missing = {"intent_contract_version", "request_id", "intent", "short_reason", "provider_identity", "model_identity", "raw_response_hash", "created_at"} - set(value)
    if extras:
        raise ValueError("Intent provider response contains forbidden fields.")
    if missing:
        raise ValueError("Intent provider response is missing required fields.")
    try:
        intent = IntentLabel(value["intent"])
    except (TypeError, ValueError) as exc:
        raise ValueError("Intent provider response contains an unknown intent label.") from exc
    fields = ("intent_contract_version", "request_id", "short_reason", "provider_identity", "model_identity", "raw_response_hash", "created_at")
    if any(not isinstance(value[field], str) or not value[field].strip() for field in fields):
        raise ValueError("Intent provider response contains malformed required fields.")
    confidence = value.get("confidence_label")
    if confidence is not None and confidence not in {"HIGH", "MEDIUM", "LOW"}:
        raise ValueError("Intent provider response contains an invalid confidence label.")
    return IntentProposal(value["intent_contract_version"], value["request_id"], intent, value["short_reason"], value["provider_identity"], value["model_identity"], value["raw_response_hash"], value["created_at"], confidence)
