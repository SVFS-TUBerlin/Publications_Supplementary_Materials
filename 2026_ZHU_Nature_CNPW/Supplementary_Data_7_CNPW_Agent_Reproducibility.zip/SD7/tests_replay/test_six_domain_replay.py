import csv
import json
import tempfile
import unittest
from itertools import combinations
from pathlib import Path
from unittest.mock import patch
from scripts import replay_six_domains_v8 as replay

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "tests_replay" / "manifest.json"
FROZEN = ROOT / "Cross_Domain_Validation" / "V8_Replay_Output"


class SixDomainReplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Never write the frozen publication reference directory from a test.
        audit = ROOT / "V8_Residual_ModeB_Upgrade_Audit"
        audit.mkdir(exist_ok=True)
        cls.temporary = tempfile.TemporaryDirectory(prefix="replay_tests_", dir=audit)
        cls.addClassCleanup(cls.temporary.cleanup)
        cls.output = Path(cls.temporary.name)
        with patch.object(replay, "OUTPUT", cls.output):
            replay.main()
        cls.manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
        with (cls.output / "Six_Domain_V8_Master_Ledger.csv").open(encoding="utf-8", newline="") as handle:
            cls.ledger = list(csv.DictReader(handle))

    def test_manifest_has_exact_six_frozen_inputs_and_contract_total(self):
        cases = self.manifest["cases"]
        self.assertEqual(6, len(cases))
        self.assertEqual(140, sum(case["mode_b_contracts"] for case in cases))
        for case in cases:
            self.assertTrue((ROOT / case["input"]).is_file())
            self.assertEqual(2 ** case["m"] - 2, case["mode_b_contracts"])

    def test_generated_case_packages_and_master_branch_counts(self):
        self.assertEqual(6, len(self.ledger))
        self.assertEqual(140, sum(int(row["Mode-B actual"]) for row in self.ledger))
        self.assertEqual(146, 6 + sum(int(row["Mode-B actual"]) for row in self.ledger))
        for case, row in zip(self.manifest["cases"], self.ledger):
            self.assertEqual(str(case["n"]), row["N"]); self.assertEqual(str(case["m"]), row["M"])
            self.assertEqual(str(case["mode_b_contracts"]), row["Mode-B actual"])
            self.assertEqual("completed", row["Complete verification"])
            folder = self.output / case["id"]
            for name in ("V8_Integrated_Report.md", "V8_Integrated_Report.json", "Mode_B_Contracts.csv", "QCCA_Action_Summary.csv", "Mode_A_Summary.json", "Replay_Provenance.json"):
                self.assertTrue((folder / name).is_file())

    def test_every_contract_is_ordered_unique_and_domain_safe(self):
        for case in self.manifest["cases"]:
            folder = self.output / case["id"]
            with (folder / "Mode_B_Contracts.csv").open(encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle))
            expected = [subset for size in range(1, case["m"]) for subset in combinations(range(case["m"]), size)]
            self.assertEqual(case["mode_b_contracts"], len(rows))
            self.assertEqual(list(range(1, len(rows) + 1)), [int(row["contract_index"]) for row in rows])
            self.assertEqual(len(rows), len({row["contract_id"] for row in rows}))
            self.assertTrue(all(row["verification_status"] == "completed" for row in rows))
            self.assertTrue(all(int(row["w1_count"]) <= int(row["omega_count"]) for row in rows))
            self.assertTrue(all(row["global_qcca_status"] == "COMPLETED" for row in rows))
            self.assertEqual(case["mode_b_contracts"], len(expected))

    def test_outputs_are_separate_from_frozen_evidence(self):
        self.assertEqual("V8_Residual_ModeB_Upgrade_Audit", self.output.parent.name)
        self.assertNotEqual(FROZEN, self.output)
        self.assertTrue((self.output / "Replay_Verification.log").read_text(encoding="utf-8").count("PASS") == 6)

    def test_frozen_mode_a_and_first_response_science_is_unchanged(self):
        for case in self.manifest['cases']:
            with self.subTest(case=case['id']):
                old = json.loads((FROZEN / case['id'] / 'V8_Integrated_Report.json').read_text(encoding='utf-8'))
                new = json.loads((self.output / case['id'] / 'V8_Integrated_Report.json').read_text(encoding='utf-8'))
                for key in ('stage_1','stage_2','terminal'):
                    self.assertEqual(old['mode_a']['verified_result'][key], new['mode_a']['verified_result'][key])
                    old_b = old['mode_b_contracts'][0]['verified_result'][key]
                    new_b = dict(new['mode_b_contracts'][0]['verified_result'][key])
                    if key == 'stage_1':
                        new_b.pop('qualification_scope')
                        new_b.pop('qualification_response_indices')
                    self.assertEqual(old_b,new_b)
                self.assertEqual(7,new['mode_b_contracts'][0]['verified_result']['mode_b_conditioning']['k_p'])

    def test_every_global_scope_is_residual_and_every_local_scope_is_all_active(self):
        for case in self.manifest['cases']:
            run = json.loads((self.output / case['id'] / 'V8_Integrated_Report.json').read_text(encoding='utf-8'))
            names = [x['name'] for x in run['mode_a']['verified_result']['input_summary']['active_criteria']]
            for branch in run['mode_b_contracts']:
                r = branch['verified_result']
                protected = r['mode_b_conditioning']['protected_block']
                residual = [x for x in names if x not in protected]
                self.assertEqual(residual,branch['global_qcca']['result']['criterion_names'])
                self.assertEqual(2**len(residual)-1,len(branch['global_qcca']['result']['subset_capabilities']))
                self.assertEqual(set(names),set(r['stage_2']['per_criterion_local_trace']['local']))
                if branch['local_qcca']['status']=='COMPLETED':
                    local = branch['local_qcca']['result']
                    self.assertEqual(names,local['criterion_names'])
                    self.assertEqual(r['stage_1']['retained_candidate_ids'],local['domain_candidate_ids'])
                    for action in branch['targeted_actions']:
                        self.assertTrue(action['verified'])
                        for candidate in action['result']['alternatives']:
                            self.assertIn(candidate['candidate_id'],local['domain_candidate_ids'])


if __name__ == "__main__": unittest.main()
