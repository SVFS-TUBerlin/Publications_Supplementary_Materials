# -*- coding: utf-8 -*-
"""Figure 3: measured volumetric-porosity paths along v, h and P.

Run: python plot_figure3.py
Dependencies: numpy and matplotlib. Roboto fonts and plotting data are bundled.

The input contains one row per specimen. Volumetric porosity is copied
directly from the frozen specimen-level data, in percent. This script
aggregates replicates without normalization, fitting or smoothing.
"""
from __future__ import annotations

import argparse
import csv
import io
from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import product
import json
import hashlib
import platform
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib as mpl
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FormatStrFormatter
import matplotlib.pyplot as plt
import numpy as np


# ===================== EDITABLE CONFIGURATION =====================
BASE_DIR = Path(r"D:\soft\3")
DATA_PATH = BASE_DIR / "data" / "figure3_specimens.csv"
OUTPUT_DIR = BASE_DIR
H_LEVELS = (0.10, 0.20, 0.25)
P_LEVELS = (0.43, 0.45, 0.47)
V_LEVELS = (20.0, 70.0, 120.0)
COLUMN_LAYOUT = (
    {"fixed_parameter": "h_mm", "x_parameter": "v_mm_s", "curve_parameter": "P_mm"},
    {"fixed_parameter": "P_mm", "x_parameter": "h_mm", "curve_parameter": "v_mm_s"},
    {"fixed_parameter": "v_mm_s", "x_parameter": "P_mm", "curve_parameter": "h_mm"},
)

# The design canvas is uniformly scaled to a fixed 190 mm publication width.
# Scaling also applies to typography, markers, caps and line widths.
DESIGN_FIGSIZE = (12.60, 11.70)
PUBLICATION_WIDTH_MM = 190.0
STYLE_SCALE = PUBLICATION_WIDTH_MM / (25.4 * DESIGN_FIGSIZE[0])
FIGSIZE = tuple(value * STYLE_SCALE for value in DESIGN_FIGSIZE)
EXPECTED_DATA_SHA256 = "0fd647307da7a0d97198b279dec669a3b46c7dc6ff6462638381d3fb034f7636"
LEGEND_FONT = 14.0 * STYLE_SCALE
LEGEND_TITLE_FONT = 14.0 * STYLE_SCALE
ADDITIONAL_LABEL_FONT = 14.0 * STYLE_SCALE
PNG_DPI = 600
PREVIEW_DPI = 220
FONT_FAMILY = "Roboto"
# First three exact RGB values from the user's 2-1.py; alpha is applied once.
SERIES_RGB = ((31/255,119/255,180/255), (254/255,127/255,15/255), (44/255,160/255,44/255))
SERIES_ALPHA = 0.6
MARKERS = ("o", "s", "^")
LINE_WIDTH = 1.8 * STYLE_SCALE
MARKER_SIZE = 6.0 * STYLE_SCALE
RANGE_WIDTH = 1.0 * STYLE_SCALE
CAP_SIZE = 3.0 * STYLE_SCALE
Y_LIMITS = (5.5, 16.5)
Y_TICKS = (6, 8, 10, 12, 14, 16)
SHOW_RANGES = True  # full specimen minimum-to-maximum, not SD/SE/CI
# Each extra condition occurs exactly once. Tuple: row, col, color index,
# x coordinate, expected (h, P, v), annotation offset in design points, alignment.
ADDITIONAL_MAP = {
    "V1": (1, 1, 1, 0.15, (0.15, 0.45, 70.0), (10, -10), "left"),
    "V2": (1, 2, 1, 0.46, (0.20, 0.46, 70.0), (-10, 22), "right"),
    "V3": (2, 0, 2, 90.0, (0.25, 0.47, 90.0), (12, 10), "left"),
    "V4": (0, 0, 0, 90.0, (0.10, 0.43, 90.0), (12, -7), "left"),
}
SHOW_COLUMN_TITLES = False
GRID_LINE_STYLE = (0, (2.2, 2.2))  # subtle horizontal reference grid
FILE_STEM = "Figure3"
# ==================================================================


# The exact 101 frozen specimen records are also embedded for portability.
# If the original data/reference directory exists, it is still used and checked.
# Otherwise, this standalone script reproduces the figure from these records.
EMBEDDED_DATA_SHA256 = 'eaa509b573e89945f2c283d4d8733f4a6fff1804a91727e226796b7d4922647c'
EMBEDDED_SPECIMENS = '\ufeffrecord_id,role,group_id,replicate,h_mm,P_mm,v_mm_s,area_mm2,mass_g,phi_vol_pct,Y_pp\nG8-R1,main,G8,1,0.10000000000000001,0.42999999999999999,20,29.789999999999999,6.1130000000000004,8.0631324889519291,3.0723921028460754\nG8-R2,main,G8,2,0.10000000000000001,0.42999999999999999,20,30.096,6.1539999999999999,8.3875445646809599,3.3968041785751062\nG8-R3,main,G8,3,0.10000000000000001,0.42999999999999999,20,29.724299999999999,6.1100000000000003,7.9051416809608028,2.9144012948549491\nG20-R1,main,G20,1,0.10000000000000001,0.42999999999999999,70,30.8828,6.375,7.5154197255778321,2.5246793394719784\nG20-R2,main,G20,2,0.10000000000000001,0.42999999999999999,70,30.956,6.3680000000000003,7.835424635544685,2.8446842494388318\nG20-R3,main,G20,3,0.10000000000000001,0.42999999999999999,70,30.596,6.3230000000000004,7.4099455922506774,2.4192052061448241\nG23-R1,main,G23,1,0.10000000000000001,0.42999999999999999,120,30.552,6.3289999999999997,7.188613619320849,2.1978732332149957\nG23-R2,main,G23,2,0.10000000000000001,0.42999999999999999,120,30.307700000000001,6.2789999999999999,7.1796262002477018,2.1888858141418481\nG23-R3,main,G23,3,0.10000000000000001,0.42999999999999999,120,30.655999999999999,6.3449999999999998,7.269639369654513,2.2788989835486597\nG21-R1,main,G21,1,0.10000000000000001,0.45000000000000001,20,29.850000000000001,5.8600000000000003,12.045292171730823,7.2763624694518976\nG21-R2,main,G21,2,0.10000000000000001,0.45000000000000001,20,29.569700000000001,5.7389999999999999,13.044888546729094,8.2759588444501659\nG21-R3,main,G21,3,0.10000000000000001,0.45000000000000001,20,29.719799999999999,5.7640000000000002,13.107178514469698,8.3382488121907699\nG4-R1,main,G4,1,0.10000000000000001,0.45000000000000001,70,29.5303,6.0220000000000002,8.6352433319293986,3.8663136296504712\nG4-R2,main,G4,2,0.10000000000000001,0.45000000000000001,70,29.520800000000001,6.0330000000000004,8.4388976840969132,3.6699679818179858\nG4-R3,main,G4,3,0.10000000000000001,0.45000000000000001,70,29.419599999999999,6.0129999999999999,8.4285165070018149,3.6595868047228879\nG24-R1,main,G24,1,0.10000000000000001,0.45000000000000001,120,29.902999999999999,6.0694999999999997,9.0623002427082753,4.2933705404293496\nG24-R2,main,G24,2,0.10000000000000001,0.45000000000000001,120,29.8704,6.0039999999999996,9.94549260451506,5.1765629022361326\nG24-R3,main,G24,3,0.10000000000000001,0.45000000000000001,120,29.9892,6.0439999999999996,9.7046501854168081,4.9357204831378807\nG22-R1,main,G22,1,0.10000000000000001,0.46999999999999997,20,29.617799999999999,5.5819999999999999,15.561045812056594,10.995049288598048\nG22-R2,main,G22,2,0.10000000000000001,0.46999999999999997,20,29.7667,5.6950000000000003,14.282627987279762,9.7166314638212139\nG22-R3,main,G22,3,0.10000000000000001,0.46999999999999997,20,30.048999999999999,5.7350000000000003,14.491515709526279,9.9255191860677314\nG13-R1,main,G13,1,0.10000000000000001,0.46999999999999997,70,30.048999999999999,5.8440000000000003,12.866332660239166,8.3003361367806185\nG13-R2,main,G13,2,0.10000000000000001,0.46999999999999997,70,30.168900000000001,5.8570000000000002,13.019568408117976,8.4535718846594285\nG13-R3,main,G13,3,0.10000000000000001,0.46999999999999997,70,30.198,5.8460000000000001,13.266586289153482,8.700589765694934\nG9-R1,main,G9,1,0.10000000000000001,0.46999999999999997,120,30.048999999999999,5.8159999999999998,13.283810874734936,8.7178143512763882\nG9-R2,main,G9,2,0.10000000000000001,0.46999999999999997,120,30.18,5.8339999999999996,13.392999232799152,8.8270027093406043\nG9-R3,main,G9,3,0.10000000000000001,0.46999999999999997,120,30.199999999999999,5.8159999999999998,13.71739182036128,9.1513952969027326\nG18-R1,main,G18,1,0.20000000000000001,0.42999999999999999,20,30.7057,6.4169999999999998,6.3691757556414652,-3.6123050165702422\nG18-R2,main,G18,2,0.20000000000000001,0.42999999999999999,20,30.523199999999999,6.351,6.7781193476803896,-3.2033614245313178\nG18-R3,main,G18,3,0.20000000000000001,0.42999999999999999,20,30.184000000000001,6.3250000000000002,6.1164404317794681,-3.8650403404322393\nG6-R1,main,G6,1,0.20000000000000001,0.42999999999999999,70,30.312799999999999,6.298,6.9144193933381111,-3.0670613788735963\nG6-R2,main,G6,2,0.20000000000000001,0.42999999999999999,70,30.406700000000001,6.327,6.7745786502698806,-3.2069021219418268\nG6-R3,main,G6,3,0.20000000000000001,0.42999999999999999,70,30.506699999999999,6.3230000000000004,7.138913594079388,-2.8425671781323194\nG12-R1,main,G12,1,0.20000000000000001,0.42999999999999999,120,30.494,6.0979999999999999,10.406019116987109,0.4245383447754012\nG12-R2,main,G12,2,0.20000000000000001,0.42999999999999999,120,30.612300000000001,6.226,8.8788975902662983,-1.1025831819454091\nG12-R3,main,G12,3,0.20000000000000001,0.42999999999999999,120,30.52,6.2069999999999999,8.8822418579743267,-1.0992389142373806\nG2-R1,main,G2,1,0.20000000000000001,0.45000000000000001,20,29.449200000000001,6.0439999999999996,8.0489349571635884,-1.4889244473942664\nG2-R2,main,G2,2,0.20000000000000001,0.45000000000000001,20,29.7332,6.0910000000000002,8.2190059485777169,-1.3188534559801379\nG2-R3,main,G2,3,0.20000000000000001,0.45000000000000001,20,29.7332,6.0880000000000001,8.2642108381121524,-1.2736485664457025\nG1-R1,main,G1,1,0.20000000000000001,0.45000000000000001,70,30.088799999999999,5.968,11.135202286298265,1.5973428817404081\nG1-R2,main,G1,2,0.20000000000000001,0.45000000000000001,70,29.9376,5.9560000000000004,10.86597518298036,1.3281157784225035\nG1-R3,main,G1,3,0.20000000000000001,0.45000000000000001,70,30.068899999999999,5.9690000000000003,11.061490306533861,1.5236309019760057\nG3-R1,main,G3,1,0.20000000000000001,0.45000000000000001,120,30.060600000000001,5.8949999999999996,12.139843108319038,2.6019837037611837\nG3-R2,main,G3,2,0.20000000000000001,0.45000000000000001,120,30,5.899,11.902628434886507,2.3647690303286542\nG3-R3,main,G3,3,0.20000000000000001,0.45000000000000001,120,29.798999999999999,5.8789999999999996,11.609095154981633,2.0712357504237762\nG16-R1,main,G16,1,0.20000000000000001,0.46999999999999997,20,30.193999999999999,5.9379999999999997,11.889969357058527,2.7579763101414319\nG16-R2,main,G16,2,0.20000000000000001,0.46999999999999997,20,30.075199999999999,5.9320000000000004,11.63130774891059,2.4993147019934945\nG16-R3,main,G16,3,0.20000000000000001,0.46999999999999997,20,29.835000000000001,5.923,11.055008040038617,1.9230149931215208\nG7-R1,main,G7,1,0.20000000000000001,0.46999999999999997,70,30.0425,5.7999999999999998,13.503659540859523,4.3716664939424295\nG7-R2,main,G7,2,0.20000000000000001,0.46999999999999997,70,30.09,5.8049999999999997,13.565754349853664,4.4337613029365688\nG7-R3,main,G7,3,0.20000000000000001,0.46999999999999997,70,30.0425,5.7069999999999999,14.8905836206354,5.7585905737183047\nG17-R1,main,G17,1,0.20000000000000001,0.46999999999999997,120,30.0168,5.718,14.653528790902191,5.5215357439850976\nG17-R2,main,G17,2,0.20000000000000001,0.46999999999999997,120,30.0564,5.7050000000000001,14.959756184060948,5.827763137143851\nG17-R3,main,G17,3,0.20000000000000001,0.46999999999999997,120,30.208200000000001,5.7050000000000001,15.387094092683762,6.2551010457666667\nG25-R1,main,G25,1,0.25,0.42999999999999999,20,30.620000000000001,6.3869999999999996,6.5460764276634169,-5.9307745376012182\nG25-R2,main,G25,2,0.25,0.42999999999999999,20,30.630600000000001,6.3920000000000003,6.5052828493688768,-5.9715681158957583\nG25-R3,main,G25,3,0.25,0.42999999999999999,20,30.640000000000001,6.3860000000000001,6.6217000290107357,-5.8551509362538994\nG14-R1,main,G14,1,0.25,0.42999999999999999,70,30.339500000000001,6.2750000000000004,7.3359835094377939,-5.1408674558268412\nG14-R2,main,G14,2,0.25,0.42999999999999999,70,30.333600000000001,6.282,7.2145696840382296,-5.2622812812264055\nG14-R3,main,G14,3,0.25,0.42999999999999999,70,30.393999999999998,6.2880000000000003,7.3105119077690013,-5.1663390574956338\nG27-R1,main,G27,1,0.25,0.42999999999999999,120,30.294,6.1790000000000003,8.6165849466151574,-3.8602660186494777\nG27-R2,main,G27,2,0.25,0.42999999999999999,120,30.113800000000001,6.165,8.2780394970562217,-4.1988114682084126\nG27-R3,main,G27,3,0.25,0.42999999999999999,120,30.193999999999999,6.1509999999999998,8.7294040948580296,-3.7474468704066055\nG26-R1,main,G26,1,0.25,0.45000000000000001,20,30.096,6.1059999999999999,9.1021038530942366,-2.8202204026030824\nG26-R2,main,G26,2,0.25,0.45000000000000001,20,29.792000000000002,6.0759999999999996,8.6257309941520468,-3.2965932615452704\nG26-R3,main,G26,3,0.25,0.45000000000000001,20,29.945499999999999,6.077,9.0791520964399464,-2.8431721592573709\nG5-R1,main,G5,1,0.25,0.45000000000000001,70,29.9894,6.0590000000000002,9.4811588505596909,-2.4411654051376264\nG5-R2,main,G5,2,0.25,0.45000000000000001,70,29.739599999999999,5.9630000000000001,10.167084221749668,-1.7552400339476506\nG5-R3,main,G5,3,0.25,0.45000000000000001,70,29.798999999999999,5.952,10.511538418515164,-1.4107858371821518\nG15-R1,main,G15,1,0.25,0.45000000000000001,120,29.909700000000001,5.7869999999999999,13.31434499564118,1.3920207399438631\nG15-R2,main,G15,2,0.25,0.45000000000000001,120,29.798999999999999,5.8029999999999999,12.751756962809724,0.82943270711240658\nG15-R3,main,G15,3,0.25,0.45000000000000001,120,29.798999999999999,5.8140000000000001,12.5863717011504,0.66404744545308425\nG10-R1,main,G10,1,0.25,0.46999999999999997,20,29.837199999999999,5.9429999999999996,10.761250767426224,-0.65374054122014691\nG10-R2,main,G10,2,0.25,0.46999999999999997,20,29.617799999999999,5.9000000000000004,10.750657522596541,-0.66433378604982884\nG10-R3,main,G10,3,0.25,0.46999999999999997,20,29.776,5.9109999999999996,11.059326603995622,-0.35566470465074751\nG19-R1,main,G19,1,0.25,0.46999999999999997,70,29.5656,5.782,12.381220333269226,0.96622902462285676\nG19-R2,main,G19,2,0.25,0.46999999999999997,70,29.604399999999998,5.7720000000000002,12.647393449070254,1.2324021404238843\nG19-R3,main,G19,3,0.25,0.46999999999999997,70,29.518000000000001,5.7750000000000004,12.346175506543478,0.93118419789710838\nG11-R1,main,G11,1,0.25,0.46999999999999997,120,29.997,5.657,15.508277231546341,4.0932859228999714\nG11-R2,main,G11,2,0.25,0.46999999999999997,120,29.884899999999998,5.6520000000000001,15.26630289824864,3.85131158960227\nG11-R3,main,G11,3,0.25,0.46999999999999997,120,29.997,5.6710000000000003,15.29917627366083,3.8841849650144606\nV1-R1,validation,V1,1,0.14999999999999999,0.45000000000000001,70,30.842400000000001,6.274,8.8614407555320902,1.7080462021136995\nV1-R2,validation,V1,2,0.14999999999999999,0.45000000000000001,70,30.803999999999998,6.2770000000000001,8.7041947259095309,1.5508001724911402\nV1-R3,validation,V1,3,0.14999999999999999,0.45000000000000001,70,30.803999999999998,6.2460000000000004,9.1550741210818742,2.0016795676634835\nV1-R4,validation,V1,4,0.14999999999999999,0.45000000000000001,70,30.892099999999999,6.258,9.2401150824898526,2.0867205290714619\nV1-R5,validation,V1,5,0.14999999999999999,0.45000000000000001,70,30.814,6.2709999999999999,8.8210614129917602,1.6676668595733697\nV2-R1,validation,V2,1,0.20000000000000001,0.46000000000000002,70,30.223199999999999,5.9699999999999998,11.50072848686774,2.170213851974188\nV2-R2,validation,V2,2,0.20000000000000001,0.46000000000000002,70,30.338000000000001,5.9809999999999999,11.67316572589211,2.3426510909985581\nV2-R3,validation,V2,3,0.20000000000000001,0.46000000000000002,70,30.2592,5.9740000000000002,11.546792463414778,2.2162778285212266\nV2-R4,validation,V2,4,0.20000000000000001,0.46000000000000002,70,30.23,5.9820000000000002,11.342787731335749,2.0122730964421951\nV2-R5,validation,V2,5,0.20000000000000001,0.46000000000000002,70,30.338000000000001,5.9779999999999998,11.717469438117876,2.3869548032243251\nV3-R1,validation,V3,1,0.25,0.46999999999999997,90,29.884899999999998,5.6929999999999996,14.651638782683918,3.2366474740375484\nV3-R2,validation,V3,2,0.25,0.46999999999999997,90,29.868400000000001,5.6440000000000001,15.339494746104654,3.9245034374582839\nV3-R3,validation,V3,3,0.25,0.46999999999999997,90,29.943999999999999,5.7030000000000003,14.670467309587201,3.255476000940829\nV3-R4,validation,V3,4,0.25,0.46999999999999997,90,29.93,5.7060000000000004,14.585646077406423,3.1706547687600537\nV3-R5,validation,V3,5,0.25,0.46999999999999997,90,29.924600000000002,5.7270000000000003,14.255822465337433,2.8408311566910616\nV4-R1,validation,V4,1,0.10000000000000001,0.42999999999999999,90,30.300000000000001,6.3220000000000001,6.5202219146645923,1.5294815285587386\nV4-R2,validation,V4,2,0.10000000000000001,0.42999999999999999,90,30.453600000000002,6.3280000000000003,6.90343841028076,1.9126980241749063\nV4-R3,validation,V4,3,0.10000000000000001,0.42999999999999999,90,30.454999999999998,6.3630000000000004,6.3928270690230331,1.4020866829171794\nV4-R4,validation,V4,4,0.10000000000000001,0.42999999999999999,90,30.280000000000001,6.3319999999999999,6.3105164225887078,1.3197760364828539\nV4-R5,validation,V4,5,0.10000000000000001,0.42999999999999999,90,30.280000000000001,6.327,6.3844973792986037,1.39375699319275\n'


@dataclass(frozen=True)
class Group:
    group_id: str
    role: str
    h: float
    P: float
    v: float
    n: int
    mean: float
    low: float
    high: float
    sd: float


def parameter_key(h: float, P: float, v: float) -> tuple[float, float, float]:
    return round(h, 8), round(P, 8), round(v, 8)


def configure_style() -> str:
    """Register bundled fonts first, with the user's Windows paths as fallback."""
    paths = list((BASE_DIR / "fonts").glob("Roboto-*.ttf"))
    paths += [
        Path.home() / "AppData/Local/Microsoft/Windows/Fonts/Roboto-Regular.ttf",
        Path.home() / "AppData/Local/Microsoft/Windows/Fonts/Roboto-Medium.ttf",
    ]
    for file in paths:
        if file.is_file():
            font_manager.fontManager.addfont(str(file))
    font_manager.findfont(FONT_FAMILY, fallback_to_default=False)
    mpl.rcParams.update({
        "font.family": FONT_FAMILY,
        "font.sans-serif": [FONT_FAMILY],
        "font.size": 14 * STYLE_SCALE,
        "axes.labelsize": 19 * STYLE_SCALE,
        "xtick.labelsize": 15 * STYLE_SCALE,
        "ytick.labelsize": 15 * STYLE_SCALE,
        "axes.linewidth": 1.2 * STYLE_SCALE,
        "axes.edgecolor": "black",
        "axes.labelcolor": "black",
        "text.color": "black",
        "xtick.color": "black",
        "ytick.color": "black",
        "axes.unicode_minus": True,
        "mathtext.fontset": "custom",
        "mathtext.rm": FONT_FAMILY,
        "mathtext.it": f"{FONT_FAMILY}:italic",
        "mathtext.bf": f"{FONT_FAMILY}:bold",
        "mathtext.bfit": f"{FONT_FAMILY}:bold:italic",
        "mathtext.cal": FONT_FAMILY,
        "mathtext.sf": FONT_FAMILY,
        "mathtext.tt": FONT_FAMILY,
        "mathtext.fallback": "stix",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "svg.hashsalt": "lianyu-figure3-porosity-final",
        "savefig.facecolor": "white",
        "figure.facecolor": "white",
    })
    return font_manager.findfont(FONT_FAMILY, fallback_to_default=False)


def read_groups(path: Path) -> tuple[list[Group], dict]:
    if path.is_file():
        with path.open(encoding="utf-8-sig", newline="") as file:
            rows = list(csv.DictReader(file))
    else:
        rows = list(csv.DictReader(io.StringIO(EMBEDDED_SPECIMENS.lstrip("\ufeff"))))
    required = {"record_id", "role", "group_id", "replicate", "h_mm", "P_mm", "v_mm_s", "phi_vol_pct"}
    if not rows or not required <= rows[0].keys():
        raise ValueError(f"Missing columns: {sorted(required - rows[0].keys()) if rows else sorted(required)}")
    ids = [row["record_id"] for row in rows]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate specimen identifiers")
    buckets = defaultdict(list)
    for row in rows:
        value = float(row["phi_vol_pct"])
        if not np.isfinite(value) or not 0 <= value <= 100:
            raise ValueError(f"Invalid volumetric porosity (%) at {row['record_id']}")
        buckets[(row["role"], row["group_id"])].append(row)

    groups = []
    main_values = []
    for (role, group_id), members in buckets.items():
        keys = {parameter_key(float(r["h_mm"]), float(r["P_mm"]), float(r["v_mm_s"])) for r in members}
        if len(keys) != 1:
            raise ValueError(f"Parameters vary within {group_id}")
        if role not in ("main", "validation"):
            raise ValueError(f"Unexpected role {role}")
        expected_n = 3 if role == "main" else 5
        if len(members) != expected_n or len({r["replicate"] for r in members}) != expected_n:
            raise ValueError(f"Incomplete or duplicated replicates in {group_id}")
        values = np.array([float(r["phi_vol_pct"]) for r in members], dtype=float)
        h, P, v = next(iter(keys))
        groups.append(Group(group_id, role, h, P, v, len(values),
                            float(values.mean()), float(values.min()),
                            float(values.max()), float(values.std(ddof=1))))
        if role == "main":
            main_values.extend(values)
    main = [g for g in groups if g.role == "main"]
    observed_keys = [parameter_key(g.h, g.P, g.v) for g in main]
    expected_keys = set(product(H_LEVELS, P_LEVELS, V_LEVELS))
    if len(main) != 27 or len(set(observed_keys)) != 27 or set(observed_keys) != expected_keys:
        raise ValueError("Main data do not form the frozen 3 × 3 × 3 factorial design")
    if len(main_values) != 81:
        raise ValueError("Main data no longer contain the frozen 81 specimens")
    audit = {"input_specimens": len(rows), "main_specimens": len(main_values),
             "main_conditions": len(main), "additional_conditions": len(groups)-len(main),
             "response": "measured volumetric porosity", "response_unit": "%",
             "phi_vol_pct_main_min": min(main_values), "phi_vol_pct_main_max": max(main_values),
             "main_n": 3, "additional_n": 5, "normalization_applied": False,
             "error_bars": "full replicate minimum-to-maximum", "new_model_fitting": False}
    return groups, audit


def pattern(d1: float, d2: float) -> str:
    if d1 > 0 and d2 > 0: return "increasing"
    if d1 < 0 and d2 < 0: return "decreasing"
    if d1 > 0 and d2 < 0: return "increase_then_decrease"
    if d1 < 0 and d2 > 0: return "decrease_then_increase"
    return "includes_equal_means"


def overlap(a: Group, b: Group) -> bool:
    return max(a.low, b.low) <= min(a.high, b.high)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, default=DATA_PATH)
    parser.add_argument("--outdir", type=Path, default=OUTPUT_DIR)
    parser.add_argument("--dpi", type=int, default=PNG_DPI)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    font_file = configure_style()
    if args.data.is_file():
        data_sha = hashlib.sha256(args.data.read_bytes()).hexdigest()
        if data_sha != EXPECTED_DATA_SHA256:
            raise ValueError("External specimen file differs from the original frozen Figure 3 source")
        source_mode = "original frozen external CSV"
    else:
        data_sha = hashlib.sha256(EMBEDDED_SPECIMENS.encode("utf-8")).hexdigest()
        if data_sha != EMBEDDED_DATA_SHA256:
            raise ValueError("Embedded 101-specimen source failed SHA256 integrity check")
        source_mode = "embedded verified 101-specimen dataset"
        print("Original CSV absent; using embedded identical specimen measurements")
    groups, audit = read_groups(args.data)
    additional_groups = {g.group_id: g for g in groups if g.role == "validation"}
    assert set(additional_groups) == set(ADDITIONAL_MAP)
    assert len(groups) == 31 and audit["input_specimens"] == 101
    for gid, (_, _, _, _, params, _, _) in ADDITIONAL_MAP.items():
        group = additional_groups[gid]
        assert parameter_key(group.h, group.P, group.v) == parameter_key(*params)
        assert group.n == 5
    main_groups = [g for g in groups if g.role == "main"]
    lookup = {parameter_key(g.h, g.P, g.v): g for g in main_groups}
    colors = [mpl.colors.to_hex(rgb) for rgb in SERIES_RGB]
    spacing_colors = dict(zip(P_LEVELS, colors))

    fig, axes = plt.subplots(3, 3, figsize=FIGSIZE, sharey=True)
    fig.subplots_adjust(left=0.102, right=0.992, bottom=0.150,
                        top=0.956, wspace=0.180, hspace=0.270)
    main_handles = [Line2D([0], [0], color=c, marker=m, lw=LINE_WIDTH,
                          markersize=MARKER_SIZE, markeredgewidth=0.75 * STYLE_SCALE, alpha=SERIES_ALPHA)
                    for c, m in zip(colors, MARKERS)]
    titles = ("Printing-speed effect", "Layer-height effect", "Line-pitch effect")
    path_rows, path_summary, artists = [], [], []
    legends = []

    for col in range(3):
        position = axes[0, col].get_position()
        center = (position.x0 + position.x1)/2
        if SHOW_COLUMN_TITLES:
            fig.text(center, 0.969, titles[col], ha="center", va="center",
                     fontsize=19, fontweight="medium")
        legend_title = (r"$P$ (mm)", r"$v$ (mm s$^{-1}$)", r"$h$ (mm)")[col]
        labels = (["0.43", "0.45", "0.47"], ["20", "70", "120"],
                  ["0.10", "0.20", "0.25"])[col]
        legend = fig.legend(main_handles, labels, title=legend_title, ncol=3,
                   loc="lower center", bbox_to_anchor=(center, 0.018),
                   frameon=False, fontsize=LEGEND_FONT,
                   title_fontsize=LEGEND_TITLE_FONT,
                   handlelength=1.35, handletextpad=0.35, columnspacing=0.80,
                   borderaxespad=0.0, borderpad=0.10, labelspacing=0.30)
        legends.append(legend)

    for row in range(3):
        for col in range(3):
            ax = axes[row, col]
            letter = "abcdefghi"[col*3+row]
            if col == 0:
                direction, fixed, x = "v", H_LEVELS[row], np.array(V_LEVELS)
                conditions = P_LEVELS
                get_group = lambda level, value: lookup[parameter_key(fixed, level, value)]
                condition_text = rf"$h = {fixed:.2f}$ mm"
                ax.set_xlim(11, 129)
                ax.xaxis.set_major_formatter(FormatStrFormatter("%.0f"))
            elif col == 1:
                direction, fixed, x = "h", P_LEVELS[row], np.array(H_LEVELS)
                conditions = V_LEVELS
                get_group = lambda level, value: lookup[parameter_key(value, fixed, level)]
                condition_text = rf"$P = {fixed:.2f}$ mm"
                ax.set_xlim(0.085, 0.265)
                ax.xaxis.set_major_formatter(FormatStrFormatter("%.2f"))
            else:
                direction, fixed, x = "P", V_LEVELS[row], np.array(P_LEVELS)
                conditions = H_LEVELS
                get_group = lambda level, value: lookup[parameter_key(level, value, fixed)]
                condition_text = rf"$v = {fixed:.0f}$ mm s$^{{-1}}$"
                ax.set_xlim(0.425, 0.475)
                ax.xaxis.set_major_formatter(FormatStrFormatter("%.2f"))
            condition_name = COLUMN_LAYOUT[col]["curve_parameter"]
            ax.xaxis.set_major_locator(FixedLocator(x))
            ax.set_ylim(*Y_LIMITS)
            ax.yaxis.set_major_locator(FixedLocator(Y_TICKS))
            ax.grid(False)
            ax.set_axisbelow(True)
            for spine in ax.spines.values():
                spine.set_visible(True)
                spine.set_linewidth(1.2 * STYLE_SCALE)
            ax.tick_params(axis="both", direction="in", length=4.0 * STYLE_SCALE, width=1.2 * STYLE_SCALE, pad=6 * STYLE_SCALE)
            ax.tick_params(axis="y", labelleft=True)
            ax.text(0, 1.075, f"({letter})", transform=ax.transAxes,
                    ha="left", va="center", fontsize=18 * STYLE_SCALE, fontweight="bold")
            ax.text(1, 1.075, condition_text, transform=ax.transAxes,
                    ha="right", va="center", fontsize=15 * STYLE_SCALE)
            if row == 2:
                xlabel = (r"Printing speed, $v$ (mm s$^{-1}$)", r"Layer height, $h$ (mm)",
                          r"Line pitch, $P$ (mm)")[col]
                ax.set_xlabel(xlabel, labelpad=10 * STYLE_SCALE, fontsize=19 * STYLE_SCALE)

            for j, level in enumerate(conditions):
                sequence = [get_group(level, float(value)) for value in x]
                means = np.array([g.mean for g in sequence])
                lows = np.array([g.low for g in sequence])
                highs = np.array([g.high for g in sequence])
                if SHOW_RANGES:
                    ax.errorbar(x, means, yerr=[means-lows, highs-means],
                                fmt="none", ecolor=colors[j], elinewidth=RANGE_WIDTH,
                                capsize=CAP_SIZE, capthick=RANGE_WIDTH, alpha=SERIES_ALPHA, zorder=2)
                line, = ax.plot(x, means, color=colors[j], lw=LINE_WIDTH,
                               marker=MARKERS[j], ms=MARKER_SIZE,
                               markeredgewidth=0.75 * STYLE_SCALE, markeredgecolor=colors[j],
                               markerfacecolor=colors[j], alpha=SERIES_ALPHA, zorder=3)
                artists.append(line)
                path_id = f"{direction}-{row+1}-{j+1}"
                d1, d2 = np.diff(means)
                path_summary.append({"panel": letter, "path_id": path_id,
                    "direction": direction, "fixed_parameter": COLUMN_LAYOUT[col]["fixed_parameter"],
                    "fixed_value": fixed, "curve_parameter": condition_name,
                    "curve_value": level, "delta_1_phi_vol_pp": float(d1),
                    "delta_2_phi_vol_pp": float(d2), "mean_pattern": pattern(d1,d2),
                    "range_overlap_1": overlap(sequence[0],sequence[1]),
                    "range_overlap_2": overlap(sequence[1],sequence[2])})
                for value, group in zip(x, sequence):
                    path_rows.append({"panel": letter, "path_id": path_id,
                        "direction": direction, "x": float(value),
                        "group_id": group.group_id, "h_mm": group.h, "P_mm": group.P,
                        "v_mm_s": group.v, "n": group.n, "phi_vol_pct_mean": group.mean,
                        "phi_vol_pct_min": group.low, "phi_vol_pct_max": group.high})

    shown_additional, additional_rows, additional_artists = [], [], []
    for gid, (row, col, color_index, xvalue, params, offset, alignment) in ADDITIONAL_MAP.items():
        group = additional_groups[gid]
        ax = axes[row, col]
        color = colors[color_index]
        error = ax.errorbar([xvalue], [group.mean],
                    yerr=[[group.mean-group.low], [group.high-group.mean]],
                    fmt="none", ecolor=color, elinewidth=RANGE_WIDTH,
                    capsize=CAP_SIZE, capthick=RANGE_WIDTH,
                    alpha=SERIES_ALPHA, zorder=4)
        diamond, = ax.plot(xvalue, group.mean, marker="D", ms=7.0 * STYLE_SCALE,
                    linestyle="none", mfc="white", mec=color,
                    mew=1.2 * STYLE_SCALE, alpha=SERIES_ALPHA, zorder=5)
        annotation = ax.annotate(gid, (xvalue, group.mean),
                    xytext=tuple(v * STYLE_SCALE for v in offset),
                    textcoords="offset points", fontsize=ADDITIONAL_LABEL_FONT,
                    color=color, ha=alignment, va="center")
        panel = "abcdefghi"[col*3+row]
        shown_additional.append(gid)
        additional_artists.append((gid, panel, error, diamond, annotation))
        additional_rows.append({"panel": panel, "group_id": gid,
            "role": "validation", "x": xvalue,
            "h_mm": group.h, "P_mm": group.P, "v_mm_s": group.v,
            "n": group.n, "phi_vol_pct_mean": group.mean,
            "phi_vol_pct_min": group.low, "phi_vol_pct_max": group.high,
            "color": color, "marker": "open diamond", "connected_to_main": False,
            "record_ids": ";".join(f"{gid}-R{i}" for i in range(1, 6))})

    ylabel = fig.supylabel(r"Volumetric porosity, $\varphi_{\mathrm{vol}}$ (%)",
                  x=0.049, y=(0.150 + 0.956)/2, fontsize=19 * STYLE_SCALE,
                  ha="center", va="center")

    # Data-level checks protect what is drawn, rather than testing drawing internals.
    assert len(path_summary) == 27 and len(path_rows) == 81
    assert len({r["group_id"] for r in path_rows}) == 27
    assert all(n==3 for n in Counter(r["group_id"] for r in path_rows).values())
    assert len({col["fixed_parameter"] for col in COLUMN_LAYOUT}) == 3
    assert len({col["x_parameter"] for col in COLUMN_LAYOUT}) == 3
    for col in COLUMN_LAYOUT:
        assert len(set(col.values())) == 3
    for path, first in zip(path_summary, range(0,81,3)):
        points = path_rows[first:first+3]
        assert all(p[path["fixed_parameter"]] == path["fixed_value"] for p in points)
        assert all(p[path["curve_parameter"]] == path["curve_value"] for p in points)
    for line, first in zip(artists, range(0,81,3)):
        assert np.allclose(line.get_ydata(),[r["phi_vol_pct_mean"] for r in path_rows[first:first+3]])
    assert Counter(shown_additional) == Counter({gid: 1 for gid in ADDITIONAL_MAP})
    assert {r["group_id"]: r["panel"] for r in additional_rows} == {
        "V1": "e", "V2": "h", "V3": "c", "V4": "a"}
    for gid, panel, error, diamond, annotation in additional_artists:
        group = additional_groups[gid]
        xvalue = ADDITIONAL_MAP[gid][3]
        actual = error.lines[2][0].get_segments()[0]
        assert np.allclose(actual, [[xvalue, group.low], [xvalue, group.high]], rtol=0, atol=1e-13)
        assert diamond.get_linestyle().lower() == "none"
        assert len(diamond.get_xdata()) == 1
    # Independently compare every main displayed mean and range with the supplied frozen map.
    def frozen_rows(name):
        with (BASE_DIR / "reference" / name).open(encoding="utf-8-sig", newline="") as file:
            return list(csv.DictReader(file))
    original_reference_files = (
        "original_main_plotted_points.csv",
        "original_27_path_summary.csv",
        "original_group_summary.csv",
    )
    reference_dir = BASE_DIR / "reference"
    if all((reference_dir / name).is_file() for name in original_reference_files):
        original_points = frozen_rows("original_main_plotted_points.csv")
        assert len(original_points) == len(path_rows) == 81
        numeric_point_keys = ("x", "h_mm", "P_mm", "v_mm_s", "n",
            "phi_vol_pct_mean", "phi_vol_pct_min", "phi_vol_pct_max")
        for old, current in zip(original_points, path_rows):
            for key in ("panel", "path_id", "direction", "group_id"):
                assert old[key] == current[key], (key, old, current)
            for key in numeric_point_keys:
                assert abs(float(old[key]) - float(current[key])) < 1e-12, (key, old, current)
        original_paths = frozen_rows("original_27_path_summary.csv")
        assert len(original_paths) == len(path_summary) == 27
        for old, current in zip(original_paths, path_summary):
            for key in ("panel", "path_id", "direction", "fixed_parameter", "curve_parameter", "mean_pattern"):
                assert old[key] == current[key]
            for key in ("fixed_value", "curve_value", "delta_1_phi_vol_pp", "delta_2_phi_vol_pp"):
                assert abs(float(old[key]) - float(current[key])) < 1e-12
        original_groups = {r["group_id"]: r for r in frozen_rows("original_group_summary.csv")}
        for group in groups:
            old = original_groups[group.group_id]
            assert int(old["n"]) == group.n
            for key, val in (("phi_vol_pct_mean",group.mean), ("phi_vol_pct_min",group.low),
                             ("phi_vol_pct_max",group.high), ("phi_vol_pct_SD",group.sd)):
                assert abs(float(old[key])-val) < 1e-12, (group.group_id,key)
        reference_mode = "archival plotting tables also matched"
    else:
        # The embedded specimen CSV is independently protected by SHA256,
        # while the checks below protect all 27 conditions and all four validations.
        reference_mode = "archival plotting tables unavailable; embedded source verified"
    assert additional_groups["V4"].mean < lookup[parameter_key(0.10,0.43,70)].mean
    assert additional_groups["V4"].mean < lookup[parameter_key(0.10,0.43,120)].mean
    assert all(tuple(ax.get_ylim()) == Y_LIMITS for ax in axes.flat)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    outside=[]
    for text in fig.findobj(match=mpl.text.Text):
        if text.get_visible() and text.get_text():
            box=text.get_window_extent(renderer)
            if box.x0 < -0.8 or box.y0 < -0.8 or box.x1 > fig.bbox.width+.8 or box.y1 > fig.bbox.height+.8:
                outside.append(text.get_text())
    if outside: raise RuntimeError(f"Labels outside the canvas: {outside}")
    # Check the requested bottom order and independent centering of the three legends.
    layout_audit = []
    for col, legend in enumerate(legends):
        lb = legend.get_window_extent(renderer)
        xb = axes[2,col].xaxis.label.get_window_extent(renderer)
        pos = axes[2,col].get_position()
        assert lb.y1 + 1.0 < xb.y0, ("Legend intersects x-axis title",col, lb.bounds, xb.bounds)
        center_px = ((pos.x0 + pos.x1)/2) * fig.bbox.width
        assert abs((lb.x0+lb.x1)/2-center_px) < 1.0
        layout_audit.append({"column":col+1,
            "legend_below_xlabel":True, "legend_centered":True,
            "legend_fontsize_pt":LEGEND_FONT})
    for extension in ("pdf","svg","png"):
        fig.savefig(args.outdir/f"{FILE_STEM}.{extension}", dpi=args.dpi,
                    bbox_inches=None, pad_inches=0)
    fig.savefig(args.outdir/f"{FILE_STEM}_preview.png", dpi=PREVIEW_DPI,
                bbox_inches=None, pad_inches=0)
    plt.close(fig)

    def save_csv(name: str, rows: list[dict]) -> None:
        with (args.outdir/name).open("w",encoding="utf-8-sig",newline="") as file:
            writer=csv.DictWriter(file,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    save_csv("Figure3_main_plotted_points.csv",path_rows)
    save_csv("Figure3_additional_points.csv",additional_rows)
    combined = [dict(r, role="main", color="", marker="filled", connected_to_main=True,
                     record_ids=";".join(f"{r['group_id']}-R{i}" for i in range(1,4)))
                for r in path_rows] + additional_rows
    combined_keys = list(dict.fromkeys(k for row in combined for k in row))
    save_csv("Figure3_plotted_points.csv", [{k: row.get(k, "") for k in combined_keys} for row in combined])
    save_csv("Figure3_27_path_summary.csv",path_summary)
    save_csv("Figure3_group_summary.csv",[
        {"group_id":g.group_id,"role":g.role,"h_mm":g.h,"P_mm":g.P,"v_mm_s":g.v,
         "n":g.n,"phi_vol_pct_mean":g.mean,"phi_vol_pct_min":g.low,
         "phi_vol_pct_max":g.high,"phi_vol_pct_SD":g.sd}
        for g in groups])
    audit.update({"font_family":FONT_FAMILY,"font_file":str(Path(font_file).name),
                  "palette":colors,"series_alpha":SERIES_ALPHA,
                  "style_reference":"Bundled original plot_figure2.py and style_reference/2-1.py","panels":9,"paths":27,
                  "main_mean_markers_in_all_panels":81,"distinct_main_conditions":27,
                  "additional_groups_shown":shown_additional,
                  "figure_inches":list(FIGSIZE),"png_dpi":args.dpi,
                  "preview_dpi":PREVIEW_DPI,"axes_label_fontsize_pt":19 * STYLE_SCALE,
                  "tick_label_fontsize_pt":15 * STYLE_SCALE,"legend_fontsize_pt":LEGEND_FONT,
                  "spine_width_pt":1.2 * STYLE_SCALE,"spines":"all four visible","tick_direction":"in",
                  "mean_line_width_pt":LINE_WIDTH,"marker_size_pt":MARKER_SIZE,
                  "fixed_canvas_no_post_crop":True,
                  "main_mean_patterns":dict(Counter(r["mean_pattern"] for r in path_summary)),
                  "column_titles_shown":SHOW_COLUMN_TITLES,
                  "column_layout":list(COLUMN_LAYOUT),
                  "grid":"none",
                  "P_term":"Line pitch",
                  "P_definition":"The prescribed center-to-center distance between adjacent deposited roads."})
    audit.update({"data_sha256":data_sha, "source_mode":source_mode,
        "reference_checks":reference_mode,
        "source_data_unchanged":True, "source_main_plot_map_unchanged":True,
        "source_all_31_group_statistics_unchanged":True,
        "source_all_27_path_summaries_unchanged":True,
        "additional_panel_map":{r["group_id"]:r["panel"] for r in additional_rows},
        "additional_point_count":4, "additional_minmax_verified_from_five_replicates":True,
        "total_mean_positions":len(combined), "legend_layout":layout_audit,
        "publication_width_mm":PUBLICATION_WIDTH_MM,
        "publication_height_mm":FIGSIZE[1]*25.4,
        "design_canvas_inches":list(DESIGN_FIGSIZE), "style_scale":STYLE_SCALE,
        "layout":{"left":0.102,"right":0.992,"bottom":0.150,"top":0.956,
                  "wspace":0.180,"hspace":0.270,"ylabel_x":0.049,
                  "ylabel_y":(0.150+0.956)/2},
        "extra_footer_notes_removed":True, "new_model_fitting":False,
        "python_version":platform.python_version(),
        "numpy_version":np.__version__,"matplotlib_version":mpl.__version__})
    (args.outdir/"Figure3_build_record.json").write_text(json.dumps(audit,indent=2),encoding="utf-8")
    print(json.dumps(audit,ensure_ascii=False,indent=2))
    print(f"Saved {FILE_STEM}.pdf / .svg / .png to {args.outdir}")


if __name__ == "__main__":
    main()
