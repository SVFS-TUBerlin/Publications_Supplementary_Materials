import unittest

from scripts.publication_replay import normalize


class ReplayNormalizationTests(unittest.TestCase):
    def test_machine_paths_and_both_task_hash_spellings_are_non_scientific(self):
        value = {
            "source_path": r"C:\machine\private\input.csv",
            "canonical_task_sha256": "path-dependent-current-key",
            "canonical_task_hash_sha256": "legacy-key",
            "execution_timestamp": "now",
            "scientific": {"capability": 6},
        }
        self.assertEqual({"source_path": "inputs/input.csv", "scientific": {"capability": 6}}, normalize(value))


if __name__ == "__main__": unittest.main()
