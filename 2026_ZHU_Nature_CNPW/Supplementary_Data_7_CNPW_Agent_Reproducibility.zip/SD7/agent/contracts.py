from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, is_dataclass
from enum import Enum
from typing import Any


class ExecutionMode(str, Enum):
    MODE_A = "MODE_A"
    MODE_B_SIMPLIFIED_RESULT_A_GL7 = "MODE_B_SIMPLIFIED_RESULT_A_GL7"
    MODE_B_PROTECTED_DOMAIN = "MODE_B_PROTECTED_DOMAIN"


def stable_json(value: Any) -> str:
    def default(item: Any) -> Any:
        if isinstance(item, Enum):
            return item.value
        if is_dataclass(item):
            return asdict(item)
        raise TypeError(f"Unsupported stable serialization value: {type(item).__name__}")
    return json.dumps(value, default=default, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


@dataclass(frozen=True)
class ActiveCriterion:
    name: str
    slot: str
    column_index: int
    direction: str


@dataclass(frozen=True)
class InputIdentity:
    source_name: str
    source_path: str
    source_hash_sha256: str
    file_format: str


@dataclass(frozen=True)
class InputSummary:
    identity: InputIdentity
    candidate_count: int
    candidate_id_column: str
    active_criteria: tuple[ActiveCriterion, ...]
    descriptors: tuple[str, ...]


@dataclass(frozen=True)
class FrozenCoreConfiguration:
    core_identity: str = "cnpw-core-v8"
    kg: int = 7
    kl: int = 7
    tie_policy: str = "upward_complete_tie_group"
    stage2_policy: str = "adaptive_equal_width_actual_value_on_frozen_w1"
    terminal_policy: str = "worst_first_LL_profile_then_raw_directional_dominance"


@dataclass(frozen=True)
class PresentationPreferences:
    requested_language: str = "en"


@dataclass(frozen=True)
class ProvenanceRecord:
    input_hash_sha256: str
    validation_evidence: tuple[str, ...]


@dataclass(frozen=True)
class CanonicalTask:
    task_id: str
    canonical_task_version: str
    requested_mode: ExecutionMode
    input_summary: InputSummary
    core_configuration: FrozenCoreConfiguration
    provenance: ProvenanceRecord
    presentation: PresentationPreferences
    protected_criterion: ActiveCriterion | None = None
    residual_criteria: tuple[ActiveCriterion, ...] = ()
    protection_semantics: str | None = None
    protected_indices: tuple[int, ...] = ()

    def to_json(self) -> str:
        return stable_json(self)

    @property
    def task_hash_sha256(self) -> str:
        return hashlib.sha256(self.to_json().encode("utf-8")).hexdigest()
