"""Frozen-representation QCCA diagnosis and recovery-set enumeration."""
from dataclasses import replace
from itertools import combinations

from .qcca_models import AdditionTransition, RecoverySet, RemovalRecovery, SubsetCapability, TargetRecovery, QccaResult


def _subsets(names):
    return tuple(subset for size in range(1, len(names) + 1) for subset in combinations(names, size))


def _capability(levels, indices, cols):
    values = {i: min(levels[i][j] for j in cols) for i in indices}
    cap = max(values.values())
    return cap, tuple(i for i in indices if values[i] == cap)


def recovery_for_target(result: QccaResult, target: int) -> TargetRecovery:
    """Return every minimum valid non-empty-retained recovery set, unranked."""
    names, positions = result.criterion_names, {name: i for i, name in enumerate(result.criterion_names)}
    domain = tuple(range(len(result.level_matrix)))
    for order in range(len(names)):  # excluding R=J is deliberate and explicit
        found = []
        for removed in combinations(names, order):
            retained = tuple(name for name in names if name not in removed)
            cap, supporters = _capability(result.level_matrix, domain, [positions[name] for name in retained])
            if cap >= target:
                found.append(RecoverySet(target, removed, retained, tuple(result.domain_candidate_ids[i] for i in supporters)))
        if found:
            return TargetRecovery(target, result.full_system_ceiling, order, tuple(found), "RECOVERABLE")
    return TargetRecovery(target, result.full_system_ceiling, None, (), "UNRECOVERABLE_WITH_NONEMPTY_RETAINED_BLOCK")


def analyze_qcca(names, levels, expected_full_capability, global_level_count=7, *, domain_indices=None, candidate_ids=None, representation="GLOBAL", mode="MODE_A", frozen_source_identity="UNSPECIFIED_LEGACY_INPUT", automatic_local_targets=False):
    """Analyze a fixed matrix over an explicit domain, without any re-binning.

    `levels` is the complete already-frozen representation. `domain_indices`
    selects its admissible analysis domain; no level is recalculated for a
    response subset or selected domain.
    """
    names = tuple(names)
    # Residual Mode-B Global systems may contain only one or two responses.
    if not 1 <= len(names) <= 5 or not levels:
        raise ValueError("Invalid frozen qualification matrix.")
    if representation not in {"GLOBAL", "LOCAL"} or mode not in {"MODE_A", "MODE_B"}:
        raise ValueError("Representation and mode must be explicit V8 values.")
    candidate_ids = tuple(candidate_ids or tuple(str(i) for i in range(len(levels))))
    if len(candidate_ids) != len(levels):
        raise ValueError("Candidate IDs must align with frozen representation rows.")
    domain_indices = tuple(range(len(levels))) if domain_indices is None else tuple(domain_indices)
    if not domain_indices or any(i < 0 or i >= len(levels) for i in domain_indices) or len(set(domain_indices)) != len(domain_indices):
        raise ValueError("QCCA domain must be a non-empty unique subset of frozen rows.")
    if any(len(levels[i]) != len(names) or any(type(x) is not int or not 1 <= x <= global_level_count for x in levels[i]) for i in domain_indices):
        raise ValueError("Invalid frozen qualification matrix in declared domain.")
    positions = {name: i for i, name in enumerate(names)}
    domain_levels = tuple(tuple(levels[i]) for i in domain_indices)
    records, ceilings = [], {}
    for subset in _subsets(names):
        capability, supporters = _capability(domain_levels, range(len(domain_levels)), [positions[name] for name in subset])
        ceilings[subset] = capability
        records.append(SubsetCapability(subset, len(subset), capability, tuple(candidate_ids[domain_indices[i]] for i in supporters)))
    singles = {subset: ceilings[subset] for subset in ceilings if len(subset) == 1}
    joint = {subset: ceilings[subset] for subset in ceilings if len(subset) >= 2}
    profile = {size: {level: sum(value == level for subset, value in joint.items() if len(subset) == size) for level in range(1, global_level_count + 1) if any(value == level for subset, value in joint.items() if len(subset) == size)} for size in range(2, len(names) + 1)}
    transitions = []
    for base in _subsets(names):
        for added in names:
            if added not in base:
                expanded = tuple(name for name in names if name in base or name == added)
                transitions.append(AdditionTransition(base, added, expanded, ceilings[base], ceilings[expanded], ceilings[base] - ceilings[expanded]))
    full = names
    full_capability = ceilings[full]
    # Never assign capability to an empty retained response system.
    removals = tuple(RemovalRecovery(name, tuple(x for x in names if x != name), full_capability, ceilings[tuple(x for x in names if x != name)], ceilings[tuple(x for x in names if x != name)] - full_capability) for name in names if len(names) > 1)
    first = next((size for size in range(1, len(names) + 1) if any(value < global_level_count for subset, value in ceilings.items() if len(subset) == size)), None)
    state = "NO_DETECTED_QUALIFICATION_BOTTLENECK" if full_capability == global_level_count else "SINGLE_RESPONSE_LIMITATION" if any(item.delta_gl > 0 for item in removals) else "NO_SINGLE_RESPONSE_RECOVERY_DETECTED"
    result = QccaResult(names, global_level_count, singles, joint, profile, tuple(transitions), removals, full_capability, global_level_count - full_capability, first, state, representation, mode, tuple(candidate_ids[i] for i in domain_indices), frozen_source_identity, domain_levels, tuple(records))
    if full_capability != expected_full_capability:
        # Keep the evidence for verification; callers must not silently accept it.
        return result
    if automatic_local_targets and representation == "LOCAL" and full_capability < global_level_count:
        return replace(result, target_recoveries=tuple(recovery_for_target(result, q) for q in range(full_capability + 1, global_level_count + 1)))
    return result
