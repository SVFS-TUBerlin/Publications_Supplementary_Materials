"""Reproduce the Young's modulus random forest benchmark in Table 5A.

Verified with scikit-learn 1.8.0. Requires NumPy, pandas, and scikit-learn.
Place beside raw_measurements_101.csv or supply its path as the first argument.
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import LeaveOneOut, cross_val_predict


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", nargs="?", type=Path,
                        default=Path(__file__).with_name("raw_measurements_101.csv"))
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).with_name("E_random_forest_LOOCV.csv"))
    args = parser.parse_args()

    raw = pd.read_csv(args.input)
    main_data = raw.loc[raw["set"] == "Main"].copy()
    keys = ["h_mm", "P_mm", "v_mm_s"]
    grouped = main_data.groupby(keys, sort=True)
    if len(grouped) != 27 or not grouped.size().eq(3).all():
        raise ValueError("Expected 27 main processing conditions with three specimens each.")

    # Derive properties at specimen level before averaging by condition.
    main_data["phi_vol_pct"] = 100 * (
        1 - 1000 * main_data["mass_g"] / (1.24 * main_data["area_mm2"] * 180)
    )
    main_data["E_measured_MPa"] = main_data["stiffness_N"] / main_data["area_mm2"]
    conditions = main_data.groupby(keys, sort=True).agg(
        condition=("condition", "first"),
        phi_vol_pct=("phi_vol_pct", "mean"),
        E_measured_MPa=("E_measured_MPa", "mean"),
    ).reset_index()
    features = conditions[["phi_vol_pct", "v_mm_s"]].to_numpy()
    measured = conditions["E_measured_MPa"].to_numpy()
    forest = RandomForestRegressor(n_estimators=100, random_state=42)
    predicted = cross_val_predict(forest, features, measured, cv=LeaveOneOut())

    conditions["E_predicted_LOOCV_MPa"] = predicted
    conditions["absolute_error_MPa"] = np.abs(predicted - measured)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    conditions.to_csv(args.output, index=False)

    print(f"scikit-learn {sklearn.__version__} | {len(conditions)} LOOCV folds")
    print(f"R^2: {r2_score(measured, predicted):.3f}")
    print(f"MAE: {mean_absolute_error(measured, predicted):.3f} MPa")
    print(f"RMSE: {np.sqrt(mean_squared_error(measured, predicted)):.3f} MPa")
    print(f"Fold predictions: {args.output}")


if __name__ == "__main__":
    main()
