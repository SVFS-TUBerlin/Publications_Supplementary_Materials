# WIBA Universities × CNPW v1.5.2 — Formal External Execution

## 1. Frozen case

- Source data: `WIBApp-main/www/datasets/universities.xlsx` from the uploaded author repository.
- Candidate universe: **897 universities**.
- Responses: **Teaching, Research, International Diversity, Financial Sustainability**.
- Direction: all four responses **maximize**.
- CNPW: **Mode A / Equal Priority**, baseline `K_g = K_l = 7`.
- Stage-1 tie rule: frozen **tie-upward** rule.
- Terminal rule: worst-first local-level profile, then raw-response dominance if required.

## 2. Native WIBA sanity checks

Using the author dataset and POC1 (`Teaching > Research > Diversity > Financial Sustainability`):

- max-lower-bound reference: **MIT**, lower bound = **0.887063**.
- Neutral-attitude Rank 1: **University of Oxford**, possibility = **0.539390**.
- Neutral-attitude Rank 2: **Caltech**, possibility = **0.536309**.
- MIT Neutral rank: **3**.

These reproduce the key published WIBA behavior used as the native-method audit anchor.

## 3. CNPW baseline result

Stage 1:

`897 -> 7`

- **Q1* = GL7**
- **|W1| = 7**
- No exact-value tie group crossed a nominal Stage-1 boundary in any of the four responses.

The seven jointly GL7-qualified universities are:

| ID | University | Teaching | Research | Diversity | Financial Sustainability |
|---|---|---:|---:|---:|---:|
| MIT | Massachusetts Institute of Technology (MIT) | 95.621 | 87.054 | 90.351 | 81.799 |
| SOUCAL | University of Southern California | 88.046 | 90.908 | 81.357 | 89.556 |
| CARNEG | Carnegie Mellon University | 85.239 | 91.058 | 81.952 | 93.283 |
| LAUS | Ecole Polytechnique Federale de Lausanne | 91.342 | 83.017 | 100.000 | 83.124 |
| S025 | University of California, Santa Barbara | 83.649 | 86.422 | 86.020 | 81.411 |
| S031 | Wageningen University & Research Center | 80.129 | 87.618 | 84.450 | 81.605 |
| S060 | Chalmers University of Technology | 77.171 | 80.427 | 80.195 | 85.721 |

Stage 2:

`7 -> 1`

- **Q2* = LL2**
- **|W2| = 1**
- W2 is already a singleton, so terminal pruning is the identity operation.

Final CNPW terminal:

**Ecole Polytechnique Federale de Lausanne (LAUS)**

Raw response vector:

- Teaching = **91.342**
- Research = **83.017**
- Diversity = **100.000**
- Financial Sustainability = **83.124**

Local-level profile:

**6/2/7/2**

Sorted worst-first profile:

**2/2/6/7**

## 4. WIBA × CNPW comparison

Under POC1:

- **Oxford**: WIBA Neutral Rank 1; CNPW global profile = `7/7/7/5`, Q1 = **5**.
- **Caltech**: WIBA Neutral Rank 2; CNPW global profile = `7/7/7/6`, Q1 = **6**.
- **MIT**: WIBA max-lower-bound reference and Neutral Rank 3; CNPW global profile = `7/7/7/7`, so MIT belongs to W1.
- **EPFL/LAUS**: CNPW terminal; WIBA lower-bound rank = **3**, Neutral rank = **14**.

Therefore the two approaches are not equivalent:

- WIBA asks which alternatives remain strong over an admissible region of ordered weights.
- CNPW asks which alternatives attain the highest simultaneous objective qualification, followed by actual-magnitude local refinement.

The external case shows **overlap at the high-quality candidate level** (e.g. MIT is strong under both), while the final preferred candidate differs because the decision semantics differ.

## 5. Resolution sensitivity

| K | Q1* | W1 | Q2* | W2 | Terminal |
|---:|---:|---:|---:|---:|---|
| 6 | 6 | 11 | 2 | 4 | MIT |
| 7 | 7 | 7 | 2 | 1 | LAUS |
| 8 | 8 | 4 | 1 | 4 | MIT |
| 9 | 9 | 1 | 9 | 1 | LAUS |

The exact single terminal alternates between **MIT** and **EPFL/LAUS** across `K=6–9`. This should be interpreted consistently with the frozen CNPW robustness principle:

> qualified-region structure is more stable than exact single-terminal identity.

The baseline `K=7` remains the prespecified primary analysis; sensitivity does not overwrite it.

## 6. Additional audits

- Pareto-nondominated candidates in the 897-university library: **36**.
- All 15 non-empty response subsets attain highest Stage-1 level **GL7**; the full four-response intersection contains **7** candidates.
- The Stage-1 exact-level counts are 128 candidates in GL1–GL6 and 129 in GL7 for every response under `K=7`.
- No Stage-1 boundary tie adjustment was required in the repository dataset.

## 7. Native-data caveat

The paper text reports that, under the illustrated POC, 844 of 897 alternatives cannot attain a higher score than the reference alternative. Reconstructing score intervals from the uploaded repository snapshot reproduces the key published reference and top rankings but not that single zero-possibility count exactly.

This discrepancy **does not affect the CNPW execution**, because CNPW uses the frozen 897×4 author evaluation matrix directly. It should nevertheless remain documented rather than silently reconciled if the WIBA native-method reproduction is later upgraded to a full line-by-line audit.

## 8. Verdict

**EXECUTION PASS.**

Recommended role:

**Robust preference / ordered-weight ambiguity external empirical case (WIBA 2025)**.

A precise claim is:

> CNPW identifies simultaneous qualification structure that is distinct from robustness defined over an admissible ordered-weight region.

Do not claim that CNPW universally outperforms WIBA.
