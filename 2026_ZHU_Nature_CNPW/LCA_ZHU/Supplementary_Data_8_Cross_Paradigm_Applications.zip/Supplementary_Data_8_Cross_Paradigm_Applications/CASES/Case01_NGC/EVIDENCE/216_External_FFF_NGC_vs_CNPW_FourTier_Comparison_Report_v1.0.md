# 216 — External FFF NGC vs CNPW Four-Tier Priority Comparison Report

**Version:** v1.0  
**Status:** Frozen interpretation / manuscript-positioning file  
**Numerical evidence:** File 214  
**External validation protocol:** File 212  
**Frozen external response library:** File 213  

---

# 1. Purpose and role

This file freezes the scientific interpretation of the external fused-filament-fabrication (FFF) comparison between the published Normalized Global Criterion (NGC) solution and the CNPW priority-based analysis.

It is **not** a new method file and does not modify the frozen CNPW v1.5.2 core.

Its role is:

\[
\boxed{
\text{File 214 = numerical evidence}
\qquad
\text{File 216 = scientific interpretation and manuscript positioning}
}
\]

The comparison is designed to answer a specific question:

> If the same published preference hierarchy is supplied to both methods, how does a compensatory weighted criterion differ from a non-compensatory hierarchical qualification procedure?

The central comparison is therefore not simply “which method gives a better point,” but:

\[
\boxed{
\text{how the same preference information is translated into a final engineering decision}
}
\]

---

# 2. Why the earlier Mode-A comparison is not the fairest head-to-head

The published NGC Balanced scenario is not an equal-priority problem.

Its weights are:

\[
w_{Cost}=0.40
\]

\[
w_{Ca_w}=w_{Ca_t}=0.20
\]

\[
w_{Energy}=0.10
\]

\[
w_{Cgk_w}=w_{Cgk_t}=0.05.
\]

Therefore the implied preference hierarchy is:

\[
\boxed{
Cost
>
\{Ca_w,Ca_t\}
>
Energy
>
\{Cgk_w,Cgk_t\}
}
\]

By contrast, CNPW Mode A treats all selected active responses under the same qualification priority.

Hence a direct comparison between:

\[
\text{NGC Balanced}
\]

and:

\[
\text{CNPW Mode A Equal Priority}
\]

does not use identical preference information.

Mode A remains useful as an **external transferability baseline**, because it tests whether the frozen CNPW framework operates on an external six-response engineering dataset without relying on user-specific preference ordering.

However, it should not be treated as the primary fairness-controlled comparison against the weighted Balanced NGC scenario.

---

# 3. Fair-comparison principle

The comparison in File 214 preserves the **ordering and ties** contained in the published NGC weights, but does not convert the numerical weights into Global Levels.

In particular, no claim is made that:

\[
0.40 \equiv GL7,
\]

or:

\[
0.20 \equiv GL6.
\]

Such a mapping would be arbitrary.

Instead, the NGC weights are used only to define the hierarchy:

\[
\boxed{
Cost
>
\{Ca_w,Ca_t\}
>
Energy
>
\{Cgk_w,Cgk_t\}.
}
\]

The two frameworks then process the same preference hierarchy differently.

## NGC

The preference information enters a normalized weighted scalar objective:

\[
F(x)
=
\sum_j w_j\bar f_j(x),
\]

and the optimization returns a single point.

Because all responses enter the same scalar criterion, performance losses in one response may be compensated by gains in others.

## CNPW

The same ordering is translated into sequential qualification tiers:

\[
T_1=Cost,
\]

\[
T_2=\{Ca_w,Ca_t\},
\]

\[
T_3=Energy,
\]

\[
T_4=\{Cgk_w,Cgk_t\}.
\]

Qualification is performed sequentially, and each higher-priority tier remains locked before the next tier is evaluated.

Thus:

\[
\boxed{
\text{same preference hierarchy}
\rightarrow
\text{different decision semantics}
}
\]

---

# 4. Formal four-tier CNPW rule

Let:

\[
S_0=X
\]

be the complete frozen 9,801-candidate external FFF library.

For each priority tier \(T_t\), CNPW searches from GL7 downward and identifies the highest jointly feasible level:

\[
q_t^*
=
\max
\left\{
k:
\exists x\in S_{t-1}
\text{ such that }
\ell_j(x)\ge k,\ \forall j\in T_t
\right\}.
\]

The retained set is:

\[
\boxed{
S_t
=
\left\{
x\in S_{t-1}:
\ell_j(x)\ge q_t^*,
\ \forall j\in T_t
\right\}.
}
\]

The critical hierarchy rule is:

\[
\boxed{
S_t\subseteq S_{t-1}
}
\]

and therefore:

\[
\boxed{
\text{later tiers may not relax qualification already locked by earlier tiers.}
}
\]

If the current tier has no feasible intersection at GL7, the current tier alone is reduced:

\[
GL7\rightarrow GL6\rightarrow\cdots\rightarrow GL1.
\]

An earlier tier is not relaxed.

Because GL1 contains the complete parent population for each response, every current tier has at least one feasible level inside a non-empty parent set.

Hence the strict tier search does not require ad hoc cross-tier recovery.

---

# 5. External FFF four-tier result

The frozen external library contains:

\[
\boxed{9,801}
\]

candidate parameter combinations.

The four-tier sequential qualification gives:

## Tier 1 — Cost

Highest feasible level:

\[
\boxed{GL7}
\]

Retained:

\[
9,801\rightarrow1,401.
\]

Thus the highest Cost qualification level can be fully protected.

---

## Tier 2 — Dimensional accuracy

Within the 1,401 Cost-qualified candidates, both:

\[
Ca_w
\]

and:

\[
Ca_t
\]

can simultaneously attain:

\[
\boxed{GL7}.
\]

Retained:

\[
1,401\rightarrow129.
\]

Hence:

\[
\boxed{
Cost=GL7
\quad\text{and}\quad
Ca_w,Ca_t=GL7
}
\]

can coexist.

---

## Tier 3 — Energy

Within the 129 candidates already satisfying the higher-priority Cost and \(Ca\) locks, Energy can also attain:

\[
\boxed{GL7}.
\]

Retained:

\[
129\rightarrow88.
\]

Therefore the first three preference tiers can all be maintained at the highest Global Level.

---

## Tier 4 — Capability

Within the 88 candidates satisfying:

\[
Cost=GL7,
\]

\[
Ca_w,Ca_t=GL7,
\]

and:

\[
Energy=GL7,
\]

the capability responses:

\[
Cgk_w,\ Cgk_t
\]

cannot jointly attain GL7 or GL6.

Their highest common feasible qualification is:

\[
\boxed{GL5}.
\]

Retained:

\[
88\rightarrow8.
\]

Therefore the complete global priority chain is:

\[
\boxed{
9,801
\rightarrow
1,401
\rightarrow
129
\rightarrow
88
\rightarrow
8
}
\]

with qualification sequence:

\[
\boxed{
GL7
\rightarrow
GL7
\rightarrow
GL7
\rightarrow
GL5.
}
\]

This is the primary global result of the hierarchical comparison.

---

# 6. Process-space topology

The final eight globally qualified candidates form:

\[
\boxed{
3
}
\]

four-dimensional face-connected components with sizes:

\[
\boxed{
5,\ 2,\ 1.
}
\]

The corresponding parameter ranges are:

\[
LW=0.54\text{--}0.60\ \mathrm{mm},
\]

\[
LH=0.16\text{--}0.24\ \mathrm{mm},
\]

\[
ID=10\text{--}40\%,
\]

\[
S=50\ \mathrm{mm/s}.
\]

Thus the CNPW result is not initially a single optimum but a small, structured, requirement-consistent process-space region.

This distinction is central:

\[
\boxed{
\text{NGC returns an optimized point;}
\qquad
\text{CNPW first returns a qualified nested region.}
}
\]

---

# 7. Hierarchical local refinement

The same priority order is retained during Local-Level refinement inside the final global set.

The sequence is:

\[
Cost
\rightarrow
\{Ca_w,Ca_t\}
\rightarrow
Energy
\rightarrow
\{Cgk_w,Cgk_t\}.
\]

The resulting local locks are:

\[
T_1=LL7,
\]

\[
T_2=LL3,
\]

\[
T_3=LL1,
\]

\[
T_4=LL1.
\]

After the first local tier:

\[
8\rightarrow2
\]

candidates remain.

After the dimensional-accuracy tier:

\[
2\rightarrow1.
\]

The unique terminal is:

\[
\boxed{
EPG6446
}
\]

with:

\[
LW=0.54\ \mathrm{mm},
\]

\[
LH=0.16\ \mathrm{mm},
\]

\[
ID=10\%,
\]

\[
S=50\ \mathrm{mm/s}.
\]

The terminal is Pareto-efficient.

Pareto efficiency is reported only as an independent audit property and does not participate in the hierarchical selection rule.

---

# 8. Published NGC Balanced point versus CNPW terminal

The published Balanced NGC point is approximately:

\[
\boxed{
LW=0.59,\quad
LH=0.12,\quad
ID=10,\quad
S=50
}
\]

and the external reproduction audit recovers a nearby local optimum:

\[
LW\approx0.5867,\quad
LH=0.12,\quad
ID=10,\quad
S=50.
\]

The CNPW four-tier terminal is:

\[
\boxed{
LW=0.54,\quad
LH=0.16,\quad
ID=10,\quad
S=50.
}
\]

Therefore:

\[
\boxed{
\text{the two methods do not select the same point.}
}
\]

They agree on:

\[
ID=10\%,
\]

and:

\[
S=50\ \mathrm{mm/s},
\]

but differ in both:

\[
LW
\]

and:

\[
LH.
\]

This divergence is not treated as an inconsistency; it is an expected consequence of different decision semantics.

---

# 9. Response-level comparison

## Published NGC Balanced point

Projected onto the frozen CNPW Global-Level system, the published Balanced NGC point has:

\[
Energy=GL5,
\]

\[
Cost=GL7,
\]

\[
Cgk_w=GL7,
\]

\[
Cgk_t=GL7,
\]

\[
Ca_w=GL7,
\]

\[
Ca_t=GL7.
\]

Thus:

\[
\boxed{
Q_{\min,\mathrm{NGC}}=GL5.
}
\]

The response receiving the minimum qualification is:

\[
\boxed{
Energy.
}
\]

---

## CNPW four-tier terminal EPG6446

The CNPW terminal has:

\[
Energy=GL7,
\]

\[
Cost=GL7,
\]

\[
Cgk_w=GL7,
\]

\[
Cgk_t=GL5,
\]

\[
Ca_w=GL7,
\]

\[
Ca_t=GL7.
\]

Thus:

\[
\boxed{
Q_{\min,\mathrm{CNPW}}=GL5.
}
\]

The response receiving the minimum qualification is:

\[
\boxed{
Cgk_t.
}
\]

---

# 10. Central scientific interpretation

Both decision procedures produce a solution whose worst projected Global Level is:

\[
\boxed{GL5}.
\]

However, the location of that compromise differs.

For NGC:

\[
\boxed{
Energy\rightarrow GL5
}
\]

while the remaining responses reach GL7.

For hierarchical CNPW:

\[
\boxed{
Cgk_t\rightarrow GL5
}
\]

while the higher-priority:

\[
Cost,
\]

\[
Ca_w,Ca_t,
\]

and:

\[
Energy
\]

remain at GL7.

This is precisely the semantic difference intended by the comparison.

The NGC weights assign:

\[
Energy=0.10
\]

and:

\[
Cgk_w=Cgk_t=0.05.
\]

Hence Energy is ranked above the capability responses in the published preference structure.

Yet a compensatory scalar criterion does not guarantee that every higher-weight objective will individually retain a better discrete qualification level than every lower-weight objective.

By contrast, hierarchical CNPW imposes that ordering procedurally.

Once Energy is locked at GL7 in Tier 3, the lower-priority capability tier cannot reduce it.

Therefore:

\[
\boxed{
\text{NGC expresses priority through contribution to a scalar criterion;}
}
\]

whereas:

\[
\boxed{
\text{CNPW expresses priority through sequential qualification protection.}
}
\]

---

# 11. What this comparison does and does not show

The comparison supports the statement that, under the same published preference hierarchy:

\[
\boxed{
\text{compensatory and non-compensatory decision semantics can allocate performance sacrifice differently.}
}
\]

It also shows that CNPW provides an explicit trace of where the first unavoidable qualification loss occurs.

In this case:

\[
T_1=GL7,
\]

\[
T_2=GL7,
\]

\[
T_3=GL7,
\]

but:

\[
T_4=GL5.
\]

Hence the conflict becomes localized to the lowest-priority capability tier.

This is a form of decision-space interpretability.

The analysis does **not** establish that CNPW is universally superior to NGC.

It does not prove that the CNPW terminal is universally more desirable.

It does not imply that weighted optimization is inappropriate.

If a user genuinely wishes to permit continuous compensation and can justify the selected weights, NGC is a valid decision model.

Conversely, if the engineering semantics require that higher-priority qualification be protected before lower-priority objectives are considered, the hierarchical CNPW representation is more directly aligned with that requirement.

---

# 12. Relation to Pareto efficiency

Pareto efficiency is not treated as a third preference model in this comparison.

It answers a different question:

> Is the candidate dominated by another candidate in all objectives?

The CNPW terminal EPG6446 is Pareto-efficient.

This is useful because it confirms that the non-compensatory hierarchical rule did not terminate at an obviously dominated candidate.

However:

\[
\boxed{
\text{Pareto-efficient}
\neq
\text{hierarchically qualified}
}
\]

and:

\[
\boxed{
\text{Pareto efficiency does not encode the published Cost > Ca > Energy > Cgk preference hierarchy.}
}
\]

Therefore Pareto status remains an audit property rather than the primary selector.

---

# 13. Recommended manuscript positioning

The external case should be presented in three layers.

## Layer 1 — transferability

Mode A remains the preference-free external validation:

\[
\boxed{
\text{Can frozen CNPW operate on a new six-response engineering system?}
}
\]

This establishes transferability.

## Layer 2 — fairness-controlled NGC comparison

The primary NGC comparison should use the same published preference hierarchy:

\[
Cost
>
Ca
>
Energy
>
Cgk.
\]

NGC executes this preference through weighted scalar aggregation.

CNPW executes it through hierarchical qualification locking.

This is the primary head-to-head comparison.

## Layer 3 — decision interpretation

The comparison should emphasize:

\[
\boxed{
\text{same hierarchy}
+
\text{different decision semantics}
\rightarrow
\text{different compromise allocation}.
}
\]

The most informative observation is not simply that the selected parameter points differ.

It is that:

\[
\boxed{
\text{NGC places the GL5 compromise in Energy,}
}
\]

whereas:

\[
\boxed{
\text{CNPW places the GL5 compromise in the lowest-priority capability tier.}
}
\]

---

# 14. Manuscript-ready concise result paragraph

A concise Results-style formulation is:

> To provide a preference-controlled comparison with the published Balanced NGC scenario, the original weight ordering was retained without converting numerical weights into CNPW qualification levels. The resulting hierarchy was Cost > dimensional accuracy > Energy > capability. Sequential CNPW qualification reduced the 9,801-candidate library to 1,401 candidates at Cost GL7, 129 after retaining both dimensional-accuracy responses at GL7, and 88 after additionally retaining Energy at GL7. The lowest-priority capability pair could jointly attain only GL5, yielding eight globally qualified candidates. Hierarchical Local-Level refinement subsequently identified EPG6446 as the unique terminal candidate. The published NGC point and the CNPW terminal therefore differed in process parameters and in the location of their lowest response qualification: the NGC solution projected to Energy GL5 with the other five responses at GL7, whereas CNPW retained the first three priority tiers at GL7 and localized the remaining compromise to \(Cgk_t\) at GL5.

---

# 15. Manuscript-ready discussion paragraph

A concise Discussion-style formulation is:

> The comparison illustrates a semantic rather than merely numerical distinction between weighted and qualification-based multi-objective decisions. In NGC, the published preferences enter a common scalar criterion and therefore permit performance compensation across responses. In hierarchical CNPW, the same preference ordering is implemented sequentially: once a higher-priority tier has reached its highest feasible qualification level, lower-priority responses cannot subsequently reduce that qualification. Consequently, both approaches exhibited a minimum projected level of GL5 in this case, but the compromise was allocated to different responses. This result should not be interpreted as universal superiority of either method; rather, it demonstrates that weight-based importance and non-compensatory priority protection encode different engineering decision semantics.

---

# 16. Safe claim set

The following claims are supported:

\[
\boxed{
\text{The two methods use the same preference hierarchy but different decision semantics.}
}
\]

\[
\boxed{
\text{The two methods select different final process points.}
}
\]

\[
\boxed{
\text{Both final solutions have a minimum projected Global Level of GL5.}
}
\]

\[
\boxed{
\text{The location of the GL5 compromise differs between the two methods.}
}
\]

\[
\boxed{
\text{CNPW preserves previously locked higher-priority qualification.}
}
\]

\[
\boxed{
\text{The CNPW terminal is Pareto-efficient.}
}
\]

The following claims should be avoided:

> CNPW universally outperforms NGC.

> CNPW always produces a better solution.

> NGC violates its own weights.

> A weight of 0.40 is equivalent to GL7.

> A lower-weight response must necessarily have a lower Global Level in weighted optimization.

> Pareto efficiency proves CNPW superiority.

---

# 17. Final interpretation

The external comparison can be summarized as:

\[
\boxed{
\text{NGC}
=
\text{preference by weighted compensation}
}
\]

versus:

\[
\boxed{
\text{CNPW}
=
\text{preference by hierarchical qualification protection}.
}
\]

Using the same published hierarchy:

\[
Cost
>
Ca
>
Energy
>
Cgk,
\]

the methods produce:

\[
\boxed{
\text{NGC: Energy becomes the GL5 response}
}
\]

and:

\[
\boxed{
\text{CNPW: the lowest-priority capability tier absorbs the GL5 compromise}.
}
\]

This is the principal scientific message of the comparison.

---

# 18. File architecture after this comparison

The external FFF evidence chain is therefore:

\[
\boxed{
212
=
\text{external validation protocol}
}
\]

\[
\boxed{
213
=
\text{frozen external library and comprehensive CNPW analyses}
}
\]

\[
\boxed{
214
=
\text{four-tier NGC–CNPW numerical comparison}
}
\]

\[
\boxed{
216
=
\text{interpretation and manuscript-ready positioning}
}
\]

File 215 remains a separate post-freeze configurability extension and is not required for the 214/216 head-to-head analysis.

