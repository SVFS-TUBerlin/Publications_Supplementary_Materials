# Model reproduction

This directory reproduces the final PPP models and the Young’s modulus random-forest benchmark in Table 5A.

## Quick start

Requires Python 3.11+ and the dependencies in `requirements.txt`. From this directory:

```sh
python -m pip install -r requirements.txt
python reproduce_models.py
python reproduce_E_random_forest.py --output results/E_random_forest_LOOCV.csv
```

The script reads `raw_measurements_101.csv` and writes six files to `results/`:

- `condition_predictions_31.csv`: 27 leave-one-condition-out predictions plus four additional-condition predictions, including measured responses, predicted porosity, E and UTS, and direct baselines;
- `summary_metrics.csv` and `metrics.json`: condition-mean R², MAE, RMSE;
- `modulus_porosity_diagnostics.csv`: global and stratified measured-porosity E regressions, including Table 5 speed-stratified LOOCV statistics.
- `modulus_hc3.json`: HC3-robust joint F test of equal E–porosity slopes across speeds.
- `fitted_coefficients.csv`: full-precision fitted upstream Y model and the E / UTS conditional coefficients.

The generated `results/` files are provided as checked outputs as well as being reproducible.

## Source data and units

`raw_measurements_101.csv` is extracted from two researcher-provided workbooks and retains the associated measurement provenance:

- `机理推演-1(6).xlsx`: 27 main processing combinations, three specimens each;
- `验证组数据(4).xlsx`: V1–V4, five specimens each.

Columns: condition and specimen IDs; h and P (mm); speed v (mm/s); specimen mass (g); measured cross-sectional area (mm²); tensile slope (N); maximum force (N); source workbook and row references.

Calculations: E = tensile slope / measured area (MPa); UTS = maximum force / measured area (MPa); volumetric porosity = 100*(1−1000*mass/(1.24*area*180)) in percent.

**Not provided**: individual raw width/thickness readings, or original balance readings. The parent archive includes the tensile curves and the condition-level ROI workbook.

## Final models covered

1. Geometry-referenced porosity: Y = phi_vol − 100(1−pi/4)*h/P; h² term at 20 mm/s, linear models at 70 and 120 mm/s; interpolation between adjacent speeds.
2. E: six-coefficient, speed-conditioned linear relation using measured porosity for fitting; intermediate-speed coefficient interpolation.
3. UTS: seven-coefficient model, UTS = C(h) + bF*F + bV*V + bHV*H*V + bFV*F*V, where F=(phi−10)/5, H=(h−.20)/.10 and V=(v−70)/50; C(h) interpolated among the three experimental heights.
4. Integrated PPP forward predictions using predicted porosity only; 27 synchronized LOOCV folds in which *both* upstream and downstream models are refitted with only 26 condition means per fold.
5. Independent-of-fitting V1–V4 evaluations (the 4 conditions are not used in final coefficient fitting); direct linear and full quadratic process-only baselines, and measured-porosity conditional models.

## Expected final results

| Model | 27-condition LOOCV R² | 27-condition LOOCV RMSE | V1–V4 RMSE |
| --- | ---: | ---: | ---: |
| Upstream Y | 0.953 | 0.933 pp | — |
| Integrated PPP E | 0.929 | 16.255 MPa | 13.132 MPa |
| Integrated PPP UTS | 0.926 | 0.521 MPa | 0.370 MPa |

The `reproduce_models.py` script asserts these rounding-level values at runtime.

## Scope notes

- Measured-porosity conditional predictions *do use* measured porosity from the evaluated condition, and are **diagnostic baselines, not process-only forecasts**.
- The final PPP always predicts porosity from h/P/v before predicting E or UTS, including during held-out folds.
- The Table 5A random forest uses measured volumetric porosity and printing speed to predict condition-mean modulus, with 100 trees, seed 42 and scikit-learn 1.8.0. It gives LOOCV R² = 0.887 and MAE = 14.816 MPa.
- The exploratory porosity and UTS random-forest comparisons are outside the scope of these scripts. The 3D inverse-design calculations are in directory 07.
- V1–V4 were excluded from coefficient fitting; their use during historical exploratory comparisons means they should not be represented as a prospectively untouched validation set without further evidence.
