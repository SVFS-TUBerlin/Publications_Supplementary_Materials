from __future__ import annotations

from decimal import Decimal
from pathlib import Path

from .models import Dataset, RunResult


def _d(value: Decimal) -> str:
    return format(value, "f")


def _table(headers: list[str], rows: list[list[str]]) -> list[str]:
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    lines.extend("| " + " | ".join(row).replace("|", "\\|") + " |" for row in rows)
    return lines


def _candidate_table(dataset: Dataset, result: RunResult, indices: list[int], include_ll: bool) -> list[str]:
    headers = ["Candidate ID"] + [criterion.name for criterion in dataset.criteria] + ["GL profile"]
    if include_ll:
        headers += ["LL profile", "Sorted worst-first LL"]
    headers += dataset.descriptor_names
    rows = []
    for index in indices:
        row = [dataset.candidate_ids[index]] + [_d(value) for value in dataset.values[index]]
        row += ["(" + ", ".join(f"GL{level}" for level in result.stage1.gl[index]) + ")"]
        if include_ll:
            ll_indices = list(range(1, len(dataset.criteria))) if result.protected else list(range(len(dataset.criteria)))
            levels = [result.stage2.ll[index][criterion] for criterion in ll_indices]
            row += ["(" + ", ".join(f"LL{level}" for level in levels) + ")", "(" + ", ".join(f"LL{level}" for level in sorted(levels)) + ")"]
        row += [str(value) for value in dataset.descriptors[index]]
        rows.append(row)
    return _table(headers, rows)


def write_report(dataset: Dataset, result: RunResult, output_dir: str | Path = "output") -> Path:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    is_mode_b = result.protected is not None
    report_path = output / ("CNPW_Report_Mode_B.md" if is_mode_b else "CNPW_Report_Mode_A.md")
    lines = [f"# CNPW Core Research v0.1 — {result.mode}", "", "## 1. Input Summary", "", f"- Source filename: `{Path(dataset.source).name}`", f"- File format: {dataset.file_format}", f"- Candidate count: {len(dataset.candidate_ids)}", f"- Active criterion count: {len(dataset.criteria)}", f"- Descriptor count: {len(dataset.descriptor_names)}", "- K_g: 7", "- K_l: 7", "- Stage-1 tie policy: upward", f"- Mode: {result.mode}", "", "| Criterion | Direction |", "| --- | --- |"]
    lines.extend(f"| {criterion.name} | {criterion.direction} |" for criterion in dataset.criteria)
    if is_mode_b:
        protected = result.protected
        lines += ["", "## 2. Protected Requirement (Mode B)", "", f"- Protected criterion: {protected['criterion']}", "- Protected level: GL7-or-better", f"- Protected candidate count: {protected['count']}", f"- Residual criteria: {', '.join(protected['residual'])}", "- Protected Result A is a hard qualification condition. Surplus performance above GL7 is not reused as a compensatory terminal bonus."]
    lines += ["", "## 3. Stage 1 per Criterion", ""]
    for index, criterion in enumerate(dataset.criteria):
        raw_values = [record[index] for record in dataset.values]
        lines += [f"### {criterion.name}", "", f"- Direction: {criterion.direction}", f"- Raw minimum / maximum: {_d(min(raw_values))} / {_d(max(raw_values))}", f"- Nominal GL1–GL7 counts: {result.stage1.nominal_counts[criterion.name]}", f"- Final GL1–GL7 counts: {result.stage1.final_counts[criterion.name]}", f"- Tie-upward adjustment count: {result.stage1.tie_adjustments[criterion.name]}", "- Nominal boundaries use `ceil(7r/N)` from worst to best; equal values crossing a boundary are assigned upward to the better touched GL.", "", "| Exact GL | Supplied-value range in exact GL |", "| --- | --- |"]
        for level in range(1, 8):
            exact = [dataset.values[candidate][index] for candidate in range(len(dataset.candidate_ids)) if result.stage1.gl[candidate][index] == level]
            band = "empty" if not exact else f"{_d(min(exact))} to {_d(max(exact))}"
            lines.append(f"| GL{level} | {band} |")
        lines.append("")
    stage1_title = "## 4. Residual Joint Stage 1" if is_mode_b else "## 4. Joint Stage 1"
    lines += [stage1_title, "", "| Cumulative GL requirement | Joint count |", "| --- | ---: |"]
    lines.extend(f"| GL{level}-or-better | {result.stage1.joint_counts[level]} |" for level in range(7, 0, -1))
    lines += ["", f"- Highest jointly qualified global level: GL{result.stage1.q1}", f"- W^(1) size: {len(result.stage1.retained)}", "", "### W^(1) Candidate Table", ""]
    lines += _candidate_table(dataset, result, result.stage1.retained, False)
    lines += ["", "## 5. Stage 2", ""]
    stage2_indices = list(range(1, len(dataset.criteria))) if is_mode_b else list(range(len(dataset.criteria)))
    for criterion_index in stage2_indices:
        criterion = dataset.criteria[criterion_index]
        info = result.stage2.local[criterion.name]
        lines += [f"### {criterion.name}", "", f"- W^(1) local minimum / maximum: {_d(info['min'])} / {_d(info['max'])}", f"- Local range: {_d(info['range'])}", f"- Equal-width LL interval: {_d(info['width'])}", f"- LL1–LL7 counts: {info['counts']}", "", "| LL label | Actual-value threshold | Absolute degradation from local best |", "| --- | ---: | ---: |"]
        lines.extend(f"| LL{level} | {_d(threshold)} | {_d(abs(threshold - info['best']))} |" for level, threshold in enumerate(info["thresholds"], 1))
        lines += ["", "Each threshold and absolute degradation is a linked representation of the same equal-width LL partition.", ""]
    lines += ["| Cumulative LL requirement | Joint count |", "| --- | ---: |"]
    lines.extend(f"| LL{level}-or-better | {result.stage2.joint_counts[level]} |" for level in range(7, 0, -1))
    lines += ["", f"- Highest locally co-qualified level: LL{result.stage2.q2}", f"- W^(2) size: {len(result.stage2.retained)}", "", "## 6. W^(2) Candidate Table", ""]
    lines += _candidate_table(dataset, result, result.stage2.retained, True)
    lines += ["", "## 7. Terminal", "", f"- W^(2) candidates: {len(result.stage2.retained)}", "- Step 1 retains the lexicographically best sorted worst-first LL profile class without weights, scores, averages, normalization, or distance.", f"- Best profile class size: {len(result.profile_class)}", f"- Step 2 removes raw-response dominated candidates within that class using the formal directions.", f"- W^(2T) size: {len(result.terminal)}", "", "### W^(2T) Candidate Table", ""]
    lines += _candidate_table(dataset, result, result.terminal, True)
    terminal_ids = ", ".join(dataset.candidate_ids[index] for index in result.terminal)
    if len(result.terminal) > 1:
        summary = "CNPW intentionally retains a set-valued terminal because the remaining candidates represent irreducible non-dominated trade-offs under the frozen rules."
    else:
        summary = f"Under the frozen CNPW configuration, {terminal_ids} is the terminal candidate after two qualification stages, worst-first ordinal-profile pruning, and raw-response dominance."
    lines += ["", "## 8. Deterministic Summary", "", f"The run found GL{result.stage1.q1} as the highest jointly qualified global level and retained {len(result.stage1.retained)} candidate(s) in W^(1). It then found LL{result.stage2.q2} as the highest locally co-qualified level and retained {len(result.stage2.retained)} candidate(s) in W^(2). {summary}", ""]
    report_path.write_text("\n".join(lines), encoding="utf-8")
    return report_path
