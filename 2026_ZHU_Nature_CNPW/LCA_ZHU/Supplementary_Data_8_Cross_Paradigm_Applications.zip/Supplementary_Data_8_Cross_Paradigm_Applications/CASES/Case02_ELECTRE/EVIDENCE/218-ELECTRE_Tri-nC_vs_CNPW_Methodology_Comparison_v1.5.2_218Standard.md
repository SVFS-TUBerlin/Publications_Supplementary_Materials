# ELECTRE Tri-nC vs CNPW v1.5.2
## File-218 Standard Methodology / Prior-Art Comparison

**Comparator route:** Outranking-based non-compensatory multi-criteria sorting  
**Representative paper:** Alves & Pereira (2025), *Enhancing clinical and non-clinical risk management: A case study using ELECTRE Tri-nC*, *Health Care Management Science* 28, 824–841  
**CNPW version:** v1.5.2  
**Governing comparison standard:** File 218 methodology-comparison / prior-art standard  
**Status:** **KEEP — core comparator paradigm and formal nearest-neighbour route**

---

# 1. Comparator identity

ELECTRE Tri-nC is retained because it attacks a central weak novelty narrative that CNPW must avoid:

> non-compensatory multi-criteria decision making is not new.

ELECTRE Tri-nC is a mature outranking-based sorting method.

Its healthcare implementation combines:

\[
\text{performance matrix}
+
\text{criterion weights}
+
q_j,p_j,v_j
+
\text{reference actions}
+
\lambda
\]

to construct:

\[
\text{concordance}
+
\text{discordance / veto}
\rightarrow
\text{credibility}
\rightarrow
\text{ascending / descending assignment}
\rightarrow
\text{ordered category or category interval}.
\]

Therefore the correct comparison is not:

\[
\text{non-compensatory CNPW}
\quad vs\quad
\text{compensatory ELECTRE}.
\]

Both are non-compensatory.

The correct comparison is:

\[
\boxed{
\text{outranking-based non-compensation}
\quad vs\quad
\text{conjunctive qualification-based non-compensation}.
}
\]

---

# 2. File-218 comparison rule: compare decision objects before features

The primary File-218 question is:

> What is the method's native decision object?

For ELECTRE Tri-nC:

\[
\boxed{
a_i\rightarrow C_h
\quad\text{or}\quad
[C_h,C_{h+1}]
}
\]

The method asks:

> To which ordered category should this action be assigned?

For CNPW:

\[
\boxed{
\mathcal R\rightarrow\Omega(\mathcal R)
}
\]

where \(\Omega(\mathcal R)\) is the requirement-qualified finite candidate space.

Mode A asks:

\[
\boxed{
\text{What is the highest jointly attainable qualification and which candidates satisfy it?}
}
\]

Thus the deepest distinction is:

\[
\boxed{
\text{classification of alternatives}
\neq
\text{interrogation of a jointly qualified decision space}.
}
\]

Feature-by-feature comparisons are secondary to this decision-object distinction.

---

# 3. Fair scope boundary

The fair shared layer is:

```text
upstream domain definition / candidate generation
        ↓
frozen candidate-response matrix
        ↓
decision methodology
        ↓
decision structure / output
```

The comparison does not credit CNPW for:

- generating healthcare indicators;
- handling missing data;
- estimating incident uncertainty;
- defining hospital risk categories;
- eliciting clinical preferences;
- producing the source candidate periods.

These are upstream tasks.

The same-data empirical case freezes the original 20×12 healthcare matrix before either decision interpretation is discussed.

---

# 4. What ELECTRE Tri-nC natively contributes

ELECTRE Tri-nC provides several mature capabilities that CNPW must acknowledge explicitly.

## 4.1 Outranking rather than scalar utility

The method does not require a single additive value function.

Instead, it evaluates whether an action credibly outranks category reference actions.

## 4.2 Criterion-specific pseudo-criteria

Each response may have distinct:

\[
q_j,\quad p_j,\quad v_j.
\]

This allows:

- indifference;
- weak / strict preference;
- decisive contradiction.

## 4.3 Weighted voting power

Criterion weights are not direct utility coefficients.

They represent voting power in concordance.

## 4.4 Veto-based asymmetric non-compensation

A severe weakness on one criterion may block an outranking relation even when other criteria support it.

## 4.5 Expert-defined category semantics

Categories and characteristic reference actions are created with domain experts.

This is especially valuable where institutional meaning matters.

## 4.6 Assignment imprecision is explicit

Ascending and descending procedures may return an interval such as:

\[
C_4-C_5.
\]

The interval is a legitimate expression of sorting imprecision.

## 4.7 Mature stability analysis

The healthcare paper directly studies:

- weight stability;
- credibility-level perturbation;
- criterion-set perturbation.

This is a genuine comparator strength.

---

# 5. What CNPW v1.5.2 natively contributes

CNPW starts from a finite, authoritative candidate-response library.

For active responses \(J\):

\[
Q^{(1)}(x)=\min_{j\in J}\ell_j(x)
\]

and:

\[
Q^{(1)*}=\max_xQ^{(1)}(x).
\]

The first output is:

\[
W^{(1)}
=
\{x:Q^{(1)}(x)\ge Q^{(1)*}\}.
\]

Then, inside \(W^{(1)}\), CNPW applies supplied-scale Local Levels and repeats the non-compensatory qualification logic.

Terminal discrimination is:

\[
\boxed{
\text{highest LL intersection}
\rightarrow
\text{worst-first LL profile}
\rightarrow
\text{raw-response dominance}.
}
\]

No candidate rejected at Stage 1 can re-enter.

No weighted compensatory scalar is introduced at the terminal stage.

---

# 6. Two genuinely different meanings of non-compensation

## ELECTRE Tri-nC

\[
\boxed{
\text{non-compensation}
=
\text{weighted concordance constrained by discordance / veto}.
}
\]

A weak criterion does not automatically determine the complete result unless its contradiction is sufficiently strong under the declared thresholds.

## CNPW

\[
\boxed{
\text{non-compensation}
=
\text{conjunctive satisfaction of the active qualification floor}.
}
\]

For common level \(k\):

\[
x\in W_k
\iff
\ell_j(x)\ge k
\quad\forall j.
\]

There is no majority vote that rescues a response below the active floor.

Thus:

\[
\boxed{
\text{ELECTRE non-compensation}
\neq
\text{CNPW non-compensation}.
}
\]

This difference is substantive, not terminological.

---

# 7. Ordered categories are prior art; CNPW cannot claim them

ELECTRE produces an overall action category:

\[
a_i\rightarrow C_h.
\]

CNPW produces response-wise levels first:

\[
y_j(x)\rightarrow\ell_j(x)
\]

and then the cumulative intersection:

\[
W_k
=
\bigcap_j
\{x:\ell_j(x)\ge k\}.
\]

Therefore CNPW must not claim novelty for:

- ordered categories;
- levels;
- thresholds;
- non-compensatory sorting;
- qualification-like decision semantics.

The distinction lies in:

\[
\boxed{
\text{what the ordinal object represents and what is interrogated after it is constructed}.
}
\]

---

# 8. Same-data empirical evidence

The healthcare matrix contains:

\[
20\text{ quarters}\times12\text{ responses}.
\]

Published ELECTRE base assignment:

\[
C_3:2,\quad
C_3-C_4:3,\quad
C_4:6,\quad
C_4-C_5:9.
\]

CNPW Mode A produces:

\[
\boxed{
Q^{(1)*}=GL3
}
\]

and:

\[
\boxed{
W^{(1)}
=
\{\text{Q2 2018},\text{Q3 2018},\text{Q3 2019}\}.
}
\]

All three belong to ELECTRE's most favourable observed interval:

\[
C_4-C_5.
\]

This establishes broad decision compatibility.

However, the nine \(C_4-C_5\) quarters have CNPW common qualifications spanning:

\[
GL1,\ GL2,\ GL3.
\]

Therefore:

\[
\boxed{
\text{same ELECTRE category interval}
\not\Rightarrow
\text{same conjunctive weakest-response qualification}.
}
\]

This is the strongest same-data methodological demonstration.

---

# 9. Why this is not a same-preference head-to-head

The ELECTRE model uses expert preferences:

\[
w_j,\ q_j,\ p_j,\ v_j,\ \lambda,\ B_h.
\]

CNPW Mode A uses equal-priority active response qualification.

Therefore:

\[
\boxed{
\text{same data}
\neq
\text{same preference encoding}.
}
\]

Unlike the NGC four-tier comparison, this healthcare case should **not** be described as:

> same preference hierarchy, different decision semantics.

The correct language is:

\[
\boxed{
\text{same candidate-response matrix, different native preference semantics and different decision objects}.
}
\]

ELECTRE weights must not be translated mechanically into CNPW GLs or hard priority tiers.

For example:

\[
w_j=12.12
\not\equiv GL7.
\]

Doing so would create a synthetic comparison not supported by the source method.

---

# 10. Response-subset compatibility is a distinct CNPW diagnostic

For any non-empty response subset \(S\subseteq J\):

\[
Q^{(1)*}(S)
=
\max_x\min_{j\in S}\ell_j(x).
\]

In the healthcare case all:

\[
2^{12}-1=4095
\]

subsets were evaluated.

This yields a direct map of:

\[
\boxed{
\text{which response combinations can sustain which common qualification level}.
}
\]

ELECTRE can be rerun after:

- deleting criteria;
- changing weights;
- changing thresholds;
- changing reference actions.

But exhaustive response-subset highest-joint-qualification mapping is not its native output.

Safe wording:

> CNPW natively standardizes response-subset joint-attainability interrogation; ELECTRE could support related sensitivity studies through reformulation or rerunning, but that is not the primary sorting output.

---

# 11. Limiting-response interpretation must remain semantics-specific

The CNPW leave-one-out audit finds:

\[
\boxed{
g_8\text{ removal raises }Q^*:GL3\rightarrow GL4.
}
\]

No other single-response removal increases the highest common qualification.

Therefore \(g_8\) is:

\[
\boxed{
\text{the clearest single CNPW qualification limiter in this frozen 12-response configuration}.
}
\]

However, the source ELECTRE model gives highest voting weight to:

\[
g_2,g_4,g_5,g_6.
\]

There is no contradiction.

These quantities answer different questions:

\[
\boxed{
\text{ELECTRE weight}
=
\text{importance / voting power in outranking}
}
\]

whereas:

\[
\boxed{
\text{CNPW limiter}
=
\text{response preventing a higher common conjunctive floor}.
}
\]

This distinction should be used positively as an example of decision interpretability, not as an accusation that one method identifies the "wrong" criterion.

---

# 12. The source clinical-only scenario strengthens the comparison

The original study excludes non-clinical criteria and recalculates ELECTRE assignments.

The retained clinical set is:

\[
\{g_1,g_2,g_3,g_4,g_5,g_6,g_8,g_9,g_{10}\}.
\]

Under ELECTRE, the exclusion changes many assignments and increases category precision.

Under CNPW, using exactly the same 9-response subset:

\[
\boxed{
Q^{(1)*}=GL3
}
\]

and the top set remains:

\[
\boxed{
\{\text{Q2 2018},\text{Q3 2018},\text{Q3 2019}\}.
}
\]

This does **not** prove CNPW is "more robust."

It demonstrates that:

\[
\boxed{
\text{criterion-set sensitivity depends on the method's decision semantics}.
}
\]

This is a valuable same-data / same-subset comparison that does not require inventing an artificial perturbation.

---

# 13. Stability comparison — keep three layers separate

The File-218 standard requires separation of:

1. **upstream data uncertainty**;
2. **decision-parameter sensitivity**;
3. **decision-output stability**.

ELECTRE's healthcare analysis primarily addresses:

\[
\text{decision-parameter sensitivity}
\]

through:

- criterion-weight stability;
- \(\lambda\) variation.

CNPW's audits address:

\[
\text{decision-resolution sensitivity}
\]

through:

\[
K_g,\ K_l.
\]

These are not the same uncertainty object.

Therefore avoid statements such as:

> CNPW is more robust than ELECTRE.

The defensible comparison is:

> Both frameworks expose decision sensitivity, but the perturbed quantities are method-specific.

---

# 14. Stage 2 is not "gate then compensatory rank"

A weak description of CNPW would be:

\[
\text{gate}
\rightarrow
\text{rank}.
\]

The current v1.5.2 structure is:

\[
\boxed{
\text{global qualification}
\rightarrow
\text{local actual-value qualification}
\rightarrow
\text{non-compensatory terminal discrimination}.
}
\]

Stage 2 repeats a minimum-qualified intersection in supplied-value space.

Then the sorted local profile is compared worst-first.

Thus CNPW does not reintroduce compensation after qualification.

This is important because many prior-art frameworks do use:

\[
\text{screening / gate}
\rightarrow
\text{weighted or scalar ranking}.
\]

ELECTRE itself is not such a simple gate-plus-rank method, so the distinction should not be falsely attributed to ELECTRE.

---

# 15. Non-uniqueness is prior art

ELECTRE may return category intervals because ascending and descending assignments differ.

CNPW may return:

\[
|W^{(2T)}|>1
\]

when no non-compensatory basis exists to reduce the set further.

Therefore CNPW cannot claim originality for acknowledging ambiguity or non-unique outputs.

The distinction is:

- ELECTRE interval = assignment imprecision between ordered categories;
- CNPW terminal multiplicity = multiple co-qualified candidates remain nondominated under the frozen terminal rule.

---

# 16. Genuine strengths of ELECTRE Tri-nC

The comparison must explicitly preserve these strengths:

- decades of outranking theory;
- direct handling of heterogeneous quantitative / qualitative criteria;
- pseudo-criteria for imperfect knowledge;
- criterion-specific veto logic;
- asymmetric non-compensation;
- expert elicitation of weights and thresholds;
- institutionally meaningful ordered categories;
- category intervals when assignment is imprecise;
- mature decision-parameter stability analysis.

These are not deficiencies CNPW needs to "solve."

In preference-rich institutional decisions, several may be advantages over CNPW Mode A.

---

# 17. Genuine strengths of CNPW for its intended decision question

Relative to an outranking sorting task, CNPW natively standardizes:

- highest jointly attainable qualification;
- requirement-to-qualified-set mapping;
- systematic response-subset compatibility;
- identification of an empty joint intersection;
- controlled requirement relaxation when a relaxation path is declared;
- priority-conditioned residual joint qualification in Mode B;
- separation of population-balanced qualification from supplied-scale local qualification;
- qualification-preserving terminal discrimination;
- topology only when a valid parameter adjacency exists.

These are:

\[
\boxed{
\text{decision-object and architecture differences}
}
\]

not universal superiority claims.

---

# 18. Prior-art claims removed by ELECTRE

After this comparator audit, CNPW must not claim to invent:

\[
\boxed{
\begin{aligned}
&\text{non-compensatory MCDA}\\
&\text{criterion thresholds}\\
&\text{veto / hard rejection concepts}\\
&\text{ordered decision categories}\\
&\text{preference / indifference semantics}\\
&\text{expert-defined preference parameters}\\
&\text{sensitivity analysis}\\
&\text{identification of influential criteria}\\
&\text{non-unique decision outputs}
\end{aligned}
}
\]

It should also avoid:

> "CNPW is the first weight-free non-compensatory decision method."

Absence of weights in Mode A is a design choice, not by itself a novelty claim.

---

# 19. Surviving CNPW methodological space

The defensible contribution after the ELECTRE attack is narrower and stronger:

\[
\boxed{
\begin{aligned}
&\text{population-balanced response qualification}\\
&\text{highest jointly attainable qualification}\\
&\text{jointly qualified finite-candidate decision space}\\
&\text{systematic response-subset compatibility}\\
&\text{conditional interrogation after locking requirements}\\
&\text{explicit qualification incompatibility}\\
&\text{qualification-preserving supplied-scale refinement}\\
&\text{non-compensatory terminal discrimination}\\
&\text{qualified-region topology when adjacency is physically meaningful}
\end{aligned}
}
\]

The central scientific identity is not:

\[
\text{"another non-compensatory MCDA method"}.
\]

It is:

\[
\boxed{
\textbf{a qualification-centred decision-space interrogation architecture}.
}
\]

---

# 20. Primary methodological distinction

The most compact comparison is:

## ELECTRE Tri-nC

\[
\boxed{
\text{Which ordered category credibly describes each action?}
}
\]

## CNPW

\[
\boxed{
\text{What is the highest jointly attainable qualification,
which candidates satisfy it, and what structure remains inside that qualified set?}
}
\]

The decision objects overlap in multi-criteria assessment but are not equivalent.

---

# 21. Publication-facing comparison matrix

| Feature | ELECTRE Tri-nC | CNPW v1.5.2 |
|---|---|---|
| Primary paradigm | Outranking-based sorting | Qualification-driven finite decision-space interrogation |
| Primary object | Category / category interval | Jointly qualified candidate set |
| Non-compensation | Native | Native |
| Mechanism | Weighted concordance + discordance/veto | Conjunctive minimum qualification |
| Weights | Native / important | Not required in Mode A |
| Indifference / preference thresholds | Native | Not equivalent to GL construction |
| Veto | Native | Hard qualification failure by configured floor; different semantics |
| Ordered representation | Alternative-level categories | Response-wise qualification levels |
| Highest jointly attainable response floor | Not primary | Native |
| Exhaustive response-subset compatibility | Possible by repeated reformulation | Native standardized diagnostic |
| Priority-conditioned residual qualification | Possible by redesign / repeated model use | Native Mode B |
| Empty joint intersection as decision object | Not primary | Native |
| Qualification-preserving local stage | Not native sorting object | Native |
| Compensatory post-qualification scalar | Not required | Excluded from core |
| Non-unique output | Category interval | Co-qualified terminal set |
| Expert elicitation | Strong / central | Optional depending on mode |
| Decision-parameter stability | Mature | Resolution / requirement robustness audits |
| Upstream uncertainty estimation | Outside core | Outside core |
| Process-space topology | Not sorting output | Conditional on valid adjacency |

Use:

- **native**;
- **possible through reformulation / rerun**;
- **not a primary output**;
- **different decision object**.

Do not use a simplistic checkmark scorecard.

---

# 22. Same-data validation result required by File 218

The methodological distinction is not only conceptual.

On the 20×12 healthcare matrix:

\[
\boxed{
\text{ELECTRE: 9 quarters in }C_4-C_5
}
\]

while:

\[
\boxed{
\text{CNPW: only 3 quarters reach the highest common GL3}.
}
\]

Within the same \(C_4-C_5\) interval:

\[
Q^{(1)}=1,2,3
\]

all occur.

This is direct empirical evidence that:

\[
\boxed{
\text{outranking-category equivalence}
\neq
\text{conjunctive qualification equivalence}.
}
\]

That is a stronger methodological result than merely saying the methods are mathematically different.

---

# 23. Comparator threat level

ELECTRE Tri-nC is a **high-value / high-relevance prior-art comparator**, because it invalidates broad claims around:

- non-compensation;
- thresholds;
- ordinal categories;
- veto;
- expert preference parameters;
- robustness analysis.

However, it does not collapse CNPW into an ELECTRE variant.

The primary decision objects remain different.

Threat assessment:

\[
\boxed{
\textbf{high at the generic non-compensatory MCDA layer,
moderate at the full decision-architecture layer}.
}
\]

Therefore:

\[
\boxed{
\textbf{KEEP as a Top-5 core comparator route}.
}
\]

---

# 24. Role in the eight-paradigm benchmark

ELECTRE Tri-nC occupies:

\[
\boxed{
\textbf{outranking-based non-compensatory sorting}
}
\]

within:

```text
qualification / gate
outranking / sorting              ← ELECTRE Tri-nC
near-Pareto / MGA / MAA
interactive aspiration navigation
preference programming / GPP
normalized global criterion
linear weighted sum
Pareto efficiency
```

It should not be merged with:

- gate-based MCDA;
- GPP;
- NGC;
- Pareto;
- MGA.

Its mathematical and decision semantics are sufficiently distinct to justify its own comparator slot.

---

# 25. Safe claims

Supported:

> ELECTRE Tri-nC and CNPW instantiate different forms of non-compensation.

> ELECTRE's native output is an ordered category or interval; CNPW's native Mode-A output is a highest jointly qualified candidate set.

> The same healthcare category interval contains materially different CNPW weakest-response qualification levels.

> CNPW's response-subset compatibility and highest-joint-qualification diagnostics are not primary ELECTRE sorting outputs.

> ELECTRE provides stronger mature elicitation and pseudo-criterion semantics than basic CNPW Mode A.

Avoid:

> CNPW is more non-compensatory than ELECTRE.

> ELECTRE allows arbitrary compensation.

> ELECTRE weights are equivalent to weighted-sum utility coefficients.

> ELECTRE C4–C5 is equivalent to CNPW GL3.

> CNPW proves the published risk categories are wrong.

> CNPW universally outperforms ELECTRE.

---

# 26. Manuscript-ready methodology paragraph

> ELECTRE Tri-nC was selected as the representative outranking-based non-compensatory comparator because it addresses multi-criteria conflict through a fundamentally different decision object. ELECTRE combines criterion voting weights with indifference, preference and veto thresholds to evaluate the credibility of outranking relations relative to predefined category reference actions, ultimately assigning each alternative to an ordered category or category interval. CNPW does not reproduce this sorting mechanism. Instead, it constructs response-wise qualification levels over a frozen candidate library and identifies the highest common qualification simultaneously satisfied across all active responses. The comparison therefore targets two different forms of non-compensation—outranking with veto versus conjunctive qualification—rather than a compensatory/non-compensatory dichotomy.

---

# 27. Manuscript-ready comparison paragraph

> In the healthcare case, the two paradigms were applied to the same 20-quarter, 12-criterion performance matrix. All three quarters attaining the highest CNPW Global Level belonged to the most favourable ELECTRE interval observed in the base study, indicating broad top-level compatibility. Nevertheless, the nine quarters assigned to the same C4–C5 ELECTRE interval exhibited CNPW common qualifications spanning GL1–GL3. Thus, category agreement under outranking did not imply equivalent weakest-response joint qualification. This empirical distinction supports CNPW as a complementary qualification-centred decision-space diagnostic rather than as a replacement for ELECTRE sorting.

---

# 28. Final File-218 verdict

\[
\boxed{
\textbf{KEEP — formal core comparator.}
}
\]

ELECTRE Tri-nC removes several weak novelty claims but does not make CNPW redundant.

The surviving distinction is:

\[
\boxed{
\text{ELECTRE Tri-nC}
=
\text{expert-parameterized outranking classification}
}
\]

versus:

\[
\boxed{
\text{CNPW}
=
\text{qualification-centred interrogation of a finite candidate decision space}.
}
\]

The same-data healthcare case supplies empirical evidence that these different architectures produce different internal decision structures even when their broad favourable-period conclusions are compatible.

This is the final File-218-standard methodological position.
