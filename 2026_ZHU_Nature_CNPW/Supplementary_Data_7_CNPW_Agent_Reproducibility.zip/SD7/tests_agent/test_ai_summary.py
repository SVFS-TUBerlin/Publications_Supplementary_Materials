import unittest
from pathlib import Path
from agent.dual_coordinator import DualAnalysisCoordinator
from agent.ai_summary import build_fact_packet, summarize_verified_facts

ROOT = Path(__file__).resolve().parents[1]
class Fake:
    def summarize(self, packet):
        return {"summary_contract_version":"0.1","overview":"The verified modes are reported separately.","mode_a_interpretation":"Equal-priority qualification is reported.","mode_b_interpretation":"Mode B is a predefined companion analysis.","comparison_interpretation":"The verified relation is reported.","scope_note":"Scope is bounded."}
class AiSummaryTests(unittest.TestCase):
    def test_packet_is_bounded_and_summary_is_separate(self):
        dual=DualAnalysisCoordinator(ROOT).execute(ROOT/'tests_agent'/'fixtures'/'small_m3.csv').result
        packet=build_fact_packet(dual)
        text=str(packet)
        self.assertNotIn('candidate_ids', text)
        self.assertNotIn('terminal_candidate_ids', text)
        self.assertEqual('AI_SUMMARY_AVAILABLE', summarize_verified_facts(packet, Fake()).status)
        self.assertEqual('AI_SUMMARY_UNAVAILABLE', summarize_verified_facts(packet, None).status)
if __name__ == '__main__': unittest.main()
