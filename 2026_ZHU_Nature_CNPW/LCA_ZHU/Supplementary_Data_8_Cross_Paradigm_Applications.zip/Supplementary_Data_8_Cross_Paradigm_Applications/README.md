# Supplementary Data 8 — Cross-paradigm applications of CNPW to published decision systems

## Purpose

Supplementary Data 8 provides the complete **claim-specific** reconstruction and audit package for the nine external applications reported in Results 2.3 and Table 1.

“Complete” in this package means:

> every manuscript claim has an inspectable chain from the published/native decision object and reconstructed/frozen candidate–response population to the reported CNPW evaluation or diagnosis.

It does **not** mean that every external case is forced to display every CNPW branch. The nine source methods answer different decision questions, so the evidence package preserves only the Mode-A, Mode-B, Stage-2, QCCA, recovery or positive-control objects actually used for the corresponding manuscript claims.

## Evidence architecture

`source / reconstruction evidence → frozen candidate–response representation → native output record → CNPW result → claim-specific diagnosis → verification ledger`

Each `CASES/CaseXX_*` folder contains:
- `CASE_REPORT.md`
- `CLAIM_LEDGER.csv`
- `EVIDENCE/` — supplied source-aligned reconstruction/execution objects
- `DERIVED_AUDIT/` — compact audits that expose the arithmetic behind Table-1 headline claims

Top-level files:
- `MASTER_CLAIM_LEDGER.csv`
- `MASTER_CLAIM_LEDGER.xlsx`
- `CROSS_PARADIGM_APPLICATION_SUMMARY.csv`
- `PROVENANCE_AND_CLAIM_BOUNDARIES.csv`
- `EVIDENCE_INVENTORY.csv`
- `MANIFEST.csv`
- `SHA256SUMS.txt`

## Scientific boundary

CNPW does not re-label the native methods as wrong. Native rankings, categories, robust choices, Pareto endpoints, near-optimal portfolios and lexicographic solutions retain their source semantics. CNPW adds a common qualification and candidate-space diagnostic representation that asks whether stronger joint qualification is already attainable, whether the candidate space itself is limiting, and which response compositions govern recovery.

The external cases are heterogeneous. Model-generated libraries, direct published matrices, author-repository data, synthetic benchmarks and digitized process trajectories are therefore distinguished explicitly in the case reports and provenance table.

## Authority

The current manuscript/Table-1 scientific statements and the supplied final case evidence are the authority for this package. Historical summaries are retained only where they support those claims and do not override later frozen results. In particular, the MGCA conditional residual-QCCA audit distinguishes full-system leave-one-out capability from the source-native protected-budget residual diagnosis.

## Redistribution

Source papers are cited but are not redistributed. Evidence objects included here are the supplied reconstruction, execution, audit and author-derived files used to support the manuscript claims. Source-specific caveats are recorded in `PROVENANCE_AND_CLAIM_BOUNDARIES.csv`.


## Final-formalism repair note (v1.6.0)

Three legacy evidence branches were replaced after adversarial audit:

- **Case05 Pesticide:** Stage 2 was replayed under the final adaptive Local formalism. The manuscript headline counts remain unchanged; the Okra-I terminal set is corrected to scenarios 6584/6585.
- **Case06 MGCA:** protected-domain membership is frozen to the source-native MGA budget batches. This reproduces 87/166/252/340/418 unique admissible portfolios while explicitly separating native budget membership from solver-level realized-cost residuals. All-active-response Mode-B Stage 2 and conditional QCCA reproduce the manuscript claims.
- **Case09 ALEM:** the representative dual-GL7 branch now applies all-active-response Stage 2. Lex-ranks 26 and 29 are co-terminal; both retain the reported Global profile (7,7,4,3).

Legacy evidence files carrying the superseded fixed-Local or residual-only Stage-2 semantics were removed from the final SD8 package.
