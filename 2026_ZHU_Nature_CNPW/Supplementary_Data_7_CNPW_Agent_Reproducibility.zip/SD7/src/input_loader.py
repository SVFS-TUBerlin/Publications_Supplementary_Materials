"""Raw positional CSV/XLSX reader. No third-party dependency is required."""
from __future__ import annotations

import csv
import re
import zipfile
from decimal import Decimal, InvalidOperation
from pathlib import Path
from xml.etree import ElementTree as ET

from .models import Criterion, Dataset

NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


class InputError(ValueError):
    pass


def _text(value: object) -> str:
    return "" if value is None else str(value).strip()


def _column_index(reference: str) -> int:
    letters = re.match(r"([A-Z]+)", reference).group(1)
    number = 0
    for char in letters:
        number = number * 26 + ord(char) - ord("A") + 1
    return number - 1


def _read_csv(path: Path) -> list[list[str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return [row for row in csv.reader(handle)]


def _read_xlsx(path: Path) -> list[list[str]]:
    with zipfile.ZipFile(path) as archive:
        shared: list[str] = []
        if "xl/sharedStrings.xml" in archive.namelist():
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            shared = ["".join(node.itertext()) for node in root.findall(f"{NS}si")]
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        relationship_id = workbook.find(f"{NS}sheets/{NS}sheet").attrib["{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"]
        rels = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        target = next(node.attrib["Target"] for node in rels if node.attrib.get("Id") == relationship_id)
        normalized_target = target.lstrip("/")
        sheet_path = normalized_target if normalized_target.startswith("xl/") else "xl/" + normalized_target
        root = ET.fromstring(archive.read(sheet_path))
        rows: list[list[str]] = []
        for row in root.findall(f".//{NS}sheetData/{NS}row"):
            cells: dict[int, str] = {}
            for cell in row.findall(f"{NS}c"):
                index = _column_index(cell.attrib["r"])
                kind = cell.attrib.get("t")
                value = cell.find(f"{NS}v")
                if kind == "inlineStr":
                    inline = cell.find(f"{NS}is")
                    cells[index] = "" if inline is None else "".join(inline.itertext())
                elif value is None:
                    cells[index] = ""
                elif kind == "s":
                    cells[index] = shared[int(value.text)]
                elif kind == "b":
                    cells[index] = "TRUE" if value.text == "1" else "FALSE"
                else:
                    cells[index] = value.text or ""
            width = max(cells, default=-1) + 1
            rows.append([cells.get(i, "") for i in range(width)])
        return rows


def _cell(rows: list[list[str]], row: int, column: int) -> str:
    return rows[row][column] if row < len(rows) and column < len(rows[row]) else ""


def load_dataset(filename: str | Path) -> Dataset:
    path = Path(filename)
    suffix = path.suffix.lower()
    if suffix == ".csv":
        rows, file_format = _read_csv(path), "CSV"
    elif suffix == ".xlsx":
        rows, file_format = _read_xlsx(path), "XLSX"
    else:
        raise InputError("Input file must be .csv or .xlsx.")
    if len(rows) < 3:
        raise InputError("Input requires title row, direction row, and at least one candidate row.")
    candidate_ids: list[str] = []
    criteria: list[Criterion] = []
    for column in range(1, 11):
        title = _text(_cell(rows, 0, column))
        if title:
            rule = _text(_cell(rows, 1, column))
            if rule not in {"0", "1"}:
                raise InputError(f"Active Result slot '{title}' must have direction rule exactly 0 or 1.")
            criteria.append(Criterion(title, column, "maximize" if rule == "1" else "minimize"))
        elif any(_text(_cell(rows, row, column)) for row in range(2, len(rows))):
            raise InputError(f"Blank Result slot {column + 1} contains candidate data.")
    if len(criteria) < 2:
        raise InputError("At least two active Result slots are required.")
    descriptor_columns = list(range(11, max(len(row) for row in rows)))
    descriptor_names = [_text(_cell(rows, 0, column)) or f"Column {column + 1} (untitled)" for column in descriptor_columns]
    values: list[list[Decimal]] = []
    descriptors: list[list[str]] = []
    seen: set[str] = set()
    for row_number in range(2, len(rows)):
        candidate_id = _text(_cell(rows, row_number, 0))
        if not candidate_id:
            raise InputError(f"Candidate ID is blank at input row {row_number + 1}.")
        if candidate_id in seen:
            raise InputError(f"Duplicate Candidate ID: {candidate_id}.")
        seen.add(candidate_id)
        record: list[Decimal] = []
        for criterion in criteria:
            raw = _text(_cell(rows, row_number, criterion.column))
            if not raw:
                raise InputError(f"Missing result '{criterion.name}' for Candidate ID {candidate_id}.")
            try:
                numeric = Decimal(raw)
            except InvalidOperation as error:
                raise InputError(f"Result '{criterion.name}' for Candidate ID {candidate_id} is not numeric.") from error
            if not numeric.is_finite():
                raise InputError(f"Result '{criterion.name}' for Candidate ID {candidate_id} must be finite.")
            record.append(numeric)
        candidate_ids.append(candidate_id)
        values.append(record)
        descriptors.append([_cell(rows, row_number, column) for column in descriptor_columns])
    return Dataset(str(path), file_format, criteria, descriptor_names, candidate_ids, values, descriptors)
