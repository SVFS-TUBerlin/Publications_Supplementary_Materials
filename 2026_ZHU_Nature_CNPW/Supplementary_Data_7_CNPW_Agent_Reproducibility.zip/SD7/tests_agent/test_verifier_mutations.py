import copy
import unittest
from dataclasses import replace
from pathlib import Path

from agent.core_adapter import CoreAdapter
from agent.input_guard import InputGuard
from agent.qcca_pipeline import run_core_qcca
from agent.qcca_verifier import verify_qcca
from agent.result_builder import build_result
from agent.verifier import verify_result
from agent.dual_coordinator import DualAnalysisCoordinator
from src.stage2 import assign_stage2
from src.terminal import prune_terminal


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "tests_agent" / "fixtures" / "small_m3.csv"


class VerifierMutationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.task = InputGuard().validate(SOURCE, "MODE_A").task
        cls.execution = CoreAdapter().execute(cls.task)
        cls.result = build_result(cls.execution)

    def verify(self, value):
        return verify_result(self.task, value, self.execution.dataset.candidate_ids, SOURCE)

    def test_corrupted_global_matrix_fails(self):
        value = copy.deepcopy(self.result)
        current = value["stage_1"]["per_criterion_global_trace"]["gl"][0][0]
        value["stage_1"]["per_criterion_global_trace"]["gl"][0][0] = 2 if current == 1 else 1
        self.assertFalse(self.verify(value).passed)

    def test_corrupted_stage_summary_fails(self):
        value = copy.deepcopy(self.result)
        value["stage_1"]["retained_candidate_ids"] = []
        self.assertFalse(self.verify(value).passed)

    def test_corrupted_terminal_identity_fails(self):
        value = copy.deepcopy(self.result)
        value["terminal"]["terminal_candidate_ids"] = [self.execution.dataset.candidate_ids[0]]
        self.assertFalse(self.verify(value).passed)

    def test_corrupted_qcca_matrix_fails(self):
        outcome = run_core_qcca(self.execution.dataset, self.execution.core_result, "GLOBAL")
        self.assertTrue(outcome.verification.passed)
        rows = [list(row) for row in outcome.result.level_matrix]
        rows[0][0] = 1 if rows[0][0] != 1 else outcome.result.global_level_count
        corrupted = replace(outcome.result, level_matrix=tuple(tuple(row) for row in rows))
        self.assertFalse(verify_qcca(corrupted, outcome.result.full_system_ceiling).passed)


class A01ContractBindingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = ROOT / "CNPW_PLA_MEX_7056_Core_Input_v0.2.csv"
        cls.task = InputGuard().validate(cls.source, "MODE_A").task
        cls.execution = CoreAdapter().execute(cls.task)
        cls.result = build_result(cls.execution)

    def verify(self, task, value):
        return verify_result(task, value, self.execution.dataset.candidate_ids, self.source)

    def test_coherent_wrong_k_l_8_pg6629_fails(self):
        altered = copy.deepcopy(self.execution.core_result)
        altered.stage2 = assign_stage2(self.execution.dataset, altered.stage1.retained, list(range(4)), 8)
        altered.stage2.local_status = "local_qcca_required"
        altered.stage2.local_qcca_required = True
        altered.profile_class, altered.terminal = prune_terminal(self.execution.dataset, altered.stage2.retained, altered.stage2.ll, list(range(4)))
        value = build_result(replace(self.execution, core_result=altered))
        report = self.verify(self.task, value)
        self.assertEqual(["PG6629"], value["terminal"]["terminal_candidate_ids"])
        self.assertFalse(report.passed)
        self.assertIn("ADAPTIVE_K_L_MATCHES_TASK", report.failures)

    def test_relabelled_e_protected_result_for_uts_task_fails(self):
        uts_task = DualAnalysisCoordinator._mode_b_task(self.task, (0,), 1)
        e_task = DualAnalysisCoordinator._mode_b_task(self.task, (1,), 2)
        e_execution = CoreAdapter().execute(e_task)
        value = build_result(e_execution)
        value["task_id"] = uts_task.task_id
        value["provenance"]["canonical_task_hash_sha256"] = uts_task.task_hash_sha256
        report = verify_result(uts_task, value, e_execution.dataset.candidate_ids, self.source)
        self.assertFalse(report.passed)
        self.assertIn("MODE_B_PROTECTED_INDICES_MATCH_TASK", report.failures)

    def test_false_local_status_fails(self):
        value = copy.deepcopy(self.result)
        value["stage_2"]["local_status"] = "resolved_unique_all_top_local"
        self.assertIn("LOCAL_STATUS_RECOMPUTED", self.verify(self.task, value).failures)

    def test_false_local_qcca_required_fails(self):
        value = copy.deepcopy(self.result)
        value["stage_2"]["local_qcca_required"] = False
        self.assertIn("LOCAL_QCCA_REQUIRED_RECOMPUTED", self.verify(self.task, value).failures)

    def test_missing_adaptive_trace_fails(self):
        value = copy.deepcopy(self.result)
        value["stage_2"]["adaptive_trace"] = []
        self.assertIn("ADAPTIVE_TRACE_RECOMPUTED", self.verify(self.task, value).failures)

    def test_empty_and_partial_local_recovery_targets_fail(self):
        outcome = run_core_qcca(self.execution.dataset, self.execution.core_result, "LOCAL")
        self.assertGreater(len(outcome.result.target_recoveries), 1)
        empty = replace(outcome.result, target_recoveries=())
        partial = replace(outcome.result, target_recoveries=outcome.result.target_recoveries[:-1])
        self.assertIn("RECOVERY_ORDER_OR_SETS", verify_qcca(empty, outcome.result.full_system_ceiling).failures)
        self.assertIn("RECOVERY_ORDER_OR_SETS", verify_qcca(partial, outcome.result.full_system_ceiling).failures)


if __name__ == "__main__": unittest.main()
