from dataclasses import dataclass, field

Subset = tuple[str, ...]


@dataclass(frozen=True)
class AdditionTransition:
    base: Subset; added: str; expanded: Subset; base_ceiling: int; expanded_ceiling: int; delta_gl: int


@dataclass(frozen=True)
class RemovalRecovery:
    removed: str; reduced: Subset; full_ceiling: int; reduced_ceiling: int; delta_gl: int


@dataclass(frozen=True)
class SubsetCapability:
    responses: Subset
    size: int
    capability: int
    supporting_candidate_ids: tuple[str, ...]


@dataclass(frozen=True)
class RecoverySet:
    target: int
    removed_responses: Subset
    retained_responses: Subset
    supporting_candidate_ids: tuple[str, ...]


@dataclass(frozen=True)
class TargetRecovery:
    target: int
    baseline_capability: int
    minimum_recovery_order: int | None
    recovery_sets: tuple[RecoverySet, ...]
    state: str


@dataclass(frozen=True)
class QccaResult:
    # Legacy fields remain first for the existing bounded export.
    criterion_names: tuple[str, ...]
    global_level_count: int
    singleton_ceilings: dict[Subset, int]
    subset_ceilings: dict[Subset, int]
    size_profile: dict[int, dict[int, int]]
    addition_transitions: tuple[AdditionTransition, ...]
    leave_one_out_recoveries: tuple[RemovalRecovery, ...]
    full_system_ceiling: int
    full_system_collapse_depth: int
    first_collapse_order: int | None
    bottleneck_state: str
    representation: str = "GLOBAL"
    mode: str = "MODE_A"
    domain_candidate_ids: tuple[str, ...] = ()
    frozen_source_identity: str = "UNSPECIFIED_LEGACY_INPUT"
    level_matrix: tuple[tuple[int, ...], ...] = ()
    subset_capabilities: tuple[SubsetCapability, ...] = ()
    target_recoveries: tuple[TargetRecovery, ...] = ()
