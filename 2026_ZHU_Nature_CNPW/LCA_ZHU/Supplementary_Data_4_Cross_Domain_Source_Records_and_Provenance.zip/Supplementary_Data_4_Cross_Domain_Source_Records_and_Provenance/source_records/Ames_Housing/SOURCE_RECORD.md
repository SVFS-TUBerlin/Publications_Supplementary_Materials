# Case 05 — Residential housing source record

- **Local archived source:** `AmesHousing.xlsx`
- **Source locator:** AmesHousing sheet
- **Source citation:** De Cock, D. *Ames, Iowa: Alternative to the Boston Housing Data as an End of Semester Regression Project*. Journal of Statistics Education 19(3) (2011). DOI: https://doi.org/10.1080/10691898.2011.11889627
- **Source documentation:** https://jse.amstat.org/v19n3/decock/DataDocumentation.txt
- **Initial source population:** 2,930 property records
- **Candidate filter / population rule:** All 2,930 records retained for the five frozen responses
- **Final CNPW population:** 2930
- **Active responses:** 5
- **Local source SHA256:** `e8fa72b709414ee0b4cd79644005cd78ef7be988751f741130febd45612f11a0`
- **Local source size (bytes):** 973171
- **Redistribution status:** `PROVENANCE_ONLY_ORIGINAL_NOT_BUNDLED`
- **Frozen input:** `CNPW_Case05_Ames_Housing_M5_Input_v0.1.xlsx`

The five retained Ames variables, PID-based Candidate_ID rule and favourable directions are recorded in `Source_to_Input_Mapping.xlsx`. The original third-party workbook is not bundled in SD4.
