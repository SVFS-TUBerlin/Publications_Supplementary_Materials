"""Local-only, QCCA-guided action routes over a frozen Stage-2 domain."""
from collections import defaultdict

from .qcca_models import RecoverySet
from .qcca_analyzer import recovery_for_target
from .qcca_verifier import verify_qcca
from .targeted_relaxation_models import TargetedAlternative, TargetedRelaxationResult


def _dominates(left, right):
    return all(a <= b for a, b in zip(left, right)) and any(a < b for a, b in zip(left, right))


def targeted_relaxation(qcca, recovery: RecoverySet, *, raw_values=None, mode_b_omega_candidate_ids=None) -> TargetedRelaxationResult:
    """Return all real Local alternatives for one verified recovery set.

    The QCCA matrix is already restricted to frozen W(1); this routine has no
    parameter capable of expanding that domain.
    """
    if qcca.representation != "LOCAL":
        raise ValueError("Targeted relaxation is Local-only.")
    # Action may consume only a structurally verified frozen QCCA result and
    # one of its deterministically reconstructed minimum recovery sets.
    if not verify_qcca(qcca, qcca.full_system_ceiling).passed or recovery not in recovery_for_target(qcca, recovery.target).recovery_sets:
        raise ValueError("Targeted relaxation requires a verified minimum QCCA recovery set.")
    names = qcca.criterion_names
    positions = {name: i for i, name in enumerate(names)}
    recovered = tuple(recovery.removed_responses)
    retained = tuple(recovery.retained_responses)
    if not recovered or not retained:
        raise ValueError("A recovery route requires non-empty recovery and retained response blocks.")
    raw_values = tuple(raw_values) if raw_values is not None else None
    if raw_values is not None and len(raw_values) != len(qcca.level_matrix):
        raise ValueError("Raw values must align with the frozen Local domain.")
    omega = None if mode_b_omega_candidate_ids is None else set(mode_b_omega_candidate_ids)
    feasible = []
    for row_index, profile in enumerate(qcca.level_matrix):
        if all(profile[positions[name]] >= recovery.target for name in retained):
            deficit = tuple(max(0, recovery.target - profile[positions[name]]) for name in recovered)
            feasible.append((row_index, tuple(profile), deficit))
    if len(recovered) == 1 and feasible:
        best = max(item[1][positions[recovered[0]]] for item in feasible)
        feasible = [item for item in feasible if item[1][positions[recovered[0]]] == best]
        kind = "SINGLETON_MAXIMUM_MAINTAINED_LEVEL"
    else:
        vectors = {item[2] for item in feasible}
        frontier = {vector for vector in vectors if not any(_dominates(other, vector) for other in vectors if other != vector)}
        feasible = [item for item in feasible if item[2] in frontier]
        kind = "HIGHER_ORDER_NONDOMINATED_DEFICIT_FRONTIER"
    alternatives = tuple(TargetedAlternative(recovery.target, recovered, retained, qcca.domain_candidate_ids[index], profile, deficit, None if raw_values is None else tuple(raw_values[index]), True, None if omega is None else qcca.domain_candidate_ids[index] in omega) for index, profile, deficit in feasible)
    return TargetedRelaxationResult(recovery.target, recovered, retained, alternatives, kind)
