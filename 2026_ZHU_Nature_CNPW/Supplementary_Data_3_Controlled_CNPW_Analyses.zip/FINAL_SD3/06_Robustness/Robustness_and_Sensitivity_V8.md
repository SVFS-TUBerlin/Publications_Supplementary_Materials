# Supplementary Data 3 — CNPW V8 robustness and sensitivity record

## 1. Scope

This file contains robustness analyses on the frozen 7,056-candidate PLA–MEX response space. It does not redefine the V8 algorithm. The formal V8 baseline is:

\[
7056\rightarrow C_G=GL6\rightarrow |W^{(1)}|=65
\rightarrow K_L^*=7\rightarrow C_L=LL4
\rightarrow |W^{(2)}|=3\rightarrow PG6628.
\]

The adaptive Local state machine starts at \(K_L=7\). In the controlled system there is no all-top candidate at that resolution, so \(K_L^*=7\) is frozen immediately and Local QCCA is triggered. Fixed \(K_L=6,8,9\) results below are counterfactual resolution-sensitivity experiments, not alternative formal algorithms.

## 2. Stage-1 threshold sensitivity

The W5 and W6 numerical qualification thresholds were uniformly perturbed by \(\pm1\%\) and \(\pm2\%\) of each response's full candidate-space range.

| Threshold perturbation | W5 N | W5 share | W6 N | W6 share |
|---:|---:|---:|---:|---:|
| -2% | 940 | 13.322% | 188 | 2.664% |
| -1% | 792 | 11.224% | 121 | 1.715% |
| baseline | 643 | 9.113% | 65 | 0.921% |
| +1% | 502 | 7.115% | 19 | 0.269% |
| +2% | 377 | 5.343% | 0 | 0.000% |

Under the primary 26-neighbour convention, every non-empty W5/W6 state above forms one connected component. W5 therefore remains a broader practical qualification region, whereas W6 is a substantially stricter state with limited tightening margin.

## 3. Global-resolution sensitivity

The same 7,056 candidates were audited with \(K_G=6,7,8,9\). This is a robustness experiment only; V8 remains configured at \(K_G=7\).

| \(K_G\) | Highest occupied common level | Common N | Equivalent per-response top fraction | Process-space range |
|---:|---:|---:|---:|---|
| 6 | GL5 | 186 | 33.33% | \(h=0.14\)–0.25, \(P=0.430\)–0.440, \(v=70\)–120 |
| 7 | GL6 | 65 | 28.57% | \(h=0.16\)–0.25, \(P=0.430\)–0.438, \(v=70\)–120 |
| 8 | GL7 | 10 | 25.00% | \(h=0.21\)–0.25, \(P=0.430\)–0.432, \(v=80\)–100 |
| 9 | GL7 | 186 | 33.33% | \(h=0.14\)–0.25, \(P=0.430\)–0.440, \(v=70\)–120 |

Raw GL labels should not be compared directly across different configured resolutions. The robust observation is the repeated localization of the highest common state at low \(P\), intermediate-to-high \(h\), and moderate-to-high \(v\).

## 4. Fixed Local-resolution sensitivity

Holding the formal Stage-1 domain fixed at 65 candidates:

| Fixed \(K_L\) audit | Highest joint Local level | W2 N | Terminal candidate(s) |
|---:|---:|---:|---|
| 6 | LL3 | 8 | PG6628; PG6629 |
| 7 | LL4 | 3 | PG6628 |
| 8 | LL4 | 4 | PG6629 |
| 9 | LL5 | 1 | PG5748 |

The terminal family remains narrow:

\[
\{PG5748,PG6628,PG6629\}.
\]

V8 interpretation: the qualified region is more robust than the identity of a single terminal under counterfactual Local discretizations. The formal adaptive controlled-system run nevertheless stops at its initial \(K_L=7\) because the no-all-top condition is already met there.

## 5. Continuous oriented-rank reference

A discretization-free oriented-percentile reference gives:

\[
Q_{pct}^*=0.770691610
\]

at PG6629 \((h=0.25,P=0.430,v=85)\). This is a sensitivity reference only; it does not replace GL/LL qualification or the V8 terminal rule.

## 6. Validation-error adverse sensitivity

Reserved V1–V4 end-to-end absolute percentage errors are used only to define deterministic adverse-direction stress scenarios.

| Response | External mean APE | External max APE |
|---|---:|---:|
| E | 0.828% | 1.614% |
| UTS | 0.761% | 0.994% |
| GWP | 3.004% | 4.201% |
| FRS | 1.421% | 1.669% |

Applying mean adverse errors leaves W5 with 216 candidates but removes W6. Applying maximum observed adverse errors leaves W5 with 30 candidates and again removes W6. These are empirical stress tests, not confidence intervals or probabilistic guarantees.

## 7. Connectivity sensitivity

Under 26-neighbour adjacency, W6 is one 65-point connected component. Under the stricter axis-adjacent 6-neighbour definition, 61/65 candidates remain in one dominant component and four candidates become isolated: PG2667, PG3107, PG3547 and PG4007. W5 remains connected under both definitions.

The manuscript-safe conclusion is therefore that the highest-qualified process state is geometrically dominated by one coherent process-space region, while its exact topological description depends on the stated adjacency rule.

## 8. V8 boundary

This robustness layer does **not** contain the superseded nominal 0–5% UTS-loss scan, unrestricted all-response relaxation, or old Mode-A subset compatibility tables. Formal Mode-B protection consequences and QCCA recovery structures are provided in the V8 Mode-B and QCCA folders of this SD3 package.

Current Mode B uses the validated residual Stage-1/all-response Stage-2 contract; historical exclusion of old workbooks does not exclude that contract. This wording correction changes no robustness analysis.
