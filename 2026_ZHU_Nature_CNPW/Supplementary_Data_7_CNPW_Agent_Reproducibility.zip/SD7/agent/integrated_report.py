from __future__ import annotations
from decimal import Decimal

from .contracts import stable_json


def _branch_lines(title, branch):
    result = branch["verified_result"]
    if result is None: return [f"### {title}", "", "Technical branch failure; scientific interpretation is suppressed.", ""]
    s1, s2, terminal = result["stage_1"], result["stage_2"], result["terminal"]
    label = "Residual Stage-1 capability" if result.get("mode_b_conditioning") else "Full-system Global capability"
    return [f"### {title}", "", f"- {label}: GL{s1['highest_joint_level']} · |W¹|={len(s1['retained_candidate_ids'])}", f"- All-response Local state: {s2['local_status']} · K_L={s2['k_l']}" + (f" · C_L=LL{s2['highest_joint_level']}" if s2['local_qcca_required'] else ""), f"- Terminal/co-terminal candidates: {', '.join(terminal['terminal_candidate_ids'])}", ""]


def render_presentation_markdown(dual: dict, ai_summary=None, display_filename=None, qcca_outcome=None) -> str:
    a = dual["mode_a"]
    ar = a["verified_result"]
    filename = display_filename or dual["input_identity"].source_name
    criteria = ar["input_summary"]["active_criteria"]
    lines = ["# CNPW V8 Integrated Analysis Report", "", "## 1. Input and scientific contract", "", f"- Filename: {filename}", f"- N: {ar['input_summary']['candidate_count']} · M: {len(criteria)}", f"- Responses, declared order: {', '.join(x['name'] for x in criteria)}", "- One-click execution: Mode A plus every non-empty proper equal-count protected-response block.", "- CNPW selects first; any percentages are reporting-only and never influence qualification, QCCA, recovery, or alternatives.", ""]
    lines += ["## 2. Mode A", ""] + _branch_lines("Mode A deterministic state", a)
    lines += ["## 3. Mode-B protected-domain contract landscape", "", "Protection determines admissibility; residual responses determine Stage-1 conditional capability; all active responses re-enter Stage-2 Local refinement.", "Rows follow protected-block cardinality and declared response order. They are not ranked. Ω_P is the protected admissible population; W_B¹ is the residual Stage-1 retained population.", "", "| Contract | Protected block | k_P | Ω_P size | Residual Stage-1 capability | W_B¹ size | All-response Local state / C_L | Terminal/co-terminal | QCCA/action |", "|---|---|---:|---:|---:|---:|---|---|---|"]
    for branch in dual["mode_b_contracts"]:
        result = branch.get("verified_result")
        if result is None:
            lines.append(f"| {branch['contract_id'][:12]} | technical failure | — | — | — | — | — | — | suppressed |")
            continue
        condition, s1, s2, terminal = result["mode_b_conditioning"], result["stage_1"], result["stage_2"], result["terminal"]
        qstatus = branch.get("local_qcca").status if branch.get("local_qcca") else "NOT_REQUIRED"
        lines.append(f"| {branch['contract_id'][:12]} | {' + '.join(condition['protected_block'])} | GL{condition['k_p']} | {condition['protected_count']} | GL{s1['highest_joint_level']} | {len(s1['retained_candidate_ids'])} | {s2['local_status']}" + (f" / LL{s2['highest_joint_level']}" if s2['local_qcca_required'] else "") + f" | {', '.join(terminal['terminal_candidate_ids'])} | {qstatus} |")
    lines += ["", "## 4. QCCA diagnosis and QCCA-guided alternatives", "", "Global QCCA diagnoses (X, J, G) for Mode A and (Ω_P, J_res, G) for Mode B, excluding protected responses only from the residual Global system. Local QCCA uses all active responses J on frozen W¹, only for a Core-declared Local collapse. Recovery sets and targeted alternatives preserve all equal formal routes; none is preferred.", ""]
    for title, branch in [("Mode A", a), *[(f"Mode B {b['contract_id'][:12]}", b) for b in dual["mode_b_contracts"]]]:
        local = branch.get("local_qcca")
        if local and local.status == "COMPLETED":
            lines += [f"### {title} Local QCCA", "", f"- Baseline C_L: LL{local.result.full_system_ceiling}; targets: {', '.join('LL'+str(x.target) for x in local.result.target_recoveries)}."]
            for action in branch.get("targeted_actions", ()):
                lines.append(f"- Target LL{action['target']}; recovery set {{{', '.join(action['recovery'].removed_responses)}}}; witnesses: {', '.join(x.candidate_id for x in action['result'].alternatives) or 'none'}." )
            lines.append("")
    lines += ["## 5. Verification and provenance", "", f"- Complete public-run verification: {'PASS' if dual['complete_verification'].passed else 'FAILED'}.", f"- Expected/actual Mode-B contracts: {dual['execution']['expected_mode_b_contract_count']}/{dual['execution']['actual_mode_b_contract_count']}.", "- Every Mode-B contract has a deterministic content-derived identity and reuses the frozen full-population Global matrix.", "", "## 6. AI-assisted interpretation", "", "AI-assisted interpretation: Unavailable in this execution." if ai_summary is None else ai_summary.get('overview', 'Unavailable.'), "", "## 7. Limitations", "", "A protected response with a lower Local position remains inside its Stage-1 protected domain; this does not relax or invalidate the protection contract. No weights, scores, preferred contract, preferred recovery set, preferred alternative, SHAP, connectivity, boundary, or process interpretation is provided."]
    return "\n".join(lines)


def render_integrated_markdown(dual, ai_summary=None): return render_presentation_markdown(dual, ai_summary)


def render_integrated_json(dual):
    """Technical export converts QCCA tuple-key maps to deterministic records."""
    def clean(value):
        if isinstance(value, Decimal): return format(value, "f")
        if hasattr(value, "__dataclass_fields__"):
            return {name: clean(getattr(value, name)) for name in value.__dataclass_fields__}
        if isinstance(value, dict): return {str(key): clean(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)): return [clean(item) for item in value]
        return value
    export = dict(dual)
    if export.get("qcca") is not None:
        outcome = export["qcca"]
        export["qcca"] = {"status": outcome.status, "verification": None if outcome.verification is None else {"passed": outcome.verification.passed, "failures": list(outcome.verification.failures)}, "result": None if outcome.result is None else {"criterion_names": list(outcome.result.criterion_names), "subset_ceilings": [{"criteria": list(key), "ceiling": value} for key, value in outcome.result.subset_ceilings.items()], "full_system_ceiling": outcome.result.full_system_ceiling, "leave_one_out_recoveries": clean(outcome.result.leave_one_out_recoveries), "bottleneck_state": outcome.result.bottleneck_state}}
    return stable_json(clean(export))
