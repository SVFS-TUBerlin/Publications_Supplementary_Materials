from decimal import Decimal

from .models import Dataset, K_L, Stage2Result


def assign_stage2(dataset: Dataset, candidate_indices: list[int], criterion_indices: list[int], k_l: int = K_L) -> Stage2Result:
    """Assign direction-aware equal-width Local Levels inside frozen W(1)."""
    if not candidate_indices:
        raise ValueError("Stage 2 requires a non-empty Stage-1 retained set.")
    if k_l < 1:
        raise ValueError("Local resolution must be positive.")
    ll = [[0] * len(dataset.criteria) for _ in dataset.candidate_ids]
    local: dict[str, dict] = {}
    for criterion_index in criterion_indices:
        criterion = dataset.criteria[criterion_index]
        values = [dataset.values[index][criterion_index] for index in candidate_indices]
        minimum, maximum = min(values), max(values)
        response_range = maximum - minimum
        width = response_range / Decimal(k_l)
        thresholds = [minimum + Decimal(level - 1) * width if criterion.direction == "maximize" else maximum - Decimal(level - 1) * width for level in range(1, k_l + 1)]
        for candidate in candidate_indices:
            value = dataset.values[candidate][criterion_index]
            if response_range == 0:
                level = k_l
            elif criterion.direction == "maximize":
                level = max(level for level, threshold in enumerate(thresholds, 1) if value >= threshold)
            else:
                level = max(level for level, threshold in enumerate(thresholds, 1) if value <= threshold)
            ll[candidate][criterion_index] = level
        best = maximum if criterion.direction == "maximize" else minimum
        local[criterion.name] = {"min": minimum, "max": maximum, "range": response_range, "width": width, "thresholds": thresholds, "counts": [sum(ll[i][criterion_index] == level for i in candidate_indices) for level in range(1, k_l + 1)], "best": best}
    q_by_candidate = {candidate: min(ll[candidate][criterion] for criterion in criterion_indices) for candidate in candidate_indices}
    q2 = max(q_by_candidate.values())
    retained = [candidate for candidate in candidate_indices if q_by_candidate[candidate] == q2]
    joint_counts = {level: sum(q >= level for q in q_by_candidate.values()) for level in range(k_l, 0, -1)}
    return Stage2Result(ll, local, joint_counts, q2, retained, k_l=k_l)


def _shortfall(dataset: Dataset, candidate: int, criterion: int, candidates: list[int]) -> Decimal:
    values = [dataset.values[i][criterion] for i in candidates]
    minimum, maximum = min(values), max(values)
    span = maximum - minimum
    if span == 0:
        return Decimal(0)
    value = dataset.values[candidate][criterion]
    return (maximum - value) / span if dataset.criteria[criterion].direction == "maximize" else (value - minimum) / span


def response_equivalent(dataset: Dataset, candidates: list[int], criterion_indices: list[int]) -> bool:
    """Core raw equality is exact Decimal equality; it never invents a winner."""
    first = candidates[0]
    return all(all(dataset.values[i][j] == dataset.values[first][j] for j in criterion_indices) for i in candidates[1:])


def adaptive_stage2(dataset: Dataset, candidate_indices: list[int], criterion_indices: list[int]) -> Stage2Result:
    """Finite event-driven Local refinement.

    Exact interval convention: a candidate is all-top at K iff s_max <= 1/K.
    Its sole exit event is K_exit=floor(1/s_max)+1 for s_max>0.  Starting at
    K=7, only sorted distinct exits above 7 are inspected, so no arbitrary
    cap or no-op K values are used.
    """
    initial = assign_stage2(dataset, candidate_indices, criterion_indices, K_L)
    if len(candidate_indices) == 1:
        initial.local_status = "resolved_unique_highest_global"
        initial.adaptive_trace = [{"k_l": K_L, "all_top": list(candidate_indices), "event": "unique_w1"}]
        return initial
    s_max = {i: max(_shortfall(dataset, i, j, candidate_indices) for j in criterion_indices) for i in candidate_indices}
    exits = sorted({int(Decimal(1) / s) + 1 for s in s_max.values() if s > 0 and int(Decimal(1) / s) + 1 > K_L})
    trace: list[dict] = []
    for k in [K_L, *exits]:
        current = initial if k == K_L else assign_stage2(dataset, candidate_indices, criterion_indices, k)
        all_top = [i for i in candidate_indices if all(current.ll[i][j] == k for j in criterion_indices)]
        trace.append({"k_l": k, "all_top": list(all_top), "event": "initial" if k == K_L else "exit_threshold"})
        if len(all_top) == 1:
            current.local_status = "resolved_unique_all_top_local"
            current.adaptive_trace = trace
            return current
        if not all_top:
            current.local_status = "local_qcca_required"
            current.local_qcca_required = True
            current.adaptive_trace = trace
            return current
    current = initial if not exits else assign_stage2(dataset, candidate_indices, criterion_indices, exits[-1])
    equivalents = [i for i in candidate_indices if s_max[i] == 0]
    if len(equivalents) >= 2 and response_equivalent(dataset, equivalents, criterion_indices):
        current.retained = equivalents
        current.local_status = "co_terminal_response_equivalent"
        current.response_equivalent = True
        current.adaptive_trace = trace
        return current
    raise RuntimeError("Finite Local event sequence ended without a valid scientific state.")
