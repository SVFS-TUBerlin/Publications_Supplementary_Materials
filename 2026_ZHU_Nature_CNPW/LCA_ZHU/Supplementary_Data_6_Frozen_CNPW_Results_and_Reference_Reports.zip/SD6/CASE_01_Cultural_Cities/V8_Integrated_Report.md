# CNPW V8 Integrated Analysis Report

## 1. Input and scientific contract

- Filename: CNPW_H1_Cultural_Cities_2019_M5_Input_v0.1.xlsx
- N: 196 · M: 5
- Responses, declared order: Jobs in arts, culture & entertainment, Museums & art galleries, Cinema attendance, Graduates in arts & humanities, Quality of governance
- One-click execution: Mode A plus every non-empty proper equal-count protected-response block.
- CNPW selects first; any percentages are reporting-only and never influence qualification, QCCA, recovery, or alternatives.

## 2. Mode A

### Mode A deterministic state

- Full-system Global capability: GL5 · |W¹|=7
- All-response Local state: local_qcca_required · K_L=7 · C_L=LL1
- Terminal/co-terminal candidates: Helsinki

## 3. Mode-B protected-domain contract landscape

Protection determines admissibility; residual responses determine Stage-1 conditional capability; all active responses re-enter Stage-2 Local refinement.
Rows follow protected-block cardinality and declared response order. They are not ranked. Ω_P is the protected admissible population; W_B¹ is the residual Stage-1 retained population.

| Contract | Protected block | k_P | Ω_P size | Residual Stage-1 capability | W_B¹ size | All-response Local state / C_L | Terminal/co-terminal | QCCA/action |
|---|---|---:|---:|---:|---:|---|---|---|
| cd6cdc3fdc30 | Jobs in arts, culture & entertainment | GL7 | 28 | GL5 | 3 | local_qcca_required / LL1 | Bern, Helsinki | COMPLETED |
| f98408c619ef | Museums & art galleries | GL7 | 28 | GL5 | 1 | resolved_unique_highest_global | Amsterdam | NOT_REQUIRED |
| 28a8e82e3993 | Cinema attendance | GL7 | 28 | GL4 | 4 | local_qcca_required / LL1 | Namur | COMPLETED |
| 3a78057f2e4f | Graduates in arts & humanities | GL7 | 28 | GL5 | 2 | local_qcca_required / LL1 | Aarhus | COMPLETED |
| 92c7b6f4859b | Quality of governance | GL7 | 28 | GL5 | 3 | local_qcca_required / LL1 | Helsinki | COMPLETED |
| 227d5e0fcd15 | Jobs in arts, culture & entertainment + Museums & art galleries | GL7 | 4 | GL3 | 1 | resolved_unique_highest_global | Copenhagen | NOT_REQUIRED |
| 55d51c95b03f | Jobs in arts, culture & entertainment + Cinema attendance | GL7 | 6 | GL3 | 2 | local_qcca_required / LL1 | Santiago | COMPLETED |
| 53760c555ad8 | Jobs in arts, culture & entertainment + Graduates in arts & humanities | GL7 | 4 | GL3 | 3 | local_qcca_required / LL1 | Mainz | COMPLETED |
| 712c993adff8 | Jobs in arts, culture & entertainment + Quality of governance | GL7 | 3 | GL5 | 1 | resolved_unique_highest_global | Helsinki | NOT_REQUIRED |
| 7b4f39e68733 | Museums & art galleries + Cinema attendance | GL7 | 8 | GL4 | 2 | local_qcca_required / LL1 | Bruges | COMPLETED |
| a103b036751e | Museums & art galleries + Graduates in arts & humanities | GL7 | 8 | GL4 | 2 | local_qcca_required / LL1 | Odense | COMPLETED |
| e746ff911a13 | Museums & art galleries + Quality of governance | GL7 | 3 | GL5 | 1 | resolved_unique_highest_global | Amsterdam | NOT_REQUIRED |
| fcb2abf81442 | Cinema attendance + Graduates in arts & humanities | GL7 | 6 | GL4 | 1 | resolved_unique_highest_global | Cork | NOT_REQUIRED |
| baa1b6dbc07c | Cinema attendance + Quality of governance | GL6 | 14 | GL5 | 3 | local_qcca_required / LL1 | Graz | COMPLETED |
| 57e651023408 | Graduates in arts & humanities + Quality of governance | GL7 | 4 | GL5 | 1 | resolved_unique_highest_global | Aarhus | NOT_REQUIRED |
| 1edf8f332fbe | Jobs in arts, culture & entertainment + Museums & art galleries + Cinema attendance | GL7 | 2 | GL2 | 2 | resolved_unique_all_top_local | Tartu | NOT_REQUIRED |
| 090bdfa13aa4 | Jobs in arts, culture & entertainment + Museums & art galleries + Graduates in arts & humanities | GL6 | 6 | GL5 | 1 | resolved_unique_highest_global | Helsinki | NOT_REQUIRED |
| 5146d2f0fdb9 | Jobs in arts, culture & entertainment + Museums & art galleries + Quality of governance | GL7 | 1 | GL3 | 1 | resolved_unique_highest_global | Copenhagen | NOT_REQUIRED |
| 06761a8431f8 | Jobs in arts, culture & entertainment + Cinema attendance + Graduates in arts & humanities | GL7 | 2 | GL3 | 1 | resolved_unique_highest_global | Santiago | NOT_REQUIRED |
| f9b10268bf7c | Jobs in arts, culture & entertainment + Cinema attendance + Quality of governance | GL6 | 3 | GL5 | 1 | resolved_unique_highest_global | Bern | NOT_REQUIRED |
| 3a0e97824af5 | Jobs in arts, culture & entertainment + Graduates in arts & humanities + Quality of governance | GL7 | 1 | GL3 | 1 | resolved_unique_highest_global | Utrecht | NOT_REQUIRED |
| 250588d027cb | Museums & art galleries + Cinema attendance + Graduates in arts & humanities | GL7 | 2 | GL4 | 1 | resolved_unique_highest_global | Cork | NOT_REQUIRED |
| e9fa7944ffd8 | Museums & art galleries + Cinema attendance + Quality of governance | GL6 | 6 | GL5 | 2 | local_qcca_required / LL1 | Graz | COMPLETED |
| 6bff50583872 | Museums & art galleries + Graduates in arts & humanities + Quality of governance | GL7 | 1 | GL4 | 1 | resolved_unique_highest_global | Odense | NOT_REQUIRED |
| 92259b1b809b | Cinema attendance + Graduates in arts & humanities + Quality of governance | GL6 | 4 | GL5 | 2 | local_qcca_required / LL1 | Ghent | COMPLETED |
| 1e6c6511dcc2 | Jobs in arts, culture & entertainment + Museums & art galleries + Cinema attendance + Graduates in arts & humanities | GL6 | 2 | GL3 | 1 | resolved_unique_highest_global | Santiago | NOT_REQUIRED |
| 1079368af746 | Jobs in arts, culture & entertainment + Museums & art galleries + Cinema attendance + Quality of governance | GL5 | 10 | GL7 | 2 | local_qcca_required / LL1 | Aarhus | COMPLETED |
| d8dc6bcf7637 | Jobs in arts, culture & entertainment + Museums & art galleries + Graduates in arts & humanities + Quality of governance | GL6 | 3 | GL5 | 1 | resolved_unique_highest_global | Helsinki | NOT_REQUIRED |
| c5d2cb18172c | Jobs in arts, culture & entertainment + Cinema attendance + Graduates in arts & humanities + Quality of governance | GL6 | 2 | GL5 | 1 | resolved_unique_highest_global | Bern | NOT_REQUIRED |
| 342a143b23b5 | Museums & art galleries + Cinema attendance + Graduates in arts & humanities + Quality of governance | GL6 | 1 | GL5 | 1 | resolved_unique_highest_global | Ghent | NOT_REQUIRED |

## 4. QCCA diagnosis and QCCA-guided alternatives

Global QCCA diagnoses (X, J, G) for Mode A and (Ω_P, J_res, G) for Mode B, excluding protected responses only from the residual Global system. Local QCCA uses all active responses J on frozen W¹, only for a Core-declared Local collapse. Recovery sets and targeted alternatives preserve all equal formal routes; none is preferred.

### Mode A Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Cinema attendance}; witnesses: Helsinki.
- Target LL3; recovery set {Cinema attendance}; witnesses: Helsinki.
- Target LL4; recovery set {Jobs in arts, culture & entertainment, Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL4; recovery set {Jobs in arts, culture & entertainment, Museums & art galleries, Quality of governance}; witnesses: Ghent.
- Target LL4; recovery set {Jobs in arts, culture & entertainment, Cinema attendance, Graduates in arts & humanities}; witnesses: Helsinki.
- Target LL4; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities, Quality of governance}; witnesses: Graz.
- Target LL4; recovery set {Museums & art galleries, Graduates in arts & humanities, Quality of governance}; witnesses: Bern.
- Target LL5; recovery set {Jobs in arts, culture & entertainment, Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL5; recovery set {Jobs in arts, culture & entertainment, Museums & art galleries, Quality of governance}; witnesses: Ghent.
- Target LL5; recovery set {Jobs in arts, culture & entertainment, Cinema attendance, Graduates in arts & humanities}; witnesses: Helsinki.
- Target LL5; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities, Quality of governance}; witnesses: Graz.
- Target LL5; recovery set {Museums & art galleries, Graduates in arts & humanities, Quality of governance}; witnesses: Bern.
- Target LL6; recovery set {Jobs in arts, culture & entertainment, Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL6; recovery set {Jobs in arts, culture & entertainment, Museums & art galleries, Quality of governance}; witnesses: Ghent.
- Target LL6; recovery set {Jobs in arts, culture & entertainment, Cinema attendance, Graduates in arts & humanities}; witnesses: Helsinki.
- Target LL6; recovery set {Museums & art galleries, Graduates in arts & humanities, Quality of governance}; witnesses: Bern.
- Target LL7; recovery set {Jobs in arts, culture & entertainment, Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL7; recovery set {Jobs in arts, culture & entertainment, Museums & art galleries, Quality of governance}; witnesses: Ghent.

### Mode B cd6cdc3fdc30 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Jobs in arts, culture & entertainment, Cinema attendance}; witnesses: Helsinki.
- Target LL2; recovery set {Museums & art galleries, Quality of governance}; witnesses: Bern.
- Target LL3; recovery set {Jobs in arts, culture & entertainment, Cinema attendance}; witnesses: Helsinki.
- Target LL3; recovery set {Museums & art galleries, Quality of governance}; witnesses: Bern.
- Target LL4; recovery set {Jobs in arts, culture & entertainment, Cinema attendance}; witnesses: Helsinki.
- Target LL4; recovery set {Museums & art galleries, Quality of governance}; witnesses: Bern.
- Target LL5; recovery set {Jobs in arts, culture & entertainment, Cinema attendance}; witnesses: Helsinki.
- Target LL5; recovery set {Museums & art galleries, Quality of governance}; witnesses: Bern.
- Target LL6; recovery set {Jobs in arts, culture & entertainment, Cinema attendance}; witnesses: Helsinki.
- Target LL6; recovery set {Museums & art galleries, Quality of governance}; witnesses: Bern.
- Target LL7; recovery set {Jobs in arts, culture & entertainment, Cinema attendance}; witnesses: Helsinki.
- Target LL7; recovery set {Museums & art galleries, Quality of governance}; witnesses: Bern.

### Mode B 28a8e82e3993 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Jobs in arts, culture & entertainment, Quality of governance}; witnesses: Cork.
- Target LL2; recovery set {Museums & art galleries, Graduates in arts & humanities}; witnesses: Namur.
- Target LL2; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Bruges.
- Target LL3; recovery set {Jobs in arts, culture & entertainment, Quality of governance}; witnesses: Cork.
- Target LL3; recovery set {Museums & art galleries, Graduates in arts & humanities}; witnesses: Namur.
- Target LL3; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Bruges.
- Target LL4; recovery set {Jobs in arts, culture & entertainment, Quality of governance}; witnesses: Cork.
- Target LL4; recovery set {Museums & art galleries, Graduates in arts & humanities}; witnesses: Namur.
- Target LL5; recovery set {Museums & art galleries, Graduates in arts & humanities}; witnesses: Namur.
- Target LL6; recovery set {Museums & art galleries, Graduates in arts & humanities}; witnesses: Namur.
- Target LL7; recovery set {Jobs in arts, culture & entertainment, Museums & art galleries, Quality of governance}; witnesses: Cork.
- Target LL7; recovery set {Jobs in arts, culture & entertainment, Cinema attendance, Graduates in arts & humanities}; witnesses: Bruges.
- Target LL7; recovery set {Museums & art galleries, Cinema attendance, Graduates in arts & humanities}; witnesses: Namur.

### Mode B 3a78057f2e4f Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL3; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL4; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL5; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL6; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL7; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Aarhus.

### Mode B 92c7b6f4859b Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Cinema attendance}; witnesses: Helsinki.
- Target LL3; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Helsinki.
- Target LL4; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Helsinki.
- Target LL5; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Helsinki.
- Target LL6; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Helsinki.
- Target LL7; recovery set {Jobs in arts, culture & entertainment, Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL7; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities, Quality of governance}; witnesses: Amsterdam.

### Mode B 55d51c95b03f Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Cinema attendance, Quality of governance}; witnesses: Santiago.
- Target LL3; recovery set {Cinema attendance, Quality of governance}; witnesses: Santiago.
- Target LL4; recovery set {Cinema attendance, Quality of governance}; witnesses: Santiago.
- Target LL5; recovery set {Cinema attendance, Quality of governance}; witnesses: Santiago.
- Target LL6; recovery set {Cinema attendance, Quality of governance}; witnesses: Santiago.
- Target LL7; recovery set {Cinema attendance, Quality of governance}; witnesses: Santiago.

### Mode B 53760c555ad8 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Museums & art galleries}; witnesses: Mainz.
- Target LL3; recovery set {Museums & art galleries}; witnesses: Mainz.
- Target LL4; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Mainz.
- Target LL4; recovery set {Graduates in arts & humanities, Quality of governance}; witnesses: Santiago.
- Target LL5; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Mainz.
- Target LL5; recovery set {Graduates in arts & humanities, Quality of governance}; witnesses: Santiago.
- Target LL6; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Mainz.
- Target LL7; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities, Quality of governance}; witnesses: Santiago.
- Target LL7; recovery set {Museums & art galleries, Cinema attendance, Quality of governance}; witnesses: Mainz.

### Mode B 7b4f39e68733 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Bruges.
- Target LL3; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Bruges.
- Target LL4; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Bruges.
- Target LL5; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Bruges.
- Target LL6; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Bruges.
- Target LL7; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Bruges.

### Mode B a103b036751e Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Odense.
- Target LL3; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Odense.
- Target LL4; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Odense.
- Target LL5; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Odense.
- Target LL6; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Odense.
- Target LL7; recovery set {Cinema attendance, Graduates in arts & humanities}; witnesses: Odense.

### Mode B baa1b6dbc07c Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities}; witnesses: Graz.
- Target LL2; recovery set {Jobs in arts, culture & entertainment, Quality of governance}; witnesses: Ghent.
- Target LL3; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities}; witnesses: Graz.
- Target LL3; recovery set {Jobs in arts, culture & entertainment, Quality of governance}; witnesses: Ghent.
- Target LL4; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities}; witnesses: Graz.
- Target LL4; recovery set {Jobs in arts, culture & entertainment, Quality of governance}; witnesses: Ghent.
- Target LL5; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities}; witnesses: Graz.
- Target LL6; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities}; witnesses: Graz.
- Target LL7; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities}; witnesses: Graz.

### Mode B e9fa7944ffd8 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities}; witnesses: Graz.
- Target LL3; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities}; witnesses: Graz.
- Target LL4; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities}; witnesses: Graz.
- Target LL5; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities}; witnesses: Graz.
- Target LL6; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities}; witnesses: Graz.
- Target LL7; recovery set {Jobs in arts, culture & entertainment, Graduates in arts & humanities}; witnesses: Graz.

### Mode B 92259b1b809b Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Jobs in arts, culture & entertainment}; witnesses: Ghent.
- Target LL3; recovery set {Jobs in arts, culture & entertainment}; witnesses: Ghent.
- Target LL4; recovery set {Jobs in arts, culture & entertainment}; witnesses: Ghent.
- Target LL5; recovery set {Jobs in arts, culture & entertainment}; witnesses: Ghent.
- Target LL6; recovery set {Jobs in arts, culture & entertainment}; witnesses: Ghent.
- Target LL7; recovery set {Jobs in arts, culture & entertainment}; witnesses: Ghent.

### Mode B 1079368af746 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL3; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL4; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL5; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL6; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Aarhus.
- Target LL7; recovery set {Museums & art galleries, Cinema attendance}; witnesses: Aarhus.

## 5. Verification and provenance

- Complete public-run verification: PASS.
- Expected/actual Mode-B contracts: 30/30.
- Every Mode-B contract has a deterministic content-derived identity and reuses the frozen full-population Global matrix.

## 6. AI-assisted interpretation

AI-assisted interpretation: Unavailable in this execution.

## 7. Limitations

A protected response with a lower Local position remains inside its Stage-1 protected domain; this does not relax or invalidate the protection contract. No weights, scores, preferred contract, preferred recovery set, preferred alternative, SHAP, connectivity, boundary, or process interpretation is provided.