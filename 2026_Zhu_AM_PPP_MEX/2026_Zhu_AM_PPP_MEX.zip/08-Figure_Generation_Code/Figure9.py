#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Figure 9: final seven-coefficient, measured-porosity-conditioned UTS model.

Requires: Python 3.9+, numpy, pandas, matplotlib, Roboto Regular (preferred).
Usage from folder containing this script and both CSV inputs:
    python Figure9_UTS_7coeff_plot.py
    python Figure9_UTS_7coeff_plot.py --output-dir "D:/soft/3"
Outputs PDF (vector), 600-dpi PNG, SVG (vector), plotting data and line data CSV.

Provenance:
  - The 81 Main specimen values and 27 condition means are supplied measurements.
  - Full-sample seven-parameter coefficients below are frozen archival coefficients.
  - LOOCV predictions are recomputed by leaving out one *condition* at a time
    using the identical seven-term design, NOT from the in-sample fitted lines.
  - Speeds are not individually refit; only globally fitted 27-point models
    enter the conditional lines and the 27-fold LOOCV calculation.
  - Global panel (a) alone uses a separate 27-point simple OLS model.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D
import matplotlib.patheffects as pe
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
RAW_NAME = 'Figure9_UTS_81_original_specimens.csv'
CONDITION_NAME = 'Figure9_UTS_27_conditions_plotdata.csv'
STEM = 'Figure9_UTS_7coeff_Final'

# Feature columns: C(0.10), C(0.20), C(0.25), F, V, H*V, F*V
COEFF = np.array([50.57631285, 49.92428097, 49.58437633,
                  -3.18593157, 0.25017994, -0.44000981, -0.59510753])
H_LEVELS = (0.10, 0.20, 0.25)
P_LEVELS = (0.43, 0.45, 0.47)
SPEED_LEVELS = (20, 70, 120)
P_COLORS = {0.43: '#1f77b4', 0.45: '#ff7f0e', 0.47: '#2ca02c'}
H_MARKERS = {0.10: 'o', 0.20: '^', 0.25: 's'}
H_LINESTYLES = {0.10: 'solid', 0.20: (0, (5, 2.5)), 0.25: (0, (1.25, 2.0))}

# Preserve Figure 8 production layout and typographic scale.
WIDTH_MM, HEIGHT_MM, DPI = 190.0, 175.0, 600
SIZES = {'panel': 11, 'axis': 11, 'tick': 9, 'metric': 9}
LAYOUT = dict(left=.105, right=.928, bottom=.085, top=.965,
              wspace=.20, hspace=.18)
POINT_SIZE, POINT_ALPHA = 25, .60
ERROR_CAPSIZE, ERROR_LINEWIDTH, ERROR_ALPHA = 2.0, .8, .65
AXIS_COLOR = '#263642'
LINE_COLOR = '#42474b'
X_BOUNDS = (5.7, 16.0)
Y_BOUNDS = (45.3, 54.6)


def design_matrix(h, v, phi):
    """Seven columns in the exact archival coefficient order."""
    h, v, phi = np.broadcast_arrays(
        np.asarray(h, dtype=float), np.asarray(v, dtype=float),
        np.asarray(phi, dtype=float))
    f = (phi - 10.0) / 5.0
    h_scaled = (h - .20) / .10
    v_scaled = (v - 70.0) / 50.0
    return np.column_stack(
        [np.isclose(h, hv).astype(float) for hv in H_LEVELS] +
        [f, v_scaled, h_scaled*v_scaled, f*v_scaled])


def conditional_uts(h, v, phi):
    return design_matrix(h, v, phi) @ COEFF


def effective_slope(v):
    v_scaled = (v - 70.0) / 50.0
    return (COEFF[3] + COEFF[6]*v_scaled)/5.0  # MPa per porosity percentage point


def ordinary_line(x, y):
    return np.linalg.lstsq(
        np.column_stack((np.ones(len(x)), x)), y, rcond=None)[0]


def scores(y, pred):
    y = np.asarray(y, dtype=float)
    pred = np.asarray(pred, dtype=float)
    return dict(R2=float(1.0 - np.sum((y-pred)**2)/np.sum((y-y.mean())**2)),
                MAE=float(np.mean(np.abs(y-pred))),
                RMSE=float(np.sqrt(np.mean((y-pred)**2))))


def read_and_check_data(input_dir):
    """Recalculate condition summaries from independent specimen rows; audit archived means."""
    raw = pd.read_csv(input_dir / RAW_NAME)
    saved = pd.read_csv(input_dir / CONDITION_NAME)
    assert len(raw) == 81 and len(saved) == 27
    assert set(raw['dataset']) == {'Main'}
    assert set(raw['condition']) == set(saved['condition']) == {f'G{i}' for i in range(1, 28)}
    assert not raw.isnull().values.any() and not saved.isnull().values.any()
    assert set(np.round(raw['h_mm'], 2)) == set(H_LEVELS)
    assert set(np.round(raw['P_mm'], 2)) == set(P_LEVELS)
    assert set(raw['v_mm_s']) == set(SPEED_LEVELS)
    assert all(raw.groupby('condition').size() == 3)
    assert all(raw.groupby(['h_mm', 'v_mm_s']).size() == 9)
    assert len(raw.groupby(['h_mm', 'P_mm', 'v_mm_s'])) == 27

    # Original porosity convention: rho=1.24 g/cm^3; length=180 mm.
    phi_recomputed = 100.0*(1.0 - 1000.0*raw['mass_g'].to_numpy() /
                           (1.24*raw['area_mm2'].to_numpy()*180.0))
    if not np.allclose(phi_recomputed, raw['varphi_vol_pct'], rtol=0, atol=2e-8):
        raise ValueError('Specimen-level volumetric porosity inconsistent with area/mass formula.')

    agg = raw.groupby('condition', sort=False).agg(
        h_mm=('h_mm', 'first'), P_mm=('P_mm', 'first'), v_mm_s=('v_mm_s', 'first'),
        varphi_vol_mean_pct=('varphi_vol_pct', 'mean'),
        UTS_mean_MPa=('UTS_MPa', 'mean'),
        UTS_min_MPa=('UTS_MPa', 'min'),
        UTS_max_MPa=('UTS_MPa', 'max')).reset_index()
    agg = agg.sort_values(['v_mm_s', 'h_mm', 'P_mm']).reset_index(drop=True)
    check = saved.set_index('condition').loc[agg['condition']]
    for col in ('h_mm', 'P_mm', 'v_mm_s', 'varphi_vol_mean_pct',
                'UTS_mean_MPa', 'UTS_min_MPa', 'UTS_max_MPa'):
        if not np.allclose(agg[col].to_numpy(), check[col].to_numpy(), rtol=0, atol=2e-8):
            raise ValueError(f'81 specimens and 27-condition file disagree on {col}.')
    lower = agg['UTS_mean_MPa'] - agg['UTS_min_MPa']
    upper = agg['UTS_max_MPa'] - agg['UTS_mean_MPa']
    if (lower < 0).any() or (upper < 0).any():
        raise ValueError('Incorrect UTS min/mean/max ordering.')
    if not np.allclose(lower, check['UTS_minus_err_MPa'], atol=2e-8, rtol=0):
        raise ValueError('Lower errorbar lengths disagree with archived 27 conditions.')
    if not np.allclose(upper, check['UTS_plus_err_MPa'], atol=2e-8, rtol=0):
        raise ValueError('Upper errorbar lengths disagree with archived 27 conditions.')
    for v in SPEED_LEVELS:
        sub = agg.loc[agg['v_mm_s'] == v]
        assert len(sub) == 9
        for h in H_LEVELS:
            assert set(np.round(sub.loc[np.isclose(sub.h_mm, h), 'P_mm'], 2)) == set(P_LEVELS)
    return agg


def compute_model_and_loocv(data):
    """Use frozen full-fit coefficients; independently reconstruct 27 held-out predictions."""
    phi = data['varphi_vol_mean_pct'].to_numpy()
    h = data['h_mm'].to_numpy()
    v = data['v_mm_s'].to_numpy()
    y = data['UTS_mean_MPa'].to_numpy()
    X = design_matrix(h, v, phi)
    if X.shape != (27, 7) or np.linalg.matrix_rank(X) != 7:
        raise ValueError('Seven-coefficient feature matrix has incorrect rank.')
    coef_from_raw = np.linalg.lstsq(X, y, rcond=None)[0]
    if not np.allclose(coef_from_raw, COEFF, rtol=0, atol=1e-6):
        raise ValueError(f'Archived seven coefficients inconsistent with source data:\n{coef_from_raw}')
    pred_full = X @ COEFF
    pred_loocv = np.empty(27, dtype=float)
    for i in range(27):
        train = np.arange(27) != i
        if np.linalg.matrix_rank(X[train]) != 7:
            raise ValueError(f'LOOCV fold {i} is rank-deficient.')
        coeff_fold = np.linalg.lstsq(X[train], y[train], rcond=None)[0]
        pred_loocv[i] = X[i] @ coeff_fold

    global_coef = ordinary_line(phi, y)
    global_loocv = np.empty(27)
    for i in range(27):
        train = np.arange(27) != i
        ab = ordinary_line(phi[train], y[train])
        global_loocv[i] = ab[0] + ab[1]*phi[i]

    model_scores = scores(y, pred_loocv)
    baseline_scores = scores(y, global_loocv)
    if abs(global_coef[1] - (-.64527679)) > 1e-5 or abs(baseline_scores['R2'] - .834944980) > 1e-5:
        raise ValueError('Global simple-linear regression audit failed.')
    for field, expected in [('R2', .939114039516), ('MAE', .415637326287), ('RMSE', .474058348739)]:
        if abs(model_scores[field] - expected) > 1e-5:
            raise ValueError(f'Seven-coefficient pooled LOOCV {field} audit failed.')
    expected_by_speed = {20: .9230566972, 70: .9344206293, 120: .9415162507}
    speed_scores = {}
    for speed in SPEED_LEVELS:
        sel = v == speed
        speed_scores[speed] = scores(y[sel], pred_loocv[sel])
        if abs(speed_scores[speed]['R2'] - expected_by_speed[speed]) > 1e-5:
            raise ValueError(f'27-fold seven-coefficient LOOCV audit failed for v={speed}.')

    result = data.copy()
    result['UTS_7coeff_full_fit_MPa'] = pred_full
    result['UTS_7coeff_condition_LOOCV_MPa'] = pred_loocv
    result['LOOCV_residual_measured_minus_pred_MPa'] = y - pred_loocv
    result['UTS_simple_global_full_fit_MPa'] = global_coef[0] + global_coef[1]*phi
    result['UTS_simple_global_LOOCV_MPa'] = global_loocv
    result['UTS_minus_err_MPa'] = result['UTS_mean_MPa'] - result['UTS_min_MPa']
    result['UTS_plus_err_MPa'] = result['UTS_max_MPa'] - result['UTS_mean_MPa']
    result['speed_7coeff_phi_slope_MPa_per_pp'] = [effective_slope(k) for k in v]
    return result, global_coef, baseline_scores, model_scores, speed_scores


def setup_style():
    """Match Figure 8's font rules; fall back gracefully on non-Windows systems."""
    try:
        font_path = font_manager.findfont(FontProperties(family='Roboto', weight='normal'),
                                          fallback_to_default=False)
        if not Path(font_path).is_file():
            font_path = None
    except ValueError:
        font_path = None
    if font_path is None:
        candidates = [Path.home() / 'AppData/Local/Microsoft/Windows/Fonts/Roboto-Regular.ttf',
                      Path('C:/Windows/Fonts/Roboto-Regular.ttf')]
        font_path = next((str(p) for p in candidates if p.is_file()), None)
    if font_path:
        font_manager.fontManager.addfont(str(font_path))
        prop = FontProperties(fname=str(font_path))
    else:
        prop = FontProperties(family='DejaVu Sans')
    prop.set_math_fontfamily('stix')
    mpl.rcParams.update({
        'font.family': prop.get_name(), 'font.size': SIZES['tick'],
        'axes.labelsize': SIZES['axis'], 'axes.labelweight': 'normal',
        'axes.linewidth': .8, 'xtick.labelsize': SIZES['tick'],
        'ytick.labelsize': SIZES['tick'], 'axes.grid': False,
        'mathtext.fontset': 'stix', 'text.usetex': False,
        'pdf.fonttype': 42, 'ps.fonttype': 42, 'pdf.compression': 0,
        'svg.fonttype': 'none', 'svg.hashsalt': 'Figure9-seven-coefficient-final',
        'figure.facecolor': 'white', 'axes.facecolor': 'white',
        'savefig.facecolor': 'white',
    })
    return prop


def make_figure(data, global_coef, global_scores, speed_scores, output_dir):
    regular = setup_style()
    fig, axes = plt.subplots(2, 2,
                             figsize=(WIDTH_MM/25.4, HEIGHT_MM/25.4),
                             sharex=True, sharey=True, dpi=180)
    fig.subplots_adjust(**LAYOUT)
    axes = axes.ravel()
    groups = [data] + [data.loc[data.v_mm_s == v].copy() for v in SPEED_LEVELS]

    if (data['varphi_vol_mean_pct'].min() < X_BOUNDS[0] or
        data['varphi_vol_mean_pct'].max() > X_BOUNDS[1] or
        data['UTS_min_MPa'].min() < Y_BOUNDS[0] or
        data['UTS_max_MPa'].max() > Y_BOUNDS[1]):
        raise ValueError('Fixed axis limits would clip real specimen minima/maxima.')
    line_data = []
    for pidx, (ax, group) in enumerate(zip(axes, groups)):
        ax.set_xlim(*X_BOUNDS)
        ax.set_ylim(*Y_BOUNDS)
        ax.set_box_aspect(1)
        ax.grid(False)
        for side in ('top', 'right', 'bottom', 'left'):
            ax.spines[side].set_linewidth(.8)
            ax.spines[side].set_color(AXIS_COLOR)
        ax.tick_params(axis='both', direction='in', length=3, width=.8, pad=4,
                       labelbottom=True, labelleft=True)
        ax.set_xticks([6, 8, 10, 12, 14, 16])
        ax.set_yticks([46, 48, 50, 52, 54])

        # Dark gray model lines first, so real measured points remain visible.
        if pidx == 0:
            lo, hi = group.varphi_vol_mean_pct.agg(['min', 'max'])
            xx = np.linspace(lo, hi, 150)
            yy = global_coef[0] + global_coef[1]*xx
            ax.plot(xx, yy, color=LINE_COLOR, linewidth=1.0, zorder=2.5)
            for x_value, y_value in zip(xx, yy):
                line_data.append(('a', 'global_simple', '', '', x_value, y_value))
            r2 = global_scores['R2']
            slope = global_coef[1]
        else:
            speed = SPEED_LEVELS[pidx-1]
            for h in H_LEVELS:
                # Restrict h-specific lines to the x-domain spanned by that
                # (h, speed) group's three actual P conditions: no global extrapolation.
                sub = group.loc[np.isclose(group.h_mm, h)]
                assert len(sub) == 3
                lo, hi = sub.varphi_vol_mean_pct.agg(['min', 'max'])
                xx = np.linspace(lo, hi, 120)
                yy = conditional_uts(np.full(len(xx), h), np.full(len(xx), speed), xx)
                ax.plot(xx, yy, color=LINE_COLOR, linewidth=1.4,
                        linestyle=H_LINESTYLES[h], zorder=2.5,
                        dash_capstyle='round')
                for x_value, y_value in zip(xx, yy):
                    line_data.append(('abcd'[pidx], 'seven_coeff', speed, h,
                                      x_value, y_value))
            r2 = speed_scores[speed]['R2']
            slope = effective_slope(speed)

        # Observed 3-specimen condition means, plus genuine asymmetric UTS min-max.
        for P in P_LEVELS:
            for _, r in group.loc[np.isclose(group.P_mm, P)].iterrows():
                low = float(r.UTS_minus_err_MPa)
                high = float(r.UTS_plus_err_MPa)
                if min(low, high) < -1e-10:
                    raise ValueError('Negative UTS min-max error-bar extent.')
                bars = ax.errorbar(float(r.varphi_vol_mean_pct), float(r.UTS_mean_MPa),
                                   yerr=[[low], [high]], fmt='none',
                                   capsize=ERROR_CAPSIZE, capthick=ERROR_LINEWIDTH,
                                   elinewidth=ERROR_LINEWIDTH, alpha=ERROR_ALPHA,
                                   ecolor=P_COLORS[P], zorder=3)
                segment = bars.lines[2][0].get_segments()[0]
                ends = [[float(r.varphi_vol_mean_pct), float(r.UTS_min_MPa)],
                        [float(r.varphi_vol_mean_pct), float(r.UTS_max_MPa)]]
                if bars.has_xerr or not bars.has_yerr or not np.allclose(segment, ends, atol=1e-10):
                    raise RuntimeError('Measured UTS errorbar endpoint mismatch.')
                ax.scatter(float(r.varphi_vol_mean_pct), float(r.UTS_mean_MPa),
                           s=POINT_SIZE, marker=H_MARKERS[float(r.h_mm)],
                           c=P_COLORS[P], edgecolors='white', linewidths=.3,
                           alpha=POINT_ALPHA, zorder=4)

        ax.text(.955, .955, rf'$R^2_{{\mathrm{{LOOCV}}}} = {r2:.3f}$',
                transform=ax.transAxes, ha='right', va='top',
                fontsize=SIZES['metric'], zorder=10)
        ax.text(.955, .855, f'Slope = {slope:.3f} MPa/pp',
                transform=ax.transAxes, ha='right', va='top',
                fontsize=SIZES['metric'], zorder=10)
        tag = ax.text(0, 1.025, f'({"abcd"[pidx]})',
                      transform=ax.transAxes, ha='left', va='bottom',
                      fontsize=SIZES['panel'], fontweight='bold',
                      color=AXIS_COLOR, clip_on=False)
        tag.set_path_effects([pe.withStroke(linewidth=.3, foreground=AXIS_COLOR), pe.Normal()])
        if pidx > 0:
            ax.text(1.0, 1.025, rf'$v={SPEED_LEVELS[pidx-1]}$ mm/s',
                    transform=ax.transAxes, ha='right', va='bottom',
                    fontsize=SIZES['metric'], color=AXIS_COLOR, clip_on=False)
        if pidx // 2 == 1:
            ax.set_xlabel(r'Volumetric porosity, $\varphi_{\mathrm{vol}}$ (%)', labelpad=6)
        if pidx % 2 == 0:
            ax.set_ylabel(r'Ultimate tensile strength, UTS (MPa)', labelpad=6)

    # Separate color and combined marker+line-style legends, outside data panels.
    xcenter = (LAYOUT['left']+LAYOUT['right'])/2
    legend_P = [Line2D([0], [0], marker='o', linestyle='none',
                       markerfacecolor=P_COLORS[p], markeredgecolor='white',
                       markeredgewidth=.3, markersize=6,
                       label=fr'$P={p:.2f}$ mm') for p in P_LEVELS]
    legend_h = [Line2D([0], [0], color=LINE_COLOR, linestyle=H_LINESTYLES[h],
                       marker=H_MARKERS[h], markerfacecolor='#697178',
                       markeredgecolor='white', markeredgewidth=.3,
                       linewidth=1.4, markersize=5.5,
                       label=fr'$h={h:.2f}$ mm') for h in H_LEVELS]
    fig.legend(handles=legend_P, ncol=3, loc='upper center',
               bbox_to_anchor=(xcenter, -.012), frameon=False,
               fontsize=SIZES['tick'], borderaxespad=0, handletextpad=.5,
               columnspacing=2.0)
    fig.legend(handles=legend_h, ncol=3, loc='upper center',
               bbox_to_anchor=(xcenter, -.056), frameon=False,
               fontsize=SIZES['tick'], borderaxespad=0, handletextpad=.5,
               columnspacing=2.0, handlelength=2.3)
    footer_inches = 18.0/25.4
    export_bounds = mpl.transforms.Bbox.from_extents(
        0, -footer_inches, fig.get_figwidth(), fig.get_figheight())

    # Apply the same explicit text font handling as Figure 8's production script.
    fig.canvas.draw()
    for txt in fig.findobj(match=mpl.text.Text):
        prop = regular.copy()
        prop.set_size(txt.get_fontsize())
        txt.set_fontproperties(prop)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for txt in fig.findobj(match=mpl.text.Text):
        if txt.get_visible() and txt.get_text():
            box = txt.get_window_extent(renderer)
            if (box.x0 < -1 or box.y0 < -footer_inches*fig.dpi-1 or
                box.x1 > fig.bbox.width+1 or box.y1 > fig.bbox.height+1):
                raise RuntimeError(f'Figure text outside exported page: {txt.get_text()}')
    for ax in axes:
        if len([t for t in ax.get_xticklabels() if t.get_visible() and t.get_text()]) != 6:
            raise RuntimeError('Panel missing one of its six X ticks.')
        if len([t for t in ax.get_yticklabels() if t.get_visible() and t.get_text()]) != 5:
            raise RuntimeError('Panel missing one of its five Y ticks.')
        if any(l.get_visible() for l in ax.get_xgridlines()+ax.get_ygridlines()):
            raise RuntimeError('Background grid visible unexpectedly.')

    output_dir.mkdir(parents=True, exist_ok=True)
    for ext, kwargs in [('pdf', {}), ('svg', {}), ('png', {'dpi': DPI})]:
        fig.savefig(output_dir / f'{STEM}.{ext}', format=ext,
                    bbox_inches=export_bounds, transparent=False, **kwargs)
    plt.close(fig)
    lines = pd.DataFrame(line_data, columns=['panel', 'line_model', 'v_mm_s', 'h_mm',
                                             'varphi_vol_pct', 'UTS_model_MPa'])
    lines.to_csv(output_dir / 'Figure9_UTS_7coeff_line_data.csv', index=False,
                 float_format='%.12f')


def main():
    parser = argparse.ArgumentParser(description='Seven-coefficient conditional UTS Figure 9')
    parser.add_argument('--input-dir', type=Path, default=ROOT)
    parser.add_argument('--output-dir', type=Path, default=ROOT)
    args = parser.parse_args()
    data = read_and_check_data(args.input_dir)
    data, baseline, baseline_scores, overall_scores, by_speed = compute_model_and_loocv(data)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    data.to_csv(args.output_dir / 'Figure9_UTS_7coeff_plotting_data.csv',
                index=False, float_format='%.12f')
    make_figure(data, baseline, baseline_scores, by_speed, args.output_dir)
    summary = []
    summary.append(f'Global simple OLS: LOOCV R² = {baseline_scores["R2"]:.9f}, slope = {baseline[1]:.9f} MPa/pp')
    for v in SPEED_LEVELS:
        summary.append(f'v = {v} mm/s, 7-coeff 27-fold condition LOOCV subset: '
                       f'R² = {by_speed[v]["R2"]:.9f}, '
                       f'RMSE = {by_speed[v]["RMSE"]:.9f} MPa, '
                       f'slope = {effective_slope(v):.9f} MPa/pp')
    summary.append(f'Pooled 7-coeff 27-fold condition LOOCV: '
                   f'R² = {overall_scores["R2"]:.9f}, '
                   f'MAE = {overall_scores["MAE"]:.9f}, RMSE = {overall_scores["RMSE"]:.9f} MPa')
    summary.append('The full-fit seven coefficients are frozen; 27 leave-one-CONDITION-out '
                   'predictions were reconstructed for independent audit, with no model selection.')
    (args.output_dir / 'Figure9_UTS_7coeff_audit.txt').write_text(
        '\n'.join(summary)+'\n', encoding='utf-8')
    print('\n'.join(summary))
    print('Output:', args.output_dir.resolve())


if __name__ == '__main__':
    main()
