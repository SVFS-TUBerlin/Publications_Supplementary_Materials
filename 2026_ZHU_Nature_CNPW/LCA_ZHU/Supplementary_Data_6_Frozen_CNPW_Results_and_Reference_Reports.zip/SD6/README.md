# SD6 — V8_RESIDUAL_MODEB

Official regenerated reference results. 146 six-domain decisions plus 15 controlled decisions. Source inputs remain in unchanged SD5 and the separately hashed controlled author input. Scientific contract: Protection determines admissibility; residual responses determine Stage-1 conditional capability; all active responses re-enter Stage-2 Local refinement.

Global Mode-B QCCA: (Omega_P,J_res,G). Local: (W1,J,L). All 154 Mode-B Global scopes changed; eight contracts also changed Stage-1 capability/population. Old controlled comparison is replay of the archived V8 implementation because the old SD6 contains six domains only. Transport normalization is described in each JSON.
