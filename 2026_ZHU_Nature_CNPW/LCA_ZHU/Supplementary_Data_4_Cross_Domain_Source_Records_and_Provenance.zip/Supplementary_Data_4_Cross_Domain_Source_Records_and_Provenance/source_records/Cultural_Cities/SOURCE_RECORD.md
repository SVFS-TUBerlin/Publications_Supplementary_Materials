# Case 01 — Cultural and creative cities source record

- **Local archived source:** `C3M2023_Data Annex_0.xlsx`
- **Source locator:** Final data sheet; Reference year = 2019
- **Source citation:** Alberti, V. et al. *Cultural and Creative Cities Monitor: 2023 Update*. European Commission, Joint Research Centre, JRC134516 (2023). DOI: https://doi.org/10.2760/975348
- **Official dataset locator:** https://data.jrc.ec.europa.eu/dataset/0febda0d-66f8-4aef-b460-a6f89accc5a2
- **Initial source population:** 592 records across three reference years; 196 cities in the 2019 cross-section
- **Candidate filter / population rule:** Retain Reference year = 2019 only
- **Final CNPW population:** 196
- **Active responses:** 5
- **Local source SHA256:** `56ce9088b490b5bd019c76fdfecca29f6c6d005c49a4c1c4d38f08904148e9b1`
- **Local source size (bytes):** 1226684
- **Redistribution status:** `PROVENANCE_ONLY_ORIGINAL_NOT_BUNDLED`
- **Frozen input:** `CNPW_H1_Cultural_Cities_2019_M5_Input_v0.1.xlsx`

The response-level mapping is recorded in `Source_to_Input_Mapping.xlsx`. The original third-party workbook is not bundled in SD4.
