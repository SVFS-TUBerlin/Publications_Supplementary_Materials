#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Figure 10 | Direct four-panel scientific plotting master.

One Matplotlib figure (not a stitched-image composite).
(a) E process->porosity->property inverse map at v=70 mm/s
(b) E independent-validation results (MEASURED and frozen PIECEWISE B)
(c) UTS process->porosity->property inverse map at h=0.20 mm
(d) UTS independent-validation results (MEASURED and seven-coefficient PPP)

Source provenance: the four user-provided original Python scripts plus the
previously audited frozen-model 31-group and validation-prediction CSVs.
No regression is performed. The frozen speed-conditioned piecewise E model
is retained. UTS uses the selected seven-coefficient conditional model with
process-only predicted porosity from the unchanged upstream Y formulation.

Windows output: D:\\soft\\3\\Figure10_PPP_7coeff_Final.pdf, .png, .svg, and audit.csv
Cross-platform: output beside this script unless FIGURE10_OUTPUT_DIR set.
Install: pip install numpy matplotlib
"""
from __future__ import annotations
import os
import csv
from pathlib import Path
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import ticker, font_manager, patheffects as pe
from matplotlib.font_manager import FontProperties
from matplotlib.patches import Rectangle, Patch
from matplotlib.lines import Line2D

# ======================= CONFIGURE ONLY THESE VALUES ========================
OUT = Path(os.environ.get('FIGURE10_OUTPUT_DIR',
               str(Path(__file__).resolve().parent / 'Regenerated')))
FIG_W_MM, FIG_H_MM = 185.0, 137.0
DPI = 600
# Physical millimetre positions, calibrated for a less dominant left column.
# Each row uses IDENTICAL y/height. Outer top and bottom margins are 14 mm.
# Height: 14 + 47 + 15 + 47 + 14 = 137 mm (perfect vertical symmetry).
# Wider separation between the inverse map/colorbar and validation axes.
LEFT_X, LEFT_W = 18.0, 70.0
CB_X, CB_W = 92.0, 3.3
RIGHT_X, RIGHT_W = 123.0, 56.0
ROW_H, Y_UPPER, Y_LOWER = 47.0, 76.0, 14.0
FIGURE_STEM = 'Figure10_PPP_7coeff_Final'

# Model-target windows in inverse maps, not confidence intervals.
E_TARGET, E_TARGET_TOL = 2400., 10.
UTS_TARGET, UTS_TARGET_TOL = 49., 0.5
# Prediction-centered acceptance windows in validation panels.
E_VALID_TOL, UTS_VALID_TOL = 10., 0.5

P_BOUNDS, H_BOUNDS, V_BOUNDS = (.43, .47), (.10, .25), (20.,120.)
N_GRID_E, N_GRID_UTS_V, N_GRID_UTS_P = 401, 501, 401
COLORMAP='viridis_r'
TARGET_COLOR='#E5B340'
WINDOW_FILL='#FFE6A3'
WINDOW_EDGE='#E5B340'
AXIS_COLOR='#263642'
OBS_COLOR='#287AA1'
PRED_COLOR='#343E47'
STAR_COLOR='#C73535'
FONT={'axis':8.6,'tick':7.3,'note':6.3,'range':6.1,'legend':6.8,'panel':10.0}

# ========================== FROZEN MODEL COEFFICIENTS =======================
# phi (%) = Y(h,P,v) + 100*(1-pi/4)*h/P, Y in percentage points.
# Y_v=a_v+b_v*h+c_v*P+q_v*h^2, piecewise linear interpolation of COEFFICIENTS.
V_NODES = np.array([20.,70.,120.])
Y_COEF = np.array([
    [-49.5271718543019, -145.824466516601, 153.328804741198, 221.291944362916],
    [-65.4345223775051, -45.1564369158113, 166.793836664214, 0.],
    [-70.1392677658163, -32.4351556920786, 175.132068999162, 0.],
])
# E(v)=A(v)+B(v)*(phi-10); both A and B piecewise interpolated at unmeasured speeds.
E_INTERCEPTS = np.array([2458.22743296381,2436.528872972547,2437.6327218978267])
E_SLOPES = np.array([-17.327806259815247,-20.995993650912684,-23.83491332446211])
# Seven-coefficient UTS model; C(h) piecewise interpolated between h nodes.
# F=(predicted phi-10)/5, H=(h-0.20)/0.10, V=(v-70)/50.
# UTS=C(h)+bF*F+bV*V+bHV*H*V+bFV*F*V.
H_NODES=np.array([.10,.20,.25])
UTS_INTERCEPTS=np.array([50.57631285,49.92428097,49.58437633])
UTS_BF=-3.18593157
UTS_BV=0.25017994
UTS_BHV=-0.44000981
UTS_BFV=-0.59510753

# ============= MEASURED MEANS FROM FOUR UPLOADED SOURCE SCRIPTS =============
# These are nine 3-specimen group means, computed per specimen prior to averaging.
# The master is self-contained: it embeds the already-verified measurements;
# values are NOT recolored with model predictions.
E_MAP_EXPERIMENTS = [  # (h, P, measured E [MPa]) at v=70
(.10,.43,2496.4408829490535),(.10,.45,2476.41962215871),(.10,.47,2369.8161601619377),
(.20,.43,2499.764758443325),(.20,.45,2412.787158290395),(.20,.47,2361.3495359049107),
(.25,.43,2479.7112734640996),(.25,.45,2440.79654637075),(.25,.47,2373.042440696005)]
UTS_MAP_EXPERIMENTS = [  # (v, P, measured UTS [MPa]) at h=.20
(20.,.43,51.7079343922827),(20.,.45,50.270474831763714),(20.,.47,48.612413929954364),
(70.,.43,51.64485557117978),(70.,.45,49.41753439430306),(70.,.47,47.86777832385067),
(120.,.43,51.443266743948335),(120.,.45,48.31447194815811),(120.,.47,46.06182184124816)]

# Verified independent V1-V4 (five specimens per condition), all data MPa.
# For the diamond, use FULL process-only PPP predictions, NOT measured porosity.
# E predictions retain their frozen speed-conditioned piecewise model.
# UTS predictions use the seven-coefficient conditional model with predicted porosity.
CASES=('V1','V2','V3','V4')
VALIDATION = [
# case h  P   v   E_mean       E_min         E_max        E_B               U_mean         U_min         U_max        U_B
('V1',0.15,0.45,70.0,2450.76027646877,2415.07897708834,2475.75921828334,2436.473587635616,50.9669375711974,50.7508723913233,51.2592121153097,50.248619113),
('V2',0.2,0.46,70.0,2395.23835871583,2384.60026534379,2408.45164207741,2403.147978010669,49.0720525675286,48.8980846792801,49.2714304333444,48.911237734),
('V3',0.25,0.47,90.0,2327.04463145199,2322.43275347315,2342.05776050473,2347.5084311953533,46.7698584114186,46.5642759484371,47.1737472848426,46.828313151),
('V4',0.1,0.43,90.0,2505.19624205507,2487.80594872199,2515.76525396301,2507.2812074687686,53.0741064244028,52.9305985799207,53.2201745544554,53.027945810),
]
# Predictions use the final conditional fits for E and UTS.
# All predictions are checked against the direct process-only forward chain.


def set_style():
    # Roboto is installed on the user's Windows setup; degrade gracefully elsewhere.
    try:
        path=font_manager.findfont(FontProperties(family='Roboto',weight='normal'),fallback_to_default=False)
        if Path(path).exists(): font_manager.fontManager.addfont(path)
        family='Roboto'
    except ValueError:
        family='DejaVu Sans'
        print('Roboto not installed: using DejaVu Sans. Install Roboto for exact reference typography.')
    mpl.rcParams.update({
        'font.family':family,'font.weight':'normal','font.size':FONT['tick'],
        'axes.labelsize':FONT['axis'],'xtick.labelsize':FONT['tick'],
        'ytick.labelsize':FONT['tick'],'mathtext.fontset':'stix',
        'text.usetex':False,'axes.unicode_minus':True,'axes.linewidth':.75,
        'axes.grid':False,'pdf.fonttype':42,'ps.fonttype':42,
        'svg.fonttype':'none','figure.facecolor':'white',
        'axes.facecolor':'white','savefig.facecolor':'white',
    })


def get_axes(fig, x, y, w, h):
    return fig.add_axes([x/FIG_W_MM,y/FIG_H_MM,w/FIG_W_MM,h/FIG_H_MM])


def porosity_and_Y(h,p,v):
    h,p,v=np.broadcast_arrays(np.asarray(h,float),np.asarray(p,float),np.asarray(v,float))
    if np.any((h<.1-1e-12)|(h>.25+1e-12)|(p<.43-1e-12)|(p>.47+1e-12)|
              (v<20-1e-12)|(v>120+1e-12)):
        raise ValueError('Requested process outside the experimentally studied domain.')
    coeff=[np.interp(v,V_NODES,Y_COEF[:,i]) for i in range(4)]
    Y=coeff[0]+coeff[1]*h+coeff[2]*p+coeff[3]*h*h
    phi=Y+100.*(1.-np.pi/4.)*h/p
    return Y,phi


def predict_E(h,p,v):
    _,phi=porosity_and_Y(h,p,v)
    return np.interp(v,V_NODES,E_INTERCEPTS)+np.interp(v,V_NODES,E_SLOPES)*(phi-10.)


def predict_UTS(h,p,v):
    _,phi=porosity_and_Y(h,p,v)
    C=np.interp(h,H_NODES,UTS_INTERCEPTS)
    F=(phi-10.)/5.
    H=(np.asarray(h,dtype=float)-.20)/.10
    V=(np.asarray(v,dtype=float)-70.)/50.
    return C+UTS_BF*F+UTS_BV*V+UTS_BHV*H*V+UTS_BFV*F*V


def verify_inputs():
    """Hard-stop if the audit dataset/model combination is inconsistent."""
    assert len(E_MAP_EXPERIMENTS)==len(UTS_MAP_EXPERIMENTS)==9
    assert len(VALIDATION)==4
    assert {r[0] for r in VALIDATION}==set(CASES)
    assert abs(float(predict_E(.20,.46,70.))-2403.147978010669)<1e-6
    assert abs(float(predict_UTS(.20,.46,70.))-48.9112377339437)<1e-5
    for case,h,p,v,Em,Elo,Ehi,Eb,Um,Ulo,Uhi,Ub in VALIDATION:
        if not(Elo<=Em<=Ehi and Ulo<=Um<=Uhi):
            raise ValueError(f'{case}: measured value outside true min-max range.')
        em=float(predict_E(h,p,v)); um=float(predict_UTS(h,p,v))
        if not np.isclose(em,Eb,rtol=0,atol=3e-5) or not np.isclose(um,Ub,rtol=0,atol=1e-6):
            raise ValueError(f'{case}: PPP predictions disagree with direct model: '
                             f'E {em} vs {Eb}; UTS {um} vs {Ub}.')
    u_measured=np.array([r[8] for r in VALIDATION])
    u_predicted=np.array([float(predict_UTS(r[1],r[2],r[3])) for r in VALIDATION])
    assert abs(float(np.sqrt(np.mean((u_measured-u_predicted)**2)))-0.369929)<1e-5
    assert np.array_equal(np.abs(u_measured-u_predicted)<=UTS_VALID_TOL,
                          np.array([False,True,True,True]))
    # Independent numerical check of the h=0.20 mm UTS process-only prediction field.
    _pp,_vv=np.meshgrid(np.linspace(*P_BOUNDS,N_GRID_UTS_P),
                        np.linspace(*V_BOUNDS,N_GRID_UTS_V))
    _uts_field=predict_UTS(.20,_pp,_vv)
    assert abs(float(_uts_field.min())-46.531228)<1e-4
    assert abs(float(_uts_field.max())-51.732733)<1e-4
    assert float(_uts_field.min())<UTS_TARGET<float(_uts_field.max())


def format_axis(ax, xlab, ylab):
    ax.set_xlabel(xlab,labelpad=3.5)
    ax.set_ylabel(ylab,labelpad=3.5)
    ax.tick_params(direction='in',length=2.6,width=.75,pad=3)
    ax.grid(False)
    for spine in ax.spines.values():
        spine.set_linewidth(.75); spine.set_color(AXIS_COLOR)


def colorbar(fig,ax,cax,norm,cmap,label):
    sm=mpl.cm.ScalarMappable(norm=norm,cmap=cmap)
    cb=fig.colorbar(sm,cax=cax)
    cb.set_label(label,fontsize=FONT['axis'],labelpad=4)
    cb.locator=ticker.MaxNLocator(nbins=5)
    cb.update_ticks();cb.ax.tick_params(direction='in',width=.65,length=2.5,pad=2,labelsize=FONT['tick'])
    cb.outline.set_linewidth(.65)
    return cb


def colored_main_dots(ax,coords,measured,cmap,norm):
    artist=ax.scatter(coords[:,1],coords[:,0],c=measured,cmap=cmap,norm=norm,
                      s=24,edgecolors=AXIS_COLOR,linewidths=.60,
                      zorder=8,clip_on=False)
    artist.set_path_effects([pe.Stroke(linewidth=1.7,foreground='white'),pe.Normal()])
    return artist


def draw_inverse_panel(fig, ax, cax, which):
    cmap=plt.get_cmap(COLORMAP)
    if which=='E':
        pp,hh=np.meshgrid(np.linspace(*P_BOUNDS,N_GRID_E),np.linspace(*H_BOUNDS,N_GRID_E))
        values=predict_E(hh,pp,70.)
        coords=np.asarray([(h,p,m) for h,p,m in E_MAP_EXPERIMENTS],float)
        pred_range=(float(np.min(values)),float(np.max(values)))
        target, tol=E_TARGET,E_TARGET_TOL
        ylim=H_BOUNDS
        xlabel=r'Line pitch, $P$ (mm)'
        ylabel=r'Layer height, $h$ (mm)'
        cb_label=r'Predicted $E$ (MPa)'
        xgrid,ygrid=pp,hh
        special=r'$v=70$ mm s$^{-1}$'
        measured_v2=2395.2383587158315
        star_xy=(.46,.20)
        fig_label='(a)'
        v2_offset=(-5.5,9.0)
        pr_label_fmt=lambda z: f'{z:.1f}'
    elif which=='UTS':
        pp,vv=np.meshgrid(np.linspace(*P_BOUNDS,N_GRID_UTS_P),
                          np.linspace(*V_BOUNDS,N_GRID_UTS_V))
        values=predict_UTS(.20,pp,vv)
        coords=np.asarray([(v,p,m) for v,p,m in UTS_MAP_EXPERIMENTS],float)
        pred_range=(float(np.min(values)),float(np.max(values)))
        target,tol=UTS_TARGET,UTS_TARGET_TOL
        ylim=V_BOUNDS
        xlabel=r'Line pitch, $P$ (mm)'
        ylabel=r'Printing speed, $v$ (mm/s)'
        cb_label='Predicted UTS (MPa)'
        xgrid,ygrid=pp,vv
        special=r'$h=0.20$ mm'
        measured_v2=49.07205256752856
        star_xy=(.46,70.)
        fig_label='(c)'
        v2_offset=(-5.5,9.0)
        pr_label_fmt=lambda z: f'{z:.2f}'
    else: raise ValueError(which)

    # Include measured markers in the color scale, not just modeled extrema.
    all_obs=coords[:,2]
    low=min(pred_range[0],float(all_obs.min()))
    high=max(pred_range[1],float(all_obs.max()))
    if which=='E':
        cmin=10*np.floor(low/10);cmax=10*np.ceil(high/10)
    else:
        cmin=low;cmax=high
    norm=mpl.colors.Normalize(vmin=cmin,vmax=cmax)
    # Direct vector contour shading (not imshow/PIL assembling).
    contours=ax.contourf(xgrid,ygrid,values,levels=np.linspace(cmin,cmax,130),
                         cmap=cmap,norm=norm,antialiased=False,zorder=0)
    # Matplotlib 3.8+ QuadContourSet is itself an artist; older uses .collections.
    artists = contours.collections if hasattr(contours, 'collections') else [contours]
    for coll in artists:
        coll.set_edgecolor('face')
        coll.set_linewidth(.20)
    # Region enclosing nominal model-based inverse-target range.
    ax.contourf(xgrid,ygrid,values,levels=[target-tol,target+tol],
                colors=[WINDOW_FILL],alpha=.26,zorder=1)
    if which=='E':
        ordinary=[2430.,2460.]
    else:
        ordinary=[48.,50.]
    ordinary=[lv for lv in ordinary if pred_range[0]<lv<pred_range[1] and abs(lv-target)>tol+.04]
    ordinary_labels=[]
    if ordinary:
        contour_lines=ax.contour(xgrid,ygrid,values,levels=ordinary,
                   colors='#303844',linewidths=.45,alpha=.75,zorder=3)
        ordinary_labels=ax.clabel(contour_lines,inline=True,fmt='%g',fontsize=FONT['note'],inline_spacing=4)
        for t in ordinary_labels:
            t.set_bbox(dict(facecolor='white',edgecolor='none',alpha=.80,pad=.5))
    for edge in (target-tol,target+tol):
        if pred_range[0]<edge<pred_range[1]:
            ax.contour(xgrid,ygrid,values,levels=[edge],colors=TARGET_COLOR,
                       linestyles='--',linewidths=1.00,zorder=4)
    center=ax.contour(xgrid,ygrid,values,levels=[target],colors=TARGET_COLOR,
                       linewidths=1.45,zorder=5)
    # Label target contour near the lower portion; preserve scientific target.
    segments=[a for a in center.allsegs[0] if len(a)>1]
    if not segments: raise ValueError(f'Target contour absent: {which}')
    points=np.concatenate(segments)
    desired_y=ylim[0]+.23*(ylim[1]-ylim[0])
    anchor=points[np.argmin(abs(points[:,1]-desired_y))]
    lab=ax.clabel(center,levels=[target],manual=[tuple(anchor)],inline=True,
          fmt={target:f'{target:g} MPa'},fontsize=FONT['note'],colors='#795817')
    for t in lab:
        t.set_bbox(dict(facecolor='white',edgecolor='none',alpha=.95,pad=1.0))
    colored_main_dots(ax,coords[:,:2],coords[:,2],cmap,norm)
    ax.scatter(*star_xy,marker='*',s=98,color=STAR_COLOR,edgecolors='white',
               linewidths=.9,zorder=11)
    ax.annotate(f'V2: {measured_v2:.2f} MPa' if which=='UTS' else
                f'V2: {measured_v2:.1f} MPa',star_xy,
                xytext=v2_offset,textcoords='offset points',ha='right',va='bottom',
                fontsize=FONT['note'],zorder=12,
                bbox=dict(facecolor='white',edgecolor='none',alpha=.96,pad=1.2))
    ax.set_xlim(*P_BOUNDS);ax.set_ylim(*ylim)
    ax.set_xticks([.43,.44,.45,.46,.47]);ax.xaxis.set_major_formatter(ticker.FormatStrFormatter('%.3f'))
    if which=='E':
        ax.set_yticks([.10,.15,.20,.25]);ax.yaxis.set_major_formatter(ticker.FormatStrFormatter('%.2f'))
    else: ax.set_yticks([20,40,60,80,100,120])
    format_axis(ax,xlabel,ylabel)
    note1=ax.text(.013,.963,special,transform=ax.transAxes,ha='left',va='top',fontsize=FONT['note'],
            bbox=dict(facecolor='white',edgecolor='none',alpha=.94,pad=1.15),zorder=12)
    note2=ax.text(.987,.963,f'Predicted range: {pr_label_fmt(pred_range[0])}–{pr_label_fmt(pred_range[1])} MPa',
            transform=ax.transAxes,ha='right',va='top',fontsize=FONT['range'],
            bbox=dict(facecolor='white',edgecolor='none',alpha=.94,pad=1.15),zorder=12)
    colorbar(fig,ax,cax,norm,cmap,cb_label)
    # Omit contour NUMBER labels that crowd plot boundaries/annotation boxes;
    # never hide or move actual contour lines or change underlying numeric fields.
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    axes_bbox=ax.get_window_extent(renderer)
    note_boxes=[note1.get_bbox_patch().get_window_extent(renderer),
                note2.get_bbox_patch().get_window_extent(renderer)]
    for text in ordinary_labels:
        bbox=text.get_window_extent(renderer)
        if (bbox.x0<axes_bbox.x0+4 or bbox.x1>axes_bbox.x1-4 or
            bbox.y0<axes_bbox.y0+4 or bbox.y1>axes_bbox.y1-4 or
            any(bbox.overlaps(n) for n in note_boxes)):
            text.set_visible(False)
    return pred_range


def draw_validation_panel(ax, which):
    """Measured group mean/errorbars and final process-only PPP prediction."""
    if which=='E':
        measured=np.array([r[4] for r in VALIDATION]);lower=np.array([r[5] for r in VALIDATION])
        upper=np.array([r[6] for r in VALIDATION]);pred=np.array([r[7] for r in VALIDATION])
        tol=E_VALID_TOL
        ylab=r"Young's modulus, $E$ (MPa)"
        ybounds=(2300,2550);yticks=np.arange(2300,2551,50)
    else:
        measured=np.array([r[8] for r in VALIDATION]);lower=np.array([r[9] for r in VALIDATION])
        upper=np.array([r[10] for r in VALIDATION]);pred=np.array([r[11] for r in VALIDATION])
        tol=UTS_VALID_TOL
        ylab='Ultimate tensile strength, UTS (MPa)'
        ybounds=(45.5,54.0);yticks=np.arange(46,55,2)
    x=np.arange(4,dtype=float)
    mx,px=x-.055,x+.055
    for xp,y in zip(px,pred):
        ax.add_patch(Rectangle((xp-.17,y-tol),.34,2*tol,
                       facecolor=WINDOW_FILL,edgecolor=WINDOW_EDGE,
                       linewidth=.70,linestyle=(0,(4,3)),alpha=.55,zorder=1))
    ax.errorbar(mx,measured,yerr=np.vstack((measured-lower,upper-measured)),
                fmt='o',markersize=4.2,color=OBS_COLOR,ecolor=OBS_COLOR,
                markeredgecolor='white',markeredgewidth=.3,
                elinewidth=.72,capsize=1.7,capthick=.72,zorder=5)
    ax.scatter(px,pred,marker='D',s=27,facecolors='white',edgecolors=PRED_COLOR,
               linewidths=.9,zorder=6)
    ax.set_xlim(-.50,3.5);ax.set_ylim(*ybounds)
    ax.set_xticks(x,CASES);ax.set_yticks(yticks)
    format_axis(ax,'Additional condition',ylab)
    handles=[
        Line2D([],[],linestyle='none',marker='o',markersize=4.7,color=OBS_COLOR,label='Measured'),
        Line2D([],[],linestyle='none',marker='D',markersize=4.7,markerfacecolor='white',
               markeredgecolor=PRED_COLOR,markeredgewidth=.9,label='Predicted'),
        Patch(facecolor=WINDOW_FILL,edgecolor=WINDOW_EDGE,linewidth=.7,linestyle='--',
              alpha=.55,label=f'±{tol:g} MPa window')]
    ax.legend(handles=handles,frameon=False,loc='upper left',bbox_to_anchor=(.025,.987),
              borderaxespad=0,ncol=1,handlelength=1.3,handletextpad=.35,
              labelspacing=.35,fontsize=FONT['legend'])
    return dict(measured=measured,predicted=pred,mins=lower,maxes=upper,tol=tol)


def audit_writer(results):
    OUT.mkdir(parents=True,exist_ok=True)
    filename=OUT/'Figure10_PPP_7coeff_validation_audit.csv'
    with filename.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f)
        w.writerow(['response','case','h_mm','P_mm','v_mm_s','measured_mean_MPa',
                    'measured_min_MPa','measured_max_MPa','PPP_predicted_MPa',
                    'abs_prediction_error_MPa','acceptance_tolerance_MPa',
                    'measured_mean_within_predicted_window','prediction_model'])
        for response,result in results.items():
            for i,row in enumerate(VALIDATION):
                mean=float(result['measured'][i]);pred=float(result['predicted'][i])
                w.writerow([response,row[0],row[1],row[2],row[3],
                            f'{mean:.12f}',f'{result["mins"][i]:.12f}',
                            f'{result["maxes"][i]:.12f}',f'{pred:.12f}',
                            f'{abs(mean-pred):.12f}',result['tol'],
                            int(abs(mean-pred)<=result['tol']),
                            'E speed-conditioned integrated PPP' if response=='E' else 'UTS seven-coefficient integrated PPP'])
    return filename


def make_figure():
    set_style()
    verify_inputs()
    fig=plt.figure(figsize=(FIG_W_MM/25.4,FIG_H_MM/25.4),dpi=160)
    # Equal-row geometry; width left/right = 70/56 = 1.25.
    assert np.isclose(Y_LOWER, FIG_H_MM - (Y_UPPER + ROW_H)), 'unequal top/bottom margins'
    assert np.isclose(Y_UPPER - (Y_LOWER + ROW_H), 15.0), 'wrong inter-row gap'
    assert np.isclose(Y_UPPER + ROW_H, FIG_H_MM-Y_LOWER), 'rows not symmetric'

    axes={};caxes={}
    for tag,x,y,w in [('a',LEFT_X,Y_UPPER,LEFT_W),('b',RIGHT_X,Y_UPPER,RIGHT_W),
                      ('c',LEFT_X,Y_LOWER,LEFT_W),('d',RIGHT_X,Y_LOWER,RIGHT_W)]:
        axes[tag]=get_axes(fig,x,y,w,ROW_H)
    caxes['a']=get_axes(fig,CB_X,Y_UPPER,CB_W,ROW_H)
    caxes['c']=get_axes(fig,CB_X,Y_LOWER,CB_W,ROW_H)
    rng_E=draw_inverse_panel(fig,axes['a'],caxes['a'],'E')
    vals_E=draw_validation_panel(axes['b'],'E')
    rng_U=draw_inverse_panel(fig,axes['c'],caxes['c'],'UTS')
    vals_U=draw_validation_panel(axes['d'],'UTS')
    # Panel letters just outside plotting axes. Content inside panels is untouched.
    for tag,x,y in [('a',LEFT_X,Y_UPPER+ROW_H+3.4),('b',RIGHT_X,Y_UPPER+ROW_H+3.4),
                    ('c',LEFT_X,Y_LOWER+ROW_H+3.4),('d',RIGHT_X,Y_LOWER+ROW_H+3.4)]:
        fig.text(x/FIG_W_MM,y/FIG_H_MM,f'({tag})',fontsize=FONT['panel'],
                 va='center',ha='left',fontweight='normal',color='black')
    fig.canvas.draw()
    ren=fig.canvas.get_renderer()
    bad=[]
    for text_obj in fig.findobj(mpl.text.Text):
        if text_obj.get_visible() and text_obj.get_text():
            bbox=text_obj.get_window_extent(ren)
            if not np.isfinite([bbox.x0,bbox.x1,bbox.y0,bbox.y1]).all():
                bad.append(('nonfinite',text_obj.get_text()))
            elif (bbox.x0< -2 or bbox.x1>fig.bbox.width+2 or
                  bbox.y0 < -2 or bbox.y1>fig.bbox.height+2):
                bad.append(('outside canvas',text_obj.get_text()))
    if bad: raise RuntimeError(f'Text canvas clip: {bad}')
    OUT.mkdir(parents=True,exist_ok=True)
    for ext in ('pdf','png','svg'):
        fig.savefig(OUT/f'{FIGURE_STEM}.{ext}',dpi=DPI,facecolor='white',
                    transparent=False,bbox_inches=None)
    plt.close(fig)
    audit_writer({'E':vals_E,'UTS':vals_U})
    print('Figure 10 DIRECT rendering done:',OUT)
    print('Physical canvas:',FIG_W_MM,'x',FIG_H_MM,'mm, left/right axis width:',LEFT_W,RIGHT_W)
    print('E model range:',rng_E,'UTS model range:',rng_U)
    for key,vals in [('E',vals_E),('UTS',vals_U)]:
        observed,pred=vals['measured'],vals['predicted']
        print(key,'prediction-window pass:',int(np.sum(abs(pred-observed)<=vals['tol'])),'/4',
              'RMSE:',float(np.sqrt(np.mean((pred-observed)**2))))

if __name__=='__main__':
    make_figure()
