from __future__ import annotations

import hashlib
import os
import tempfile
from pathlib import Path
from typing import Any


DEPENDENT_RESULT_KEYS = (
    "pipeline_outcome", "dual_outcome", "validated_task", "verification_state",
    "report_state", "export_state", "dual_outcome_input_hash",
    "pipeline_outcome_input_hash",
)


def invalidate_results(state: Any) -> None:
    for key in DEPENDENT_RESULT_KEYS:
        state.pop(key, None)


def result_matches_current_input(state: Any, result_key: str) -> bool:
    return bool(state.get(result_key)) and bool(state.get("upload_hash")) and state.get(f"{result_key}_input_hash") == state.get("upload_hash")


def store_uploaded_file(uploaded_file: Any, state: Any) -> str:
    """Create a session-local temporary copy; replacement removes the prior copy."""
    payload = uploaded_file.getvalue()
    digest = hashlib.sha256(payload).hexdigest()
    if state.get("upload_hash") == digest and state.get("upload_path"):
        return state["upload_path"]
    clear_temporary_upload(state)
    suffix = Path(uploaded_file.name).suffix.lower()
    handle = tempfile.NamedTemporaryFile(delete=False, suffix=suffix, prefix="cnpw_upload_")
    try:
        handle.write(payload)
    finally:
        handle.close()
    state["upload_path"] = handle.name
    state["upload_hash"] = digest
    state["upload_name"] = Path(uploaded_file.name).name
    invalidate_results(state)
    return handle.name


def clear_temporary_upload(state: Any) -> None:
    path = state.get("upload_path")
    if path:
        try:
            os.unlink(path)
        except FileNotFoundError:
            pass
    invalidate_results(state)
    for key in ("upload_path", "upload_hash", "upload_name"):
        state.pop(key, None)
