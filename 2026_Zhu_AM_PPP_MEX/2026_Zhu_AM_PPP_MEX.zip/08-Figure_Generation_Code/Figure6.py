# -*- coding: utf-8 -*-
"""Figure 6: frozen 10-coefficient Y model, condition-wise LOOCV.
Run: python Figure6.py
Dependencies: numpy, matplotlib. No external data or network access.
Data source: attached 20261020 Figure 6 package, specimens101_porosity.csv.
Only its 81 main specimens are embedded. Its old linear prediction columns
are NOT reused. Final model: 20 mm/s quadratic in h; 70/120 mm/s linear.
No speeds in headings, no grid; three P-color legend entries below.
Panels (a-d) have measured horizontal min-max error bars.
Source group means/min/max are embedded as independent checks.
Y is calculated specimen by specimen, in percentage points (pp).
"""
from pathlib import Path
from itertools import product
import os
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.patheffects as pe
from matplotlib import font_manager as fm
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D

OUTPUT_DIR = Path(os.environ.get(
    'FIGURE6_OUTPUT_DIR', r'D:\soft\3' if os.name == 'nt' else '/mnt/data/Figure6_AllPanels_Output'))
WIDTH_MM, HEIGHT_MM, DPI = 190.0, 175.0, 600
SIZES = dict(panel=11, axis=11, tick=9, metric=9)
LAYOUT = dict(left=.105, right=.928, bottom=.085, top=.965,
              wspace=.20, hspace=.18)
POINT_SIZE, POINT_ALPHA = 25, .6
ERROR_CAPSIZE, ERROR_LINEWIDTH, ERROR_ALPHA = 2.0, .8, .65
REFERENCE_COLOR = '#858C91'
DATA_ATOL, PRESS_ATOL = 1e-10, 1e-9
COLORS = {0.43: '#1F77B4', 0.45: '#FF7F0E', 0.47: '#2CA02C'}
H_LEVELS = (0.10, 0.20, 0.25)
P_LEVELS = (0.43, 0.45, 0.47)
V_LEVELS = (20, 70, 120)
BASE_LIMITS = (-8.0, 12.0)
# Prompt metrics are approximate: the supplied 120 mm/s R2 differs from
# archive metadata by 1.7706026e-6, not by floating-point roundoff.
# Retain and disclose both values; independently check the archive value.
HISTORY_TOL = 2e-6
ARCHIVE_R2_120 = 0.9521707706026243
HISTORY = {
    'All': dict(R2=0.953265, MAE=0.748018, RMSE=0.932643),
    20: dict(R2=0.967784, RMSE=0.912056),
    70: dict(R2=0.925764, RMSE=1.085761),
    120: dict(R2=0.952169, RMSE=0.773782),
}

# (group ID, h/mm, P/mm, v/(mm/s), phi_vol R1/%, R2/%, R3/%)
# These are measured specimen values, not digitized plot coordinates.
RAW_DATA = [
    ('G1', 0.2, 0.45, 70, 11.135202286298265, 10.86597518298036, 11.06149030653386),
    ('G2', 0.2, 0.45, 20, 8.048934957163588, 8.219005948577717, 8.264210838112152),
    ('G3', 0.2, 0.45, 120, 12.139843108319038, 11.902628434886507, 11.609095154981633),
    ('G4', 0.1, 0.45, 70, 8.635243331929399, 8.438897684096913, 8.428516507001815),
    ('G5', 0.25, 0.45, 70, 9.48115885055969, 10.167084221749668, 10.511538418515164),
    ('G6', 0.2, 0.43, 70, 6.914419393338111, 6.774578650269881, 7.138913594079388),
    ('G7', 0.2, 0.47, 70, 13.503659540859523, 13.565754349853664, 14.8905836206354),
    ('G8', 0.1, 0.43, 20, 8.06313248895193, 8.38754456468096, 7.905141680960803),
    ('G9', 0.1, 0.47, 120, 13.283810874734936, 13.392999232799152, 13.71739182036128),
    ('G10', 0.25, 0.47, 20, 10.761250767426224, 10.75065752259654, 11.059326603995622),
    ('G11', 0.25, 0.47, 120, 15.50827723154634, 15.26630289824864, 15.29917627366083),
    ('G12', 0.2, 0.43, 120, 10.406019116987109, 8.878897590266298, 8.882241857974327),
    ('G13', 0.1, 0.47, 70, 12.866332660239166, 13.019568408117976, 13.266586289153482),
    ('G14', 0.25, 0.43, 70, 7.335983509437794, 7.21456968403823, 7.310511907769001),
    ('G15', 0.25, 0.45, 120, 13.31434499564118, 12.751756962809724, 12.5863717011504),
    ('G16', 0.2, 0.47, 20, 11.889969357058527, 11.63130774891059, 11.055008040038617),
    ('G17', 0.2, 0.47, 120, 14.653528790902191, 14.959756184060948, 15.387094092683762),
    ('G18', 0.2, 0.43, 20, 6.369175755641465, 6.77811934768039, 6.116440431779468),
    ('G19', 0.25, 0.47, 70, 12.381220333269226, 12.647393449070254, 12.346175506543478),
    ('G20', 0.1, 0.43, 70, 7.515419725577832, 7.835424635544685, 7.409945592250677),
    ('G21', 0.1, 0.45, 20, 12.045292171730823, 13.044888546729094, 13.107178514469698),
    ('G22', 0.1, 0.47, 20, 15.561045812056594, 14.282627987279762, 14.49151570952628),
    ('G23', 0.1, 0.43, 120, 7.188613619320849, 7.179626200247702, 7.269639369654513),
    ('G24', 0.1, 0.45, 120, 9.062300242708275, 9.94549260451506, 9.704650185416808),
    ('G25', 0.25, 0.43, 20, 6.546076427663417, 6.505282849368877, 6.621700029010736),
    ('G26', 0.25, 0.45, 20, 9.102103853094237, 8.625730994152047, 9.079152096439946),
    ('G27', 0.25, 0.43, 120, 8.616584946615157, 8.278039497056222, 8.72940409485803),
]

# Archived experimental group mean/min/max; used only for source checks.
ARCHIVE_SUMMARY = {
    'G1': (1.48302985404631, 1.32811577842251, 1.59734288174041),
    'G2': (-1.36047548994004, -1.48892444739427, -1.2736485664457),
    'G3': (2.34599616150454, 2.07123575042378, 2.60198370376118),
    'G4': (3.73195613873045, 3.65958680472289, 3.86631362965047),
    'G5': (-1.86906375875581, -2.44116540513763, -1.41078583718215),
    'G6': (-3.03884355964925, -3.20690212194183, -2.84256717813232),
    'G7': (4.8546727901991, 4.37166649394243, 5.7585905737183),
    'G8': (3.12786585875871, 2.91440129485495, 3.3968041785751),
    'G9': (8.89873745250657, 8.71781435127639, 9.15139529690273),
    'G10': (-0.55791301064024, -0.664333786049829, -0.355664704650748),
    'G11': (3.94292749250557, 3.85131158960227, 4.09328592289997),
    'G12': (-0.5924279171358, -1.10258318194541, 0.424538344775398),
    'G13': (8.48483259571166, 8.30033613678062, 8.70058976569493),
    'G14': (-5.18982926484963, -5.26228128122641, -5.14086745582684),
    'G15': (0.961833630836451, 0.664047445453082, 1.39202073994386),
    'G16': (2.39343533508548, 1.92301499312152, 2.75797631014143),
    'G17': (5.86813330896521, 5.5215357439851, 6.25510104576667),
    'G18': (-3.5602355938446, -3.86504034043224, -3.20336142453132),
    'G19': (1.04327178764795, 0.931184197897108, 1.23240214042388),
    'G20': (2.59618959835188, 2.41920520614482, 2.84468424943883),
    'G21': (7.96352337536428, 7.2763624694519, 8.33824881219077),
    'G22': (10.2123999794957, 9.71663146382121, 10.995049288598),
    'G23': (2.22188601030183, 2.18888581414185, 2.27889898354866),
    'G24': (4.80188464193445, 4.29337054042935, 5.17656290223613),
    'G25': (-5.91916452991696, -5.97156811589576, -5.8551509362539),
    'G26': (-2.98666194113524, -3.29659326154527, -2.82022040260308),
    'G27': (-3.93550811908817, -4.19881146820842, -3.74744687040661),
}


def prepare_data():
    if len(RAW_DATA) != 27:
        raise ValueError('Expected exactly 27 main conditions.')
    if any(len(row) != 7 for row in RAW_DATA):
        raise ValueError('Each condition must contain exactly three specimens.')
    rows = sorted(RAW_DATA, key=lambda row: int(row[0][1:]))
    if {r[0] for r in rows} != {f'G{i}' for i in range(1, 28)}:
        raise ValueError('Group IDs must be unique G1 through G27.')
    if any(len(row) != 7 for row in rows):
        raise ValueError('Each condition must contain exactly three specimens.')
    params = np.asarray([r[1:4] for r in rows], dtype=float)
    phi = np.asarray([r[4:] for r in rows], dtype=float)
    if not np.all(np.isfinite(params)) or not np.all(np.isfinite(phi)):
        raise ValueError('Non-finite parameters or specimen measurements.')
    expected = set(product(H_LEVELS, P_LEVELS, V_LEVELS))
    if {tuple(r) for r in params} != expected:
        raise ValueError('Incomplete or duplicated h-P-v factorial design.')
    if phi.shape != (27, 3) or np.any((phi < 0) | (phi > 100)):
        raise ValueError('Invalid specimen count or volumetric porosity.')
    h, P, v = params.T
    phi2 = 100.0 * (1.0 - np.pi / 4.0) * h / P
    yr = phi - phi2[:, None]
    if not np.all(np.isfinite(yr)):
        raise ValueError('Non-finite specimen-level Y.')
    y, lo, hi = yr.mean(axis=1), yr.min(axis=1), yr.max(axis=1)
    if np.any(lo > y) or np.any(hi < y):
        raise ValueError('Invalid min-mean-max ordering.')
    for i, row in enumerate(rows):
        reference = np.asarray(ARCHIVE_SUMMARY[row[0]])
        if not np.allclose([y[i], lo[i], hi[i]], reference, atol=DATA_ATOL, rtol=0):
            raise ValueError(f'Archived mean/min/max mismatch: {row[0]}')
    for speed in V_LEVELS:
        if np.count_nonzero(v == speed) != 9:
            raise ValueError(f'Expected nine conditions at {speed} mm/s.')
    return dict(ids=[r[0] for r in rows], h=h, P=P, v=v,
                phi=phi, phi2=phi2, yr=yr, y=y, lo=lo, hi=hi)


def design(h, P, speed):
    # The order of coefficients is always a, b, c [, q].
    h, P = np.asarray(h), np.asarray(P)
    columns = [np.ones_like(h), h, P]
    if speed == 20:
        columns.append(h ** 2)
    elif speed not in (70, 120):
        raise ValueError(f'Unsupported speed: {speed}')
    return np.column_stack(columns)


def fit_ols(X, y):
    beta, _, rank, _ = np.linalg.lstsq(X, y, rcond=None)
    if rank != X.shape[1]:
        raise ValueError('Rank-deficient OLS design matrix.')
    if not np.all(np.isfinite(beta)):
        raise ValueError('Non-finite model coefficients.')
    return beta


def condition_loocv(data):
    y, v = data['y'], data['v']
    pred = np.full(27, np.nan)
    fold_beta = []
    for i in range(27):
        speed = int(v[i])
        train = (v == speed) & (np.arange(27) != i)
        if int(train.sum()) != 8:
            raise ValueError('Each fold must train on eight same-speed conditions.')
        X = design(data['h'][train], data['P'][train], speed)
        beta = fit_ols(X, y[train])  # refit for every held-out condition
        test = design(data['h'][i:i+1], data['P'][i:i+1], speed)
        pred[i] = (test @ beta)[0]
        fold_beta.append(beta)
    if not np.all(np.isfinite(pred)):
        raise ValueError('Missing or non-finite LOOCV predictions.')
    # Full-data fits are for coefficient reporting only, never for plot points.
    final = {}
    for speed in V_LEVELS:
        mask = v == speed
        if int(mask.sum()) != 9:
            raise ValueError('Each speed must contain nine conditions.')
        final[speed] = fit_ols(
            design(data['h'][mask], data['P'][mask], speed), y[mask])
    if tuple(len(final[s]) for s in V_LEVELS) != (4, 3, 3):
        raise ValueError('Expected the fixed 4+3+3 = 10 coefficient model.')
    # Independent PRESS identity check, inherited from the original workflow.
    # These values verify the explicit refit predictions; they never replace them.
    for speed in V_LEVELS:
        mask = v == speed
        X = design(data['h'][mask], data['P'][mask], speed)
        fitted = X @ final[speed]
        leverage = np.einsum('ij,ji->i', X, np.linalg.pinv(X))
        if np.any(1.0 - leverage <= 1e-12):
            raise ValueError('Invalid leverage in independent PRESS check.')
        press_pred = y[mask] - (y[mask] - fitted) / (1.0 - leverage)
        if not np.allclose(pred[mask], press_pred, atol=PRESS_ATOL, rtol=0):
            raise ValueError(f'Explicit LOOCV/PRESS mismatch at {speed} mm/s.')
    return pred, final, fold_beta


def metrics(y, pred):
    error = pred - y
    total = float(np.sum((y - np.mean(y)) ** 2))
    if total <= 0:
        raise ValueError('R-squared is undefined for a constant response.')
    return dict(R2=1.0 - float(np.sum(error ** 2)) / total,
                MAE=float(np.mean(np.abs(error))),
                RMSE=float(np.sqrt(np.mean(error ** 2))))


def all_metrics(data, pred):
    out = {'All': metrics(data['y'], pred)}
    for speed in V_LEVELS:
        mask = data['v'] == speed
        out[speed] = metrics(data['y'][mask], pred[mask])
    return out


def common_limits(data, pred):
    low = float(min(data['lo'].min(), pred.min()))
    high = float(max(data['hi'].max(), pred.max()))
    # Expand only when necessary; include every horizontal error-bar endpoint.
    limits = (min(BASE_LIMITS[0], 2 * np.floor((low - .5) / 2)),
              max(BASE_LIMITS[1], 2 * np.ceil((high + .5) / 2)))
    return tuple(float(x) for x in limits)


def write_report(data, pred, final, fold_beta, stats, limits):
    lines = [
        'Figure 6 | Frozen 10-coefficient Y model',
        'Source: supplied 20261020 package, specimens101_porosity.csv.',
        'G1-G27 / 81 main specimens; V1-V4 not embedded or fitted.',
        'Source mean/min/max checks: PASS; explicit LOOCV/PRESS check: PASS.',
        'Archived old pooled/all-linear predictions were not used.',
        'phi_vol and phi2: percent numerical values; Y: percentage points (pp).',
        'Y_i = phi_vol_i - 100*(1-pi/4)*h/P; then group mean/min/max.',
        'Equal-weight OLS on condition means; no replicate-level splitting.',
        '27 held-out conditions; eight same-speed training conditions per fold.',
        '20 mm/s: a+b*h+c*P+q*h^2; 70/120 mm/s: a+b*h+c*P.',
        'Panel (a) pools all 27 held-out predictions; no global baseline fit.',
        f'Common measured/predicted axis limits: {limits}',
        f'Python {sys.version.split()[0]}; numpy {np.__version__}; '
        f'matplotlib {mpl.__version__}',
        '', 'LOOCV METRICS',
        'Scope       R2              MAE (pp)        RMSE (pp)',
    ]
    for scope, m in stats.items():
        lines.append(f'{str(scope):<10}  {m["R2"]:.12f}  '
                     f'{m["MAE"]:.12f}  {m["RMSE"]:.12f}')
    lines += ['', 'FINAL FIT COEFFICIENTS (nine conditions per speed)',
              'h and P in mm; a in pp; b,c in pp/mm; q in pp/mm^2.']
    for speed, beta in final.items():
        names = ('a', 'b', 'c', 'q') if speed == 20 else ('a', 'b', 'c')
        lines.append(f'v={speed}: ' + ', '.join(
            f'{name}={value:.15g}' for name, value in zip(names, beta)))
    lines += ['', 'CONDITION RESULTS',
              'ID,h_mm,P_mm,v_mm_s,phi2_pct,Y_R1_pp,Y_R2_pp,Y_R3_pp,'
              'Y_mean_pp,Y_min_pp,Y_max_pp,LOOCV_pred_pp,pred_minus_measured_pp']
    for i, group in enumerate(data['ids']):
        values = [data['h'][i], data['P'][i], data['v'][i], data['phi2'][i],
                  *data['yr'][i], data['y'][i], data['lo'][i], data['hi'][i],
                  pred[i], pred[i] - data['y'][i]]
        lines.append(group + ',' + ','.join(f'{x:.15g}' for x in values))
    error = np.abs(pred - data['y'])
    i = int(np.argmax(error))
    lines += ['', f'Maximum absolute LOOCV error: {error[i]:.12f} pp '
              f'({data["ids"][i]})', '', 'HISTORICAL CHECKS',
              'Difference = computed minus historical rounded value.']
    passed = True
    for scope, reference in HISTORY.items():
        for name, expected in reference.items():
            actual = stats[scope][name]
            difference = actual - expected
            ok = abs(difference) <= HISTORY_TOL
            passed = passed and ok
            lines.append(f'{scope} {name}: calculated={actual:.12f}, '
                         f'reference={expected:.6f}, difference={difference:+.12g}, '
                         f'{"PASS" if ok else "MISMATCH"}')
    exact_ok = abs(stats[120]['R2'] - ARCHIVE_R2_120) <= DATA_ATOL
    passed = passed and exact_ok
    lines += [
        'Reference caveat: prompt 120 mm/s R2=0.952169; archive metadata '
        'R2=0.9521707706026243 (same unchanged 120 mm/s linear model).',
        'The 1.7706e-6 difference is an archival reference discrepancy, '
        'not floating-point roundoff; neither data nor predictions are changed.',
        f'Archive 120 mm/s R2 check at {DATA_ATOL:g}: '
        + ('PASS' if exact_ok else 'MISMATCH'),
        f'Approximate prompt-reference tolerance: {HISTORY_TOL:g}',
              'Historical check: ' + ('PASS' if passed else 'MISMATCH'),
              'Predictions are never modified to match historical metrics.',
              '', 'PER-FOLD COEFFICIENTS (a,b,c[,q])']
    for group, beta in zip(data['ids'], fold_beta):
        lines.append(group + ': ' + ', '.join(f'{b:.15g}' for b in beta))
    path = OUTPUT_DIR / 'Figure6_LOOCV_results.txt'
    path.write_text('\n'.join(lines) + '\n', encoding='utf-8-sig')
    print('\n'.join(lines))
    return path, passed


def configure_font():
    # Prefer the installed regular face. Never silently substitute Arial/DejaVu.
    path = None
    try:
        found = fm.findfont(FontProperties(family='Roboto', style='normal',
                                          weight='normal'), fallback_to_default=False)
        if Path(found).is_file():
            path = Path(found)
    except ValueError:
        pass
    if path is None:
        candidates = [
            Path.home() / 'AppData/Local/Microsoft/Windows/Fonts/Roboto-Regular.ttf',
            Path(os.environ.get('WINDIR', r'C:\Windows')) / 'Fonts/Roboto-Regular.ttf',
        ]
        path = next((p for p in candidates if p.is_file()), None)
    if path is None:
        raise FileNotFoundError('Roboto Regular was not found among installed fonts. '
                                'Install Roboto Regular and restart Python. '
                                'The numeric report has already been saved.')
    fm.fontManager.addfont(str(path))
    regular = FontProperties(fname=str(path))
    mpl.rcParams.update({
        'font.family': regular.get_name(), 'font.weight': 'normal',
        'font.size': SIZES['tick'], 'axes.labelsize': SIZES['axis'],
        'axes.labelweight': 'normal', 'axes.grid': False,
        'axes.grid.which': 'both', 'xtick.labelsize': SIZES['tick'],
        'ytick.labelsize': SIZES['tick'], 'axes.unicode_minus': True,
        'mathtext.fontset': 'stix', 'text.usetex': False,
        'pdf.fonttype': 42, 'ps.fonttype': 42, 'pdf.compression': 0,
        'svg.fonttype': 'none', 'svg.hashsalt': 'Figure6-frozen-10coef',
        'figure.facecolor': 'white', 'axes.facecolor': 'white',
        'savefig.facecolor': 'white', 'axes.axisbelow': True,
    })
    print(f'Roboto Regular: {path}')
    return regular


def draw_figure(data, pred, stats, limits, regular):
    fig, axes = plt.subplots(2, 2, figsize=(WIDTH_MM / 25.4, HEIGHT_MM / 25.4))
    fig.subplots_adjust(**LAYOUT)
    panels = [('All', '(a)'), (20, '(b)'), (70, '(c)'), (120, '(d)')]
    checks, tags, metric_texts, scatter_artists = [], [], [], []
    for index, (ax, (scope, label)) in enumerate(zip(axes.flat, panels)):
        row, col = divmod(index, 2)
        ax.set_xlim(*limits)
        ax.set_ylim(*limits)
        ax.set_aspect('equal', adjustable='box')
        ticks = np.arange(np.ceil(limits[0] / 4) * 4, limits[1] + .01, 4)
        ax.set_xticks(ticks)
        ax.set_yticks(ticks)
        ax.grid(False, which='both', axis='both')
        for spine in ax.spines.values():
            spine.set_linewidth(.8)
            spine.set_color('#263642')
        # Retain tick values in every panel; share axis titles only.
        ax.tick_params(direction='in', width=.8, length=3, pad=4,
                       labelbottom=True, labelleft=True)
        reference, = ax.plot(limits, limits, color=REFERENCE_COLOR, linewidth=1.0,
                             linestyle=(0, (4, 3)), zorder=1)
        selected = np.ones(27, dtype=bool) if scope == 'All' else data['v'] == scope
        points, ranges = 0, 0
        for P in P_LEVELS:
            mask = selected & (data['P'] == P)
            x, z = data['y'][mask], pred[mask]
            xerr = np.vstack((x - data['lo'][mask], data['hi'][mask] - x))
            if np.any(xerr < 0) or not np.all(np.isfinite(xerr)):
                raise ValueError('Invalid asymmetric horizontal min-max bars.')
            if (not np.allclose(x - xerr[0], data['lo'][mask], rtol=0, atol=DATA_ATOL)
                    or not np.allclose(x + xerr[1], data['hi'][mask], rtol=0, atol=DATA_ATOL)):
                raise ValueError('Error-bar endpoints do not match true min/max.')
            # No yerr: the short vertical strokes are end caps, not Y-errors.
            errorbars = ax.errorbar(
                x, z, xerr=xerr, fmt='none', ecolor=COLORS[P],
                elinewidth=ERROR_LINEWIDTH, capsize=ERROR_CAPSIZE,
                capthick=ERROR_LINEWIDTH, alpha=ERROR_ALPHA, zorder=2)
            if not errorbars.has_xerr or errorbars.has_yerr:
                raise ValueError('Expected horizontal-only error bars.')
            segments = errorbars.lines[2][0].get_segments()
            if len(segments) != len(x):
                raise ValueError('Missing experimental range segments.')
            for j, segment in enumerate(segments):
                expected = [[data['lo'][mask][j], z[j]],
                            [data['hi'][mask][j], z[j]]]
                if not np.allclose(segment, expected, rtol=0, atol=DATA_ATOL):
                    raise ValueError('Rendered min-max segment mismatch.')
            ranges += len(x)
            scatter = ax.scatter(
                x, z, s=POINT_SIZE, marker='o', c=COLORS[P], alpha=POINT_ALPHA,
                edgecolors='white', linewidths=.3, zorder=3)
            scatter_artists.append(scatter)
            points += len(scatter.get_offsets())
        if points != (27 if scope == 'All' else 9):
            raise ValueError('Incorrect number of plotted points.')
        if ranges != (27 if scope == 'All' else 9):
            raise ValueError('Incorrect number of horizontal min-max ranges.')
        tag = ax.text(0, 1.025, label, transform=ax.transAxes,
                      ha='left', va='bottom', fontsize=SIZES['panel'],
                      fontweight='bold', color='#263642', clip_on=False)
        tag.set_path_effects([pe.withStroke(linewidth=.3, foreground='#263642'),
                             pe.Normal()])
        tags.append(tag)
        m = stats[scope]
        metric_texts.append(ax.text(
            .045, .955,
            rf'$R^2_{{\mathrm{{LOOCV}}}} = {m["R2"]:.3f}$'
            + '\n' + rf'$\mathrm{{RMSE}} = {m["RMSE"]:.3f}\ \mathrm{{pp}}$',
            transform=ax.transAxes, ha='left', va='top',
            fontsize=SIZES['metric'], linespacing=1.35, zorder=4))
        if row == 1:
            ax.set_xlabel(r'Measured $Y$ (pp)', labelpad=6)
        if col == 0:
            ax.set_ylabel(r'LOOCV-predicted $\widehat{Y}$ (pp)', labelpad=6)
        checks.append((ax, reference, row, col))
    # P-color legend: same appearance/position as Figure 8. Reserve an export
    # footer instead of moving the existing four panels or axis labels.
    legend_items = [Line2D(
        [0], [0], marker='o', linestyle='none',
        markerfacecolor=COLORS[pitch], markeredgecolor='white',
        markeredgewidth=.3, markersize=6,
        label=fr'$P={pitch:.2f}$ mm') for pitch in P_LEVELS]
    fig.legend(handles=legend_items, ncol=3, loc='upper center',
               bbox_to_anchor=((LAYOUT['left'] + LAYOUT['right']) / 2, -.012),
               frameon=False, fontsize=SIZES['tick'], borderaxespad=0,
               handletextpad=.5, columnspacing=2.0)
    footer_inches = 10.0 / 25.4
    export_bounds = mpl.transforms.Bbox.from_extents(
        0, -footer_inches, fig.get_figwidth(), fig.get_figheight())

    fig.canvas.draw()
    for text in fig.findobj(match=mpl.text.Text):
        fp = regular.copy()
        fp.set_size(text.get_fontsize())
        text.set_fontproperties(fp)  # STIX mathematics handled by MathText
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for text in fig.findobj(match=mpl.text.Text):
        if text.get_visible() and text.get_text():
            box = text.get_window_extent(renderer)
            if (box.x0 < -1 or box.y0 < -footer_inches * fig.dpi - 1 or
                    box.x1 > fig.bbox.width + 1 or box.y1 > fig.bbox.height + 1):
                raise RuntimeError(f'Text exceeds canvas: {text.get_text()}')
    for ax, reference, row, col in checks:
        if any(line.get_visible() for line in ax.get_xgridlines() + ax.get_ygridlines()):
            raise RuntimeError('Background grid must be disabled.')
        if tuple(ax.get_xlim()) != limits or tuple(ax.get_ylim()) != limits:
            raise RuntimeError('Inconsistent axis limits.')
        if not np.isclose(float(ax.get_aspect()), 1.0):
            raise RuntimeError('X/Y scaling must be equal.')
        if bool(ax.get_xlabel()) != (row == 1) or bool(ax.get_ylabel()) != (col == 0):
            raise RuntimeError('Incorrect shared axis-title arrangement.')
        if ax.get_title() or ax.get_legend() is not None:
            raise RuntimeError('Speed titles and legends must be absent.')
        if not (np.array_equal(reference.get_xdata(), reference.get_ydata())):
            raise RuntimeError('Reference line is not the true 1:1 diagonal.')
    # Check point centers against the metric blocks using actual display positions.
    for ax, metric in zip(axes.flat, metric_texts):
        box = metric.get_window_extent(renderer).padded(2)
        for scatter in ax.collections:
            if isinstance(scatter, mpl.collections.PathCollection):
                for xy in scatter.get_offsets():
                    if box.contains(*ax.transData.transform(xy)):
                        raise RuntimeError('Metric text overlaps a data-point center.')
    # Record narrow true ranges; never inflate them to make them look wider.
    ax_width_pt = axes.flat[1].get_window_extent(renderer).width * 72 / fig.dpi
    marker_diameter_pt = np.sqrt(POINT_SIZE)
    range_width_pt = (data['hi'] - data['lo']) / (limits[1] - limits[0]) * ax_width_pt
    narrow = [g for g, w in zip(data['ids'], range_width_pt) if w < marker_diameter_pt]
    report = OUTPUT_DIR / 'Figure6_LOOCV_results.txt'
    with report.open('a', encoding='utf-8') as handle:
        handle.write('\nPLOT CHECKS: PASS\n'
                     'Point counts: 27/9/9/9; horizontal range counts: 27/9/9/9.\n'
                     'No vertical uncertainties (vertical caps are retained).\n'
                     'No grid, speed title or validation groups; P-color footer legend included.\n'
                     'Shared labels, common axes, 1:1 reference and canvas bounds checked.\n'
                     f'True ranges narrower than approximate marker diameter: {narrow}\n'
                     'These ranges can be partly hidden by a marker; no range was enlarged.\n')
    # No exports occur until all numerical and rendering checks have passed.
    for suffix in ('pdf', 'svg', 'png'):
        path = OUTPUT_DIR / f'Figure6.{suffix}'
        fig.savefig(path, dpi=DPI, bbox_inches=export_bounds, transparent=False)
        print(f'Saved: {path}')
    plt.close(fig)


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    data = prepare_data()
    pred, final, fold_beta = condition_loocv(data)
    stats = all_metrics(data, pred)
    limits = common_limits(data, pred)
    report, passed = write_report(data, pred, final, fold_beta, stats, limits)
    if not passed:
        raise RuntimeError('Historical numerical check failed; no new figures exported. '
                           'Inspect Figure6_LOOCV_results.txt.')
    regular = configure_font()
    with report.open('a', encoding='utf-8-sig') as handle:
        handle.write(f'\nRoboto font file: {regular.get_file()}\n'
                     'Math font: STIX (Matplotlib bundled); panel bold: simulated stroke.\n')
    draw_figure(data, pred, stats, limits, regular)
    with report.open('a', encoding='utf-8') as handle:
        handle.write('EXPORT_STATUS: SUCCESS\n')
    print(f'Saved: {report}')


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        # Preserve diagnostic information and do not silently publish a failed run.
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        with (OUTPUT_DIR / 'Figure6_LOOCV_results.txt').open('a', encoding='utf-8') as handle:
            handle.write(f'\nEXPORT_STATUS: FAILED - {type(error).__name__}: {error}\n'
                         'Existing figure files, if any, may belong to an older run.\n')
        raise
