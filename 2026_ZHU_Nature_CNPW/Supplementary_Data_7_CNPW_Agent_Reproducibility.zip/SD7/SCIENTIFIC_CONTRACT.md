# Current CNPW V8 software contract — residual Mode-B synchronization

Protection determines admissibility; residual responses determine Stage-1 conditional capability; all active responses re-enter Stage-2 Local refinement.

Protected responses are not ignored by Mode B. They first define the admissible candidate domain and later re-enter all-response Local refinement. They are excluded only from the residual Stage-1 capability calculation because their protection requirement has already been satisfied.

## Core domains and response universes

Global Levels are assigned once on complete X and frozen, using the finite-library rule `K_G_eff = min(K_G, N)` and upward completion of tied rank groups. For a non-empty proper protected block P, equal-count protection uses k_P = max_x min_{j in P} ell_j^G(x), independently for every block. Omega_P contains exactly candidates satisfying all protected levels >= k_P. Explicit raw-threshold and normalized operating-range-tolerance contracts remain supported by Core. Infeasible protection fails without lowering.

Let J_res = J minus P. Stage 1 evaluates min_{j in J_res} ell_j^G(x) on Omega_P; its maximum is the residual conditional capability. W_B^(1) retains all candidates attaining that maximum. No Global re-binning or lower-GL backfill occurs. Empty or full protected blocks are rejected: an empty residual system has no defined capability. Singleton residual systems are supported.

Stage 2, adaptive K_L, Local QCCA and terminal discrimination use all J on fixed W_B^(1). The existing finite exit-event termination and co-terminal rules are unchanged. Terminal pruning remains weakest-first lexicographic Local profile selection followed by direction-aware raw Pareto pruning. Targeted Local alternatives remain inside W_B^(1), preserve the target for non-recovery responses and preserve the existing nondominated alternatives.

Global Mode-B QCCA uses (Omega_P, J_res, G). Subsets, witnesses and target-specific recovery sets contain only residual responses. One-response diagnosis has one non-empty subset, no leave-one-out system and no recovery above its ceiling while retaining a non-empty system. Two-response diagnosis is also supported. Local Mode-B QCCA remains (W_B^(1), J, L), evaluating every higher target automatically. QCCA performs diagnosis only.

Mode A is unchanged: Global (X,J,G), then Local (W_A^(1),J,L).

## Public architecture and compatibility

The default Streamlit dual_main -> DualAnalysisCoordinator route preserves Upload -> Run -> Download. It enumerates 2^M-2 protected blocks in block-size-first and declared-response order (6/14/30 for M=3/4/5). The first-contract alias is a compatibility display, not a preferred contract. The complete Markdown report remains the canonical report download.

Input schema, directions, IDs, Stage-2 and terminal structure are unchanged. Existing Mode-B highest_joint_level and retained_candidate_ids now denote residual qualification. residual_criteria is populated; Mode-B stage_1 additionally exposes qualification_scope and qualification_response_indices. Mode-A result fields are unchanged. Contract IDs still identify input/protection blocks; the Core source hashes identify this semantic revision. Old and new evidence must not be mixed on contract ID alone.

Verification independently reconstructs Global and Local matrices from the input and recomputes Stage-1/Stage-2 membership, Mode-B admissibility and residual scope, QCCA subset capabilities/supporting sets, minimum recovery sets, targeted-action witnesses, and terminal/co-terminal identity.

## Legacy and evidence boundary

The old app.streamlit_app.main, agent/report_renderer.py and docs/agent_v0_1 are historical, not authoritative for the default V8 path. _release_build, _v8_package_build, archived replay outputs, existing SD archives and release ZIPs remain untouched historical snapshots. Their scientific language may describe earlier semantics. This document governs the working software only. Phase-1 audit outputs are in V8_Residual_ModeB_Upgrade_Audit; official evidence/package synchronization belongs to Phase 2.

The historical cnpw_core.py -> src/main.py interactive CLI is also non-authoritative: its Mode-B option still calls run_mode_b without a required contract. Use the default public Agent or an explicit ProtectionContract through the Core API. This Phase-1 patch does not restore that legacy CLI.
