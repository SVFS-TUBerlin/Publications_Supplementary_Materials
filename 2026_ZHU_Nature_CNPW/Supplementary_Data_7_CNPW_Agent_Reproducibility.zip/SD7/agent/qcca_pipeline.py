from dataclasses import dataclass

from .qcca_analyzer import analyze_qcca
from .qcca_verifier import verify_qcca


@dataclass(frozen=True)
class QccaOutcome:
    status: str
    result: object | None
    verification: object | None


def run_qcca(verified_mode_a):
    """Compatibility entry point for the prior verified Mode-A Global path."""
    try:
        result = verified_mode_a
        names = tuple(item["name"] for item in result["input_summary"]["active_criteria"])
        matrix = result["stage_1"]["per_criterion_global_trace"]["gl"]
        qcca = analyze_qcca(names, matrix, result["stage_1"]["highest_joint_level"], candidate_ids=tuple(str(i) for i in range(len(matrix))))
        verification = verify_qcca(qcca, result["stage_1"]["highest_joint_level"])
        return QccaOutcome("COMPLETED" if verification.passed else "INTEGRITY_FAILED", qcca if verification.passed else None, verification)
    except Exception:
        return QccaOutcome("UNAVAILABLE", None, None)


def run_core_qcca(dataset, core_result, representation: str) -> QccaOutcome:
    """Bind QCCA to the authoritative frozen Core state without recomputation."""
    try:
        mode = "MODE_B" if core_result.protected else "MODE_A"
        names = tuple(item.name for item in dataset.criteria)
        if representation == "GLOBAL":
            matrix = core_result.stage1.gl
            if mode == "MODE_A":
                domain = tuple(range(len(dataset.candidate_ids)))
            else:
                omega = set(core_result.protected["omega_candidate_ids"])
                domain = tuple(i for i, identifier in enumerate(dataset.candidate_ids) if identifier in omega)
                # Project columns only: Global levels stay frozen on the original X.
                residual = [i for i in range(len(dataset.criteria)) if i not in core_result.protected["protected_indices"]]
                if core_result.stage1.active_criteria != residual:
                    raise ValueError("Mode-B Global QCCA requires residual Stage-1 scope.")
                names = tuple(dataset.criteria[i].name for i in residual)
                matrix = [[row[i] for i in residual] for row in matrix]
            expected, level_count = core_result.stage1.q1, core_result.stage1.k_g_eff
            automatic = False
            source = core_result.stage1.frozen_global.identity
        elif representation == "LOCAL":
            if not core_result.stage2.local_qcca_required:
                return QccaOutcome("NOT_REQUIRED", None, None)
            matrix = core_result.stage2.ll
            domain = tuple(core_result.stage1.retained)
            expected, level_count = core_result.stage2.q2, core_result.stage2.k_l
            automatic = True
            source = f"{core_result.stage1.frozen_global.identity}:LOCAL:{level_count}"
        else:
            raise ValueError("QCCA representation must be GLOBAL or LOCAL.")
        qcca = analyze_qcca(names, matrix, expected, level_count, domain_indices=domain, candidate_ids=dataset.candidate_ids, representation=representation, mode=mode, frozen_source_identity=source, automatic_local_targets=automatic)
        verification = verify_qcca(qcca, expected)
        return QccaOutcome("COMPLETED" if verification.passed else "INTEGRITY_FAILED", qcca if verification.passed else None, verification)
    except Exception:
        return QccaOutcome("UNAVAILABLE", None, None)
