# Case 02 — Urban quality of life source record

- **Local archived source:** `quality_of_life_european_cities_2023_aggregated_data.xlsx`
- **Source locator:** QoL in European cities 2023_V2; Top2 aggregate rows TB_Q1a_1, TB_Q2_1, TB_Q2_2, TB_Q2_3 and TB_Q2_5
- **Source citation:** De Dominicis, L. et al. *Report on the Quality of Life in European Cities, 2023*. European Commission, DG REGIO (2023). DOI: https://doi.org/10.2776/830208
- **Official source locator:** https://ec.europa.eu/regional_policy/en/information/maps/quality_of_life
- **Initial source population:** 83 city columns
- **Candidate filter / population rule:** Retain the 83 city-level aggregates; total-average column is not a candidate
- **Final CNPW population:** 83
- **Active responses:** 5
- **Local source SHA256:** `49986134cde7cddd1858ad1536558e66698ae86d28252f4d9b911ee63d79c03c`
- **Local source size (bytes):** 815216
- **Redistribution status:** `PROVENANCE_ONLY_ORIGINAL_NOT_BUNDLED`
- **Frozen input:** `CNPW_H2_EU_Quality_of_Life_Cities_2023_M5_Input_v0.1.xlsx`

The five frozen Top2 aggregate rows and response labels are recorded explicitly in `Source_to_Input_Mapping.xlsx`. The original third-party workbook is not bundled in SD4.
