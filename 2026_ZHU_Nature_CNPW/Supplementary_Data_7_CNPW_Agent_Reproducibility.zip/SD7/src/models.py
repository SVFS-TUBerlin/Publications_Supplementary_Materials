from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Literal

K_G = 7
K_L = 7


@dataclass(frozen=True)
class Criterion:
    name: str
    column: int
    direction: str  # "maximize" or "minimize"


@dataclass
class Dataset:
    source: str
    file_format: str
    criteria: list[Criterion]
    descriptor_names: list[str]
    candidate_ids: list[str]
    values: list[list[Decimal]]
    descriptors: list[list[Any]]


@dataclass(frozen=True)
class FrozenGlobalLevels:
    """The once-only full-population Global assignment, identified by content."""
    identity: str
    levels: tuple[tuple[int, ...], ...]


@dataclass(frozen=True)
class ProtectionContract:
    """Explicit V8 Mode-B admissible-domain definition."""
    semantics: Literal["equal_count_global_qualification", "explicit_raw_thresholds", "normalized_operating_range_tolerances"]
    protected_indices: tuple[int, ...]
    raw_thresholds: dict[int, Decimal] | None = None
    tolerances: dict[int, Decimal] | None = None


@dataclass
class Stage1Result:
    gl: list[list[int]]
    nominal_counts: dict[str, list[int]]
    final_counts: dict[str, list[int]]
    tie_adjustments: dict[str, int]
    joint_counts: dict[int, int]
    q1: int
    retained: list[int]
    frozen_global: FrozenGlobalLevels | None = None
    active_criteria: list[int] = field(default_factory=list)
    k_g_eff: int = K_G


@dataclass
class Stage2Result:
    ll: list[list[int]]
    local: dict[str, dict[str, Any]]
    joint_counts: dict[int, int]
    q2: int
    retained: list[int]
    k_l: int = K_L
    adaptive_trace: list[dict[str, Any]] = field(default_factory=list)
    local_status: str = "local_unclassified"
    local_qcca_required: bool = False
    response_equivalent: bool = False


@dataclass
class RunResult:
    mode: str
    stage1: Stage1Result
    stage2: Stage2Result
    profile_class: list[int]
    terminal: list[int]
    protected: dict[str, Any] | None = None
    co_terminal: bool = False
    response_equivalent: bool = False
