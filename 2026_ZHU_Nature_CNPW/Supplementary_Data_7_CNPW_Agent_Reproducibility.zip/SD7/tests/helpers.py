from decimal import Decimal

from src.models import Criterion, Dataset


def make_dataset(ids, names, directions, rows, descriptors=None):
    descriptors = descriptors or [[] for _ in ids]
    return Dataset("memory.csv", "CSV", [Criterion(name, index + 1, direction) for index, (name, direction) in enumerate(zip(names, directions))], [], ids, [[Decimal(str(value)) for value in row] for row in rows], descriptors)
