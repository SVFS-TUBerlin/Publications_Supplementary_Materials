# Case 05 — Pesticide substitution × CNPW final-formalism replay v1.6.0

## Status

**FINAL REPLACEMENT EVIDENCE.** This replay supersedes the legacy fixed-`K_L=7` Stage-2 records in the previous v1.5.4 compatibility workbook/report while preserving the same reconstructed 47-block / 200,625-scenario universe.

## Frozen contract

- Stage 1 uses the final finite-library rule `K_G=min(7,N)` and deterministic positional Global-Level allocation with exact-tie upward handling.
- Each block is evaluated independently.
- Stage 2 begins from `K_L,0=7` and follows the final adaptive all-top procedure.
- When the all-top set becomes empty, the current `K_L*` is frozen; candidates are compared by joint Local capability, weakest-first ordered Local profiles and raw-response Pareto pruning.
- Set-valued co-terminal outcomes are retained.
- All four environmental impacts are minimized.

## Final headline results

- 47 decision blocks; 200,625 reconstructed scenarios.
- Native rank-1 reaches the Stage-1 highest-qualified set in **30/47** blocks.
- Native rank-1 is retained as a final CNPW terminal/co-terminal in **24/47** blocks.
- Therefore the 23 disagreements decompose into **17** native rank-1 alternatives below the attainable candidate-space ceiling and **6** that reach the ceiling but differ after final refinement.
- **21/47** blocks are top-compatible.
- Among the remaining **26** candidate-space-limited blocks, **25** recover a higher Global capability after removing one impact; **Tomato-H** requires a minimum removal order of two.

These are the manuscript/Table-1 claims and they are **unchanged** by the final adaptive Stage-2 replay.

## Adaptive Stage-2 corrections

The old v1.5.4 report used a fixed `K_L=7` Stage 2. Under the final adaptive formalism:

- **Chili-I:** `K_L*=9`; the unique all-top candidate remains scenario **40415**.
- **Tomato-I:** `K_L*=8`; the unique all-top candidate remains scenario **13416**.
- **Okra-I:** the all-top set becomes empty at `K_L*=182`; Local capability is **LL181**. Four candidates share that Local floor, after which ordered-profile and raw-response pruning retain only scenarios **6584** and **6585** as co-terminals. The legacy fixed-`K_L=7` co-terminals **6596** and **6597** are removed.
- Stage-1 singleton blocks are now recorded as resolved at Stage 1 rather than being assigned an artificial fixed-`K_L=7` Stage-2 state.
- Blocks with candidates that remain permanently all-top because of identical supplied response magnitudes retain set-valued co-terminal treatment.

The pooled number of terminal/co-terminal candidate records is therefore **60**, rather than the legacy fixed-`K_L=7` total of 62. This does not change the 24/47 native/CNPW agreement count.

## Included files

- `es5c-Pesticide_CNPW_FinalFormalism_v1.6.0.xlsx` — final block summary, adaptive Stage-2 audit, complete 47×15 Global compatibility audit, collapse/recovery table and final terminal records.
- `es5c-Pesticide_CNPW_200625_FinalFormalism_v1.6.0.csv.gz` — complete candidate-level reconstructed universe with final Global labels and final Stage-2 state/membership fields.
- `DERIVED_AUDIT/Pesticide_Headline_Audit.csv` — compact manuscript-claim audit.

## Replacement instruction

In SD8 Case05, remove/supersede:

- `es5c-Pesticide_CNPW_v1.5.4_Compatibility_and_Regression.xlsx`
- `es5c-Pesticide_CNPW_v1.5.4_Compatibility_and_Regression_Report.md`
- the legacy candidate CSV containing fixed-`K_L=7` derived Stage-2 columns.

Use the files in this final package as the authoritative Case05 evidence.
