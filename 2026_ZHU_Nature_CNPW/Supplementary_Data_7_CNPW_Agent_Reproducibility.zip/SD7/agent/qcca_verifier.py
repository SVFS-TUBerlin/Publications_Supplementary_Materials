from dataclasses import dataclass
from itertools import combinations

from .qcca_analyzer import recovery_for_target


@dataclass(frozen=True)
class QccaVerification:
    passed: bool
    failures: tuple[str, ...]


def verify_qcca(result, expected_full_capability):
    failures = []
    all_capabilities = {**result.singleton_ceilings, **result.subset_ceilings}
    expected = 2 ** len(result.criterion_names) - 1
    if len(all_capabilities) != expected or len(result.subset_capabilities) not in {0, expected}:
        failures.append("SUBSET_COUNT")
    if result.full_system_ceiling != expected_full_capability:
        failures.append("FULL_CAPABILITY")
    if result.representation not in {"GLOBAL", "LOCAL"} or result.mode not in {"MODE_A", "MODE_B"}:
        failures.append("DOMAIN_OR_REPRESENTATION")
    if not result.domain_candidate_ids or not result.level_matrix or len(result.domain_candidate_ids) != len(result.level_matrix):
        failures.append("DOMAIN_BINDING")
    if not result.frozen_source_identity:
        failures.append("FROZEN_SOURCE")
    if any(type(value) is not int or not 1 <= value <= result.global_level_count for value in all_capabilities.values()):
        failures.append("CEILING_RANGE")
    # Recompute every subset capability and its exact supporting set directly
    # from the bound frozen matrix; stored summary fields are never trusted.
    positions = {name: i for i, name in enumerate(result.criterion_names)}
    records = {item.responses: item for item in result.subset_capabilities}
    for size in range(1, len(result.criterion_names) + 1):
        for subset in combinations(result.criterion_names, size):
            values = [min(row[positions[name]] for name in subset) for row in result.level_matrix]
            capability = max(values)
            supporters = tuple(result.domain_candidate_ids[i] for i, value in enumerate(values) if value == capability)
            record = records.get(subset)
            if all_capabilities.get(subset) != capability or record is None or record.capability != capability or record.supporting_candidate_ids != supporters:
                failures.append("SUBSET_RECOMPUTATION")
                break
    if any(all_capabilities[t] > all_capabilities[s] for s in all_capabilities for t in all_capabilities if set(s) < set(t)):
        failures.append("MONOTONICITY")
    if any(item.delta_gl != all_capabilities[item.base] - all_capabilities[item.expanded] or item.delta_gl < 0 for item in result.addition_transitions):
        failures.append("ADDITION")
    if any(item.delta_gl != all_capabilities[item.reduced] - result.full_system_ceiling or item.delta_gl < 0 for item in result.leave_one_out_recoveries):
        failures.append("REMOVAL")
    if result.full_system_collapse_depth != result.global_level_count - result.full_system_ceiling:
        failures.append("DEPTH")
    expected_targets = tuple(recovery_for_target(result, target) for target in range(result.full_system_ceiling + 1, result.global_level_count + 1)) if result.representation == "LOCAL" else ()
    if result.target_recoveries != expected_targets:
        failures.append("RECOVERY_ORDER_OR_SETS")
    for target in result.target_recoveries:
        if not verify_recovery(result, target):
            failures.append("RECOVERY")
            break
    return QccaVerification(not failures, tuple(failures))


def verify_recovery(result, recovery):
    if recovery.state != "RECOVERABLE":
        return recovery.minimum_recovery_order is None and not recovery.recovery_sets
    rebuilt = recovery_for_target(result, recovery.target)
    return rebuilt == recovery and all(item.retained_responses for item in recovery.recovery_sets)
