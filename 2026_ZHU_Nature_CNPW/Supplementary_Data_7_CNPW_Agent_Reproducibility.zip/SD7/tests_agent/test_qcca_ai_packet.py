import unittest
from pathlib import Path
from agent.dual_coordinator import DualAnalysisCoordinator
from agent.ai_summary import build_fact_packet, summarize_verified_facts
ROOT=Path(__file__).resolve().parents[1]
class QccaPacketTests(unittest.TestCase):
 def test_verified_qcca_is_bounded(self):
  d=DualAnalysisCoordinator(ROOT).execute(ROOT/'examples'/'example_m3.csv').result;p=build_fact_packet(d);self.assertIn('qcca',p);s=str(p);self.assertNotIn('candidate_ids',s);self.assertNotIn('per_criterion_global_trace',s)
 def test_unsafe_removal_is_rejected(self):
  d=DualAnalysisCoordinator(ROOT).execute(ROOT/'examples'/'example_m3.csv').result;p=build_fact_packet(d)
  class F:
   def summarize(self,p): return {'summary_contract_version':'0.1','overview':'Criterion X should be removed.','mode_a_interpretation':'x','mode_b_interpretation':'x','comparison_interpretation':'x','scope_note':'x'}
  self.assertEqual('AI_SUMMARY_INVALID',summarize_verified_facts(p,F()).status)
