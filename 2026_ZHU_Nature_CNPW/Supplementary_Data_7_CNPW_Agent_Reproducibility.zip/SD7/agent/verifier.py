from __future__ import annotations

import hashlib
from dataclasses import dataclass
from decimal import Decimal
from itertools import combinations
from pathlib import Path

from src.input_loader import load_dataset
from src.models import K_G
from .contracts import CanonicalTask, ExecutionMode


@dataclass(frozen=True)
class VerificationReport:
    status: str
    failures: tuple[str, ...]
    semantic_states: tuple[str, ...]
    checks: tuple[tuple[str, bool], ...]

    @property
    def passed(self): return self.status == "completed"
    def to_dict(self): return {"status": self.status, "failures": list(self.failures), "semantic_states": list(self.semantic_states), "checks": dict(self.checks)}


def _hash(path):
    item = Path(path)
    return hashlib.sha256(item.read_bytes()).hexdigest() if item.is_file() else None


def _expected_global(dataset):
    """Independent implementation of the SI finite-library allocation rule."""
    n, m, k = len(dataset.candidate_ids), len(dataset.criteria), min(K_G, len(dataset.candidate_ids))
    matrix = [[0] * m for _ in range(n)]
    for j, criterion in enumerate(dataset.criteria):
        ordered = sorted(range(n), key=lambda i: dataset.values[i][j], reverse=criterion.direction == "minimize")
        nominal = [min(k, (k * (rank + 1) + n - 1) // n) for rank in range(n)]
        start = 0
        while start < n:
            end = start
            while end + 1 < n and dataset.values[ordered[end + 1]][j] == dataset.values[ordered[start]][j]: end += 1
            level = max(nominal[start:end + 1])
            for position in range(start, end + 1): matrix[ordered[position]][j] = level
            start = end + 1
    return matrix, k


def _expected_local(dataset, domain, k_l):
    matrix = [[0] * len(dataset.criteria) for _ in dataset.candidate_ids]
    for j, criterion in enumerate(dataset.criteria):
        values = [dataset.values[i][j] for i in domain]
        low, high = min(values), max(values)
        span, width = high - low, (high - low) / Decimal(k_l)
        thresholds = [low + Decimal(level - 1) * width if criterion.direction == "maximize" else high - Decimal(level - 1) * width for level in range(1, k_l + 1)]
        for i in domain:
            value = dataset.values[i][j]
            if span == 0: matrix[i][j] = k_l
            elif criterion.direction == "maximize": matrix[i][j] = max(level for level, threshold in enumerate(thresholds, 1) if value >= threshold)
            else: matrix[i][j] = max(level for level, threshold in enumerate(thresholds, 1) if value <= threshold)
    return matrix


def _shortfall(dataset, candidate, criterion, domain):
    values = [dataset.values[i][criterion] for i in domain]
    low, high = min(values), max(values)
    span = high - low
    if span == 0:
        return Decimal(0)
    value = dataset.values[candidate][criterion]
    return ((high - value) / span if dataset.criteria[criterion].direction == "maximize"
            else (value - low) / span)


def _expected_adaptive_local(dataset, domain, initial_k_l):
    """Independently derive the finite adaptive Local state required by the task."""
    columns = list(range(len(dataset.criteria)))
    initial = _expected_local(dataset, domain, initial_k_l)
    if len(domain) == 1:
        return initial, initial_k_l, [{"k_l": initial_k_l, "all_top": list(domain), "event": "unique_w1"}], "resolved_unique_highest_global", False, False, None
    maximum_shortfall = {i: max(_shortfall(dataset, i, j, domain) for j in columns) for i in domain}
    exits = sorted({int(Decimal(1) / value) + 1 for value in maximum_shortfall.values()
                    if value > 0 and int(Decimal(1) / value) + 1 > initial_k_l})
    trace = []
    for k_l in [initial_k_l, *exits]:
        matrix = initial if k_l == initial_k_l else _expected_local(dataset, domain, k_l)
        all_top = [i for i in domain if all(matrix[i][j] == k_l for j in columns)]
        trace.append({"k_l": k_l, "all_top": list(all_top), "event": "initial" if k_l == initial_k_l else "exit_threshold"})
        if len(all_top) == 1:
            return matrix, k_l, trace, "resolved_unique_all_top_local", False, False, None
        if not all_top:
            return matrix, k_l, trace, "local_qcca_required", True, False, None
    matrix = initial if not exits else _expected_local(dataset, domain, exits[-1])
    equivalent = [i for i in domain if maximum_shortfall[i] == 0]
    same_responses = len(equivalent) >= 2 and all(
        all(dataset.values[i][j] == dataset.values[equivalent[0]][j] for j in columns)
        for i in equivalent[1:])
    if same_responses:
        return matrix, exits[-1] if exits else initial_k_l, trace, "co_terminal_response_equivalent", False, True, equivalent
    raise RuntimeError("Independent adaptive Local derivation ended without a valid state.")


def _capability(matrix, domain, columns):
    values = {i: min(matrix[i][j] for j in columns) for i in domain}
    capability = max(values.values())
    return capability, [i for i in domain if values[i] == capability]


def _terminal(dataset, candidates, ll):
    columns = range(len(dataset.criteria))
    profiles = {i: tuple(sorted(ll[i][j] for j in columns)) for i in candidates}
    best = max(profiles.values())
    profile_class = [i for i in candidates if profiles[i] == best]
    terminal = []
    for i in profile_class:
        dominated = False
        for other in profile_class:
            if other == i: continue
            no_worse = all(dataset.values[other][j] >= dataset.values[i][j] if dataset.criteria[j].direction == "maximize" else dataset.values[other][j] <= dataset.values[i][j] for j in columns)
            better = any(dataset.values[other][j] > dataset.values[i][j] if dataset.criteria[j].direction == "maximize" else dataset.values[other][j] < dataset.values[i][j] for j in columns)
            if no_worse and better:
                dominated = True
                break
        if not dominated: terminal.append(i)
    return profile_class, terminal


def verify_result(task: CanonicalTask, result: dict, candidate_ids: list[str], execution_input_path) -> VerificationReport:
    """Reconstruct scientific invariants from the raw dataset and level matrices."""
    checks, failures = {}, []
    required = {"task_id", "mode", "input_summary", "stage_1", "stage_2", "terminal", "provenance", "integrity"}
    checks["required_result_fields"] = required <= set(result)
    try:
        dataset = load_dataset(execution_input_path)
        active, s1, s2, terminal = result["input_summary"]["active_criteria"], result["stage_1"], result["stage_2"], result["terminal"]
        ids = dataset.candidate_ids
        gl, k_eff = _expected_global(dataset)
        condition = result.get("mode_b_conditioning")
        expected_mode_b = task.requested_mode in {ExecutionMode.MODE_B_PROTECTED_DOMAIN, ExecutionMode.MODE_B_SIMPLIFIED_RESULT_A_GL7}
        expected_protected = list(task.protected_indices) if task.requested_mode is ExecutionMode.MODE_B_PROTECTED_DOMAIN else ([0] if expected_mode_b else [])
        expected_semantics = task.protection_semantics if task.requested_mode is ExecutionMode.MODE_B_PROTECTED_DOMAIN else ("equal_count_global_qualification" if expected_mode_b else None)
        if not expected_mode_b:
            domain, stage1_columns = list(range(len(ids))), list(range(len(active)))
        else:
            protected = expected_protected
            if expected_semantics != "equal_count_global_qualification":
                raise ValueError("Canonical task uses unsupported protection semantics.")
            k_p = max(min(gl[i][j] for j in protected) for i in range(len(ids)))
            domain = [i for i in range(len(ids)) if min(gl[i][j] for j in protected) >= k_p]
            stage1_columns = [j for j in range(len(active)) if j not in protected]
            expected_names = [dataset.criteria[j].name for j in protected]
            expected_residual_names = [dataset.criteria[j].name for j in stage1_columns]
            checks.update({
                "mode_b_conditioning_present": condition is not None,
                "mode_b_contract_semantics_match_task": condition["contract_type"] == expected_semantics,
                "mode_b_protected_indices_match_task": condition["protected_indices"] == protected,
                "mode_b_protected_names_match_task": condition["protected_block"] == expected_names,
                "mode_b_residual_names_match_task": condition["residual_criteria"] == expected_residual_names,
                "mode_b_protected_level_recomputed": condition["k_p"] == k_p,
                "mode_b_omega_recomputed": condition["omega_candidate_ids"] == [ids[i] for i in domain],
                "mode_b_protected_count_recomputed": condition["protected_count"] == len(domain),
                "stage1_uses_exact_residual_responses": s1.get("qualification_response_indices") == stage1_columns,
                "protected_responses_reenter_stage2": set(s2["per_criterion_local_trace"]["local"]) == {x["name"] for x in active},
                "protected_response_reenters_local": set(expected_names) <= set(s2["per_criterion_local_trace"]["local"]),
            })
        q1, w1 = _capability(gl, domain, stage1_columns)
        ll, expected_k_l, expected_trace, expected_status, expected_qcca, expected_equivalent, equivalent_retained = _expected_adaptive_local(dataset, w1, task.core_configuration.kl)
        q2, w2 = _capability(ll, w1, list(range(len(active))))
        if equivalent_retained is not None:
            w2 = equivalent_retained
        stored_w1, stored_w2 = set(s1["retained_candidate_ids"]), set(s2["retained_candidate_ids"])
        stored_terminal = set(terminal["terminal_candidate_ids"]) if isinstance(terminal["terminal_candidate_ids"], list) else set()
        profile, term = _terminal(dataset, w2, ll)
        if expected_status == "co_terminal_response_equivalent": profile = term = w2
        checks.update({
            "task_id_matches": result["task_id"] == task.task_id,
            "task_mode_matches": result["mode"] == task.requested_mode.value,
            "input_hash_matches": result["provenance"]["input_hash_sha256"] == task.input_summary.identity.source_hash_sha256 == _hash(execution_input_path),
            "canonical_task_hash_matches": result["provenance"].get("canonical_task_sha256", result["provenance"].get("canonical_task_hash_sha256")) == task.task_hash_sha256,
            "active_response_order": [x["name"] for x in active] == [x.name for x in task.input_summary.active_criteria],
            "directions_match": [x["direction"] for x in active] == [x.direction for x in task.input_summary.active_criteria],
            "descriptors_metadata_only": result["input_summary"].get("descriptors") == list(task.input_summary.descriptors),
            "w2_subset_w1": stored_w2 <= stored_w1,
            "w2t_subset_w2": stored_terminal <= stored_w2,
            "k_g_eff_rule": s1.get("k_g_eff", k_eff) == k_eff,
            "global_matrix_recomputed": s1["per_criterion_global_trace"]["gl"] == gl,
            "stage1_capability_recomputed": s1["highest_joint_level"] == q1,
            "w1_membership_recomputed": s1["retained_candidate_ids"] == [ids[i] for i in w1],
            "adaptive_k_l_matches_task": s2["k_l"] == expected_k_l,
            "adaptive_trace_recomputed": s2.get("adaptive_trace") == expected_trace,
            "local_status_recomputed": s2.get("local_status") == expected_status,
            "local_qcca_required_recomputed": s2.get("local_qcca_required") is expected_qcca,
            "response_equivalent_recomputed": s2.get("response_equivalent") is expected_equivalent,
            "local_matrix_recomputed": all(s2["per_criterion_local_trace"]["ll"][i] == ll[i] for i in w1),
            "stage2_capability_recomputed": s2["highest_joint_level"] == q2,
            "w2_membership_recomputed": s2["retained_candidate_ids"] == [ids[i] for i in w2],
            "profile_membership_recomputed": terminal["profile_class_candidate_ids"] == [ids[i] for i in profile],
            "terminal_identity_recomputed": terminal["terminal_candidate_ids"] == [ids[i] for i in term],
            "terminal_is_list": isinstance(terminal["terminal_candidate_ids"], list),
        })
        if task.requested_mode is ExecutionMode.MODE_A: checks["mode_a_unprotected"] = condition is None
    except Exception:
        checks["independent_scientific_recomputation"] = False
    for key, value in checks.items():
        if not value: failures.append(key.upper())
    result["status"] = "completed" if not failures else "failed_integrity"
    states = []
    if not failures and len(result["terminal"]["terminal_candidate_ids"]) > 1: states.append("SET_VALUED_TERMINAL")
    return VerificationReport(result["status"], tuple(failures), tuple(states), tuple(checks.items()))


def verify_public_run(result: dict) -> VerificationReport:
    branches = result.get("mode_b_contracts", [])
    summary = result.get("input_summary")
    names = summary.active_criteria if hasattr(summary, "active_criteria") else []
    m, expected = len(names), 2 ** len(names) - 2
    blocks = [tuple(branch["canonical_task"].protected_indices) for branch in branches]
    required = [subset for size in range(1, m) for subset in combinations(range(m), size)]
    checks = {"expected_contract_count": result.get("execution", {}).get("expected_mode_b_contract_count") == expected, "actual_contract_count": len(branches) == expected, "exact_protected_family": blocks == required, "unique_contract_ids": len({branch.get("contract_id") for branch in branches}) == len(branches), "all_branch_verifications_pass": all(branch["verification"].passed for branch in branches)}
    failures = tuple(key.upper() for key, value in checks.items() if not value)
    return VerificationReport("completed" if not failures else "failed_integrity", failures, (), tuple(checks.items()))
