# Supplementary Data 3 — Controlled CNPW analyses, V8

## Scientific role

This package contains **only derived analyses of the controlled 7,056-candidate PLA–MEX system**. Its input candidate-response space is frozen in Supplementary Data 2. The V8 rebuild updates the decision and diagnostic layer without moving material from other supplementary datasets into SD3.

The controlled evidence chain is:

\[
SD1\;(source\ and\ validation)
\rightarrow
SD2\;(frozen\ 7,056\ candidate-response\ space)
\rightarrow
SD3\;(derived\ CNPW\ analyses).
\]

## What is inside SD3 V8

- `00_Summary/` — V8 numerical summary, response references and legacy-replacement map.
- `01_ModeA/` — full frozen Global reporting, adaptive Local trace and formal Mode-A baseline/terminal outputs.
- `02_Pareto/` — Pareto efficiency benchmark on the same controlled response space.
- `03_Scalarization/` — 969-weight compensatory benchmark plus exact positive-linear supportability audit.
- `04_ModeB/` — formal 14 protected-block contracts and the three UTS protection specifications.
- `05_QCCA_and_Targeted_Alternatives/` — Global/Local QCCA, target-specific recovery sets, targeted requirement changes and executable candidate alternatives.
- `06_Robustness/` — threshold, resolution, validation-error and topology sensitivity; stable strengthening audits rebuilt without superseded V8 logic.
- `07_Explainability/` — exact finite-grid SHAP, process-state pathways, process-window geometry and qualification-boundary interpretation, including the complete 7,056-row SHAP candidate table and the complete W6 boundary-controller candidate table.
- `08_Verification/` — master numerical ledger, machine-readable formal summary and the existing Phase-2 controlled residual-V8 authoritative record.

## V8 scientific boundaries

Mode A and Mode B share the frozen Global qualification representation. Mode B protection defines admissibility; residual responses determine Stage-1 conditional capability; all active responses, including protected responses, participate in Stage-2 Local refinement. Mode-B Global QCCA uses (Omega_P, J_res, G); Mode-B Local QCCA uses (W_B^(1), J, L).

QCCA is a diagnostic operator. It reuses frozen Global or Local levels, identifies response-composition compatibility/collapse and target-specific recovery sets, and does not itself perform relaxation. Targeted relaxation is a downstream action layer restricted to QCCA-identified recovery sets.

The formal controlled Mode-A path is:

\[
7056\rightarrow65\rightarrow3\rightarrow PG6628,
\]

with \(C_G=GL6\), \(K_L^*=7\) and \(C_L=LL4\).

## Explicit supplementary-data separation

The following material is **not part of SD3** and has not been copied into this package:

- **SD1:** G1–G27 process-state anchors, V1–V4 independent validation and response-space generation provenance.
- **SD2:** the canonical 7,056-row candidate-response input table.
- **SD4:** source records, rights/provenance and source-identity records for the six cross-domain datasets.
- **SD5:** the six frozen cross-domain CNPW input spreadsheets and source-to-input mapping ledger.
- **SD6:** cross-domain Mode A/Mode B/QCCA reference outputs and six detailed case reports.
- **SD7:** CNPW Agent/software identity, environment and cross-domain replay verification.
- **SD8:** nine-system cross-paradigm reconstruction ledger, complete external outputs and provenance/caveat tables.
- **Supplementary Software:** executable public software package and software release artifacts.

This separation is deliberate. SD3 is the controlled-system analysis package, not a container for cross-domain, cross-paradigm or Agent evidence.

## Legacy firewall

The active V8 package excludes superseded formal outputs implementing any of the following:

- protected-response deletion or permanent Local locking;
- automatic protection lowering;
- lower-GL backfill;
- QCCA as a relaxation frontier;
- unrestricted all-response relaxation as the formal action layer;
- the old 24 sequential Mode-B permutations as the formal core;
- the old nominal 1/2/3/5% UTS-loss scan as the formal normalized protection analysis.

Historical files remain separately available for provenance. The old 59-check log and Step-3 replay report are superseded as current Mode-B authority and are not included in this finalized active package.

## Current controlled authority and reporting fields

`08_Verification/Controlled_Residual_V8_Authoritative_Record.json` preserves the controlled residual-V8 record supplied in the authoritative snapshot. Software identity, execution-environment, replay and regression verification are provided separately in Supplementary Data 7.

Named profiles use UTS, E, GWP, FRS order (canonical names UTS_MPa, E_MPa, GWP_kgCO2eq, FRS_kgoileq). `Conditional_C_G` and Mode-B `Global_C` denote residual capability C_res; they are not the full-profile `Q_G`. The latter retains its existing definition across all four frozen Global responses. Mode-A fields retain their original meaning. Unchanged UTS protection-language values also report residual capability; the stored-level invariance argument is documented in the approved pre-finalization audit.

The formal UTS Global table contains the seven residual E/GWP/FRS subsets. The protected-UTS comparison from the original table is retained in the historical source archive, not presented as part of formal residual QCCA. All Results-2.2 Local/action evidence and surviving residual-subset values are unchanged.

The affected Local recovery CSV preserves its two set definitions. Minimum-cardinality sets are copied from recorded target_recoveries. Inclusion-minimal sets are a relational projection of the recorded exhaustive subset capabilities; no levels or subset capabilities were recomputed. Full witness and action records remain in the canonical companion.
