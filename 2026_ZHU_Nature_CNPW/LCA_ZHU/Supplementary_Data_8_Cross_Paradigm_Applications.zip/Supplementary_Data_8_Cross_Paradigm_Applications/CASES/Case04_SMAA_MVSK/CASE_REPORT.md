# SMAA / MVSK — CNPW external application evidence package

## Scope

This package supports the claims actually reported for this published decision system in Results 2.3 and Table 1. It is **not** intended to reproduce every possible CNPW Mode-A, Mode-B, Stage-2, QCCA or relaxation branch. The evidential standard is claim-specific: each manuscript claim is linked to the frozen/reconstructed candidate–response evidence and to the supplied calculation or audit that supports it.

## Source system

- **Domain:** Business
- **Candidate–response size:** 46 × 10
- **Source citation:** Angilella et al. (2026), An enhanced simulation-based approach for multicriteria evaluation of SMEs’ performance, Annals of Operations Research 360, 767–813
- **Native decision object:** Stochastic preference / criterion-weight-uncertainty robust ranking

## Manuscript-claim verification

| ID | Claim | Verified result | Verification route |
|---|---|---|---|
| MVSK-1 | Candidate space | **46 × 10** | Direct frozen 2022 matrix |
| MVSK-2 | Published rank-1 mapping | **AC Immune rank 1 under λ=3,18,36; CNPW GL2** | Direct row-level mapping |
| MVSK-3 | CNPW candidate-space result | **C(J)=GL4; Eleco unique GL4 candidate** | Direct frozen-level audit |
| MVSK-4 | Recovery order | **No single-response removal raises GL4; two-response removal can recover GL5** | Exhaustive 10 choose 1 / 10 choose 2 recomputation from frozen Global levels |

The machine-readable version is `CLAIM_LEDGER.csv`.

## Included source/reconstruction evidence

- `MVSK_SME_CNPW_2018_2022_all_results_v1.csv`
- `MVSK_SME_CNPW_2022_results_v1.csv`
- `MVSK_SME_CNPW_cross_domain_validation_v1.md`
- `MVSK_SME_CNPW_temporal_summary_v1.csv`

## Derived claim-specific audits

- `MVSK_Recovery_Audit.csv`

Derived audits do not introduce a new decision method. They expose the exact arithmetic or frozen-level comparison needed to verify manuscript headline claims from the supplied evidence.

## Claim boundary

CNPW maps published SME performance/ranking results; it does not claim to rerun the full source stochastic simulation engine.

## Interpretation

CNPW is applied as an additional qualification and candidate-space diagnostic layer. A difference between the native decision and the CNPW output is not treated as proof that the native method is incorrect; it shows that the native decision object and joint qualification answer different questions. Where the candidate space is top-compatible, the package retains that positive-control result rather than forcing a limitation diagnosis.

## Status

**CLAIM-SPECIFIC EVIDENCE COMPLETE FOR THE CURRENT MANUSCRIPT/TABLE-1 CLAIMS.**
