from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Protocol

from .contracts import stable_json

SYSTEM_PROMPT = """You are a bounded scientific communication layer. You receive only verified CNPW facts. You do not calculate CNPW, recommend a mode or candidate, infer hidden preferences or domain causality, or add metrics. Summarize only supplied facts. Mode B is a predefined companion analysis, not an inferred user preference. Omit unsupported statements."""


class SummaryClient(Protocol):
    def summarize(self, fact_packet: dict[str, Any]) -> dict[str, Any]: ...


@dataclass(frozen=True)
class SummaryOutcome:
    status: str
    interpretation: dict[str, Any] | None


def build_fact_packet(dual: dict[str, Any]) -> dict[str, Any] | None:
    if dual.get("overall_integrity_status") != "completed":
        return None
    a, b, c = dual["mode_a"], dual["mode_b"], dual["comparison"]
    def branch(result, verification):
        states = set(verification.semantic_states)
        terminal = result["terminal"]["terminal_candidate_ids"]
        return {"q1_level": result["stage_1"]["highest_joint_level"], "w1_count": len(result["stage_1"]["retained_candidate_ids"]), "q2_level": result["stage_2"]["highest_joint_level"], "w2_count": len(result["stage_2"]["retained_candidate_ids"]), "terminal_count": len(terminal), "terminal_form": "SET_VALUED" if len(terminal) > 1 else "SINGLETON", "stage2_compression": "NO" if "STAGE2_NO_COMPRESSION" in states else "YES", "raw_dominance_activated": "YES" if "RAW_DOMINANCE_ACTIVATED" in states else "NO", "semantic_state_labels": list(verification.semantic_states)}
    relation = "IDENTICAL" if c["terminal_same"] else "PARTIAL_OVERLAP" if c["terminal_overlap_ids"] else "DIFFERENT"
    rel = lambda x, y: "EQUAL" if x == y else "A_GREATER" if x > y else "B_GREATER"
    packet = {"fact_packet_version": "0.1", "active_criterion_names": [x.name for x in dual["input_summary"].active_criteria], "mode_a": branch(a["verified_result"], a["verification"]), "mode_b": {**branch(b["verified_result"], b["verification"]), "protected_result_name": b["verified_result"]["mode_b_conditioning"]["protected_criterion"], "protected_level": "GL7", "protected_count": c["mode_b_protected_count"], "residual_criterion_count": len(b["verified_result"]["mode_b_conditioning"]["residual_criteria"])}, "comparison": {"terminal_relation": relation, "w1_count_relation": rel(c["mode_a_w1_count"], c["mode_b_w1_count"]), "w2_count_relation": rel(c["mode_a_w2_count"], c["mode_b_w2_count"])}}
    q = dual.get("qcca")
    if q is not None and q.status == "COMPLETED" and q.verification and q.verification.passed:
        x=q.result; positive=[{"base_subset": list(t.base), "added_response": t.added, "before": t.base_ceiling, "after": t.expanded_ceiling, "loss": t.delta_gl} for t in x.addition_transitions if t.delta_gl>0]
        packet["qcca"]={"criterion_names":list(x.criterion_names),"full_system_ceiling":x.full_system_ceiling,"full_system_collapse_depth":x.full_system_collapse_depth,"first_collapse_order":x.first_collapse_order,"objective_count_profile":x.size_profile,"composition_effect_sizes":[size for size,levels in x.size_profile.items() if len(levels)>1],"positive_addition_transitions":positive,"transition_counts":{"total":len(x.addition_transitions),"stable":len(x.addition_transitions)-len(positive),"collapse":len(positive)},"leave_one_out_recoveries":[{"removed_response":t.removed,"full":t.full_ceiling,"after_removal":t.reduced_ceiling,"recovery":t.delta_gl} for t in x.leave_one_out_recoveries],"bottleneck_state":x.bottleneck_state}
    return packet


def summarize_verified_facts(packet: dict[str, Any] | None, client: SummaryClient | None) -> SummaryOutcome:
    if packet is None or client is None:
        return SummaryOutcome("AI_SUMMARY_UNAVAILABLE", None)
    try:
        value = client.summarize(packet)
    except Exception:
        return SummaryOutcome("AI_SUMMARY_UNAVAILABLE", None)
    allowed = {"summary_contract_version", "overview", "mode_a_interpretation", "mode_b_interpretation", "comparison_interpretation", "scope_note", "provider_identity", "model_identity"}
    required = allowed - {"provider_identity", "model_identity"}
    if set(value) - allowed or not required.issubset(value):
        return SummaryOutcome("AI_SUMMARY_INVALID", None)
    prohibited = ("recommend", "winner", "user prioritized", "objectively best", "should be removed", "should remove", "causes", "definitely distributed")
    if any(word in " ".join(str(value[x]).lower() for x in required) for word in prohibited):
        return SummaryOutcome("AI_SUMMARY_INVALID", None)
    packet_hash = hashlib.sha256(stable_json(packet).encode()).hexdigest()
    response_hash = hashlib.sha256(stable_json(value).encode()).hexdigest()
    return SummaryOutcome("AI_SUMMARY_AVAILABLE", {**value, "fact_packet_hash": packet_hash, "response_hash": response_hash, "system_prompt_hash": hashlib.sha256(SYSTEM_PROMPT.encode()).hexdigest(), "created_at": datetime.now(timezone.utc).isoformat()})
