# CNPW V8_RESIDUAL_MODEB software

Protection determines admissibility; residual responses determine Stage-1 conditional capability; all active responses re-enter Stage-2 Local refinement.

Mode-B Global QCCA: (Omega_P,J_res,G). Local: (W1,J,L). Start Streamlit with run_agent.bat or run_agent.sh. Upload → Run → Download.

The exact controlled replay fixture `CNPW_PLA_MEX_7056_Core_Input_v0.2.csv` is included and its SHA-256 is recorded in the package manifest. For reference-output reproduction, extract SD5 and SD6 separately, then run:

```text
python -B scripts/publication_replay.py --inputs SD5/inputs --controlled CNPW_PLA_MEX_7056_Core_Input_v0.2.csv --reference SD6 --output new_replay
```

The harness verifies all 161 decisions, including the separately counted controlled 15, against the complete portable SD6 scientific state; non-scientific paths, timestamps and implementation hashes are excluded from comparison. Core/Agent/UI tests include finite-library allocation, independent verifier mutation, and stale-state regressions.

LEGACY / NOT USED BY DEFAULT V8: src/main.py interactive CLI; app.streamlit_app.main; agent/report_renderer.py and intent-driven compatibility modules. Their historical labels do not define the current contract. Scientific source files are exact Phase-1 bytes.

The included tests_replay/test_six_domain_replay.py is the Phase-1 comparison test against the OLD full-response reference; it is not the new SD6 reference verifier. Use publication_replay.py for current SD6. The old reference is intentionally excluded from the submission archives.
