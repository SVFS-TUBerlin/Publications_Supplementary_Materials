from __future__ import annotations

import os
import unittest
from pathlib import Path

from agent.contracts import ExecutionMode
from agent.coordinator import AgentCoordinator
from agent.intent_models import (INTENT_CONTRACT_VERSION, INTENT_SYSTEM_PROMPT_HASH,
                                 IntentLabel, IntentProposal)
from agent.intent_router import validate_intent_proposal
from agent.llm_client import IntentProviderError, OpenAIIntentClient


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = str(ROOT / "tests_agent" / "fixtures" / "small_m3.csv")
TIME = "2026-08-19T12:00:00+00:00"


def proposal(intent: str, **extra):
    base = {"intent_contract_version": INTENT_CONTRACT_VERSION, "request_id": "request-1", "intent": intent, "short_reason": "bounded technical test", "provider_identity": "fake", "model_identity": "fake-model", "raw_response_hash": "a" * 64, "created_at": TIME, "confidence_label": "HIGH"}
    base.update(extra)
    return base


class FakeIntentClient:
    def __init__(self, response=None, error: Exception | None = None):
        self.response = response
        self.error = error
        self.calls = 0
        self.last_context = None

    def propose_intent(self, user_text, context):
        self.calls += 1
        self.last_context = context
        if self.error:
            raise self.error
        return self.response


class AgentStage4Tests(unittest.TestCase):
    def coordinator(self, response=None, error=None):
        client = FakeIntentClient(response, error)
        return AgentCoordinator(client, ROOT), client

    def test_valid_mode_a_and_mode_b_proposals(self):
        self.assertEqual(ExecutionMode.MODE_A, validate_intent_proposal(proposal("MODE_A")).mode)
        self.assertEqual(ExecutionMode.MODE_B_SIMPLIFIED_RESULT_A_GL7, validate_intent_proposal(proposal("MODE_B_SIMPLIFIED_RESULT_A_GL7")).mode)

    def test_unsupported_intent_is_rejected(self):
        outcome = validate_intent_proposal(proposal("UNSUPPORTED"))
        self.assertFalse(outcome.accepted)
        self.assertEqual("AI_INTENT_UNSUPPORTED", outcome.error.code)

    def test_malformed_unknown_and_forbidden_model_output_are_rejected(self):
        for value in ({"intent": "MODE_A"}, proposal("UNKNOWN"), proposal("MODE_A", direction="minimize")):
            with self.subTest(value=value):
                outcome = validate_intent_proposal(value)
                self.assertFalse(outcome.accepted)
                self.assertEqual("AI_INTENT_INVALID", outcome.error.code)

    def test_ai_cannot_set_scientific_fields(self):
        for field in ("direction", "protected_criterion", "protected_level", "kg", "kl", "threshold", "weight", "terminal_candidate_ids"):
            with self.subTest(field=field):
                outcome = validate_intent_proposal(proposal("MODE_A", **{field: "forbidden"}))
                self.assertFalse(outcome.accepted)
                self.assertEqual("AI_INTENT_INVALID", outcome.error.code)

    def test_validated_mode_a_pipeline_builds_task_and_reaches_core(self):
        coordinator, client = self.coordinator(proposal("MODE_A"))
        outcome = coordinator.execute(FIXTURE, "Treat all results equally.", execution_timestamp=TIME)
        self.assertIsNone(outcome.error)
        self.assertEqual("MODE_A", outcome.result["mode"])
        self.assertTrue(outcome.verification.passed)
        self.assertEqual(("A", "B", "C"), client.last_context.active_result_names)
        self.assertTrue(client.last_context.directions_are_defined_by_input)
        self.assertFalse(hasattr(client.last_context, "direction_vector"))

    def test_validated_mode_b_pipeline_derives_result_a(self):
        coordinator, _ = self.coordinator(proposal("MODE_B_SIMPLIFIED_RESULT_A_GL7"))
        outcome = coordinator.execute(FIXTURE, "Protect the first Result A before evaluating the rest.", execution_timestamp=TIME)
        self.assertIsNone(outcome.error)
        self.assertEqual("MODE_B_SIMPLIFIED_RESULT_A_GL7", outcome.result["mode"])
        self.assertEqual("A", outcome.result["input_summary"]["active_criteria"][0]["slot"])
        self.assertEqual(outcome.result["input_summary"]["active_criteria"][0]["name"], outcome.result["mode_b_conditioning"]["protected_criterion"])
        self.assertTrue(dict(outcome.verification.checks)["protected_response_reenters_local"])

    def test_invalid_proposal_never_reaches_core(self):
        coordinator, client = self.coordinator(proposal("MODE_A", weight="1"))
        outcome = coordinator.execute(FIXTURE, "Use a weight.", execution_timestamp=TIME)
        self.assertEqual("AI_INTENT_INVALID", outcome.error.code)
        self.assertEqual(1, client.calls)
        self.assertIsNone(outcome.result)

    def test_provider_error_and_timeout_fail_closed(self):
        for error, expected in ((IntentProviderError("x"), "AI_PROVIDER_ERROR"), (TimeoutError(), "AI_INTENT_UNAVAILABLE")):
            with self.subTest(expected=expected):
                coordinator, _ = self.coordinator(error=error)
                outcome = coordinator.execute(FIXTURE, "Treat all results equally.", execution_timestamp=TIME)
                self.assertEqual(expected, outcome.error.code)
                self.assertIsNone(outcome.result)

    def test_ai_provenance_is_safe_and_deterministic(self):
        coordinator, _ = self.coordinator(proposal("MODE_A"))
        first = coordinator.execute(FIXTURE, "Treat all results equally.", execution_timestamp=TIME)
        second = coordinator.execute(FIXTURE, "Treat all results equally.", execution_timestamp=TIME)
        self.assertEqual(first.provenance["ai_intent"], second.provenance["ai_intent"])
        self.assertEqual(INTENT_SYSTEM_PROMPT_HASH, first.provenance["ai_intent"]["system_prompt_hash_sha256"])
        self.assertNotIn("api", " ".join(first.provenance["ai_intent"].keys()).lower())
        self.assertNotIn("secret", str(first.provenance).lower())

    def test_optional_openai_adapter_has_no_serialized_key_and_no_live_call(self):
        client = OpenAIIntentClient(api_key="do-not-serialize", model="gpt-5")
        self.assertNotIn("do-not-serialize", repr(client))
        previous = os.environ.pop("OPENAI_API_KEY", None)
        try:
            unavailable = OpenAIIntentClient(api_key=None)
            with self.assertRaises(IntentProviderError):
                unavailable.propose_intent("equal treatment", type("Context", (), {"active_result_names": ("A",), "directions_are_defined_by_input": True})())
        finally:
            if previous is not None:
                os.environ["OPENAI_API_KEY"] = previous


if __name__ == "__main__":
    unittest.main()
