# SD5: Frozen V8 Cross-Domain Inputs

This package contains inputs only. Values, candidate IDs, response order, directions, N, and M are frozen. V8 outputs are in SD6; software is in SD7. Replay manifest: `tests_replay/manifest.json` in SD7.
