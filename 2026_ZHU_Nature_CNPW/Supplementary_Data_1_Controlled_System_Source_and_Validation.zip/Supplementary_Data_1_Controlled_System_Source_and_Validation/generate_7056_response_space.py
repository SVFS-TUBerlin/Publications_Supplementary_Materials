#!/usr/bin/env python3
"""
Reproduce the frozen 7,056-point PLA-MEX candidate-response table used by
CNPW System I from G1-G27 process-state anchors + final response equations.

Standard-library only.
"""
from pathlib import Path
import csv
import argparse

H_KNOTS = [0.10, 0.20, 0.25]
P_KNOTS = [0.430, 0.450, 0.470]
V_KNOTS = [20.0, 70.0, 120.0]

def key3(h, p, v):
    return (round(float(h), 6), round(float(p), 6), round(float(v), 6))

def load_anchors(path):
    anchors = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            k = key3(r["h_mm"], r["P_mm"], r["v_mm_s"])
            anchors[k] = {
                "Mass": float(r["Mass_mean_g"]),
                "Time": float(r["Time_min"]),
                "rhoA": float(r["rhoA_mean_g_mm2"]),
            }
    if len(anchors) != 27:
        raise RuntimeError(f"Expected 27 anchors, found {len(anchors)}")
    return anchors

def bracket(value, knots):
    value = float(value)
    if value <= knots[0]:
        return knots[0], knots[0], 0.0
    if value >= knots[-1]:
        return knots[-1], knots[-1], 0.0
    for a, b in zip(knots[:-1], knots[1:]):
        if a <= value <= b:
            if abs(value-a) < 1e-15:
                return a, a, 0.0
            if abs(value-b) < 1e-15:
                return b, b, 0.0
            return a, b, (value-a)/(b-a)
    raise ValueError(value)

def trilinear(anchors, h, p, v, field):
    h0,h1,th = bracket(h,H_KNOTS)
    p0,p1,tp = bracket(p,P_KNOTS)
    v0,v1,tv = bracket(v,V_KNOTS)

    hs = [(h0,1.0)] if h0 == h1 else [(h0,1-th),(h1,th)]
    ps = [(p0,1.0)] if p0 == p1 else [(p0,1-tp),(p1,tp)]
    vs = [(v0,1.0)] if v0 == v1 else [(v0,1-tv),(v1,tv)]

    out = 0.0
    for hh,wh in hs:
        for pp,wp in ps:
            for vv,wv in vs:
                out += wh*wp*wv*anchors[key3(hh,pp,vv)][field]
    return out

def responses(anchors, h, p, v):
    mass = trilinear(anchors,h,p,v,"Mass")
    time = trilinear(anchors,h,p,v,"Time")
    rhoA = trilinear(anchors,h,p,v,"rhoA")

    E = 506.01312 + 9581.3949*rhoA + 0.38843914*time
    UTS = (15.410646 - 13.261491*h - 20.421528*p - 0.010502281*v
           + 237.28512*rhoA - 0.026039376*time)
    GWP = 1.48*mass/1000.0 + 1.282e-3*time
    FRS = 1.78*mass/1000.0 + 1.918e-4*time
    return mass,time,rhoA,E,UTS,GWP,FRS

def grid():
    hs = [round(0.10 + 0.01*i, 2) for i in range(16)]
    ps = [round(0.430 + 0.002*i, 3) for i in range(21)]
    vs = [20 + 5*i for i in range(21)]
    pg = 0
    for h in hs:
        for p in ps:
            for v in vs:
                pg += 1
                yield pg,h,p,v

def generate(anchor_path, output_path):
    anchors = load_anchors(anchor_path)
    with open(output_path,"w",newline="",encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["Candidate_ID","h_mm","P","v_mm_s",
                    "Mass_g","Time_min","rhoA_g_mm2",
                    "E_MPa","UTS_MPa","GWP_kgCO2eq","FRS_kgoileq"])
        for pg,h,p,v in grid():
            vals = responses(anchors,h,p,v)
            w.writerow([f"PG{pg}",h,p,v,*vals])

def compare(generated_path, frozen_path, tol=1e-10):
    with open(generated_path,newline="",encoding="utf-8-sig") as fg, \
         open(frozen_path,newline="",encoding="utf-8-sig") as ff:
        g = csv.DictReader(fg)
        f = csv.DictReader(ff)
        maxdiff = {"E":0.0,"UTS":0.0,"GWP":0.0,"FRS":0.0}
        bad = 0
        n = 0
        for rg,rf in zip(g,f):
            n += 1
            pairs = {
                "E": (float(rg["E_MPa"]), float(rf["E_MPa"])),
                "UTS": (float(rg["UTS_MPa"]), float(rf["UTS_MPa"])),
                "GWP": (float(rg["GWP_kgCO2eq"]), float(rf["GWP_kgCO2eq"])),
                "FRS": (float(rg["FRS_kgoileq"]), float(rf["FRS_kgoileq"])),
            }
            row_bad = False
            for k,(a,b) in pairs.items():
                d = abs(a-b)
                maxdiff[k] = max(maxdiff[k],d)
                row_bad |= d > tol
            bad += int(row_bad)
    print("rows:", n)
    print("rows exceeding tolerance:", bad)
    print("max absolute differences:", maxdiff)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--anchors", default="G1_G27_Frozen_ProcessState_Anchors.csv")
    ap.add_argument("--output", default="CNPW_PLA_MEX_7056_Reproduced.csv")
    ap.add_argument("--compare", default=None,
                    help="Optional frozen response table to compare against")
    args = ap.parse_args()
    generate(args.anchors,args.output)
    if args.compare:
        compare(args.output,args.compare)
