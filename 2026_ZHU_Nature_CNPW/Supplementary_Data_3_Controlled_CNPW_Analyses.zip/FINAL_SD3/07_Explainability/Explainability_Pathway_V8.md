# Supplementary Data 3 — CNPW V8 explainability and process-pathway record

## 1. Scientific role

This layer explains the controlled PLA–MEX result without conflating three distinct questions:

\[
\boxed{
\text{global parameter attribution}
\rightarrow
\text{process-state pathway}
\rightarrow
\text{qualification-boundary localization}
}
\]

QCCA is separate. QCCA diagnoses response-composition compatibility, collapse and target-specific recovery in the qualification representation. The analyses here connect the resulting decision state back to process-space geometry, boundary responses and controllable process variables.

## 2. Exact global SHAP attribution

Exact finite-grid SHAP was evaluated on the complete 7,056-point Cartesian \((h,P,v)\) grid with equal candidate weight and all \(2^3\) feature coalitions. No Monte-Carlo approximation, auxiliary surrogate or model retraining was used.

| Response | \(h\) share | \(P\) share | \(v\) share | Dominant parameter |
|---|---:|---:|---:|---|
| E | 11.599% | **61.947%** | 26.454% | \(P\) |
| UTS | 22.550% | **59.546%** | 17.904% | \(P\) |
| GWP | 32.382% | 3.484% | **64.133%** | \(v\) |
| FRS | 30.852% | 7.604% | **61.544%** | \(v\) |

Maximum SHAP additivity error was \(2.78\times10^{-17}\). These are predictive-attribution statements over the frozen executable design distribution, not causal effects.

## 3. Process-state pathway

The frozen response models preserve the pathway

\[
(h,P,v)\rightarrow(Mass,Time,\rho_A)\rightarrow(E,UTS,GWP,FRS).
\]

For Young's modulus:

\[
E=506.01312+9581.3949\rho_A+0.38843914Time.
\]

For UTS:

\[
UTS=15.410646-13.261491h-20.421528P-0.010502281v+237.28512\rho_A-0.026039376Time.
\]

The environmental responses are deterministic functions of Mass and Time:

\[
GWP=1.48\times10^{-3}Mass+1.282\times10^{-3}Time,
\]

\[
FRS=1.78\times10^{-3}Mass+1.918\times10^{-4}Time.
\]

The pathway therefore supports response-specific engineering interpretation while remaining bounded to the frozen models; it is not an independent causal decomposition.

## 4. Process-space realization of the highest-qualified state

Mode A identifies 65 candidates in the highest jointly attainable Global state, spanning

\[
h=0.16\text{--}0.25,\quad
P=0.430\text{--}0.438,\quad
v=70\text{--}120.
\]

All 65 are connected under 26-neighbour adjacency. Under the stricter 6-neighbour convention, 61 remain in the dominant component and four become isolated. The highest-qualified decision state therefore maps to a coherent qualification-derived process window rather than an isolated parameter setting.

## 5. Qualification-boundary localization

At each audited inside-boundary W6 point, the boundary-controlling response is defined as the response with the smallest normalized margin to its corresponding qualification boundary. The counts are:

| Response | Inside-boundary controller count |
|---|---:|
| FRS | 38 |
| UTS | 12 |
| E | 3 |
| GWP | 0 |

This identifies which responses most frequently define the local qualification boundary. It does **not** prove that those responses causally constrain physical expansion of the process window.

The combination of boundary localization and SHAP supports a bounded reverse interpretation:

\[
\boxed{
\text{qualified-state geometry}
\rightarrow
\text{boundary response}
\rightarrow
\text{associated controllable process variable}
}
\]

For example, FRS is the most frequent W6 boundary controller, while its global variation is most strongly associated with \(v\); UTS is the principal mechanical boundary controller, while its global variation is most strongly associated with \(P\).

## 6. Formal terminal neighborhood

In V8 response order \((UTS,E,GWP,FRS)\), the Mode-A terminal PG6628 has

\[
GL=(6,7,6,6),\qquad LL=(5,6,5,4).
\]

Its process setting is

\[
h=0.25,\quad P=0.430,\quad v=80.
\]

One-factor W6-admissible intervals around this point are approximately \(h=0.24\)–0.25 mm, \(P=0.430\)–0.432 and \(v=70\)–90 mm s\(^{-1}\). These are grid-based one-factor admissible intervals, not confidence intervals and not a simultaneous tolerance box.

## 7. Relationship to QCCA

The V8 diagnostic chain and the process-explainability chain answer different questions:

\[
\boxed{
\text{QCCA: which response composition limits or recovers qualification?}
}
\]

\[
\boxed{
\text{Explainability: where is that state realized, which response defines its boundary, and which process variables are associated with response variation?}
}
\]

Accordingly, SHAP does not replace QCCA, and QCCA does not claim physical causality. Together they connect an abstract multi-response qualification ceiling to response-composition structure and then back to the controllable process domain.
