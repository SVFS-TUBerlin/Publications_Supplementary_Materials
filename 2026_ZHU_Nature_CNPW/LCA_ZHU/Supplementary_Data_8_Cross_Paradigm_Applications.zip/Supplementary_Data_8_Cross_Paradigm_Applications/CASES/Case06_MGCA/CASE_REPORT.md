# Case 06 — MGCA energy planning × CNPW final-formalism replay v1.6.0

## Status

**FINAL REPLACEMENT EVIDENCE.** This replay resolves the audit ambiguity around the nominal 0/2/4/6/8/10% cost-slack boundaries and re-executes the reported Mode-B path under the final all-active-response Stage-2 formalism.

## Source-native protected-domain definition

The source MGCA experiment generated one least-cost solution plus 100 MGA iterates at each nominal total-system-cost slack of **2%, 4%, 6%, 8% and 10%**. The original source-row blocks therefore define the native budget contract. After exact duplicate removal, cumulative unique populations are:

- 0%: **1**
- 2%: **87**
- 4%: **166**
- 6%: **252**
- 8%: **340**
- 10%: **418**

This final replay uses **source-native MGA budget-batch membership** as the protected-domain rule. The realized cost ratio is retained as a numerical audit rather than re-used as a strict floating-point classifier.

This distinction is necessary because solver-level residuals place many portfolios microscopically above their nominal boundary. The maximum realized excess over the generating nominal budget is **0.000318995 percentage points** (2% family), with smaller maxima at the other budgets. A strict `realized_slack <= nominal_slack` comparison would therefore incorrectly exclude native members of the source's own budget family.

This resolves the previous tolerance ambiguity without introducing a post-hoc arbitrary numerical tolerance.

## Final Mode-A result

On the frozen 418-portfolio × 8-response population:

- `C(J)=GL5`;
- Stage-1 `W1={MGCA-008, MGCA-052}`;
- all eight responses enter Stage 2;
- at `K_L*=7`, Local capability is LL1 and both remain locally retained;
- weakest-first Local-profile discrimination followed by raw-response Pareto pruning resolves **MGCA-008** as the terminal portfolio.

## Final source-native Mode-B path

For every protected budget from 2% through 10%:

- residual seven-response Stage-1 capability remains **GL5**;
- residual `W1={MGCA-008, MGCA-052}`;
- all eight active responses, including protected total system cost, re-enter Stage 2;
- Stage 2 resolves **MGCA-008** as terminal.

Thus the current manuscript statement **87 → 418 candidates with no increase beyond residual GL5** is reproduced exactly.

## Conditional residual QCCA

Using frozen Global labels inside each source-native protected domain:

- **2%:** no single residual-response removal improves GL5; the minimum recovery order is `r*=2`, with joint removal of **Zone-1 Cost + Zone-3 Cost** raising capability to **GL6**.
- **4%, 6%, 8%, 10%:** removing **Zone-1 Cost** alone raises residual capability from **GL5 to GL7**.

These are the manuscript/SI claims and they are reproduced exactly.

## Included files

- `MGCA_Energy_CNPW_FinalFormalism_v1.6.0.xlsx` — final Mode A, source-native budget path, realized-slack audit, all-active Stage 2, conditional QCCA and 418-candidate evidence.
- `DERIVED_AUDIT/MGCA_Conditional_QCCA_Audit.csv` — compact recovery audit.

## Replacement instruction

In SD8 Case06, supersede `MGCA_Energy_CNPW_v1.5.4_MasterTables.xlsx` with the final v1.6.0 workbook and include this report. The final report should be cited as the authority for the protected-domain semantics.
