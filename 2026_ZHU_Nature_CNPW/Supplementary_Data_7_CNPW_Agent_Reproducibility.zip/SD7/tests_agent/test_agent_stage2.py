from __future__ import annotations

import csv
import hashlib
import tempfile
import unittest
from pathlib import Path

from agent.contracts import ExecutionMode, stable_json
from agent.core_adapter import CoreAdapter
from agent.input_guard import InputGuard
from agent.result_builder import build_result


ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / "tests_agent" / "fixtures"


class AgentStage2Tests(unittest.TestCase):
    def setUp(self):
        self.guard = InputGuard()

    def fixture(self, name: str) -> Path:
        return FIXTURES / name

    def write_csv(self, rows: list[list[str]]) -> Path:
        handle = tempfile.NamedTemporaryFile("w", suffix=".csv", newline="", delete=False, encoding="utf-8")
        with handle:
            csv.writer(handle).writerows(rows)
        path = Path(handle.name)
        self.addCleanup(lambda: path.unlink(missing_ok=True))
        return path

    def task(self, fixture: str, mode: ExecutionMode = ExecutionMode.MODE_A):
        outcome = self.guard.validate(self.fixture(fixture), mode)
        self.assertTrue(outcome.accepted, outcome.error)
        return outcome.task

    def test_valid_direct_m3_m4_m5_are_accepted(self):
        for name, expected in (("small_m3.csv", 3), ("small_m4.csv", 4), ("small_m5.csv", 5)):
            with self.subTest(name=name):
                task = self.task(name)
                self.assertEqual(expected, len(task.input_summary.active_criteria))

    def test_mixed_and_all_maximize_directions_are_copied_from_file(self):
        mixed = self.task("small_m5.csv")
        self.assertEqual(["maximize", "minimize", "maximize", "minimize", "maximize"], [item.direction for item in mixed.input_summary.active_criteria])
        all_max = self.write_csv([["Candidate_ID", "A", "B", "C"], ["Direction", "1", "1", "1"], ["x", "1", "2", "3"], ["y", "2", "3", "4"]])
        outcome = self.guard.validate(all_max, ExecutionMode.MODE_A)
        self.assertTrue(outcome.accepted)
        self.assertTrue(all(item.direction == "maximize" for item in outcome.task.input_summary.active_criteria))

    def test_descriptors_are_preserved_and_not_active_criteria(self):
        task = self.task("small_m4.csv")
        self.assertEqual(("Descriptor",), task.input_summary.descriptors)
        self.assertEqual(4, len(task.input_summary.active_criteria))

    def test_direct_m2_and_m6_are_rejected(self):
        m2 = self.write_csv([["Candidate_ID", "A", "B"], ["Direction", "1", "0"], ["x", "1", "2"], ["y", "2", "1"]])
        m6 = self.write_csv([["Candidate_ID", "A", "B", "C", "D", "E", "F"], ["Direction", "1", "1", "1", "1", "1", "1"], ["x", "1", "2", "3", "4", "5", "6"], ["y", "2", "3", "4", "5", "6", "7"]])
        self.assertEqual("UNSUPPORTED_DIRECT_CRITERION_COUNT", self.guard.validate(m2, ExecutionMode.MODE_A).error.code)
        self.assertEqual("UNSUPPORTED_DIRECT_CRITERION_COUNT", self.guard.validate(m6, ExecutionMode.MODE_A).error.code)

    def test_input_error_codes_fail_closed(self):
        cases = [
            ([["Candidate_ID", "A", "B", "C"], ["Direction", "1", "1", "1"], ["", "1", "2", "3"]], "INVALID_CANDIDATE_ID"),
            ([["Candidate_ID", "A", "B", "C"], ["Direction", "1", "1", "1"], ["x", "1", "2", "3"], ["x", "2", "3", "4"]], "DUPLICATE_CANDIDATE_ID"),
            ([["Candidate_ID", "A", "B", "C"], ["Direction", "2", "1", "1"], ["x", "1", "2", "3"]], "INVALID_DIRECTION"),
            ([["Candidate_ID", "A", "", "C"], ["Direction", "1", "", "1"], ["x", "1", "secret", "3"]], "HIDDEN_DATA_IN_INACTIVE_RESULT_SLOT"),
            ([["Candidate_ID", "A", "B", "C"], ["Direction", "1", "1", "1"], ["x", "NaN", "2", "3"]], "NONFINITE_RESULT"),
        ]
        for rows, code in cases:
            with self.subTest(code=code):
                outcome = self.guard.validate(self.write_csv(rows), ExecutionMode.MODE_A)
                self.assertFalse(outcome.accepted)
                self.assertEqual(code, outcome.error.code)

    def test_unsupported_format_and_mode_are_rejected(self):
        outcome = self.guard.validate(ROOT / "README.md", ExecutionMode.MODE_A)
        self.assertEqual("UNSUPPORTED_INPUT_FORMAT", outcome.error.code)
        outcome = self.guard.validate(self.fixture("small_m3.csv"), "MODE_C")
        self.assertEqual("UNSUPPORTED_MODE", outcome.error.code)

    def test_stable_contract_serialization_and_hash(self):
        first = self.task("small_m3.csv", ExecutionMode.MODE_A)
        second = self.task("small_m3.csv", ExecutionMode.MODE_A)
        self.assertEqual(first.to_json(), second.to_json())
        self.assertEqual(first.task_hash_sha256, second.task_hash_sha256)
        self.assertEqual(first.to_json(), stable_json(first))

    def test_mode_a_and_mode_b_routing(self):
        self.assertEqual(ExecutionMode.MODE_A, self.task("small_m4.csv", ExecutionMode.MODE_A).requested_mode)
        task = self.task("small_m4.csv", ExecutionMode.MODE_B_SIMPLIFIED_RESULT_A_GL7)
        self.assertEqual(ExecutionMode.MODE_B_SIMPLIFIED_RESULT_A_GL7, task.requested_mode)
        self.assertEqual("A", task.protected_criterion.slot)
        self.assertEqual(["B", "C", "D"], [item.slot for item in task.residual_criteria])

    def test_result_a_protection_cannot_be_overridden(self):
        task = self.task("small_m5.csv", ExecutionMode.MODE_B_SIMPLIFIED_RESULT_A_GL7)
        self.assertEqual(task.input_summary.active_criteria[0], task.protected_criterion)
        self.assertNotIn("protected_criterion", InputGuard.validate.__annotations__)

    def test_adapter_copies_core_structured_result_and_terminal_is_list(self):
        task = self.task("small_m3.csv", ExecutionMode.MODE_B_SIMPLIFIED_RESULT_A_GL7)
        result = build_result(CoreAdapter().execute(task))
        self.assertEqual("completed", result["status"])
        self.assertIsInstance(result["terminal"]["terminal_candidate_ids"], list)
        self.assertEqual("A", task.protected_criterion.slot)
        self.assertEqual([item.name for item in task.residual_criteria], result["mode_b_conditioning"]["residual_criteria"])
        self.assertIn(task.protected_criterion.name, result["stage_2"]["per_criterion_local_trace"]["local"])
        self.assertEqual(task.task_id, result["task_id"])

    def test_core_isolation_no_src_depends_on_agent(self):
        for source in sorted((ROOT / "src").glob("*.py")):
            with self.subTest(source=source.name):
                self.assertNotIn("agent", source.read_text(encoding="utf-8"))

    def test_guard_records_preexecution_file_hash(self):
        path = self.fixture("small_m3.csv")
        task = self.task("small_m3.csv")
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), task.input_summary.identity.source_hash_sha256)


if __name__ == "__main__":
    unittest.main()
