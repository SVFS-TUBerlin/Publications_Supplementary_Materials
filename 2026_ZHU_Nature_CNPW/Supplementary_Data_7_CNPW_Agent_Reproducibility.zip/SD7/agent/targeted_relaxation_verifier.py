from .targeted_relaxation import _dominates
from .targeted_relaxation import targeted_relaxation


def verify_targeted_relaxation(result, qcca, recovery):
    names = qcca.criterion_names
    positions = {name: i for i, name in enumerate(names)}
    if result.target != recovery.target or result.recovery_set != recovery.removed_responses:
        return False
    vectors = [item.deficit_vector for item in result.alternatives]
    for item in result.alternatives:
        if item.candidate_id not in qcca.domain_candidate_ids or not item.in_frozen_w1:
            return False
        if item.in_mode_b_omega is False:
            return False
        if any(item.local_profile[positions[name]] < recovery.target for name in recovery.retained_responses):
            return False
        expected = tuple(max(0, recovery.target - item.local_profile[positions[name]]) for name in recovery.removed_responses)
        if expected != item.deficit_vector:
            return False
    # Rebuild the complete scientific claim from the matrix, including every
    # witness and the singleton/frontier selection rule.
    rebuilt = targeted_relaxation(qcca, recovery)
    projected = tuple((item.candidate_id, item.local_profile, item.deficit_vector) for item in result.alternatives)
    expected = tuple((item.candidate_id, item.local_profile, item.deficit_vector) for item in rebuilt.alternatives)
    if projected != expected or result.kind != rebuilt.kind:
        return False
    if len(recovery.removed_responses) == 1 and result.alternatives:
        recovered_col = positions[recovery.removed_responses[0]]
        return len({item.local_profile[recovered_col] for item in result.alternatives}) == 1
    return not any(_dominates(left, right) for left in vectors for right in vectors if left != right)
