from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .core_adapter import CoreAdapter
from .errors import AgentError
from .input_guard import InputGuard
from .intent_models import IntentContext, IntentModelClient
from .intent_router import build_task_from_validated_intent, validate_intent_proposal
from .llm_client import IntentProviderError
from .provenance import build_ai_provenance, build_provenance_manifest
from .result_builder import build_result
from .verifier import VerificationReport, verify_result


@dataclass(frozen=True)
class PipelineOutcome:
    result: dict[str, Any] | None
    verification: VerificationReport | None
    provenance: dict[str, Any] | None
    error: AgentError | None


class AgentCoordinator:
    """Orchestrates bounded interpretation and existing deterministic components."""

    def __init__(self, intent_client: IntentModelClient, project_root: str | Path):
        self._intent_client = intent_client
        self._project_root = Path(project_root)
        self._guard = InputGuard()

    def execute(self, filename: str, user_text: str, requested_language: str = "en",
                execution_timestamp: str | None = None) -> PipelineOutcome:
        preflight = self._guard.validate(filename, "MODE_A", requested_language)
        if not preflight.accepted:
            return PipelineOutcome(None, None, None, preflight.error)
        context = IntentContext(tuple(item.name for item in preflight.task.input_summary.active_criteria))
        try:
            raw_proposal = self._intent_client.propose_intent(user_text, context)
        except TimeoutError:
            return PipelineOutcome(None, None, None, AgentError("AI_INTENT_UNAVAILABLE", "AI intent provider timed out."))
        except IntentProviderError:
            return PipelineOutcome(None, None, None, AgentError("AI_PROVIDER_ERROR", "AI intent provider failed."))
        except Exception:
            return PipelineOutcome(None, None, None, AgentError("AI_PROVIDER_ERROR", "AI intent provider failed."))
        interpreted = validate_intent_proposal(raw_proposal)
        if not interpreted.accepted:
            return PipelineOutcome(None, None, None, interpreted.error)
        guarded = build_task_from_validated_intent(self._guard, filename, interpreted, requested_language)
        if not guarded.accepted:
            return PipelineOutcome(None, None, None, guarded.error)
        execution = CoreAdapter().execute(guarded.task)
        result = build_result(execution)
        verification = verify_result(guarded.task, result, execution.dataset.candidate_ids, guarded.task.input_summary.identity.source_path)
        provenance = build_provenance_manifest(guarded.task, self._project_root, execution_timestamp)
        provenance["ai_intent"] = build_ai_provenance(interpreted.proposal, user_text)
        return PipelineOutcome(result, verification, provenance, None)
