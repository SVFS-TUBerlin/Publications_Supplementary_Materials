#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Figure 8: measured-porosity-conditioned Young's modulus, final paper version.

Requirements: numpy, matplotlib (no pandas or external data files).
Runs: python Figure8.py
Windows default outputs: D:/soft/3
Optional override: set FIGURE8_OUTPUT_DIR to another directory.

The 101 original measurements are embedded below. 81 main specimens from
27 process conditions are fitted; V1-V4 (20 specimens) remain unfit and are
not plotted in this figure.

Panels: (a) global E-porosity, (b-d) v=20/70/120 mm/s E-porosity.
Markers: observed condition means. P=0.43/0.45/0.47 mm is encoded
by blue/orange/green; h=0.10/0.20/0.25 mm is encoded by
circle/triangle/square throughout all panels.
Lines: OLS fits to 27 or 9 condition means.
Performance text: LOOCV R² and fitted slope, not in-sample fit R².
(a-d) vertical error bars: measured E min-max of the THREE replicate
specimens. Horizontal coordinates remain mean measured porosity.
No horizontal porosity error bars and no model uncertainty bars.
Two X-axis titles (bottom row) and two Y-axis titles (left column); all four
panels retain their complete X and Y numerical tick labels.
"""

from __future__ import annotations

import csv
import io
import os
from pathlib import Path
from collections import defaultdict

import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D
import matplotlib.patheffects as pe

# -------------------------- Configuration --------------------------
OUTPUT = Path(os.environ.get(
    "FIGURE8_OUTPUT_DIR", str(Path(__file__).resolve().parent / "Regenerated")
))
RHO_G_CM3 = 1.24
L_MM = 180.0
P_LEVELS = [0.43, 0.45, 0.47]
SPEED_LEVELS = [20, 70, 120]
P_COLORS = {0.43: "#1f77b4", 0.45: "#ff7f0e", 0.47: "#2ca02c"}
H_LEVELS = [0.10, 0.20, 0.25]
H_MARKERS = {0.10: "o", 0.20: "^", 0.25: "s"}  # circle, triangle, square
WIDTH_MM, HEIGHT_MM, DPI = 190.0, 175.0, 600
SIZES = dict(panel=11, axis=11, tick=9, metric=9)
LAYOUT = dict(left=.105, right=.928, bottom=.085, top=.965,
              wspace=.20, hspace=.18)
POINT_SIZE, POINT_ALPHA = 25, .6
ERROR_CAPSIZE, ERROR_LINEWIDTH, ERROR_ALPHA = 2.0, .8, .65
AXIS_COLOR = '#263642'
SHOW_PLOT = False  # Set True to show window after saving locally.

# All 101 paired raw specimen measurements. No pre-averaged records.
# The numeric fields come directly from the 2026-10-24 Figure8_1 workpackage.
RAW_DATA = r"""record_id,role,group_id,h_mm,P_mm,v_mm_s,area_mm2,mass_g,E_num_N
G8-R1,main,G8,0.1,0.43,20,29.79,6.113,73755.12065
G8-R2,main,G8,0.1,0.43,20,30.096,6.154,74985.42934
G8-R3,main,G8,0.1,0.43,20,29.7243,6.11,74033.87177
G20-R1,main,G20,0.1,0.43,70,30.8828,6.375,77151.50557
G20-R2,main,G20,0.1,0.43,70,30.956,6.368,77421.99279
G20-R3,main,G20,0.1,0.43,70,30.596,6.323,76186.6741
G23-R1,main,G23,0.1,0.43,120,30.552,6.329,76385.27524
G23-R2,main,G23,0.1,0.43,120,30.3077,6.279,76551.35914
G23-R3,main,G23,0.1,0.43,120,30.656,6.345,77348.59329
G21-R1,main,G21,0.1,0.45,20,29.85,5.86,72479.81793
G21-R2,main,G21,0.1,0.45,20,29.5697,5.739,71389.94282
G21-R3,main,G21,0.1,0.45,20,29.7198,5.764,71720.55639
G4-R1,main,G4,0.1,0.45,70,29.5303,6.022,73003.98884
G4-R2,main,G4,0.1,0.45,70,29.5208,6.033,72966.13877
G4-R3,main,G4,0.1,0.45,70,29.4196,6.013,73119.5006
G24-R1,main,G24,0.1,0.45,120,29.903,6.0695,72597.83362
G24-R2,main,G24,0.1,0.45,120,29.8704,6.004,73296.98837
G24-R3,main,G24,0.1,0.45,120,29.9892,6.044,73694.19315
G22-R1,main,G22,0.1,0.47,20,29.6178,5.582,70370.60777
G22-R2,main,G22,0.1,0.47,20,29.7667,5.695,70693.42699
G22-R3,main,G22,0.1,0.47,20,30.049,5.735,71727.46977
G13-R1,main,G13,0.1,0.47,70,30.049,5.844,70979.50836
G13-R2,main,G13,0.1,0.47,70,30.1689,5.857,71557.98519
G13-R3,main,G13,0.1,0.47,70,30.198,5.846,71732.65232
G9-R1,main,G9,0.1,0.47,120,30.049,5.816,71421.40099
G9-R2,main,G9,0.1,0.47,120,30.18,5.834,71400.68386
G9-R3,main,G9,0.1,0.47,120,30.2,5.816,70678.15591
G18-R1,main,G18,0.2,0.43,20,30.7057,6.417,77811.9876
G18-R2,main,G18,0.2,0.43,20,30.5232,6.351,76447.48943
G18-R3,main,G18,0.2,0.43,20,30.184,6.325,76682.03722
G6-R1,main,G6,0.2,0.43,70,30.3128,6.298,75720.84243
G6-R2,main,G6,0.2,0.43,70,30.4067,6.327,75997.84069
G6-R3,main,G6,0.2,0.43,70,30.5067,6.323,76325.74094
G12-R1,main,G12,0.2,0.43,120,30.494,6.098,74529.29404
G12-R2,main,G12,0.2,0.43,120,30.6123,6.226,74948.92118
G12-R3,main,G12,0.2,0.43,120,30.52,6.207,74982.80182
G2-R1,main,G2,0.2,0.45,20,29.4492,6.044,73169.00131
G2-R2,main,G2,0.2,0.45,20,29.7332,6.091,74094.0918
G2-R3,main,G2,0.2,0.45,20,29.7332,6.088,73557.92057
G1-R1,main,G1,0.2,0.45,70,30.0888,5.968,72320.17555
G1-R2,main,G1,0.2,0.45,70,29.9376,5.956,72402.16022
G1-R3,main,G1,0.2,0.45,70,30.0689,5.969,72657.52178
G3-R1,main,G3,0.2,0.45,120,30.0606,5.895,72117.83632
G3-R2,main,G3,0.2,0.45,120,30,5.899,71750.23068
G3-R3,main,G3,0.2,0.45,120,29.799,5.879,71564.14464
G16-R1,main,G16,0.2,0.47,20,30.194,5.938,73447.26136
G16-R2,main,G16,0.2,0.47,20,30.0752,5.932,72706.17807
G16-R3,main,G16,0.2,0.47,20,29.835,5.923,72658.27206
G7-R1,main,G7,0.2,0.47,70,30.0425,5.8,70884.48787
G7-R2,main,G7,0.2,0.47,70,30.09,5.805,70603.28542
G7-R3,main,G7,0.2,0.47,70,30.0425,5.707,71446.21118
G17-R1,main,G17,0.2,0.47,120,30.0168,5.718,69744.00748
G17-R2,main,G17,0.2,0.47,120,30.0564,5.705,69822.56378
G17-R3,main,G17,0.2,0.47,120,30.2082,5.705,69720.82074
G25-R1,main,G25,0.25,0.43,20,30.62,6.387,77692.21169
G25-R2,main,G25,0.25,0.43,20,30.6306,6.392,77488.12429
G25-R3,main,G25,0.25,0.43,20,30.64,6.386,76576.72133
G14-R1,main,G14,0.25,0.43,70,30.3395,6.275,75288.03016
G14-R2,main,G14,0.25,0.43,70,30.3336,6.282,75344.85032
G14-R3,main,G14,0.25,0.43,70,30.394,6.288,75186.88409
G27-R1,main,G27,0.25,0.43,120,30.294,6.179,74686.40044
G27-R2,main,G27,0.25,0.43,120,30.1138,6.165,73714.20586
G27-R3,main,G27,0.25,0.43,120,30.194,6.151,74190.95003
G26-R1,main,G26,0.25,0.45,20,30.096,6.106,74822.81094
G26-R2,main,G26,0.25,0.45,20,29.792,6.076,73818.77076
G26-R3,main,G26,0.25,0.45,20,29.9455,6.077,74405.75157
G5-R1,main,G5,0.25,0.45,70,29.9894,6.059,73350.40419
G5-R2,main,G5,0.25,0.45,70,29.7396,5.963,72546.04765
G5-R3,main,G5,0.25,0.45,70,29.799,5.952,72624.23323
G15-R1,main,G15,0.25,0.45,120,29.9097,5.787,70922.75243
G15-R2,main,G15,0.25,0.45,120,29.799,5.803,71058.83079
G15-R3,main,G15,0.25,0.45,120,29.799,5.814,70133.67128
G10-R1,main,G10,0.25,0.47,20,29.8372,5.943,72581.59142
G10-R2,main,G10,0.25,0.47,20,29.6178,5.9,71821.27943
G10-R3,main,G10,0.25,0.47,20,29.776,5.911,72404.38375
G19-R1,main,G19,0.25,0.47,70,29.5656,5.782,70226.46039
G19-R2,main,G19,0.25,0.47,70,29.6044,5.772,70138.92901
G19-R3,main,G19,0.25,0.47,70,29.518,5.775,70094.77345
G11-R1,main,G11,0.25,0.47,120,29.997,5.657,69145.16829
G11-R2,main,G11,0.25,0.47,120,29.8849,5.652,68820.29974
G11-R3,main,G11,0.25,0.47,120,29.997,5.671,69289.5482
V1-R1,validation,V1,0.15,0.45,70,30.8424,6.274,75619.88658
V1-R2,validation,V1,0.15,0.45,70,30.804,6.277,75499.18032
V1-R3,validation,V1,0.15,0.45,70,30.804,6.246,76263.28696
V1-R4,validation,V1,0.15,0.45,70,30.8921,6.258,76000.54389
V1-R5,validation,V1,0.15,0.45,70,30.814,6.271,74418.2436
V2-R1,validation,V2,0.2,0.46,70,30.2232,5.97,72160.06235
V2-R2,validation,V2,0.2,0.46,70,30.338,5.981,72344.00285
V2-R3,validation,V2,0.2,0.46,70,30.2592,5.974,72398.64376
V2-R4,validation,V2,0.2,0.46,70,30.23,5.982,72807.49314
V2-R5,validation,V2,0.2,0.46,70,30.338,5.978,72900.76037
V3-R1,validation,V3,0.25,0.47,90,29.8849,5.693,69412.29254
V3-R2,validation,V3,0.25,0.47,90,29.8684,5.644,69410.01732
V3-R3,validation,V3,0.25,0.47,90,29.944,5.703,69542.92637
V3-R4,validation,V3,0.25,0.47,90,29.93,5.706,69563.81659
V3-R5,validation,V3,0.25,0.47,90,29.9246,5.727,70085.14166
V4-R1,validation,V4,0.1,0.43,90,30.3,6.322,76022.29101
V4-R2,validation,V4,0.1,0.43,90,30.4536,6.328,75762.64724
V4-R3,validation,V4,0.1,0.43,90,30.455,6.363,76415.361
V4-R4,validation,V4,0.1,0.43,90,30.28,6.332,76177.37189
V4-R5,validation,V4,0.1,0.43,90,30.28,6.327,75830.19939"""


def load_specimens():
    rows = list(csv.DictReader(io.StringIO(RAW_DATA.strip())))
    if len(rows) != 101:
        raise ValueError(f"Expected 101 specimen measurements; found {len(rows)}")
    records = []
    for row in rows:
        r = {k: float(row[k]) for k in
             ("h_mm", "P_mm", "v_mm_s", "area_mm2", "mass_g", "E_num_N")}
        if r["area_mm2"] <= 0:
            raise ValueError(f"Nonpositive specimen section: {row['record_id']}")
        r.update(record_id=row["record_id"], group_id=row["group_id"], role=row["role"])
        # IMPORTANT: derived before aggregation; mean(E_num / A), not mean(E_num) / mean(A).
        r["phi_vol_pct"] = 100.0 * (1.0 - 1000.0 * r["mass_g"] /
                                       (RHO_G_CM3 * r["area_mm2"] * L_MM))
        r["E_MPa"] = r["E_num_N"] / r["area_mm2"]
        records.append(r)
    role_counts = {role: sum(x['role'] == role for x in records)
                   for role in ('main', 'validation')}
    if role_counts != {'main': 81, 'validation': 20}:
        raise ValueError(f"Unexpected role counts: {role_counts}")
    return records


def condition_means(specimens):
    groups = defaultdict(list)
    for row in specimens:
        groups[(row['group_id'], row['h_mm'], row['P_mm'], row['v_mm_s'])].append(row)
    main, validation = [], []
    for (group, h, pitch, speed), members in groups.items():
        count = 3 if members[0]['role'] == 'main' else 5
        if len(members) != count or len({m['role'] for m in members}) != 1:
            raise ValueError(f"Replicate count or role mismatch at {group}")
        phi = np.array([m['phi_vol_pct'] for m in members], dtype=float)
        e = np.array([m['E_MPa'] for m in members], dtype=float)
        rec = dict(group=group, h=h, P=pitch, v=speed, phi=float(phi.mean()),
                   phi_min=float(phi.min()), phi_max=float(phi.max()),
                   E=float(e.mean()), E_min=float(e.min()), E_max=float(e.max()))
        if not np.isfinite(e).all() or not rec['E_min'] <= rec['E'] <= rec['E_max']:
            raise ValueError(f"Invalid measured E min-mean-max at {group}")
        (main if members[0]['role'] == 'main' else validation).append(rec)
    if len(main) != 27 or len(validation) != 4:
        raise ValueError(f"Expected 27 main and 4 validation conditions, got {len(main)}, {len(validation)}")
    return sorted(main, key=lambda r: (r['v'], r['h'], r['P'])), validation


def ols_line(xs, ys):
    x = np.asarray(xs, dtype=float)
    y = np.asarray(ys, dtype=float)
    if len(x) < 3 or np.ptp(x) < 1e-10:
        raise ValueError('Insufficient independent x values for linear fit')
    coeff, _, rank, _ = np.linalg.lstsq(np.column_stack((np.ones(len(x)), x)), y, rcond=None)
    if rank != 2:
        raise ValueError('Non-full-rank linear model')
    return coeff  # E = intercept + slope * phi_vol


def loocv(yx):
    xs = np.array([r['phi'] for r in yx], dtype=float)
    ys = np.array([r['E'] for r in yx], dtype=float)
    yhat = np.empty_like(ys)
    for i in range(len(ys)):
        mask = np.ones(len(ys), dtype=bool)
        mask[i] = False
        a, b = ols_line(xs[mask], ys[mask])
        yhat[i] = a + b * xs[i]
    mse = float(np.mean((yhat - ys)**2))
    r2 = float(1 - np.sum((yhat - ys)**2) / np.sum((ys - ys.mean())**2))
    return dict(r2=r2, rmse=float(np.sqrt(mse)), predictions=yhat)


def setup_style():
    """Use the installed Roboto Regular face; STIX renders mathematics.

    A thin same-color stroke simulates bold panel letters. No Bold TTF,
    script-local font file, download, or external research data is needed.
    """
    path = None
    try:
        found = font_manager.findfont(
            FontProperties(family='Roboto', style='normal', weight='normal'),
            fallback_to_default=False)
        if Path(found).is_file():
            path = Path(found)
    except ValueError:
        pass
    if path is None:
        candidates = [
            Path.home() / 'AppData/Local/Microsoft/Windows/Fonts/Roboto-Regular.ttf',
            Path(os.environ.get('WINDIR', r'C:\Windows')) / 'Fonts/Roboto-Regular.ttf',
        ]
        path = next((p for p in candidates if p.is_file()), None)
    if path is None:
        raise FileNotFoundError('Roboto Regular not found. Install Roboto Regular '
                                'in Windows and restart Python; no other font is substituted.')
    font_manager.fontManager.addfont(str(path))
    regular = FontProperties(fname=str(path))
    # Explicitly retain STIX when applying FontProperties to each text object.
    regular.set_math_fontfamily('stix')
    mpl.rcParams.update({
        'font.family': regular.get_name(), 'font.weight': 'normal',
        'font.size': SIZES['tick'], 'axes.labelsize': SIZES['axis'],
        'axes.labelweight': 'normal', 'axes.linewidth': .8,
        'xtick.labelsize': SIZES['tick'], 'ytick.labelsize': SIZES['tick'],
        'axes.grid': False, 'axes.unicode_minus': True,
        'mathtext.fontset': 'stix', 'text.usetex': False,
        'pdf.fonttype': 42, 'ps.fonttype': 42, 'pdf.compression': 0,
        'svg.fonttype': 'none', 'svg.hashsalt': 'Figure8-Roboto-E-minmax',
        'figure.facecolor': 'white', 'axes.facecolor': 'white',
        'savefig.facecolor': 'white', 'axes.axisbelow': True,
    })
    print('Roboto Regular:', path)
    return regular


def make_plot(main):
    regular = setup_style()
    groups = [main] + [[r for r in main if r['v'] == v] for v in SPEED_LEVELS]
    metrics = [loocv(g) for g in groups]
    coeffs = [ols_line([r['phi'] for r in g], [r['E'] for r in g]) for g in groups]

    # Numerical audit against source data, including the new uploaded parity figure.
    for (label, result, expected_r2, expected_rmse) in zip(
        ('Global', '20 mm/s', '70 mm/s', '120 mm/s'), metrics,
        (0.928294982, 0.966874881, 0.959230701, 0.976168692),
        (16.387410991, 8.607399173, 10.794081918, 10.203323051)
    ):
        if abs(result['r2']-expected_r2) > 5e-5 or abs(result['rmse']-expected_rmse) > 0.005:
            raise AssertionError(f"Data/model mismatch for {label}: {result}")

    fig, axes = plt.subplots(2, 2,
                             figsize=(WIDTH_MM / 25.4, HEIGHT_MM / 25.4),
                             dpi=180, sharex=True, sharey=True)
    fig.subplots_adjust(**LAYOUT)
    axes = axes.ravel()
    x_bounds = (5.7, 16.0)
    y_bounds = (2290, 2555)
    if (min(r['phi'] for r in main) < x_bounds[0]
            or max(r['phi'] for r in main) > x_bounds[1]
            or min(r['E_min'] for r in main) < y_bounds[0]
            or max(r['E_max'] for r in main) > y_bounds[1]):
        raise ValueError("Axis limits would clip measured means or real E min-max ranges.")

    for panel, (ax, data, cv, coeff) in enumerate(zip(axes, groups, metrics, coeffs)):
        ax.set_xlim(*x_bounds)
        ax.set_ylim(*y_bounds)
        ax.set_box_aspect(1)
        ax.grid(False)
        for side in ('top', 'right', 'bottom', 'left'):
            ax.spines[side].set_linewidth(.8)
            ax.spines[side].set_color(AXIS_COLOR)
        # Shared axes hide inner tick labels by default; explicitly show all four.
        ax.tick_params(axis='both', direction='in', length=3, width=.8, pad=4,
                       labelbottom=True, labelleft=True)
        ax.set_xticks([6, 8, 10, 12, 14, 16])
        ax.set_yticks([2300, 2350, 2400, 2450, 2500, 2550])

        # All panels: mean porosity on X; measured E min-max is shown as
        # asymmetric vertical error bars for the three replicate specimens.
        # Encode road spacing P by color, layer height h by marker shape.
        # Both mappings apply to all panels, including the global panel (a).
        for pitch in P_LEVELS:
            col = P_COLORS[pitch]
            for r in data:
                if np.isclose(r['P'], pitch):
                    marker = H_MARKERS[r['h']]
                    lower = r['E'] - r['E_min']
                    upper = r['E_max'] - r['E']
                    if not np.isfinite([lower, upper]).all() or min(lower, upper) < 0:
                        raise ValueError(f"Invalid measured E range: {r['group']}")
                    bars = ax.errorbar(
                        r['phi'], r['E'], yerr=[[lower], [upper]],
                        fmt='none', ecolor=col, elinewidth=ERROR_LINEWIDTH,
                        capsize=ERROR_CAPSIZE, capthick=ERROR_LINEWIDTH,
                        alpha=ERROR_ALPHA, zorder=2)
                    if bars.has_xerr or not bars.has_yerr:
                        raise RuntimeError("Expected vertical measured-E error bars only.")
                    expected = [[r['phi'], r['E_min']], [r['phi'], r['E_max']]]
                    segment = bars.lines[2][0].get_segments()[0]
                    if not np.allclose(segment, expected, rtol=0, atol=1e-10):
                        raise RuntimeError(f"Error-bar endpoint mismatch: {r['group']}")
                    ax.scatter(r['phi'], r['E'], s=POINT_SIZE, c=col,
                               marker=marker, alpha=POINT_ALPHA,
                               edgecolors='white', linewidths=.3, zorder=4)
        xmin = min(r['phi'] for r in data)
        xmax = max(r['phi'] for r in data)
        x_line = np.linspace(xmin, xmax, 150)
        intercept, slope = coeff
        ax.plot(x_line, intercept+slope*x_line,
                color='#42474b', lw=1.0, zorder=3)

        # Keep the performance annotations INSIDE each plot at their original
        # two positions; put the v label OUTSIDE, above the top-right frame edge,
        # level with the bold panel tag at the top-left.
        ax.text(.955, .955, rf'$R^2_{{\mathrm{{LOOCV}}}} = {cv["r2"]:.3f}$',
                transform=ax.transAxes, ha='right', va='top',
                fontsize=SIZES['metric'], zorder=10)
        ax.text(.955, .855, f'Slope = {slope:.3f} MPa/pp',
                transform=ax.transAxes, ha='right', va='top',
                fontsize=SIZES['metric'], zorder=10)
        tag = ax.text(0, 1.025, f'({"abcd"[panel]})', transform=ax.transAxes,
                      fontsize=SIZES['panel'], fontweight='bold',
                      color=AXIS_COLOR, ha='left', va='bottom', clip_on=False)
        tag.set_path_effects([pe.withStroke(linewidth=.3, foreground=AXIS_COLOR),
                              pe.Normal()])
        if panel > 0:
            ax.text(1.0, 1.025, rf'$v={int(SPEED_LEVELS[panel-1])}$ mm/s',
                    transform=ax.transAxes, ha='right', va='bottom',
                    fontsize=SIZES['panel'], color=AXIS_COLOR,
                    clip_on=False, zorder=10)

        # Exactly two X titles and two Y titles; all four keep numeric ticks.
        if panel // 2 == 1:
            ax.set_xlabel(r'Volumetric porosity, $\varphi_{\mathrm{vol}}$ (%)', labelpad=6)
        if panel % 2 == 0:
            ax.set_ylabel(r"Young's modulus, $E$ (MPa)", labelpad=6)

    # Two separate rows make the independent encodings explicit:
    # P determines color only, while h determines marker shape only.
    # Extended export footer accommodates both rows without moving axes.
    legend_center = (LAYOUT['left'] + LAYOUT['right']) / 2
    p_color_items = [Line2D(
        [0], [0], marker='o', linestyle='none',
        markerfacecolor=P_COLORS[pitch], markeredgecolor='white',
        markeredgewidth=.3, markersize=6,
        label=fr'$P={pitch:.2f}$ mm') for pitch in P_LEVELS]
    h_shape_items = [Line2D(
        [0], [0], marker=H_MARKERS[h], linestyle='none',
        markerfacecolor='#636b70', markeredgecolor='white',
        markeredgewidth=.3, markersize=6,
        label=fr'$h={h:.2f}$ mm') for h in H_LEVELS]
    fig.legend(handles=p_color_items, ncol=3, loc='upper center',
               bbox_to_anchor=(legend_center, -.012),
               frameon=False, fontsize=SIZES['tick'], borderaxespad=0,
               handletextpad=.5, columnspacing=2.0)
    fig.legend(handles=h_shape_items, ncol=3, loc='upper center',
               bbox_to_anchor=(legend_center, -.056),
               frameon=False, fontsize=SIZES['tick'], borderaxespad=0,
               handletextpad=.5, columnspacing=2.0)
    footer_inches = 18.0 / 25.4
    export_bounds = mpl.transforms.Bbox.from_extents(
        0, -footer_inches, fig.get_figwidth(), fig.get_figheight())

    fig.canvas.draw()
    for text in fig.findobj(match=mpl.text.Text):
        fp = regular.copy()
        fp.set_size(text.get_fontsize())
        text.set_fontproperties(fp)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    for text in fig.findobj(match=mpl.text.Text):
        if text.get_visible() and text.get_text():
            box = text.get_window_extent(renderer)
            if (box.x0 < -1 or box.y0 < -footer_inches * fig.dpi - 1 or box.x1 > fig.bbox.width + 1
                    or box.y1 > fig.bbox.height + 1):
                raise RuntimeError(f'Text exceeds canvas: {text.get_text()}')
    for ax in axes:
        if len([t for t in ax.get_xticklabels() if t.get_visible() and t.get_text()]) != 6:
            raise RuntimeError('Every panel must retain all six X tick values.')
        if len([t for t in ax.get_yticklabels() if t.get_visible() and t.get_text()]) != 6:
            raise RuntimeError('Every panel must retain all six Y tick values.')
        if any(line.get_visible() for line in ax.get_xgridlines() + ax.get_ygridlines()):
            raise RuntimeError('Background grid must be disabled.')
    if [bool(ax.get_xlabel()) for ax in axes] != [False, False, True, True]:
        raise RuntimeError('X titles must appear only on panels (c) and (d).')
    if [bool(ax.get_ylabel()) for ax in axes] != [True, False, True, False]:
        raise RuntimeError('Y titles must appear only on panels (a) and (c).')

    OUTPUT.mkdir(parents=True, exist_ok=True)
    for fmt, kwargs in (
        ('pdf', {}), ('svg', {}), ('png', {'dpi':DPI}),
    ):
        fig.savefig(OUTPUT / ('Figure8.'+fmt), format=fmt,
                    bbox_inches=export_bounds, transparent=False, **kwargs)
    if SHOW_PLOT:
        plt.show()
    plt.close(fig)

    print('Figure 8 saved to:', OUTPUT.resolve())
    print('Panels (b, c, d) correspond to v=20, 70, 120 mm/s.')
    print('Error bars: measured E min-max, vertical, panels a-d.')
    print('P colors: 0.43=blue, 0.45=orange, 0.47=green.')
    print('h markers: 0.10=circle, 0.20=triangle, 0.25=square.')
    print('Axis titles: two X titles (c,d), two Y titles (a,c); all four panels retain full X/Y tick values.')
    for label, (a, b), stat in zip(('global', 'v20','v70','v120'), coeffs,metrics):
        print(f'{label}: intercept={a:.6f}, slope={b:.6f} MPa/pp; '
              f'LOOCV R2={stat["r2"]:.9f}; RMSE={stat["rmse"]:.6f} MPa')
    combined_pred = np.concatenate([s['predictions'] for s in metrics[1:]])
    combined_obs = np.array([r['E'] for group in groups[1:] for r in group])
    pooled_r2 = 1 - np.sum((combined_pred-combined_obs)**2) / np.sum((combined_obs-combined_obs.mean())**2)
    pooled_rmse = np.sqrt(np.mean((combined_pred-combined_obs)**2))
    print(f'FINAL SPEED-CONDITIONED POOLED LOOCV: R2={pooled_r2:.9f}; '
          f'RMSE={pooled_rmse:.6f} MPa; this metric is NOT panel (a).')


if __name__ == '__main__':
    specimens = load_specimens()
    main, _validation = condition_means(specimens)
    make_plot(main)
