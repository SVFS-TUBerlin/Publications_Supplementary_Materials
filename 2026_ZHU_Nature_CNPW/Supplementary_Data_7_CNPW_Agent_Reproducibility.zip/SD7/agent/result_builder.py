from __future__ import annotations

from decimal import Decimal
from typing import Any

from .core_adapter import CoreExecution
from .errors import AgentError, AgentRejected


def _plain(value: Any) -> Any:
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, dict):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_plain(item) for item in value]
    return value


def build_result(execution: CoreExecution) -> dict[str, Any]:
    """Copy structured Core state into the neutral Agent result envelope."""
    try:
        task, dataset, result = execution.task, execution.dataset, execution.core_result
        ids = dataset.candidate_ids
        stage1 = {"per_criterion_global_trace": {"gl": [list(row) for row in result.stage1.gl], "nominal_counts": _plain(result.stage1.nominal_counts), "final_counts": _plain(result.stage1.final_counts), "tie_adjustments": _plain(result.stage1.tie_adjustments), "joint_counts": _plain(result.stage1.joint_counts), "frozen_global_identity": result.stage1.frozen_global.identity if result.stage1.frozen_global else None}, "k_g_eff": result.stage1.k_g_eff, "highest_joint_level": result.stage1.q1, "retained_candidate_ids": [ids[index] for index in result.stage1.retained]}
        stage2 = {"per_criterion_local_trace": {"ll": [list(row) for row in result.stage2.ll], "local": _plain(result.stage2.local), "joint_counts": _plain(result.stage2.joint_counts)}, "highest_joint_level": result.stage2.q2, "retained_candidate_ids": [ids[index] for index in result.stage2.retained], "k_l": result.stage2.k_l, "adaptive_trace": _plain(result.stage2.adaptive_trace), "local_status": result.stage2.local_status, "local_qcca_required": result.stage2.local_qcca_required, "response_equivalent": result.stage2.response_equivalent}
        if result.protected is not None:
            stage1["qualification_response_indices"] = list(result.stage1.active_criteria)
            stage1["qualification_scope"] = "RESIDUAL_CONDITIONAL_GLOBAL"
        profile_ids = [ids[index] for index in result.profile_class]
        terminal_ids = [ids[index] for index in result.terminal]
        terminal_set = set(result.terminal)
        removed = [ids[index] for index in result.profile_class if index not in terminal_set]
        descriptor_map = {ids[index]: list(dataset.descriptors[index]) for index in result.terminal}
        percentage_context = {}
        for index in result.terminal:
            measures = []
            for criterion_index, criterion in enumerate(dataset.criteria):
                values = [row[criterion_index] for row in dataset.values]
                low, high, value = min(values), max(values), dataset.values[index][criterion_index]
                span = high - low
                shortfall = Decimal(0) if span == 0 else ((high - value) / span if criterion.direction == "maximize" else (value - low) / span)
                attainment = Decimal(1) - shortfall
                best = high if criterion.direction == "maximize" else low
                legacy = None if best == 0 else abs(value - best) / abs(best)
                measures.append({"response": criterion.name, "raw_value": _plain(value), "range_normalized_shortfall": _plain(shortfall), "range_normalized_attainment": _plain(attainment), "legacy_best_relative_deviation": _plain(legacy) if legacy is not None else None})
            percentage_context[ids[index]] = measures
        conditioning = None if result.protected is None else {"contract_type": result.protected["contract_type"], "protected_block": list(result.protected["criteria"]), "protected_indices": list(result.protected["protected_indices"]), "k_p": result.protected["k_p"], "omega_candidate_ids": list(result.protected["omega_candidate_ids"]), "protected_count": result.protected["count"], "protected_criterion": result.protected["criterion"], "protected_level": result.protected["level"], "residual_criteria": list(result.protected["residual"])}
        return {"result_contract_version": "8.0", "task_id": task.task_id, "status": "completed", "provenance": {"input_hash_sha256": task.input_summary.identity.source_hash_sha256, "canonical_task_hash_sha256": task.task_hash_sha256, "core_identity": task.core_configuration.core_identity, "report_renderer_identity": None}, "mode": task.requested_mode.value, "input_summary": {"candidate_count": task.input_summary.candidate_count, "active_criteria": [{"name": item.name, "slot": item.slot, "direction": item.direction} for item in task.input_summary.active_criteria], "descriptors": list(task.input_summary.descriptors)}, "mode_b_conditioning": conditioning, "stage_1": stage1, "stage_2": stage2, "terminal": {"best_worst_first_profile": sorted([result.stage2.ll[result.profile_class[0]][i] for i in range(len(dataset.criteria))]) if result.profile_class else [], "profile_class_candidate_ids": profile_ids, "derived_raw_dominance_removed_ids": removed, "raw_dominance_audit_source": "DERIVED_PROFILE_CLASS_MINUS_CORE_TERMINAL", "terminal_candidate_ids": terminal_ids, "terminal_descriptors": descriptor_map, "reporting_percentages": percentage_context, "co_terminal": result.co_terminal, "response_equivalent": result.response_equivalent}, "integrity": {"source_hash_match": True, "task_hash_match": True, "output_schema_valid": True, "invariant_checks": ["terminal_candidate_ids_is_list", "core_structured_state_copied_without_recalculation", "reporting_percentages_do_not_affect_scientific_state"], "warnings": []}}
    except (AttributeError, IndexError, KeyError, TypeError) as exc:
        raise AgentRejected(AgentError("RESULT_CONTRACT_BUILD_FAILED", "Result contract could not be built from Core structured output.", (("reason", str(exc)),), execution.task.input_summary.identity.source_hash_sha256)) from None
