# NAUTILI — CNPW external application evidence package

## Scope

This package supports the claims actually reported for this published decision system in Results 2.3 and Table 1. It is **not** intended to reproduce every possible CNPW Mode-A, Mode-B, Stage-2, QCCA or relaxation branch. The evidential standard is claim-specific: each manuscript claim is linked to the frozen/reconstructed candidate–response evidence and to the supplied calculation or audit that supports it.

## Source system

- **Domain:** Forest planning
- **Candidate–response size:** 9061 × 4
- **Source citation:** Pajasmaa et al. (2026), NAUTILI: A trade-off-free interactive multiobjective optimization method for group decision making, Journal of Global Optimization 95, 383–404
- **Native decision object:** Interactive Pareto navigation / aspiration and reachability

## Manuscript-claim verification

| ID | Claim | Verified result | Verification route |
|---|---|---|---|
| NAU-1 | Candidate space | **9,061 × 4; 9,061/9,061 Pareto-efficient** | Direct candidate-library property |
| NAU-2 | Native endpoint mapping | **Nearest plot-digitized endpoint F4708 ≈ (6,2,2,2)** | Approximate plot-to-library mapping; explicitly digitization-bounded |
| NAU-3 | CNPW result | **C(J)=GL4; 9,061 → 1,303 → 60 → 2; terminals F1030/F3057** | Direct supplied CNPW execution record |
| NAU-4 | Recovery | **Removing Revenue raises full capability GL4 → GL6** | Response-subset capability audit |

The machine-readable version is `CLAIM_LEDGER.csv`.

## Included source/reconstruction evidence

- `NAUTILI_Forestry-dmitry_forest_problem_non_dom_solns.csv`
- `NAUTILI_Forestry_PublishedProcess_Digitized_vs_CNPW_v1.0 (1).md`
- `NAUTILI_Forestry_PublishedProcess_Digitized_vs_CNPW_v1.0 (1).xlsx`

## Derived claim-specific audits

- `NAUTILI_Headline_Audit.csv`

Derived audits do not introduce a new decision method. They expose the exact arithmetic or frozen-level comparison needed to verify manuscript headline claims from the supplied evidence.

## Claim boundary

The 9,061 candidate library is exact as supplied; the mapped published-process endpoint is approximate because Figure-3 trajectory coordinates were digitized.

## Interpretation

CNPW is applied as an additional qualification and candidate-space diagnostic layer. A difference between the native decision and the CNPW output is not treated as proof that the native method is incorrect; it shows that the native decision object and joint qualification answer different questions. Where the candidate space is top-compatible, the package retains that positive-control result rather than forcing a limitation diagnosis.

## Status

**CLAIM-SPECIFIC EVIDENCE COMPLETE FOR THE CURRENT MANUSCRIPT/TABLE-1 CLAIMS.**
