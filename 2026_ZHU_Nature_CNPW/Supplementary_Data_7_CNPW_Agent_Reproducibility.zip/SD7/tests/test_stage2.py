import unittest

from src.stage2 import assign_stage2
from tests.helpers import make_dataset


class Stage2Tests(unittest.TestCase):
    def test_stage2_maximize(self):
        data = make_dataset(["a", "b", "c", "d", "e", "f", "g"], ["max", "min", "constant"], ["maximize", "minimize", "maximize"], [[0, 7, 9], [1, 6, 9], [2, 5, 9], [3, 4, 9], [4, 3, 9], [5, 2, 9], [6, 1, 9]])
        result = assign_stage2(data, list(range(7)), [0, 1, 2])
        self.assertEqual(1, result.ll[0][0]); self.assertEqual(7, result.ll[6][0])

    def test_stage2_minimize(self):
        data = make_dataset(["a", "b", "c", "d", "e", "f", "g"], ["max", "min", "constant"], ["maximize", "minimize", "maximize"], [[0, 7, 9], [1, 6, 9], [2, 5, 9], [3, 4, 9], [4, 3, 9], [5, 2, 9], [6, 1, 9]])
        result = assign_stage2(data, list(range(7)), [0, 1, 2])
        self.assertEqual(1, result.ll[0][1]); self.assertEqual(7, result.ll[6][1])

    def test_exact_ll_boundary_is_better_level(self):
        data = make_dataset(["a", "b", "c", "d", "e", "f", "g"], ["max", "min", "constant"], ["maximize", "minimize", "maximize"], [[0, 7, 9], [1, 6, 9], [2, 5, 9], [3, 4, 9], [4, 3, 9], [5, 2, 9], [6, 1, 9]])
        result = assign_stage2(data, list(range(7)), [0, 1, 2])
        self.assertEqual(2, result.ll[1][0])

    def test_constant_stage2_criterion(self):
        data = make_dataset(["a", "b", "c", "d", "e", "f", "g"], ["max", "min", "constant"], ["maximize", "minimize", "maximize"], [[0, 7, 9], [1, 6, 9], [2, 5, 9], [3, 4, 9], [4, 3, 9], [5, 2, 9], [6, 1, 9]])
        result = assign_stage2(data, list(range(7)), [0, 1, 2])
        self.assertTrue(all(result.ll[i][2] == 7 for i in range(7)))
