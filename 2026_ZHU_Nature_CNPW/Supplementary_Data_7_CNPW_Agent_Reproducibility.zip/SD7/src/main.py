from __future__ import annotations

import sys
from pathlib import Path

from .input_loader import InputError, load_dataset
from .mode_a import run_mode_a
from .mode_b import run_mode_b
from .report import write_report


def main() -> int:
    filename = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(input("Input file: ").strip())
    try:
        dataset = load_dataset(filename)
        print("=" * 40)
        print("CNPW Core Research v0.1")
        print("=" * 40)
        print(f"Detected: {len(dataset.candidate_ids)} candidates, {len(dataset.criteria)} active criteria, {len(dataset.descriptor_names)} descriptor columns")
        for letter, criterion in zip("ABCDEFGHIJ", dataset.criteria):
            print(f"{letter}. {criterion.name:<20} {criterion.direction}")
        print("\nSelect mode:\n1. Mode A — Equal Importance\n2. Mode B — Protect Result A at GL7")
        choice = input("Choice: ").strip()
        result = run_mode_a(dataset) if choice == "1" else run_mode_b(dataset) if choice == "2" else None
        if result is None:
            print("Invalid mode choice.")
            return 2
        report = write_report(dataset, result)
        print(f"Report written: {report}")
        return 0
    except (InputError, ValueError, OSError) as error:
        print(f"INPUT/RUN ERROR: {error}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
