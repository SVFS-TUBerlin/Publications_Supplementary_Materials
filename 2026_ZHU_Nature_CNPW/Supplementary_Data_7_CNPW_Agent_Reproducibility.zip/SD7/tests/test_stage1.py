import unittest

from src.stage1 import assign_stage1
from tests.helpers import make_dataset


class Stage1Tests(unittest.TestCase):
    def test_effective_global_resolution_when_n_is_less_than_k_g(self):
        data = make_dataset(["a", "b", "c"], ["x", "y"], ["maximize", "maximize"], [[1, 3], [2, 2], [3, 1]])
        result = assign_stage1(data)
        self.assertEqual(3, result.k_g_eff)
        self.assertEqual({1, 2, 3}, {row[0] for row in result.gl})
        self.assertTrue(all(1 <= level <= 3 for row in result.gl for level in row))

    def test_maximize_ranking(self):
        data = make_dataset([str(i) for i in range(8)], ["max", "min"], ["maximize", "minimize"], [[i, 8-i] for i in range(8)])
        result = assign_stage1(data)
        self.assertEqual(1, result.gl[0][0]); self.assertEqual(7, result.gl[7][0])

    def test_minimize_ranking(self):
        data = make_dataset([str(i) for i in range(8)], ["max", "min"], ["maximize", "minimize"], [[i, 8-i] for i in range(8)])
        result = assign_stage1(data)
        self.assertEqual(7, result.gl[7][1]); self.assertEqual(1, result.gl[0][1])

    def test_nondivisible_candidate_count(self):
        data = make_dataset([str(i) for i in range(8)], ["max", "min"], ["maximize", "minimize"], [[i, 8-i] for i in range(8)])
        result = assign_stage1(data)
        self.assertEqual(8, sum(result.final_counts["max"]))
        self.assertEqual([1, 1, 1, 1, 1, 1, 2], result.nominal_counts["max"])

    def test_tie_crossing_moves_upward(self):
        data = make_dataset([str(i) for i in range(7)], ["a", "b"], ["maximize", "maximize"], [[1, i] for i in range(7)])
        result = assign_stage1(data)
        self.assertEqual([7] * 7, [row[0] for row in result.gl])
        self.assertEqual(6, result.tie_adjustments["a"])

    def test_cumulative_gl_semantics(self):
        data = make_dataset([str(i) for i in range(7)], ["a", "b"], ["maximize", "maximize"], [[1, i] for i in range(7)])
        result = assign_stage1(data)
        self.assertEqual(1, result.joint_counts[7])

    def test_stage1_non_reentry(self):
        data = make_dataset([str(i) for i in range(7)], ["a", "b"], ["maximize", "maximize"], [[i, i] for i in range(7)])
        result = assign_stage1(data)
        self.assertEqual([6], result.retained)
