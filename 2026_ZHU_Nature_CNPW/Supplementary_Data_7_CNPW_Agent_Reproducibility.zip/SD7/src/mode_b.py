from decimal import Decimal

from .mode_a import finish_from_stage1
from .models import Dataset, ProtectionContract, RunResult
from .stage1 import assign_stage1, qualify_frozen_global


def _validate(contract: ProtectionContract, criterion_count: int) -> None:
    protected = set(contract.protected_indices)
    if contract.semantics not in {"equal_count_global_qualification", "explicit_raw_thresholds", "normalized_operating_range_tolerances"}:
        raise ValueError("Unknown protection contract semantics.")
    if len(protected) != len(contract.protected_indices):
        raise ValueError("A protected response block cannot contain duplicate responses.")
    if not protected or any(i < 0 or i >= criterion_count for i in protected):
        raise ValueError("Protection contract must name valid protected responses.")
    if len(protected) == criterion_count:
        raise ValueError("Mode B requires a non-empty residual response block; full protection has no residual capability.")
    if contract.semantics == "explicit_raw_thresholds" and (not contract.raw_thresholds or set(contract.raw_thresholds) != protected):
        raise ValueError("Raw-threshold contract must provide one threshold per protected response.")
    if contract.semantics == "normalized_operating_range_tolerances" and (not contract.tolerances or set(contract.tolerances) != protected or any(value < 0 for value in contract.tolerances.values())):
        raise ValueError("Tolerance contract must provide non-negative tolerance per protected response.")


def _domain(dataset: Dataset, frozen, contract: ProtectionContract) -> tuple[list[int], int | None]:
    protected = list(contract.protected_indices)
    if contract.semantics == "equal_count_global_qualification":
        k_p = max(min(frozen.levels[i][j] for j in protected) for i in range(len(dataset.candidate_ids)))
        return [i for i in range(len(dataset.candidate_ids)) if min(frozen.levels[i][j] for j in protected) >= k_p], k_p
    if contract.semantics == "explicit_raw_thresholds":
        return [i for i in range(len(dataset.candidate_ids)) if all(dataset.values[i][j] >= contract.raw_thresholds[j] if dataset.criteria[j].direction == "maximize" else dataset.values[i][j] <= contract.raw_thresholds[j] for j in protected)], None
    domain = []
    for i in range(len(dataset.candidate_ids)):
        valid = True
        for j in protected:
            values = [row[j] for row in dataset.values]
            low, high = min(values), max(values)
            span = high - low
            shortfall = Decimal(0) if span == 0 else ((high - dataset.values[i][j]) / span if dataset.criteria[j].direction == "maximize" else (dataset.values[i][j] - low) / span)
            if shortfall > contract.tolerances[j]:
                valid = False
                break
        if valid:
            domain.append(i)
    return domain, None


def run_mode_b(dataset: Dataset, contract: ProtectionContract) -> RunResult:
    """V8 Mode B: protect, residual Global qualify, then all-response Local refine."""
    _validate(contract, len(dataset.criteria))
    full = assign_stage1(dataset)
    domain, k_p = _domain(dataset, full.frozen_global, contract)
    if not domain:
        raise ValueError("Protection contract produces an empty admissible domain; no automatic lowering is available.")
    criteria = [i for i in range(len(dataset.criteria)) if i not in contract.protected_indices]
    stage1 = qualify_frozen_global(dataset, full.frozen_global, domain, criteria, full.nominal_counts, full.final_counts, full.tie_adjustments, full.k_g_eff)
    names = [dataset.criteria[i].name for i in contract.protected_indices]
    protected = {"contract_type": contract.semantics, "criteria": names, "criterion": names[0] if len(names) == 1 else ", ".join(names), "protected_indices": list(contract.protected_indices), "level": k_p, "k_p": k_p, "omega_candidate_ids": [dataset.candidate_ids[i] for i in domain], "count": len(domain), "residual": [dataset.criteria[i].name for i in criteria]}
    return finish_from_stage1(dataset, "Mode B — Protected Admissible Domain", stage1, protected)
