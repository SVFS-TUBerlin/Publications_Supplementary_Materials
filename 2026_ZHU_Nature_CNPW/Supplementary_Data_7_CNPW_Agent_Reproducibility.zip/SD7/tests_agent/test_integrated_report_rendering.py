import unittest
from pathlib import Path

from agent.dual_coordinator import DualAnalysisCoordinator
from agent.integrated_report import render_presentation_markdown, render_integrated_markdown


ROOT = Path(__file__).resolve().parents[1]


class IntegratedReportRenderingTests(unittest.TestCase):
    def test_verified_dual_analysis_renders_semantic_notes_without_ai(self):
        outcome = DualAnalysisCoordinator(ROOT).execute(ROOT / "examples" / "example_m3.csv")
        self.assertIsNone(outcome.error)
        self.assertTrue(outcome.result["mode_a"]["verification"].passed)
        self.assertTrue(outcome.result["mode_b"]["verification"].passed)
        report = render_presentation_markdown(outcome.result)
        for heading in ("CNPW V8 Integrated Analysis Report", "Input and scientific contract", "Mode A", "Mode-B protected-domain contract landscape", "QCCA diagnosis and QCCA-guided alternatives", "Verification and provenance", "AI-assisted interpretation"):
            self.assertIn(heading, report)
        self.assertIn("AI-assisted interpretation: Unavailable", report)
        self.assertIn("Rows follow protected-block cardinality", report)
        self.assertIn("not ranked", report)
        self.assertIn("residual responses determine Stage-1 conditional capability", report)
        self.assertIn("Residual Stage-1 capability", report)
        self.assertIn("(Ω_P, J_res, G)", report)
        self.assertEqual(report, render_integrated_markdown(outcome.result))
        self.assertTrue(report.strip())


if __name__ == "__main__":
    unittest.main()
