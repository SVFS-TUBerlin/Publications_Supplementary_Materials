from __future__ import annotations

import os
from pathlib import Path

import streamlit as st

from agent.coordinator import AgentCoordinator
from agent.input_guard import InputGuard
from agent.llm_client import OpenAIIntentClient
from agent.report_renderer import render_csv, render_json, render_markdown
from agent.dual_coordinator import DualAnalysisCoordinator
from agent.integrated_report import render_integrated_json, render_integrated_markdown, render_presentation_markdown
from agent.ai_summary import build_fact_packet, summarize_verified_facts

from app.ui_helpers import dataset_rows, semantic_messages, terminal_rows, user_error
from app.ui_state import clear_temporary_upload, result_matches_current_input, store_uploaded_file


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _full_report_download_filename(upload_name: str | None) -> str:
    """Create a portable report filename while retaining the uploaded file's stem."""
    stem = Path(upload_name or "").stem
    safe_stem = "".join("_" if char in '<>:"/\\|?*' else char for char in stem).rstrip(" .")
    return f"{safe_stem or 'CNPW_Analysis'}_CNPW_Result.md"


def _show_outcome(outcome) -> None:
    if outcome.error:
        st.error(user_error(outcome.error))
        with st.expander("Technical details"):
            st.code(outcome.error.code)
        return
    if not outcome.verification.passed:
        st.error("INTEGRITY CHECK FAILED — scientific conclusions are suppressed.")
        st.write(list(outcome.verification.failures))
        return
    result, verification, provenance = outcome.result, outcome.verification, outcome.provenance
    mode_b = result["mode_b_conditioning"]
    st.subheader("Agent interpretation")
    st.success("Validation: PASS")
    st.write(f"Recognized task: **{'Mode A' if mode_b is None else 'Simplified Mode B'}**")
    if mode_b:
        st.write(f"Protected Result A: **{mode_b['protected_criterion']}** at **GL{mode_b['protected_level']}**")
        st.write("Residual criteria: " + ", ".join(mode_b["residual_criteria"]))
    ai = provenance.get("ai_intent", {})
    st.caption(f"Provider/model: {ai.get('provider_identity', 'not recorded')} / {ai.get('model_identity', 'not recorded')}")
    st.subheader("Verified result summary")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Mode", "Mode A" if mode_b is None else "Simplified Mode B")
    c2.metric("Stage 1", f"GL{result['stage_1']['highest_joint_level']} · W1 {len(result['stage_1']['retained_candidate_ids'])}")
    c3.metric("Stage 2", f"LL{result['stage_2']['highest_joint_level']} · W2 {len(result['stage_2']['retained_candidate_ids'])}")
    terminal_ids = result["terminal"]["terminal_candidate_ids"]
    c4.metric("Terminal count", len(terminal_ids))
    st.subheader("Qualification flow")
    flow = [f"N={result['input_summary']['candidate_count']}"]
    if mode_b:
        flow.append(f"Result-A GL7={mode_b['protected_count']}")
    flow.extend([f"Q1*=GL{result['stage_1']['highest_joint_level']} / W1={len(result['stage_1']['retained_candidate_ids'])}", f"Q2*=LL{result['stage_2']['highest_joint_level']} / W2={len(result['stage_2']['retained_candidate_ids'])}", f"Profile={len(result['terminal']['profile_class_candidate_ids'])}", f"Terminal={len(terminal_ids)}"])
    st.info(" → ".join(flow))
    st.subheader("TERMINAL SET" if len(terminal_ids) > 1 else "Terminal candidate")
    st.dataframe(terminal_rows(result), width="stretch", hide_index=True)
    st.subheader("Verified interpretation")
    for message in semantic_messages(verification.semantic_states):
        st.write("- " + message)
    with st.expander("Provenance and integrity"):
        st.json({"input_sha256": provenance["input_file_sha256"], "canonical_task_sha256": provenance["canonical_task_sha256"], "core_source_manifest_sha256": provenance["core_source_manifest"]["aggregate_sha256"], "agent": provenance["agent_implementation_identity"], "mode": provenance["execution_mode"], "kg": provenance["kg"], "kl": provenance["kl"], "ai_intent": provenance.get("ai_intent", {}), "verification": verification.to_dict()})
    markdown = render_markdown(result, verification, provenance)
    json_output = render_json(result, verification, provenance)
    csv_output = render_csv(result, verification, provenance)
    task_id = result["task_id"]
    st.subheader("Downloads")
    d1, d2, d3 = st.columns(3)
    d1.download_button("Download Markdown", markdown, f"CNPW_Report_{task_id}.md", "text/markdown")
    d2.download_button("Download JSON", json_output, f"CNPW_Result_{task_id}.json", "application/json")
    d3.download_button("Download CSV", csv_output, f"CNPW_Terminal_{task_id}.csv", "text/csv")


def main() -> None:
    """LEGACY / NOT USED BY DEFAULT V8: historical intent-driven UI."""
    st.set_page_config(page_title="CNPW Scientific Agent", page_icon="◈", layout="wide")
    st.title("CNPW Scientific Agent")
    st.caption("Bounded AI interface for deterministic non-compensatory multi-objective qualification.")
    st.info("v0.1 Research Release")
    st.subheader("1. Dataset")
    uploaded = st.file_uploader("Upload a CSV or XLSX candidate library", type=["csv", "xlsx"])
    if uploaded is None:
        if st.session_state.get("upload_path"):
            clear_temporary_upload(st.session_state)
        st.caption("Uploads are copied to a session-local temporary file and removed on replacement/reset where reasonably possible. No permanent history is created.")
        st.button("RUN CNPW", disabled=True)
        return
    path = store_uploaded_file(uploaded, st.session_state)
    validation = InputGuard().validate(path, "MODE_A")
    if not validation.accepted:
        st.error(user_error(validation.error))
        return
    st.success("Input validation: PASS")
    st.write(f"Filename: `{st.session_state['upload_name']}` · N={validation.task.input_summary.candidate_count} · M={len(validation.task.input_summary.active_criteria)}")
    st.dataframe(dataset_rows(validation.task), width="stretch", hide_index=True)
    if validation.task.input_summary.descriptors:
        st.caption("Descriptors preserved but inactive: " + ", ".join(validation.task.input_summary.descriptors))
    st.subheader("2. Validated scope")
    st.caption("Direct M=3–5 · Mode A · simplified Mode B · Result A protected at GL7 in Mode B · directions from file · descriptors inactive")
    st.subheader("3. User requirement")
    requirement = st.text_area("Describe how the active criteria should be treated.", placeholder="Treat all active criteria equally.")
    if not os.environ.get("OPENAI_API_KEY"):
        st.warning("Live AI intent interpretation is unavailable because no reference provider credential is configured.")
    run = st.button("RUN CNPW", type="primary", disabled=not requirement.strip() or not os.environ.get("OPENAI_API_KEY"))
    if st.button("Reset session"):
        clear_temporary_upload(st.session_state)
        st.rerun()
    if run:
        with st.spinner("Validating bounded task and running deterministic pipeline..."):
            outcome = AgentCoordinator(OpenAIIntentClient(), PROJECT_ROOT).execute(path, requirement)
            st.session_state["pipeline_outcome"] = outcome
            st.session_state["pipeline_outcome_input_hash"] = st.session_state["upload_hash"]
    if result_matches_current_input(st.session_state, "pipeline_outcome"):
        _show_outcome(st.session_state["pipeline_outcome"])


def dual_main() -> None:
    st.set_page_config(page_title="CNPW Scientific Agent", page_icon="◈", layout="wide")
    st.markdown("""<style>.block-container{max-width:1100px;padding-top:2.4rem}.cnpw-hero{padding:1.2rem 1.4rem;border:1px solid #dbe3ea;border-radius:12px;background:#fafcfd;margin-bottom:1.2rem}.cnpw-card{padding:1rem 1.1rem;border:1px solid #e1e7eb;border-radius:10px;margin:.6rem 0}</style>""", unsafe_allow_html=True)
    st.markdown("""<div class='cnpw-hero'><h1>CNPW Scientific Agent</h1><p><strong>v0.1 Research Release</strong></p><p>Deterministic non-compensatory multi-objective analysis with optional bounded AI-assisted interpretation.</p></div>""", unsafe_allow_html=True)
    st.subheader("1. Input")
    st.caption("Upload a CNPW-formatted CSV or XLSX candidate library.")
    uploaded = st.file_uploader("Upload a CSV or XLSX candidate library", type=["csv", "xlsx"])
    if uploaded is None:
        if st.session_state.get("upload_path"):
            clear_temporary_upload(st.session_state)
        st.button("Run CNPW Analysis", disabled=True)
        return
    path = store_uploaded_file(uploaded, st.session_state)
    validation = InputGuard().validate(path, "MODE_A")
    if not validation.accepted:
        st.error(user_error(validation.error))
        return
    st.success("Input validation: PASS")
    st.write(f"Filename: `{st.session_state['upload_name']}` · Candidates: {validation.task.input_summary.candidate_count} · Active criteria: {len(validation.task.input_summary.active_criteria)}")
    with st.expander("View detected criteria"):
        st.dataframe(dataset_rows(validation.task), width="stretch", hide_index=True)
    st.caption("CNPW runs Mode A and every non-empty proper protected-response block. Mode B protects, qualifies residual responses, then refines all responses locally.")
    if st.button("Run CNPW Analysis", type="primary"):
        with st.spinner("Running CNPW analysis..."):
            st.session_state["dual_outcome"] = DualAnalysisCoordinator(PROJECT_ROOT).execute(path)
            st.session_state["dual_outcome_input_hash"] = st.session_state["upload_hash"]
    outcome = st.session_state.get("dual_outcome") if result_matches_current_input(st.session_state, "dual_outcome") else None
    if not outcome:
        return
    if outcome.error:
        st.error(user_error(outcome.error))
        return
    dual = outcome.result
    if dual["overall_integrity_status"] != "completed":
        st.error("INTEGRITY CHECK FAILED — normal integrated scientific conclusions are suppressed.")
        return
    st.subheader("2. Results")
    comparison = dual["comparison"]
    st.success("Analysis completed and independently verified.")
    st.write(f"Completed {len(dual['mode_b_contracts'])} Mode-B contracts. The summary below shows the first contract in formal order; the full report contains every contract without preference ranking.")
    ai_outcome = summarize_verified_facts(build_fact_packet(dual), None)
    a,b=dual['mode_a']['verified_result'],dual['mode_b']['verified_result']
    def terminal(ids): return ", ".join(ids) if len(ids)==1 else f"{len(ids)}-candidate set"
    summary=st.columns(3); summary[0].metric("Mode A",terminal(comparison['mode_a_terminal_ids'])); summary[1].metric("Mode B: first contract",terminal(comparison['mode_b_terminal_ids'])); summary[2].metric("A / first-contract relation", "Same" if set(comparison['mode_a_terminal_ids']) == set(comparison['mode_b_terminal_ids']) else "Different")
    if len(comparison['mode_a_terminal_ids'])>1 or len(comparison['mode_b_terminal_ids'])>1:
        with st.expander("View terminal set"): st.write({"Mode A":comparison['mode_a_terminal_ids'],"Mode B":comparison['mode_b_terminal_ids']})
    st.caption("Optional AI interpretation unavailable; verified analysis is complete.")
    markdown = render_presentation_markdown(dual, ai_outcome.interpretation, st.session_state['upload_name'])
    st.download_button("Download Full Report", markdown, _full_report_download_filename(st.session_state.get('upload_name')), "text/markdown")
    with st.expander("Technical exports"):
        st.download_button("Download integrated JSON", render_integrated_json(dual), "CNPW_Integrated_Analysis_Result.json", "application/json")


if __name__ == "__main__":
    dual_main()
