# -*- coding: utf-8 -*-
"""Figure 5: 3x3 microscopy montage (Roboto Bold typography)."""
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import os

# =========================
# 1. 路径设置（不变）
# =========================
INPUT_DIR = r"D:\soft\3"
OUTPUT_PATH = r"D:\soft\3\Figure5_9panel_updated.png"

IMAGE_FILES = [
    "20.jpg", "4.jpg",  "13.jpg",
    "6.jpg",  "1.jpg",  "7.jpg",
    "14.jpg", "5.jpg",  "19.jpg"
]

PANEL_LABELS = ["(a)", "(b)", "(c)", "(d)", "(e)", "(f)", "(g)", "(h)", "(i)"]
COL_TITLES = ["P = 0.43 mm", "P = 0.45 mm", "P = 0.47 mm"]
ROW_TITLES = ["h = 0.10\nmm", "h = 0.20\nmm", "h = 0.25\nmm"]

# =========================
# 2. 单图尺寸（不变）
# =========================
PANEL_W = 900
PANEL_H = 675
AUTO_RESIZE = True

# =========================
# 3. 版式参数
# =========================
BG_COLOR = "white"

# 仅增大左、上留白以容纳放大的标题，其他间隔不变
LEFT_MARGIN = 195       # 原 120；避免 42 px 的 h 标签被画布裁掉
RIGHT_MARGIN = 40
TOP_MARGIN = 125        # 原 95；使 46 px 的列标题留白更充足
BOTTOM_MARGIN = 40

H_GAP = 16
V_GAP = 16
COL_TITLE_Y = 44
ROW_TEXT_X = 18          # 保留原变量（行标题实际按左留白居中）

# =========================
# 4. 字体设置：统一 Roboto，优先原生粗体
# =========================
# 不依赖“必须有 Roboto-Bold.ttf”这一特定文件名：
# - Roboto Bold 文件：直接用粗体（最佳）
# - Roboto 可变字体：尝试启用 Bold 字重
# - Roboto Regular 文件：用 Pillow 的 stroke_width 模拟加粗
# 如果电脑没有 Roboto 字体，请从 Google Fonts 安装后重新运行。
# 也可以在运行前设置环境变量 ROBOTO_FONT_FILE 指向现有的 Roboto 字体文件。

def find_roboto():
    font_dirs = [Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"]
    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        font_dirs.append(Path(local_app_data) / "Microsoft" / "Windows" / "Fonts")
    font_dirs.extend([Path(__file__).resolve().parent, Path(INPUT_DIR)])

    user_choice = os.environ.get("ROBOTO_FONT_FILE", "").strip().strip('"')
    if user_choice:
        candidate = Path(user_choice)
        if not candidate.is_file():
            raise FileNotFoundError(f"ROBOTO_FONT_FILE 指向的字体不存在：{candidate}")
        return str(candidate), "指定文件"

    # 查找全部 Roboto 字体文件，不依赖名称的固定大小写、标点或版本。
    candidates = []
    seen = set()
    for folder in font_dirs:
        if not folder.is_dir():
            continue
        try:
            for file in folder.iterdir():
                if not file.is_file() or file.suffix.lower() not in (".ttf", ".otf", ".ttc"):
                    continue
                name = file.stem.lower()
                if not name.startswith("roboto") or any(x in name for x in ("mono", "condensed", "slab", "serif")):
                    continue
                if file in seen:
                    continue
                seen.add(file)
                # 优先 Bold，其次可变字体，再次 Regular。
                if "bold" in name and "semi" not in name and "extra" not in name:
                    priority = 0
                elif "variable" in name or "[" in name or "wght" in name:
                    priority = 1
                elif "regular" in name or name == "roboto":
                    priority = 2
                else:
                    priority = 3
                candidates.append((priority, str(file)))
        except OSError:
            continue

    if not candidates:
        raise FileNotFoundError(
            "这台电脑未找到 Roboto 字体（不只是缺少 Bold）。请从 "
            "https://fonts.google.com/specimen/Roboto 下载并安装，"
            "或设置 ROBOTO_FONT_FILE 为 Roboto 字体文件的完整路径。"
        )

    candidates.sort(key=lambda x: (x[0], x[1].lower()))
    return candidates[0][1], "自动查找"


ROBOTO_FONT_PATH, ROBOTO_FONT_SOURCE = find_roboto()
ROBOTO_IS_NATIVE_BOLD = "bold" in Path(ROBOTO_FONT_PATH).stem.lower() and "semi" not in Path(ROBOTO_FONT_PATH).stem.lower()


def get_font(size, bold=True):
    global ROBOTO_IS_NATIVE_BOLD
    font = ImageFont.truetype(ROBOTO_FONT_PATH, size=size)
    # 如果是可变 Roboto 字体，尽可能选择真正的 Bold 字重。
    if hasattr(font, "get_variation_names") and "bold" not in Path(ROBOTO_FONT_PATH).stem.lower():
        try:
            styles = font.get_variation_names()
            for style in styles:
                name = style.decode("utf-8", errors="ignore") if isinstance(style, bytes) else str(style)
                if name.strip().lower() == "bold":
                    font.set_variation_by_name(style)
                    ROBOTO_IS_NATIVE_BOLD = True
                    break
        except (OSError, ValueError, AttributeError):
            pass
    return font


# 字号与上版一致：46 / 42 / 38 / 38 px
FONT_COL = get_font(46, bold=True)
FONT_ROW = get_font(42, bold=True)
FONT_PANEL = get_font(38, bold=True)
FONT_SCALE = get_font(60, bold=True)

# 找到真实 Bold 时无需描边；仅找到 Regular 时增加1px同色描边，视觉上加粗。
TEXT_STROKE = 0 if ROBOTO_IS_NATIVE_BOLD else 1


def bold_text(draw, xy, text, fill, font):
    draw.text(xy, text, fill=fill, font=font,
              stroke_width=TEXT_STROKE, stroke_fill=fill)


# =========================
# 5. 标尺参数（不变）
# =========================
# 只有在裁剪图像的像素标定仍为 200 µm = 156.31 px 时才有效。
SCALE_BAR_MICRONS = 200
SCALE_BAR_PX = 156.31

SCALE_COLOR = (220, 0, 0)
SCALE_LINE_WIDTH = 6
SCALE_TICK_HEIGHT = 18
SCALE_TEXT_GAP = 28
SHOW_SCALE_ON_LAST_PANEL_ONLY = True

# =========================
# 6. 工具函数（不变）
# =========================
def safe_open_resize(path, target_size):
    img = Image.open(path).convert("RGB")
    if img.size != target_size:
        if AUTO_RESIZE:
            img = img.resize(target_size, Image.Resampling.LANCZOS)
        else:
            raise ValueError(
                f"{os.path.basename(path)}: got {img.size}, expected {target_size}. "
                "No auto-resizing was done."
            )
    return img


def draw_panel_label(draw, label, x, y):
    bbox = draw.textbbox((0, 0), label, font=FONT_PANEL)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]

    pad_x = 8
    pad_y = 4
    draw.rounded_rectangle(
        [x, y, x + tw + 2 * pad_x, y + th + 2 * pad_y],
        radius=4,
        fill="white",
        outline=(80, 80, 80),
        width=1
    )
    bold_text(draw, (x + pad_x, y + pad_y - 1), label, fill=(30, 30, 30), font=FONT_PANEL)


def draw_scale_bar(draw, panel_x0, panel_y0):
    """仅在最后一张图 (i) 右下角画无白底红色 200 µm 标尺。"""
    margin_right = 26
    margin_bottom = 24

    bar_len = SCALE_BAR_PX
    x2 = panel_x0 + PANEL_W - margin_right
    x1 = x2 - bar_len
    y = panel_y0 + PANEL_H - margin_bottom

    draw.line((x1, y, x2, y), fill=SCALE_COLOR, width=SCALE_LINE_WIDTH)
    draw.line(
        (x1, y - SCALE_TICK_HEIGHT / 2, x1, y + SCALE_TICK_HEIGHT / 2),
        fill=SCALE_COLOR, width=SCALE_LINE_WIDTH
    )
    draw.line(
        (x2, y - SCALE_TICK_HEIGHT / 2, x2, y + SCALE_TICK_HEIGHT / 2),
        fill=SCALE_COLOR, width=SCALE_LINE_WIDTH
    )

    scale_text = f"{SCALE_BAR_MICRONS} μm"
    bbox = draw.textbbox((0, 0), scale_text, font=FONT_SCALE)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    tx = x1 + (bar_len - tw) / 2
    ty = y - th - SCALE_TEXT_GAP
    bold_text(draw, (tx, ty), scale_text, fill=SCALE_COLOR, font=FONT_SCALE)


def draw_centered_text(draw, text, center_x, y, font, fill=(40, 50, 60)):
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    bold_text(draw, (center_x - tw / 2, y), text, font=font, fill=fill)


def draw_row_text(draw, text, x_center, y_center):
    lines = text.split("\n")
    line_gap = 4
    bboxes = [draw.textbbox((0, 0), line, font=FONT_ROW) for line in lines]
    widths = [b[2] - b[0] for b in bboxes]
    heights = [b[3] - b[1] for b in bboxes]
    total_h = sum(heights) + line_gap * (len(lines) - 1)

    y = y_center - total_h / 2
    for i, line in enumerate(lines):
        w = widths[i]
        h = heights[i]
        bold_text(draw, (x_center - w / 2, y), line, font=FONT_ROW, fill=(40, 50, 60))
        y += h + line_gap

# =========================
# 7. 主程序（图片与标尺逻辑不变）
# =========================
def main():
    images = []
    for fname in IMAGE_FILES:
        path = os.path.join(INPUT_DIR, fname)
        if not os.path.exists(path):
            raise FileNotFoundError(f"Not found: {path}")
        img = safe_open_resize(path, (PANEL_W, PANEL_H))
        images.append(img)

    canvas_w = LEFT_MARGIN + 3 * PANEL_W + 2 * H_GAP + RIGHT_MARGIN
    canvas_h = TOP_MARGIN + 3 * PANEL_H + 2 * V_GAP + BOTTOM_MARGIN

    canvas = Image.new("RGB", (canvas_w, canvas_h), BG_COLOR)
    draw = ImageDraw.Draw(canvas)

    for idx, img in enumerate(images):
        r = idx // 3
        c = idx % 3

        x = LEFT_MARGIN + c * (PANEL_W + H_GAP)
        y = TOP_MARGIN + r * (PANEL_H + V_GAP)

        canvas.paste(img, (x, y))
        draw_panel_label(draw, PANEL_LABELS[idx], x + 12, y + 12)

        if SHOW_SCALE_ON_LAST_PANEL_ONLY and idx == 8:
            draw_scale_bar(draw, x, y)

    for c, title in enumerate(COL_TITLES):
        cx = LEFT_MARGIN + c * (PANEL_W + H_GAP) + PANEL_W / 2
        draw_centered_text(draw, title, cx, COL_TITLE_Y, FONT_COL)

    for r, title in enumerate(ROW_TITLES):
        cy = TOP_MARGIN + r * (PANEL_H + V_GAP) + PANEL_H / 2
        # 仅随左边距放大，将行标题置于左侧留白的中心，防止放大后裁切。
        draw_row_text(draw, title, LEFT_MARGIN / 2, cy)

    canvas.save(OUTPUT_PATH, format="PNG")
    print(f"Font: {ROBOTO_FONT_PATH}")
    print(f"Font weight: {'native bold' if ROBOTO_IS_NATIVE_BOLD else 'Roboto regular + 1px simulated bold'}")
    print(f"Saved to: {OUTPUT_PATH}")
    print(f"Canvas size: {canvas_w} x {canvas_h} px")


if __name__ == "__main__":
    main()
