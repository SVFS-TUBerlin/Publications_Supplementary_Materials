# Deterministic replay

140/140 six-domain Mode-B; 6/6 Mode-A; 146/146 six-domain decisions. Controlled: 14 Mode-B plus one Mode-A, separately counted. Every input executed twice and portable complete exports matched. Implementation verification, not independent replication. All eight known changed contracts reproduced.
