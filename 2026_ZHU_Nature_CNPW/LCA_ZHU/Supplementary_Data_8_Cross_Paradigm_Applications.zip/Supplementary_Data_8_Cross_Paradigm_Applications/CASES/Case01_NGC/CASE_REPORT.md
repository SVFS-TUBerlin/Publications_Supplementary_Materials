# NGC — CNPW external application evidence package

## Scope

This package supports the claims actually reported for this published decision system in Results 2.3 and Table 1. It is **not** intended to reproduce every possible CNPW Mode-A, Mode-B, Stage-2, QCCA or relaxation branch. The evidential standard is claim-specific: each manuscript claim is linked to the frozen/reconstructed candidate–response evidence and to the supplied calculation or audit that supports it.

## Source system

- **Domain:** Additive manufacturing
- **Candidate–response size:** 9801 × 6
- **Source citation:** Almeida et al. (2026), Multi-objective optimization of sustainable performance in fused filament fabrication, Computers & Industrial Engineering 216, 112001
- **Native decision object:** Weighted normalized scalar compromise under four published preference scenarios

## Manuscript-claim verification

| ID | Claim | Verified result | Verification route |
|---|---|---|---|
| NGC-1 | Candidate space size | **9,801 × 6** | Direct frozen-library record |
| NGC-2 | Four published compromise solutions under CNPW mapping | **GL4 / GL4 / GL5 / GL4** | Published-scenario projection recorded in supplied evidence |
| NGC-3 | Full candidate-space capability and refinement | **C(J)=GL6; 22 → 4 → 1; terminal EPG8129** | Direct CNPW execution record |
| NGC-4 | Recovery after removing Cgk_w and Cgk_t | **GL6 → GL7** | Recomputed from frozen Global labels in supplied 9,801-candidate workbook |

The machine-readable version is `CLAIM_LEDGER.csv`.

## Included source/reconstruction evidence

- `212_External_FFF_CNPW_Validation_Protocol_v1.5.2.md`
- `213_External_FFF_CNPW_9801_Validation_v1.5.2.xlsx`
- `214_External_FFF_NGC_vs_CNPW_FourTier_Priority_v1.0.xlsx`
- `216_External_FFF_NGC_vs_CNPW_FourTier_Comparison_Report_v1.0.md`

## Derived claim-specific audits

- `NGC_Headline_Recovery_Audit.csv`

Derived audits do not introduce a new decision method. They expose the exact arithmetic or frozen-level comparison needed to verify manuscript headline claims from the supplied evidence.

## Claim boundary

9,801 candidates are model-evaluated alternatives reconstructed from the published response-model basis, not physical experiments.

## Interpretation

CNPW is applied as an additional qualification and candidate-space diagnostic layer. A difference between the native decision and the CNPW output is not treated as proof that the native method is incorrect; it shows that the native decision object and joint qualification answer different questions. Where the candidate space is top-compatible, the package retains that positive-control result rather than forcing a limitation diagnosis.

## Status

**CLAIM-SPECIFIC EVIDENCE COMPLETE FOR THE CURRENT MANUSCRIPT/TABLE-1 CLAIMS.**
