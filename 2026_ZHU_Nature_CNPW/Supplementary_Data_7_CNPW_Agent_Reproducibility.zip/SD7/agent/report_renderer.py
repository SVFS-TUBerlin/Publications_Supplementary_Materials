"""LEGACY / NOT USED BY DEFAULT V8: historical single-branch renderer.

Current V8 scientific reports use agent.integrated_report. Historical semantic
labels below are not the authoritative residual-Stage-1 V8 contract.
"""
from __future__ import annotations

import csv
import io
from typing import Any

from .contracts import stable_json
from .errors import AgentError, AgentRejected
from .provenance import REPORT_RENDERER_IDENTITY
from .verifier import VerificationReport


SEMANTIC_TEXT = {
    "STAGE2_NO_COMPRESSION": "The highest jointly attainable local qualification does not further reduce the Stage-1 retained set under the current local geometry.",
    "SINGLETON_DOMAIN_LL7": "Stage 1 already produced a singleton; Stage 2 therefore operates on a constant local domain.",
    "GENUINE_NON_SINGLETON_LL7": "The local actual-value qualification separates the retained set at LL7.",
    "RAW_DOMINANCE_ACTIVATED": "Candidates tied on the best worst-first ordinal profile are further reduced by the frozen direction-aware raw-response dominance step. The removal audit is derived from Core-returned set membership, not independently emitted by the Core.",
    "SET_VALUED_TERMINAL": "The current criteria and declared non-compensatory semantics do not justify further discrimination among the remaining alternatives.",
    "MODE_B_PROTECTED_RESULT": "Result A acts as a hard qualification requirement and is excluded from residual discrimination once satisfied.",
    "EMPTY_EXACT_GL": "Empty exact qualification levels can arise when complete tied-value groups are preserved across nominal population boundaries.",
}


def render_markdown(result: dict[str, Any], verification: VerificationReport,
                    provenance: dict[str, Any]) -> str:
    _require_verified(verification, result)
    summary, stage1, stage2, terminal = result["input_summary"], result["stage_1"], result["stage_2"], result["terminal"]
    criteria = summary["active_criteria"]
    lines = ["# CNPW Scientific Agent v0.1 — Verified Execution", "", "## Execution identity", "", f"- Task ID: `{result['task_id']}`", f"- Input filename: `{provenance.get('input_filename', '<not-recorded>')}`", f"- Input SHA-256: `{provenance['input_file_sha256']}`", f"- Execution timestamp: `{provenance['execution_timestamp']}`", f"- Mode: `{result['mode']}`", "", "## Input and frozen Core configuration", "", f"- Candidate count (N): {summary['candidate_count']}", f"- Active criterion count (M): {len(criteria)}", f"- Directions: {', '.join(item['direction'] for item in criteria)}", f"- K_g / K_l: {provenance['kg']} / {provenance['kl']}", f"- Tie policy: `{provenance['tie_policy']}`", f"- Stage-2 policy: `{provenance['stage2_policy']}`", f"- Terminal policy: `{provenance['terminal_policy']}`", "", "| Slot | Criterion | Direction |", "| --- | --- | --- |"]
    lines.extend(f"| {item['slot']} | {item['name']} | {item['direction']} |" for item in criteria)
    if result["mode_b_conditioning"] is not None:
        condition = result["mode_b_conditioning"]
        lines += ["", "## Simplified Mode B condition", "", f"- Protected Result A: {condition['protected_criterion']} at GL{condition['protected_level']}-or-better", f"- Protected candidate count: {condition['protected_count']}", f"- Residual criteria: {', '.join(condition['residual_criteria'])}"]
    lines += ["", "## Structured Core result", "", f"- Q1*: GL{stage1['highest_joint_level']}", f"- W1 ({len(stage1['retained_candidate_ids'])}): {', '.join(stage1['retained_candidate_ids'])}", f"- Q2*: LL{stage2['highest_joint_level']}", f"- W2 ({len(stage2['retained_candidate_ids'])}): {', '.join(stage2['retained_candidate_ids'])}", f"- Best worst-first LL profile: {terminal['best_worst_first_profile']}", f"- Profile class ({len(terminal['profile_class_candidate_ids'])}): {', '.join(terminal['profile_class_candidate_ids'])}", f"- Terminal {'set' if len(terminal['terminal_candidate_ids']) > 1 else 'candidate'} ({len(terminal['terminal_candidate_ids'])}): {', '.join(terminal['terminal_candidate_ids'])}", "", "## Terminal descriptors", ""]
    for candidate_id in terminal["terminal_candidate_ids"]:
        lines.append(f"- {candidate_id}: {terminal['terminal_descriptors'].get(candidate_id, [])} (descriptors are non-mathematical metadata)")
    lines += ["", "## Integrity verification", "", "- Status: PASS", f"- Checks: {len(verification.checks)} passed", "", "## Semantic interpretation", ""]
    lines.extend(f"- {SEMANTIC_TEXT[state]}" for state in verification.semantic_states)
    if not verification.semantic_states:
        lines.append("- No additional fixed semantic state was triggered.")
    lines += ["", "## Provenance", "", f"- Core identity: `{provenance['core_identity']}`", f"- Core source-manifest aggregate SHA-256: `{provenance['core_source_manifest']['aggregate_sha256']}`", f"- Agent identity: `{provenance['agent_implementation_identity']}`", f"- Renderer identity: `{REPORT_RENDERER_IDENTITY}`", "", "## Limitations", "", "This is a deterministic result under the declared CNPW configuration. It does not identify an objective winner, universally best alternative, or complete real-world recommendation. No undeclared preference, weight, score, or tie-break was added.", ""]
    return "\n".join(lines)


def render_json(result: dict[str, Any], verification: VerificationReport,
                provenance: dict[str, Any]) -> str:
    _require_verified(verification, result)
    return stable_json({"result": result, "verification": verification.to_dict(), "provenance": provenance})


def render_csv(result: dict[str, Any], verification: VerificationReport,
               provenance: dict[str, Any]) -> str:
    _require_verified(verification, result)
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer, lineterminator="\n")
    writer.writerow(["task_id", "mode", "terminal_kind", "terminal_candidate_id", "terminal_descriptors", "input_sha256", "core_manifest_sha256"])
    terminal = result["terminal"]
    kind = "terminal_set" if len(terminal["terminal_candidate_ids"]) > 1 else "terminal_candidate"
    for candidate_id in terminal["terminal_candidate_ids"]:
        writer.writerow([result["task_id"], result["mode"], kind, candidate_id, stable_json(terminal["terminal_descriptors"].get(candidate_id, [])), provenance["input_file_sha256"], provenance["core_source_manifest"]["aggregate_sha256"]])
    return buffer.getvalue()


def _require_verified(verification: VerificationReport, result: dict[str, Any]) -> None:
    if not verification.passed:
        result["status"] = "failed_integrity"
        raise AgentRejected(AgentError("RESULT_CONTRACT_BUILD_FAILED", "Scientific conclusion rendering is suppressed because integrity verification failed.", (("failures", ",".join(verification.failures)),), result.get("provenance", {}).get("input_hash_sha256")))
