# Scope and completeness statement

This package intentionally uses a **claim-specific completeness standard**.

For each of the nine published decision systems, Supplementary Data 8 must be sufficient to audit the claims made in Results 2.3 and Table 1. A case is not required to repeat the full CNPW workflow if the manuscript does not report that workflow for the case.

Examples:
- Pesticide: blockwise Mode-A / terminal agreement and Global subset/recovery structure are reported; no Mode-B demonstration is required.
- NGC: Mode-A capability/refinement and the stated response-removal recovery are required; the complete historical priority-analysis family is supporting evidence rather than a manuscript requirement.
- WIBA: full top-compatibility is a positive control; no artificial recovery analysis is introduced.
- RAS: the explicit CNPW-declared cardinal-retention Mode-B illustration is retained, but is not presented as a native RAS acceptance threshold.
- ALEM: qualification protection and strict raw lexicographic preservation are kept distinct.

This prevents the evidence package from inflating nine external comparisons into nine redundant standalone CNPW studies while still making every published claim auditable.
