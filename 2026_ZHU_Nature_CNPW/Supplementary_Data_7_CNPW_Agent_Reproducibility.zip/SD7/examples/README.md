# Public examples

`example_m3.csv` is a fully synthetic, non-scientific M3 input template for local upload and interface checks. Its names, values, and descriptor text are invented. Do not use it to support a scientific, commercial, or policy conclusion.

The file follows the positional CNPW format: title row, direction row, candidate rows, active result columns B–D, blank reserved columns E–K, and descriptor column L.
