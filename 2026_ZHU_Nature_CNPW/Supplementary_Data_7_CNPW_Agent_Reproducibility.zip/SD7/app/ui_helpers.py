from __future__ import annotations

from typing import Any

from agent.report_renderer import SEMANTIC_TEXT


ERROR_MESSAGES = {
    "UNSUPPORTED_INPUT_FORMAT": "Upload a CSV or XLSX candidate library.",
    "INVALID_CANDIDATE_ID": "The candidate-ID column contains a missing or invalid identifier.",
    "DUPLICATE_CANDIDATE_ID": "Candidate IDs must be unique.",
    "INVALID_DIRECTION": "Each active Result direction must be exactly 1 (maximize) or 0 (minimize).",
    "NONFINITE_RESULT": "Active Result values must be numeric and finite.",
    "HIDDEN_DATA_IN_INACTIVE_RESULT_SLOT": "An inactive Result slot contains hidden candidate data.",
    "UNSUPPORTED_DIRECT_CRITERION_COUNT": "This research release accepts direct inputs with 3–5 active Results.",
    "AI_INTENT_UNSUPPORTED": "This requirement is outside the legacy intent interface scope; default V8 analysis uses the automatic complete contract family.",
    "AI_INTENT_UNAVAILABLE": "Live AI intent interpretation is unavailable because the provider timed out.",
    "AI_PROVIDER_ERROR": "Live AI intent interpretation is unavailable because the reference provider could not respond.",
    "AI_INTENT_INVALID": "The AI proposal was rejected by deterministic validation.",
    "CORE_INVOCATION_FAILED": "The deterministic Core could not complete this run.",
}


def user_error(error: Any) -> str:
    if error is None:
        return ""
    if error.code == "RESULT_CONTRACT_BUILD_FAILED":
        return "INTEGRITY CHECK FAILED — scientific conclusions are suppressed."
    return ERROR_MESSAGES.get(error.code, error.message)


def dataset_rows(task: Any) -> list[dict[str, str]]:
    return [{"Slot": item.slot, "Criterion": item.name, "Direction": "↑ Maximize" if item.direction == "maximize" else "↓ Minimize"} for item in task.input_summary.active_criteria]


def terminal_rows(result: dict[str, Any]) -> list[dict[str, Any]]:
    terminal = result["terminal"]
    return [{"Candidate_ID": candidate_id, "Descriptors (inactive)": terminal["terminal_descriptors"].get(candidate_id, [])} for candidate_id in terminal["terminal_candidate_ids"]]


def semantic_messages(states: tuple[str, ...]) -> list[str]:
    return [SEMANTIC_TEXT[state] for state in states]
