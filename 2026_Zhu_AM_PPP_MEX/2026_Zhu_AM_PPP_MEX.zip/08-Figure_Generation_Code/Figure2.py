import os
from PIL import Image, ImageDraw, ImageFont

# =========================================================
# 1. 工作目录
# =========================================================
workdir = r"D:\soft\3"

img_paths = {
    "a": os.path.join(workdir, "a_crop.jpg"),
    "b": os.path.join(workdir, "b_crop.jpg"),
    "c": os.path.join(workdir, "c_crop.jpg"),
    "d": os.path.join(workdir, "d_crop.jpg"),
}

# 两套输出
out_white_png = os.path.join(
    workdir,
    "figure_4panel_WHITE_BOLD.png"
)

out_white_pdf = os.path.join(
    workdir,
    "figure_4panel_WHITE_BOLD.pdf"
)

out_box_png = os.path.join(
    workdir,
    "figure_4panel_BLACK_WHITEBOX_BOLD.png"
)

out_box_pdf = os.path.join(
    workdir,
    "figure_4panel_BLACK_WHITEBOX_BOLD.pdf"
)


# =========================================================
# 2. 检查文件
# =========================================================
for key, path in img_paths.items():
    if not os.path.exists(path):
        raise FileNotFoundError(f"找不到文件：{path}")


# =========================================================
# 3. 读取已经裁剪好的图片
#    不再裁剪
# =========================================================
imgs = {
    key: Image.open(path).convert("RGB")
    for key, path in img_paths.items()
}

print("裁剪后的图片尺寸：")
for key, img in imgs.items():
    print(f"{key}: {img.size}")


# =========================================================
# 4. 版式设置
# =========================================================

# 左右列宽度
LEFT_COL_W = 1600
RIGHT_COL_W = 1400

# 水平、垂直缝隙完全一致
GAP = 18

# 外围白边
OUTER_MARGIN = 15

# 整体背景
BG_COLOR = (255, 255, 255)


# =========================================================
# 5. 保持比例缩放
# =========================================================
def resize_to_width(img, target_width):

    w, h = img.size

    new_height = round(
        h * target_width / w
    )

    return img.resize(
        (target_width, new_height),
        Image.Resampling.LANCZOS
    )


img_a = resize_to_width(
    imgs["a"],
    LEFT_COL_W
)

img_c = resize_to_width(
    imgs["c"],
    LEFT_COL_W
)

img_b = resize_to_width(
    imgs["b"],
    RIGHT_COL_W
)

img_d = resize_to_width(
    imgs["d"],
    RIGHT_COL_W
)


# =========================================================
# 6. 两行高度
# =========================================================
TOP_ROW_H = max(
    img_a.height,
    img_b.height
)

BOTTOM_ROW_H = max(
    img_c.height,
    img_d.height
)


# =========================================================
# 7. 最终画布尺寸
# =========================================================
canvas_width = (
    OUTER_MARGIN
    + LEFT_COL_W
    + GAP
    + RIGHT_COL_W
    + OUTER_MARGIN
)

canvas_height = (
    OUTER_MARGIN
    + TOP_ROW_H
    + GAP
    + BOTTOM_ROW_H
    + OUTER_MARGIN
)


# =========================================================
# 8. 图片位置
# =========================================================

# ---- a 左上 ----
a_x = OUTER_MARGIN

a_y = (
    OUTER_MARGIN
    + (TOP_ROW_H - img_a.height) // 2
)

# ---- b 右上 ----
b_x = (
    OUTER_MARGIN
    + LEFT_COL_W
    + GAP
)

b_y = (
    OUTER_MARGIN
    + (TOP_ROW_H - img_b.height) // 2
)

# ---- c 左下 ----
c_x = OUTER_MARGIN

c_y = (
    OUTER_MARGIN
    + TOP_ROW_H
    + GAP
    + (BOTTOM_ROW_H - img_c.height) // 2
)

# ---- d 右下 ----
d_x = (
    OUTER_MARGIN
    + LEFT_COL_W
    + GAP
)

d_y = (
    OUTER_MARGIN
    + TOP_ROW_H
    + GAP
    + (BOTTOM_ROW_H - img_d.height) // 2
)


# =========================================================
# 9. Roboto Bold 字体
# =========================================================
font = None

possible_fonts = [
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Bold.ttf",
    r"C:\Windows\Fonts\Roboto-Bold.ttf",

    # 如果 Bold 找不到，才依次回退
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Medium.ttf",
    r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts\Roboto-Regular.ttf",
    r"C:\Windows\Fonts\arialbd.ttf",
]

for fp in possible_fonts:

    if os.path.exists(fp):

        font = ImageFont.truetype(
            fp,
            54
        )

        print("使用字体：", fp)

        break


if font is None:

    raise FileNotFoundError(
        "没有找到 Roboto Bold 或其他可用粗体字体。"
    )


# =========================================================
# 10. 创建基础拼接图
# =========================================================
def create_base_canvas():

    canvas = Image.new(
        "RGB",
        (canvas_width, canvas_height),
        BG_COLOR
    )

    canvas.paste(
        img_a,
        (a_x, a_y)
    )

    canvas.paste(
        img_b,
        (b_x, b_y)
    )

    canvas.paste(
        img_c,
        (c_x, c_y)
    )

    canvas.paste(
        img_d,
        (d_x, d_y)
    )

    return canvas


# =========================================================
# 11. 标签参数
# =========================================================

LABEL_OFFSET_X = 18
LABEL_OFFSET_Y = 12

labels = [
    (a_x, a_y, "(a)"),
    (b_x, b_y, "(b)"),
    (c_x, c_y, "(c)"),
    (d_x, d_y, "(d)")
]


# =========================================================
# 12. 版本 1
#     白色加粗字体
#     无描边
#     无底框
# =========================================================
canvas_white = create_base_canvas()

draw_white = ImageDraw.Draw(
    canvas_white
)

for x, y, text in labels:

    draw_white.text(
        (
            x + LABEL_OFFSET_X,
            y + LABEL_OFFSET_Y
        ),
        text,
        font=font,
        fill=(255, 255, 255)
    )


# 保存版本 1
canvas_white.save(
    out_white_png,
    format="PNG",
    dpi=(600, 600)
)

canvas_white.save(
    out_white_pdf,
    format="PDF",
    resolution=600.0
)


# =========================================================
# 13. 版本 2
#     黑色加粗字体
#     白色底座
#     无描边
# =========================================================
canvas_box = create_base_canvas()

draw_box = ImageDraw.Draw(
    canvas_box
)

# 白底框的留白
BOX_PADDING_X = 10
BOX_PADDING_Y = 5

for x, y, text in labels:

    text_x = (
        x + LABEL_OFFSET_X
    )

    text_y = (
        y + LABEL_OFFSET_Y
    )

    # 获取文字边界
    bbox = draw_box.textbbox(
        (text_x, text_y),
        text,
        font=font
    )

    # 白色底座
    box = (
        bbox[0] - BOX_PADDING_X,
        bbox[1] - BOX_PADDING_Y,
        bbox[2] + BOX_PADDING_X,
        bbox[3] + BOX_PADDING_Y
    )

    draw_box.rectangle(
        box,
        fill=(255, 255, 255)
    )

    # 黑色加粗字体
    draw_box.text(
        (
            text_x,
            text_y
        ),
        text,
        font=font,
        fill=(0, 0, 0)
    )


# 保存版本 2
canvas_box.save(
    out_box_png,
    format="PNG",
    dpi=(600, 600)
)

canvas_box.save(
    out_box_pdf,
    format="PDF",
    resolution=600.0
)


# =========================================================
# 14. 输出信息
# =========================================================
print("\n全部完成。")

print("\n版本 1：白色 Bold 字体，无描边")
print(out_white_png)
print(out_white_pdf)

print("\n版本 2：黑色 Bold 字体 + 白色底座，无描边")
print(out_box_png)
print(out_box_pdf)

print("\n最终画布尺寸：")
print(canvas_width, "×", canvas_height)

print("\n水平 / 垂直缝隙：")
print(GAP, "px")