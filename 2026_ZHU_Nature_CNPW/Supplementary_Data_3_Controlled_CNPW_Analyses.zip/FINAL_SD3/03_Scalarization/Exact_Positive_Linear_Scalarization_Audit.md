# Exact positive-linear-scalarization audit — CNPW V8 controlled system

## Scope

This audit is a stable comparator analysis on the frozen 7,056-candidate response space in Supplementary Data 2. The V8 Mode-B/QCCA upgrade does not alter the response table or the scalarizability geometry.

All four responses are oriented so that larger normalized values are preferable, using full-space min–max normalization. The target candidate is PG6628.

## Exact LP questions

For normalized response vector \(u(x)\), the first linear program asks whether there exists a strictly positive weight vector \(w_j>0\), \(\sum_jw_j=1\), for which PG6628 is an argmax. Strict positivity is enforced by maximizing a common lower bound \(\epsilon\) subject to \(w_j\ge\epsilon\).

The second linear program asks whether PG6628 can be a unique argmax by maximizing a common positive score margin against every competitor while retaining strictly positive weights.

## Results

| Candidate domain | Positive-weight support exists | Unique positive-weight exposure exists |
|---|---:|---:|
| Full 7,056 candidates | **Yes** (\(\epsilon^*=0.118476385259\)) | **No** |
| W6, 65 candidates | **Yes** (\(\epsilon^*=0.118476385259\)) | **No** |

One supporting full-space vector is approximately

\[
(w_E,w_{UTS},w_{GWP},w_{FRS})
=(0.118476,0.118476,0.118476,0.644571).
\]

PG6628 is not unique on this supporting face. In the full space,

\[
u(PG6628)=0.8u(PG6626)+0.2u(PG6636),
\]

with numerical residual \(2.109\times10^{-15}\). Within W6,

\[
u(PG6628)=0.5u(PG6626)+0.5u(PG6630),
\]

with residual \(2.554\times10^{-15}\). A linear scalarization therefore cannot make PG6628 strictly better than both endpoints.

## Relation to the 969-weight benchmark

The 969 prespecified strictly positive 0.05-grid weights select PG6628 zero times. This finite-grid result does not imply absence of all positive supporting weights. The exact LP establishes the stronger and correct statement:

> **PG6628 is Pareto-efficient and positively linearly supportable, but it cannot be uniquely exposed by a linear scalar objective.**

This comparator remains independent of CNPW's non-compensatory qualification, QCCA diagnosis and targeted-alternative logic.
