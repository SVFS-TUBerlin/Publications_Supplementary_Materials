# CNPW Cross-Domain Validation — Healthcare / ELECTRE Tri-nC Case
## File-217 Standard Upgrade

**Validation case:** Hospital risk management  
**Native method:** ELECTRE Tri-nC  
**Domain:** Healthcare risk management  
**Representative source:** Joana Lemos Alves & Miguel Alves Pereira (2025), *Enhancing clinical and non-clinical risk management: A case study using ELECTRE Tri-nC*, *Health Care Management Science* 28, 824–841. DOI: 10.1007/s10729-025-09734-6  
**CNPW core version:** v1.5.2  
**Governing validation standard:** File 217 — CNPW cross-domain validation standard  
**Status:** **PASS — retain as a formal small-\(N\), high-\(m\), same-data cross-domain validation case**

---

# 1. Role under the File-217 validation standard

This file is not an independent healthcare application paper and is not intended to reproduce every capability of ELECTRE Tri-nC.

Its purpose is to test a narrower and reproducible portability claim:

\[
\boxed{
\text{Can frozen CNPW v1.5.2 operate on an independently published, non-manufacturing,
multi-response decision matrix without changing its core qualification grammar?}
}
\]

A valid File-217 case must separate four evidence layers:

1. **source-native evidence** — what the original study actually did and reported;
2. **frozen transferable input** — what is imported unchanged into CNPW;
3. **CNPW execution evidence** — what the frozen CNPW protocol produces;
4. **comparative interpretation** — what agreement, disagreement, or additional structure can be claimed without redefining the native method.

This case satisfies all four layers.

---

# 2. Source-native problem

The source study evaluates **20 consecutive hospital quarters** from 2018–2022 using **12 clinical and non-clinical incident criteria**.

All criteria are incident counts and are therefore minimized.

The native decision task is a **sorting / classification problem**, not an optimization problem.

ELECTRE Tri-nC assigns each quarter to one of five ordered risk categories:

\[
C_5=\text{Low risk}
\]

\[
C_4=\text{Moderate risk}
\]

\[
C_3=\text{High risk}
\]

\[
C_2=\text{Very-high risk}
\]

\[
C_1=\text{Extreme risk}.
\]

The published implementation uses:

- 12 criterion weights;
- indifference thresholds \(q_j\);
- preference thresholds \(p_j\);
- veto thresholds \(v_j\);
- two characteristic reference actions for each category;
- a base credibility level
  \[
  \lambda=0.65.
  \]

The study also reports stability / robustness analyses for:

- criterion-weight stability;
- \(\lambda=0.60,0.65,0.70\);
- exclusion of the non-clinical criteria.

These source-native robustness analyses are retained as independent context and are not re-labelled as CNPW robustness.

---

# 3. Frozen candidate-response matrix

The CNPW input is the source paper's Table 3 without pre-filtering, reweighting, imputation, rescaling, or healthcare-specific reinterpretation.

\[
\boxed{
N=20,\qquad m=12
}
\]

All responses are minimized.

| Criterion | Meaning |
|---|---|
| \(g_1\) | Patient management |
| \(g_2\) | Clinical procedures |
| \(g_3\) | Documentation |
| \(g_4\) | Healthcare-associated infections |
| \(g_5\) | Medication and intravenous fluids |
| \(g_6\) | Blood and derivatives |
| \(g_7\) | Behaviour |
| \(g_8\) | Medical devices and equipment |
| \(g_9\) | Nutrition and diet |
| \(g_{10}\) | Patient accident |
| \(g_{11}\) | Organisational management and resources |
| \(g_{12}\) | Infrastructure, safety, and facilities |

Because candidates are historical time periods rather than controllable design points:

\[
\boxed{
\text{process-window topology, connected components, and parameter-migration diagnostics are not activated.}
}
\]

This is a deliberate domain-validity restriction, not missing analysis.

---

# 4. Complete frozen matrix

| Period | g1 | g2 | g3 | g4 | g5 | g6 | g7 | g8 | g9 | g10 | g11 | g12 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Q1 2018 | 6 | 14 | 5 | 2 | 57 | 2 | 0 | 7 | 4 | 74 | 7 | 21 |
| Q2 2018 | 11 | 5 | 3 | 0 | 38 | 1 | 1 | 5 | 3 | 59 | 4 | 9 |
| Q3 2018 | 3 | 2 | 1 | 1 | 31 | 0 | 1 | 9 | 2 | 51 | 1 | 7 |
| Q4 2018 | 10 | 4 | 1 | 2 | 45 | 1 | 3 | 2 | 1 | 63 | 0 | 7 |
| Q1 2019 | 5 | 5 | 7 | 1 | 50 | 2 | 0 | 6 | 1 | 64 | 4 | 16 |
| Q2 2019 | 5 | 4 | 5 | 1 | 28 | 0 | 5 | 5 | 0 | 58 | 6 | 10 |
| Q3 2019 | 3 | 1 | 2 | 1 | 35 | 0 | 0 | 8 | 1 | 57 | 2 | 21 |
| Q4 2019 | 4 | 3 | 3 | 1 | 37 | 0 | 2 | 8 | 6 | 51 | 0 | 22 |
| Q1 2020 | 7 | 9 | 0 | 4 | 28 | 0 | 2 | 9 | 2 | 70 | 7 | 31 |
| Q2 2020 | 4 | 2 | 2 | 10 | 9 | 0 | 0 | 9 | 5 | 75 | 4 | 17 |
| Q3 2020 | 4 | 8 | 3 | 1 | 20 | 0 | 2 | 29 | 0 | 81 | 5 | 28 |
| Q4 2020 | 12 | 8 | 3 | 2 | 18 | 1 | 3 | 12 | 4 | 62 | 15 | 27 |
| Q1 2021 | 13 | 11 | 2 | 2 | 75 | 3 | 1 | 9 | 4 | 67 | 7 | 26 |
| Q2 2021 | 3 | 10 | 3 | 1 | 19 | 4 | 1 | 5 | 1 | 50 | 3 | 19 |
| Q3 2021 | 13 | 6 | 7 | 2 | 20 | 0 | 1 | 6 | 4 | 45 | 4 | 11 |
| Q4 2021 | 12 | 5 | 3 | 1 | 25 | 3 | 5 | 8 | 3 | 85 | 12 | 15 |
| Q1 2022 | 2 | 11 | 1 | 0 | 22 | 0 | 4 | 7 | 0 | 66 | 10 | 21 |
| Q2 2022 | 8 | 7 | 3 | 0 | 33 | 3 | 7 | 8 | 5 | 80 | 7 | 10 |
| Q3 2022 | 7 | 14 | 1 | 0 | 25 | 5 | 5 | 12 | 6 | 70 | 5 | 10 |
| Q4 2022 | 11 | 13 | 8 | 0 | 43 | 4 | 4 | 11 | 10 | 90 | 12 | 8 |

---

# 5. Native ELECTRE configuration retained for traceability

| Criterion | Weight | q | p | v |
|---|---:|---:|---:|---:|
| g1 | 8.22 | 3 | 12 | 15 |
| g2 | 12.12 | 2 | 5 | 10 |
| g3 | 5.63 | 5 | 25 | 25 |
| g4 | 12.12 | 2 | 5 | 10 |
| g5 | 12.12 | 3 | 8 | 60 |
| g6 | 12.12 | 2 | 3 | 15 |
| g7 | 5.63 | 10 | 20 | 20 |
| g8 | 5.63 | 3 | 10 | 30 |
| g9 | 5.63 | 2 | 5 | 10 |
| g10 | 10.82 | 20 | 40 | 60 |
| g11 | 8.23 | 5 | 15 | 30 |
| g12 | 1.73 | 15 | 30 | 70 |

Source-native preference ranking:

\[
\{g_2,g_4,g_5,g_6\}
>
g_{10}
>
\{g_1,g_{11}\}
>
\{g_3,g_7,g_8,g_9\}
>
g_{12}.
\]

Important:

\[
\boxed{
\text{these ELECTRE weights are not converted into CNPW Global Levels or hard-priority tiers.}
}
\]

They are different preference semantics.

---

# 6. Published ELECTRE baseline

| Period | Published category |
|---|---|
| Q1 2018 | C3–C4 |
| Q2 2018 | C4–C5 |
| Q3 2018 | C4–C5 |
| Q4 2018 | C4–C5 |
| Q1 2019 | C4–C5 |
| Q2 2019 | C4–C5 |
| Q3 2019 | C4–C5 |
| Q4 2019 | C4–C5 |
| Q1 2020 | C4 |
| Q2 2020 | C4 |
| Q3 2020 | C4 |
| Q4 2020 | C4 |
| Q1 2021 | C3 |
| Q2 2021 | C4–C5 |
| Q3 2021 | C4–C5 |
| Q4 2021 | C4 |
| Q1 2022 | C4 |
| Q2 2022 | C3–C4 |
| Q3 2022 | C3–C4 |
| Q4 2022 | C3 |

Distribution:

\[
C_3:2,\quad
C_3-C_4:3,\quad
C_4:6,\quad
C_4-C_5:9.
\]

No quarter is assigned to \(C_1\) or \(C_2\).

---

# 7. Frozen CNPW v1.5.2 execution

Primary configuration:

\[
K_g=7,\qquad K_l=7.
\]

Stage 1 uses population-balanced, nominal equal-count Global Levels with tie-upward preservation.

For each response:

\[
\ell_j(x)\in\{1,\ldots,7\},
\]

where 7 is best.

For the full 12-response Mode-A query:

\[
Q^{(1)}(x)=\min_{j=1,\ldots,12}\ell_j(x).
\]

The highest jointly attainable qualification is:

\[
Q^{(1)*}=\max_xQ^{(1)}(x).
\]

Stage 2 is executed only inside the Stage-1 retained set using equal-width Local Levels on the supplied numerical scale.

Formal terminal logic:

\[
\boxed{
\text{highest local joint intersection}
\rightarrow
\text{worst-first sorted LL profile}
\rightarrow
\text{raw-response dominance}
}
\]

No weighted mean, normalized utility, or B/M scalar tie-break is used.

---

# 8. Primary Stage-1 result

\[
\boxed{
Q^{(1)*}=GL3
}
\]

with:

\[
\boxed{
W^{(1)}
=
\{\text{Q2 2018},\text{Q3 2018},\text{Q3 2019}\}.
}
\]

Thus:

\[
\boxed{
20\rightarrow3
}
\]

under the full 12-response equal-priority qualification query.

Profiles:

| Quarter | ELECTRE | GL profile \(g_1\ldots g_{12}\) | Limiting response(s) |
|---|---|---|---|
| Q2 2018 | C4–C5 | 3,5,5,7,3,4,6,7,4,5,6,6 | g1, g5 |
| Q3 2018 | C4–C5 | 7,7,7,6,4,7,6,3,5,7,7,7 | g8 |
| Q3 2019 | C4–C5 | 7,7,6,6,3,7,7,5,6,6,6,3 | g5, g12 |

All three highest jointly qualified quarters belong to the most favourable ELECTRE interval actually observed in the base study:

\[
\boxed{
C_4-C_5.
}
\]

---

# 9. Full same-data comparison

| ELECTRE group | n | CNPW Q min | CNPW Q max | Mean Q |
|---|---:|---:|---:|---:|
| C3 | 2 | 1 | 1 | 1.000 |
| C3–C4 | 3 | 1 | 1 | 1.000 |
| C4 | 6 | 1 | 2 | 1.167 |
| C4–C5 | 9 | 1 | 3 | 2.222 |

The broad ordering is compatible:

- all \(C_3\) and \(C_3-C_4\) quarters have CNPW common qualification 1;
- the highest CNPW qualification occurs only within \(C_4-C_5\).

However, the nine \(C_4-C_5\) quarters are not homogeneous under conjunctive qualification:

\[
\boxed{
C_4-C_5
\Rightarrow
Q^{(1)}\in\{1,2,3\}.
}
\]

Therefore:

\[
\boxed{
\text{same ELECTRE category interval}
\not\Rightarrow
\text{same weakest-response joint qualification}.
}
\]

This is the principal incremental information produced by CNPW in this case.

---

# 10. Tie-preservation audit

This dataset is intentionally difficult for population-balanced discretization because many incident counts are repeated.

At \(K_g=7\), the numbers of candidates shifted upward relative to strict nominal equal-count splitting are:

| Criterion | Shifted candidates | Fraction |
|---|---:|---:|
| g1 | 3 | 15% |
| g2 | 1 | 5% |
| g3 | 11 | 55% |
| g4 | 12 | 60% |
| g5 | 1 | 5% |
| g6 | 9 | 45% |
| g7 | 6 | 30% |
| g8 | 6 | 30% |
| g9 | 5 | 25% |
| g10 | 1 | 5% |
| g11 | 5 | 25% |
| g12 | 1 | 5% |

This materially stress-tests the frozen rule:

\[
\boxed{
\text{identical response values must not be split across Stage-1 levels.}
}
\]

The unequal final level counts are therefore expected.

---

# 11. Global-level resolution sensitivity

| \(K_g\) | Highest common level | Highest-qualified quarters |
|---:|---:|---|
| 4 | 2 | Q2 2018, Q3 2018, Q3 2019 |
| 5 | 2 | Q2 2018, Q3 2018, Q3 2019 |
| 6 | 3 | Q3 2018, Q3 2019 |
| 7 | 3 | Q2 2018, Q3 2018, Q3 2019 |
| 8 | 4 | Q3 2018, Q3 2019 |
| 9 | 4 | Q3 2018, Q3 2019 |

Interpretation:

\[
\boxed{
\text{candidate-family stability is stronger than raw level-label stability.}
}
\]

Q3 2018 and Q3 2019 remain highest-qualified at every tested resolution.

Q2 2018 joins the highest set at \(K_g=4,5,7\).

Raw GL numbers are not compared directly across different \(K_g\).

---

# 12. Complete response-subset audit

The full non-empty subset family contains:

\[
2^{12}-1=4095
\]

response combinations.

At \(K_g=7\):

| Active responses | Number of subsets | Min Q* | Median Q* | Max Q* | Mean Q* |
|---:|---:|---:|---:|---:|---:|
| 1 | 12 | 7 | 7 | 7 | 7.000 |
| 2 | 66 | 5 | 7 | 7 | 6.682 |
| 3 | 220 | 5 | 6 | 7 | 6.141 |
| 4 | 495 | 4 | 6 | 7 | 5.651 |
| 5 | 792 | 3 | 5 | 7 | 5.138 |
| 6 | 924 | 3 | 5 | 7 | 4.663 |
| 7 | 792 | 3 | 4 | 7 | 4.239 |
| 8 | 495 | 3 | 4 | 6 | 3.857 |
| 9 | 220 | 3 | 3 | 6 | 3.523 |
| 10 | 66 | 3 | 3 | 5 | 3.258 |
| 11 | 12 | 3 | 3 | 4 | 3.083 |
| 12 | 1 | 3 | 3 | 3 | 3.000 |

This is not used to claim that “adding objectives always lowers qualification” for every nested subset.

The safe statement is:

> Across the complete subset family, higher-dimensional response combinations exhibit progressively lower attainable joint qualification in aggregate.

---

# 13. Leave-one-response-out bottleneck diagnosis

Removing each response individually gives:

| Removed | Q* | Highest-qualified quarter(s) |
|---|---:|---|
| g1 | 3 | Q2 2018, Q3 2018, Q3 2019 |
| g2 | 3 | Q2 2018, Q3 2018, Q3 2019 |
| g3 | 3 | Q2 2018, Q3 2018, Q3 2019 |
| g4 | 3 | Q2 2018, Q3 2018, Q3 2019 |
| g5 | 3 | Q2 2018, Q3 2018, Q4 2018, Q3 2019 |
| g6 | 3 | Q2 2018, Q3 2018, Q3 2019, Q2 2021 |
| g7 | 3 | Q2 2018, Q3 2018, Q3 2019 |
| **g8** | **4** | **Q3 2018** |
| g9 | 3 | Q2 2018, Q3 2018, Q3 2019 |
| g10 | 3 | Q2 2018, Q3 2018, Q3 2019 |
| g11 | 3 | Q2 2018, Q3 2018, Q3 2019 |
| g12 | 3 | Q2 2018, Q3 2018, Q3 2019 |

The unique single-response removal that raises the full-system qualification is:

\[
\boxed{
\text{remove }g_8
\Rightarrow
GL3\rightarrow GL4.
}
\]

This means:

> \(g_8\) is the clearest single qualification limiter under the CNPW equal-priority conjunctive semantics.

It does **not** mean:

> \(g_8\) is the most important ELECTRE criterion.

Indeed, \(g_8\) has only moderate voting weight in the native model.

This difference itself is decision-semantically informative.

---

# 14. Stage-2 result under v1.5.2

The Stage-1 population contains only three candidates across twelve active responses.

At:

\[
K_l=7,
\]

all three have:

\[
Q^{(2)}=LL1.
\]

Their worst-first profiles are:

- Q2 2018:
  \[
  (1,1,1,1,1,1,1,1,1,7,7,7)
  \]
- Q3 2018:
  \[
  (1,1,1,4,6,7,7,7,7,7,7,7)
  \]
- Q3 2019:
  \[
  (1,1,2,2,4,4,5,7,7,7,7,7)
  \]

Worst-first lexicographic pruning retains:

\[
\boxed{
Q3\ 2019
}
\]

and raw-response dominance does not change the singleton result.

Therefore:

\[
\boxed{
20\rightarrow3\rightarrow3\rightarrow1
}
\]

for the complete v1.5.2 execution.

The primary scientific result remains the Stage-1 reduction:

\[
\boxed{
20\rightarrow3.
}
\]

The single terminal is secondary because local discrimination is necessarily strict in a 3-candidate / 12-response set.

---

# 15. Local-level resolution sensitivity

The exact terminal was re-audited for:

\[
K_l=4,5,6,7,8,9.
\]

| \(K_l\) | Highest local joint level | W2 | Final terminal |
|---:|---:|---:|---|
| 4 | 1 | 3 | Q3 2019 |
| 5 | 1 | 3 | Q3 2019 |
| 6 | 1 | 3 | Q3 2019 |
| 7 | 1 | 3 | Q3 2019 |
| 8 | 1 | 3 | Q3 2019 |
| 9 | 1 | 3 | Q3 2019 |

Thus:

\[
\boxed{
\text{terminal identity is invariant over }K_l=4\text{–}9.
}
\]

This does not remove the small-\(N\) limitation, but it shows that the reported terminal is not an artifact of choosing \(K_l=7\).

---

# 16. Native-scenario mirror audit: removing non-clinical criteria

The source study performs a robustness scenario excluding non-clinical criteria.

Its retained clinical set is:

\[
\boxed{
\{g_1,g_2,g_3,g_4,g_5,g_6,g_8,g_9,g_{10}\}
}
\]

with:

\[
g_7,\ g_{11},\ g_{12}
\]

excluded.

The source ELECTRE analysis reports substantial assignment changes and greater assignment precision under this exclusion scenario.

CNPW was therefore rerun on exactly the same 9-response clinical subset.

Result:

\[
\boxed{
Q_{\mathrm{clinical}}^{(1)*}=GL3
}
\]

with the same highest-qualified set:

\[
\boxed{
\{\text{Q2 2018},\text{Q3 2018},\text{Q3 2019}\}.
}
\]

Therefore:

\[
\boxed{
\text{full 12-response top set}
=
\text{clinical-only 9-response top set}
}
\]

under the CNPW qualification semantics.

This is a useful cross-paradigm contrast:

- ELECTRE category assignments respond materially to removal of non-clinical criteria;
- the CNPW highest joint-qualified trio remains unchanged.

This is **not** evidence that one method is more robust.

The methods encode preferences differently.

It is evidence that:

\[
\boxed{
\text{decision-parameter / criterion-set sensitivity is method-semantic.}
}
\]

---

# 17. Stability bridge to the native ELECTRE robustness scenarios

For the three CNPW Stage-1 candidates:

| Quarter | ELECTRE \(\lambda=0.60\) | Base \(\lambda=0.65\) | \(\lambda=0.70\) | Clinical-only ELECTRE |
|---|---|---|---|---|
| Q2 2018 | C4–C5 | C4–C5 | C4 | C4 |
| Q3 2018 | C4–C5 | C4–C5 | C4–C5 | C5 |
| Q3 2019 | C4–C5 | C4–C5 | C5 | C5 |

Hence the CNPW top trio remains in favourable ELECTRE categories under the native source perturbations.

The CNPW terminal Q3 2019 is especially notable because it becomes:

\[
C_5
\]

both when:

- \(\lambda\) is raised to 0.70;
- non-clinical criteria are excluded.

This is supporting concordance only.

It must not be presented as proof that Q3 2019 is the universally best historical quarter.

---

# 18. Pareto audit — optional secondary diagnostic

Across 12 minimized responses:

\[
19/20
\]

quarters are Pareto non-dominated.

All three CNPW Stage-1 candidates are Pareto non-dominated.

Therefore Pareto efficiency is almost non-discriminating in this high-dimensional small-\(N\) case.

This reinforces:

\[
\boxed{
\text{Pareto-efficient}\neq\text{jointly qualified}.
}
\]

Pareto status is not used in the CNPW decision path.

---

# 19. What this case validates under File 217

This case provides positive evidence for:

### 19.1 Cross-domain executability
CNPW operates without structural modification on healthcare data.

### 19.2 Response-dimensional portability
The core works with:

\[
m=12,
\]

well beyond the four-response internal PLA-MEX case.

### 19.3 Tie-heavy robustness
The frozen tie-upward rule is materially exercised and remains executable.

### 19.4 Same-data cross-paradigm consistency
The CNPW top set lies entirely within the most favourable native ELECTRE interval observed at baseline.

### 19.5 Additional joint-qualification information
Nine quarters share \(C_4-C_5\), but their CNPW weakest-response qualifications span GL1–GL3.

### 19.6 Systematic compatibility interrogation
All 4,095 response subsets can be audited without redefining the method.

### 19.7 Limiting-response diagnosis
\(g_8\) is identified as the only single-response removal that raises full-system joint qualification.

### 19.8 Native-scenario transfer
The source paper's clinical-only criterion scenario can be mirrored directly in CNPW without inventing a synthetic perturbation.

---

# 20. What this case does not validate

Do **not** use this case as evidence for:

- large-\(N\) scalability;
- process-window connectivity;
- manufacturing parameter guidance;
- causal risk attribution;
- uncertainty estimation;
- superiority over ELECTRE;
- replacement of stakeholder elicitation;
- equivalence of ELECTRE weights and CNPW qualification levels;
- equivalence of ELECTRE categories and CNPW GLs;
- universal optimality of Q3 2019.

The case is deliberately classified as:

\[
\boxed{
\textbf{small-}N\textbf{/high-}m\textbf{ cross-domain validation}.
}
\]

---

# 21. File-217 acceptance checklist

| Requirement | Evidence | Status |
|---|---|---|
| Independent domain | Healthcare risk management | PASS |
| Independent published source | Alves & Pereira 2025 | PASS |
| Frozen same-data matrix | 20×12 Table-3 matrix | PASS |
| Response directions unambiguous | all minimized | PASS |
| Native method/result available | full ELECTRE configuration + assignments | PASS |
| CNPW core unchanged | v1.5.2 Mode A | PASS |
| Non-trivial CNPW result | 20→3→1 | PASS |
| Robustness / sensitivity evidence | \(K_g=4\)–9; \(K_l=4\)–9 | PASS |
| Native scenario audit | clinical-only exclusion mirrored | PASS |
| Claim boundaries explicit | Section 20 | PASS |
| Domain-invalid outputs disabled | topology / parameter migration off | PASS |
| Added decision information identifiable | within-category qualification heterogeneity | PASS |

Final File-217 verdict:

\[
\boxed{
\textbf{PASS — retain.}
}
\]

---

# 22. Recommended manuscript role

The healthcare case should be used as:

\[
\boxed{
\textbf{a compact same-data test of two distinct non-compensatory decision semantics}
}
\]

rather than as a large standalone application.

The manuscript should emphasize:

\[
\boxed{
\text{ELECTRE sorting}
\rightarrow
\text{ordered category / interval}
}
\]

versus:

\[
\boxed{
\text{CNPW qualification}
\rightarrow
\text{highest jointly qualified candidate set}.
}
\]

Primary empirical message:

\[
\boxed{
\text{the methods agree broadly on favourable periods, while CNPW exposes
heterogeneous weakest-response qualification within the same ELECTRE category interval.}
}
\]

---

# 23. Manuscript-ready Results paragraph

> **Healthcare / ELECTRE Tri-nC case.** The published study evaluated 20 hospital quarters using 12 clinical and non-clinical incident criteria and assigned them to ordered risk categories through ELECTRE Tri-nC. Applying frozen CNPW v1.5.2 to the same 20×12 performance matrix yielded a highest common Global Level of GL3 and retained Q2 2018, Q3 2018 and Q3 2019. All three periods belonged to the most favourable ELECTRE interval observed in the base study, C4–C5. However, the nine quarters sharing this ELECTRE interval exhibited CNPW common qualifications spanning GL1–GL3, demonstrating substantial weakest-response heterogeneity inside a common outranking category. The Stage-1 candidate family was stable over \(K_g=4\)–9, while Q3 2019 remained the terminal candidate over \(K_l=4\)–9. Repeating the qualification with the same clinical-only criterion set used in the source robustness analysis preserved the same three highest-qualified quarters.

---

# 24. Manuscript-ready Discussion paragraph

> ELECTRE Tri-nC and CNPW are both non-compensatory, but they encode non-compensation differently. ELECTRE evaluates whether an alternative sufficiently outranks characteristic category actions through weighted concordance, discordance, veto thresholds and a credibility level. CNPW instead applies conjunctive response-wise qualification and asks for the highest simultaneously attainable floor across all active responses. The healthcare case therefore should not be interpreted as a win–loss comparison. Its value is that two different decision semantics produced broadly compatible favourable-period identification while preserving different internal structures: ELECTRE supplied institutionally meaningful ordered risk classes, whereas CNPW exposed the weakest-response qualification and subset-compatibility structure within the same candidate matrix.

---

# 25. Final frozen interpretation

\[
\boxed{
\text{ELECTRE Tri-nC}
=
\text{expert-parameterized non-compensatory sorting}
}
\]

\[
\boxed{
\text{CNPW}
=
\text{conjunctive joint-qualification interrogation}
}
\]

and in this dataset:

\[
\boxed{
\text{broad native-method agreement}
+
\text{additional CNPW joint-qualification structure}
}
\]

with explicit recognition that:

\[
\boxed{
N=20
}
\]

is a limitation for scale claims but not a reason to discard the case.

This is the final File-217-standard validation position.
