# Packaging decisions — Supplementary Data 3 V8

1. **SD3 remains controlled-system only.** The package was rebuilt after auditing the existing SD1–SD8 division of labour. No SD4–SD8 cross-domain, cross-paradigm or Agent files were imported into SD3.

2. **SD1 and SD2 remain upstream.** Experimental anchors/validation stay in SD1; the canonical 7,056 response table stays in SD2. SD3 contains only derived analysis outputs and references candidate IDs back to SD2.

3. **Mode A formal execution was replaced by V8 Step-3 outputs.** The old monolithic Mode-A workbook is not retained as the active formal authority because the V8 package now provides explicit Global reporting, adaptive Local trace, baseline set and terminal output.

4. **Pareto and scalarization were preserved.** Their numerical questions are independent of the Mode-B/QCCA revision. Publication-clean workbooks were synchronized to V8 terminology and current Local-profile order without changing the underlying benchmark results.

5. **Mode B was synchronized to the existing Phase-2 residual-V8 record.** Historical workbook removal does not exclude the validated residual contract. Protection defines admissibility, residual responses determine Stage 1, and all active responses enter Local refinement. Only the two changed contract branches and their dependent records were updated.

6. **Mode-B QCCA uses the authoritative scopes.** Global QCCA diagnoses residual responses within the protected domain; Local QCCA uses all active responses on W_B^(1). The existing Phase-2 canonical companion supplies all 14 Global diagnoses. Mode-A and unchanged UTS Local/action records are retained.

7. **Old unrestricted relaxation is excluded.** It remains historical/audit material only and is not part of the publication-authoritative SD3 V8 package.

8. **Robustness was retained but reinterpreted.** Fixed \(K_L\) perturbations are sensitivity audits outside the baseline adaptive Local state machine. The old strengthening workbook was decomposed and only stable robustness evidence was rebuilt into a publication-clean V8 support workbook.

9. **Explainability was retained but bounded.** Exact finite-grid SHAP is unchanged numerically. Qualification-boundary control is described as a minimum normalized qualification-margin property, not a causal physical constraint. QCCA diagnosis and process explainability remain distinct layers.

10. **Software is not packaged here.** The old Step-3 replay report and 59-check log are superseded in active SD3 by the existing controlled residual-V8 authoritative record. Original historical files remain untouched outside FINAL_SD3. Executable software remains outside this package; no scientific analysis was rerun.
