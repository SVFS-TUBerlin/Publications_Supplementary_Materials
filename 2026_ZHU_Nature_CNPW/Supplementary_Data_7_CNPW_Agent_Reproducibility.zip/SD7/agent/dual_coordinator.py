from __future__ import annotations

import hashlib
from dataclasses import dataclass, replace
from itertools import combinations
from pathlib import Path

from .contracts import CanonicalTask, ExecutionMode, stable_json
from .core_adapter import CoreAdapter
from .errors import AgentError, AgentRejected
from .input_guard import InputGuard
from .provenance import build_provenance_manifest
from .qcca_pipeline import run_core_qcca
from .result_builder import build_result
from .targeted_relaxation import targeted_relaxation
from .targeted_relaxation_verifier import verify_targeted_relaxation
from .verifier import verify_public_run, verify_result


@dataclass(frozen=True)
class DualAnalysisOutcome:
    result: dict | None
    error: AgentError | None


class DualAnalysisCoordinator:
    """Public V8 run: Mode A plus every equal-count protected Mode-B block."""
    def __init__(self, project_root: str | Path):
        self._project_root, self._guard = Path(project_root), InputGuard()

    def execute(self, filename: str | Path, requested_language: str = "en") -> DualAnalysisOutcome:
        guarded = self._guard.validate(filename, ExecutionMode.MODE_A, requested_language)
        if not guarded.accepted: return DualAnalysisOutcome(None, guarded.error)
        base = guarded.task
        try:
            mode_a = self._run_branch(base)
        except AgentRejected as exc:
            return DualAnalysisOutcome(None, exc.error)
        contracts = []
        for ordinal, protected in enumerate(_protected_blocks(len(base.input_summary.active_criteria)), 1):
            task = self._mode_b_task(base, protected, ordinal)
            try:
                contracts.append(self._run_branch(task, contract_id=_contract_id(base, protected)))
            except AgentRejected as exc:
                contracts.append({"canonical_task": task, "contract_id": _contract_id(base, protected), "technical_error": exc.error, "verification": _failed_verification(), "verified_result": None})
        provisional = {"dual_result_contract_version": "8.0", "input_identity": base.input_summary.identity, "input_summary": base.input_summary, "mode_a": mode_a, "mode_b_contracts": contracts, "execution": {"expected_mode_b_contract_count": 2 ** len(base.input_summary.active_criteria) - 2, "actual_mode_b_contract_count": len(contracts), "scientific_contract_version": "CNPW_V8"}}
        complete = verify_public_run(provisional)
        provisional["complete_verification"] = complete
        provisional["overall_integrity_status"] = "completed" if mode_a["verification"].passed and complete.passed else "failed_integrity"
        # Compatibility aliases are non-preferential views of the first formal block.
        provisional["mode_b"] = contracts[0] if contracts else None
        first = contracts[0].get("verified_result") if contracts else None
        a_result = mode_a["verified_result"]
        provisional["comparison"] = {"mode_a_terminal_ids": a_result["terminal"]["terminal_candidate_ids"], "mode_b_terminal_ids": [] if first is None else first["terminal"]["terminal_candidate_ids"], "terminal_same": False, "terminal_overlap_ids": [], "mode_a_w1_count": len(a_result["stage_1"]["retained_candidate_ids"]), "mode_a_w2_count": len(a_result["stage_2"]["retained_candidate_ids"]), "mode_b_w1_count": 0 if first is None else len(first["stage_1"]["retained_candidate_ids"]), "mode_b_w2_count": 0 if first is None else len(first["stage_2"]["retained_candidate_ids"]), "mode_b_protected_count": 0 if first is None else first["mode_b_conditioning"]["protected_count"]}
        provisional["qcca"] = mode_a["global_qcca"]
        # Reporting alias only: compare the actual terminal sets, not a constant.
        comparison = provisional["comparison"]
        a_ids, b_ids = set(comparison["mode_a_terminal_ids"]), set(comparison["mode_b_terminal_ids"])
        comparison["terminal_same"] = first is not None and a_ids == b_ids
        comparison["terminal_overlap_ids"] = [identifier for identifier in comparison["mode_a_terminal_ids"] if identifier in b_ids]
        return DualAnalysisOutcome(provisional, None)

    def _run_branch(self, task: CanonicalTask, contract_id: str | None = None):
        execution = CoreAdapter().execute(task)
        result = build_result(execution)
        verification = verify_result(task, result, execution.dataset.candidate_ids, task.input_summary.identity.source_path)
        branch = {"canonical_task": task, "contract_id": contract_id or task.task_id, "verified_result": result, "verification": verification, "provenance": build_provenance_manifest(task, self._project_root)}
        if not verification.passed: return branch
        branch["global_qcca"] = run_core_qcca(execution.dataset, execution.core_result, "GLOBAL")
        if branch["global_qcca"].status != "COMPLETED":
            branch["verification"] = _branch_failure(verification, "GLOBAL_QCCA_FAILED")
            return branch
        branch["local_qcca"] = run_core_qcca(execution.dataset, execution.core_result, "LOCAL")
        if execution.core_result.stage2.local_qcca_required and branch["local_qcca"].status != "COMPLETED":
            branch["verification"] = _branch_failure(verification, "LOCAL_QCCA_FAILED")
            return branch
        actions = []
        local = branch["local_qcca"]
        if local.status == "COMPLETED":
            raw = [execution.dataset.values[i] for i in execution.core_result.stage1.retained]
            omega = None if execution.core_result.protected is None else execution.core_result.protected["omega_candidate_ids"]
            for target in local.result.target_recoveries:
                for recovery in target.recovery_sets:
                    action = targeted_relaxation(local.result, recovery, raw_values=raw, mode_b_omega_candidate_ids=omega)
                    action_verified = verify_targeted_relaxation(action, local.result, recovery)
                    actions.append({"target": target.target, "recovery": recovery, "result": action, "verified": action_verified})
                    if not action_verified:
                        branch["verification"] = _branch_failure(branch["verification"], "TARGETED_ACTION_FAILED")
        branch["targeted_actions"] = tuple(actions)
        return branch

    @staticmethod
    def _mode_b_task(task, protected, ordinal):
        names = [task.input_summary.active_criteria[i].name for i in protected]
        seed = {"input": task.input_summary.identity.source_hash_sha256, "mode": "MODE_B_PROTECTED_DOMAIN", "semantic": "equal_count_global_qualification", "protected_indices": protected}
        return replace(task, task_id=hashlib.sha256(stable_json(seed).encode()).hexdigest()[:32], requested_mode=ExecutionMode.MODE_B_PROTECTED_DOMAIN, protected_criterion=task.input_summary.active_criteria[protected[0]], residual_criteria=tuple(item for i, item in enumerate(task.input_summary.active_criteria) if i not in protected), protection_semantics="equal_count_global_qualification", protected_indices=tuple(protected))


def _protected_blocks(m): return [subset for size in range(1, m) for subset in combinations(range(m), size)]
def _contract_id(task, protected): return hashlib.sha256(stable_json({"input": task.input_summary.identity.source_hash_sha256, "semantic": "equal_count_global_qualification", "protected_indices": protected}).encode()).hexdigest()
def _failed_verification():
    from .verifier import VerificationReport
    return VerificationReport("failed_integrity", ("CORE_INVOCATION_FAILED",), (), ())

def _branch_failure(report, failure):
    from .verifier import VerificationReport
    return VerificationReport("failed_integrity", tuple((*report.failures, failure)), report.semantic_states, report.checks)
