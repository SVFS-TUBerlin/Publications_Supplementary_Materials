# CNPW V8 Integrated Analysis Report

## 1. Input and scientific contract

- Filename: CNPW_Case06_Australian_Hotels_M4_Input_v0.1.xlsx
- N: 312 · M: 4
- Responses, declared order: Wi-Fi speed (Mbps), Location rating, Value rating, Cleanliness rating
- One-click execution: Mode A plus every non-empty proper equal-count protected-response block.
- CNPW selects first; any percentages are reporting-only and never influence qualification, QCCA, recovery, or alternatives.

## 2. Mode A

### Mode A deterministic state

- Full-system Global capability: GL7 · |W¹|=18
- All-response Local state: local_qcca_required · K_L=7 · C_L=LL1
- Terminal/co-terminal candidates: Hotel_017

## 3. Mode-B protected-domain contract landscape

Protection determines admissibility; residual responses determine Stage-1 conditional capability; all active responses re-enter Stage-2 Local refinement.
Rows follow protected-block cardinality and declared response order. They are not ranked. Ω_P is the protected admissible population; W_B¹ is the residual Stage-1 retained population.

| Contract | Protected block | k_P | Ω_P size | Residual Stage-1 capability | W_B¹ size | All-response Local state / C_L | Terminal/co-terminal | QCCA/action |
|---|---|---:|---:|---:|---:|---|---|---|
| 0c09fe56a5ba | Wi-Fi speed (Mbps) | GL7 | 45 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| 8d527a8daaf0 | Location rating | GL7 | 249 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| d127054f09a2 | Value rating | GL7 | 111 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| 9fe93dda3a86 | Cleanliness rating | GL7 | 142 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| 88721ba537c5 | Wi-Fi speed (Mbps) + Location rating | GL7 | 41 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| 94cbfb4bc7ab | Wi-Fi speed (Mbps) + Value rating | GL7 | 38 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| 9bd43ebbcb1f | Wi-Fi speed (Mbps) + Cleanliness rating | GL7 | 23 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| 1f16d489304a | Location rating + Value rating | GL7 | 101 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| b1e43e145bdf | Location rating + Cleanliness rating | GL7 | 126 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| d93012fca9e2 | Value rating + Cleanliness rating | GL7 | 68 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| 59df0e753652 | Wi-Fi speed (Mbps) + Location rating + Value rating | GL7 | 36 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| ed9383bfb579 | Wi-Fi speed (Mbps) + Location rating + Cleanliness rating | GL7 | 22 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| 56f51638b683 | Wi-Fi speed (Mbps) + Value rating + Cleanliness rating | GL7 | 19 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |
| c04453549dab | Location rating + Value rating + Cleanliness rating | GL7 | 64 | GL7 | 18 | local_qcca_required / LL1 | Hotel_017 | COMPLETED |

## 4. QCCA diagnosis and QCCA-guided alternatives

Global QCCA diagnoses (X, J, G) for Mode A and (Ω_P, J_res, G) for Mode B, excluding protected responses only from the residual Global system. Local QCCA uses all active responses J on frozen W¹, only for a Core-declared Local collapse. Recovery sets and targeted alternatives preserve all equal formal routes; none is preferred.

### Mode A Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B 0c09fe56a5ba Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B 8d527a8daaf0 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B d127054f09a2 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B 9fe93dda3a86 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B 88721ba537c5 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B 94cbfb4bc7ab Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B 9bd43ebbcb1f Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B 1f16d489304a Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B b1e43e145bdf Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B d93012fca9e2 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B 59df0e753652 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B ed9383bfb579 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B 56f51638b683 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

### Mode B c04453549dab Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Location rating}; witnesses: Hotel_017, Hotel_099, Hotel_162, Hotel_283.
- Target LL2; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL3; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL3; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL4; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL4; recovery set {Value rating}; witnesses: Hotel_161.
- Target LL5; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL6; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.
- Target LL7; recovery set {Location rating}; witnesses: Hotel_017, Hotel_283.

## 5. Verification and provenance

- Complete public-run verification: PASS.
- Expected/actual Mode-B contracts: 14/14.
- Every Mode-B contract has a deterministic content-derived identity and reuses the frozen full-population Global matrix.

## 6. AI-assisted interpretation

AI-assisted interpretation: Unavailable in this execution.

## 7. Limitations

A protected response with a lower Local position remains inside its Stage-1 protected domain; this does not relax or invalidate the protection contract. No weights, scores, preferred contract, preferred recovery set, preferred alternative, SHAP, connectivity, boundary, or process interpretation is provided.