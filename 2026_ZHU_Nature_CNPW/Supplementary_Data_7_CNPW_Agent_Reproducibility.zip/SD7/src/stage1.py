import hashlib
import json

from .models import Dataset, FrozenGlobalLevels, K_G, Stage1Result


def _identity(dataset: Dataset, gl: list[list[int]]) -> str:
    payload = {"candidate_ids": dataset.candidate_ids, "criteria": [(c.name, c.direction) for c in dataset.criteria], "levels": gl}
    return hashlib.sha256(json.dumps(payload, separators=(",", ":")).encode("utf-8")).hexdigest()


def assign_stage1(dataset: Dataset) -> Stage1Result:
    """Construct the full-population frozen Global matrix exactly once."""
    count = len(dataset.candidate_ids)
    if count < 1:
        raise ValueError("Global assignment requires at least one candidate.")
    k_g_eff = min(K_G, count)
    gl = [[0] * len(dataset.criteria) for _ in dataset.candidate_ids]
    nominal_counts, final_counts, tie_adjustments = {}, {}, {}
    for criterion_index, criterion in enumerate(dataset.criteria):
        ordered = sorted(range(count), key=lambda i: dataset.values[i][criterion_index], reverse=criterion.direction == "minimize")
        nominal = [min(k_g_eff, (k_g_eff * (rank + 1) + count - 1) // count) for rank in range(count)]
        assigned = [0] * count
        tie_changed = 0
        start = 0
        while start < count:
            end = start
            value = dataset.values[ordered[start]][criterion_index]
            while end + 1 < count and dataset.values[ordered[end + 1]][criterion_index] == value:
                end += 1
            level = max(nominal[start : end + 1])
            for position in range(start, end + 1):
                assigned[ordered[position]] = level
                tie_changed += nominal[position] != level
            start = end + 1
        for candidate, level in enumerate(assigned):
            gl[candidate][criterion_index] = level
        nominal_counts[criterion.name] = [nominal.count(level) for level in range(1, k_g_eff + 1)]
        final_counts[criterion.name] = [assigned.count(level) for level in range(1, k_g_eff + 1)]
        tie_adjustments[criterion.name] = tie_changed
    frozen = FrozenGlobalLevels(_identity(dataset, gl), tuple(tuple(row) for row in gl))
    return qualify_frozen_global(dataset, frozen, list(range(count)), list(range(len(dataset.criteria))), nominal_counts, final_counts, tie_adjustments, k_g_eff)


def qualify_frozen_global(dataset: Dataset, frozen: FrozenGlobalLevels, candidate_indices: list[int], criterion_indices: list[int], nominal_counts=None, final_counts=None, tie_adjustments=None, k_g_eff=None) -> Stage1Result:
    """Qualify a domain from frozen levels only; this function never re-ranks."""
    if not candidate_indices:
        raise ValueError("Global qualification requires a non-empty candidate domain.")
    if not criterion_indices:
        raise ValueError("Global qualification requires at least one active response.")
    gl = [list(row) for row in frozen.levels]
    q_by_candidate = {i: min(gl[i][j] for j in criterion_indices) for i in candidate_indices}
    q1 = max(q_by_candidate.values())
    retained = [i for i in candidate_indices if q_by_candidate[i] == q1]
    effective = k_g_eff or min(K_G, len(dataset.candidate_ids))
    joint_counts = {level: sum(q >= level for q in q_by_candidate.values()) for level in range(effective, 0, -1)}
    return Stage1Result(gl, nominal_counts or {}, final_counts or {}, tie_adjustments or {}, joint_counts, q1, retained, frozen, list(criterion_indices), effective)
