# -*- coding: utf-8 -*-
"""
逐尘 ZhuChen · Current Data v3.2

当前实验专用六步工作流：
① 标尺校准
② 尺寸 / 面积测量（可选，不再作为 ROI 前置条件）
③ 对比度 + 底部裁剪 + 自动孔隙
④ 人工精修 + 预览 + 保存
⑤ 固定物理尺寸 ROI（P=0.43 / 0.45 / 0.47 mm；仅依赖①标尺）
⑥ 数据输出 / 持久总表

ROI 固定模板：
P=0.43 mm -> 0.86 × 0.40 mm -> 0.344 mm²
P=0.45 mm -> 0.90 × 0.40 mm -> 0.360 mm²
P=0.47 mm -> 0.94 × 0.40 mm -> 0.376 mm²

Concept & Development by Yanlong Zhu
"""

from __future__ import annotations

import math
import sys
import statistics
import csv
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    from PIL import Image, ImageDraw, ImageTk, ImageChops, ImageEnhance
except ImportError:
    raise SystemExit("缺少 Pillow，请运行：pip install pillow")

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font
except ImportError:
    Workbook = None

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}

DEFAULT_FOLDER = Path(r"D:\soft\1\2\202609")

OVERLAY_ALPHA = 0.55
UNDO_LIMIT = 30
MIN_ZOOM = 0.10
MAX_ZOOM = 12.0


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def is_image_file(path: Path):
    return path.is_file() and path.suffix.lower() in IMAGE_EXTS


class PoreToolApp(tk.Tk):
    """v2.11 staged UI: calibration -> measurement -> annotation -> ROI -> report."""

    def __init__(self):
        super().__init__()
        self.title("Manual Pore Annotator v2.11")
        self.geometry("1500x930")
        self.minsize(1120, 720)

        nav = ttk.Frame(self)
        nav.pack(side=tk.TOP, fill=tk.X, padx=8, pady=(7, 4))

        stage_defs = [
            ("calibrate", "① 标尺校准"),
            ("measure", "② 尺寸 / 面积测量"),
            ("annotate", "③ 图层标注"),
            ("roi", "④ ROI 测试"),
            ("report", "⑤ 报告整理"),
        ]
        self.stage_buttons = {}
        for key, label in stage_defs:
            b = ttk.Button(nav, text=label, command=lambda k=key: self.show_module(k))
            b.pack(side=tk.LEFT, padx=(0, 7), ipadx=12, ipady=5)
            self.stage_buttons[key] = b

        self.global_state_var = tk.StringVar(value="○ 尺寸未校准    ○ 测量未锁定")
        ttk.Label(
            nav, textvariable=self.global_state_var,
            anchor=tk.E, font=("Segoe UI", 9, "bold")
        ).pack(side=tk.RIGHT, padx=(12, 4))

        ttk.Separator(self, orient=tk.HORIZONTAL).pack(fill=tk.X)

        self.body = ttk.Frame(self)
        self.body.pack(fill=tk.BOTH, expand=True)

        # The first three stages share the same image/canvas/data model.
        self.annotator = StagedAnnotatorFrame(self.body, app=self)
        self.roi_calc = StagedROICalculatorFrame(self.body, app=self)
        self.report = StagedReportFrame(self.body, app=self)

        self.current_module = None
        self.show_module("calibrate")

    def refresh_global_state(self):
        try:
            c = self.annotator.calibration
            if c:
                cal = f"🔒 尺寸已锁定: 1 px = {c['unit_per_px']:.6g} {c['unit']}"
            else:
                cal = "○ 尺寸未校准"

            key = self.annotator._measurement_key()
            locked = bool(key and self.annotator.measurement_locked_by_image.get(key, False))
            mea = "🔒 当前图测量已锁定" if locked else "○ 当前图测量未锁定"
            self.global_state_var.set(f"{cal}    {mea}")
        except Exception:
            self.global_state_var.set("○ 尺寸未校准    ○ 测量未锁定")

    def show_module(self, which):
        if self.current_module == which:
            self.refresh_global_state()
            return

        self.annotator.pack_forget()
        self.roi_calc.pack_forget()
        self.report.pack_forget()

        if which in ("calibrate", "measure", "annotate"):
            self.annotator.pack(fill=tk.BOTH, expand=True)
            self.annotator.set_workspace(which)
            self.annotator.canvas.focus_set()
            titles = {
                "calibrate": "① 标尺校准",
                "measure": "② 尺寸 / 面积测量",
                "annotate": "③ 图层标注",
            }
            self.title(f"Manual Pore Annotator v2.11 — {titles[which]}")
        elif which == "roi":
            self.roi_calc.pack(fill=tk.BOTH, expand=True)
            self.roi_calc.refresh_stage_state()
            self.roi_calc.canvas.focus_set()
            self.title("Manual Pore Annotator v2.11 — ④ ROI 测试")
        else:
            self.report.pack(fill=tk.BOTH, expand=True)
            self.report.refresh_preview()
            self.title("Manual Pore Annotator v2.11 — ⑤ 报告整理")

        self.current_module = which
        self.refresh_global_state()


# ============================================================
# MODULE 1 — MANUAL ANNOTATION
# ============================================================

class AnnotatorFrame(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app

        self.image_path: Path | None = None
        self.image_files: list[Path] = []
        self.image_index = -1
        self.input_folder: Path | None = None
        self.output_root: Path | None = None

        self.original: Image.Image | None = None
        self.mask: Image.Image | None = None          # 真正参与孔隙率计算的填充 mask
        self.guide: Image.Image | None = None         # 普通辅助蓝线，不参与面积计算
        self.region: Image.Image | None = None        # 黄色闭合边界内部区域（用于整体孔隙率）
        self.boundary: Image.Image | None = None      # 黄色闭合边界线，仅显示
        self.tk_img = None

        self.img_w = 0
        self.img_h = 0

        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0

        self.mode = tk.StringVar(value="freehand")
        self.brush_size = tk.IntVar(value=12)
        self.line_width = tk.IntVar(value=3)
        self.overlay_visible = tk.BooleanVar(value=True)

        # v2.8 display-only contrast. 1.0 = raw display.
        # This never modifies the source file, pore mask, measurements or calibration.
        self.contrast_var = tk.DoubleVar(value=1.0)
        self.contrast_label_var = tk.StringVar(value="对比度 1.00×")

        self.stroke_last_img = None
        self.line_last_img = None
        self.freehand_points = []
        self.polygon_points = []

        # 参考线条理论尺寸测量：
        # measure_length = 水平方向投影长度 |x2-x1|
        # measure_width  = 垂直方向投影宽度 |y2-y1|
        # 只用于相对比较 / 长宽比，不是物理长度。
        self.measure_start = None
        self.measure_preview = None
        self.measurements_by_image = {}
        self.measurements_loaded_root = None

        # 标尺校准（批次级）：输入已知值 + 单位，再在标尺图上点两端。
        self.calibration_known_var = tk.StringVar(value="200")
        self.calibration_unit_var = tk.StringVar(value="µm")
        self.calibration_start = None
        self.calibration_preview = None
        self.calibration = None
        self.calibration_loaded_root = None

        # 黄色闭合边界自由圈选点
        self.boundary_points = []

        # 两种平移：
        # 1) 独立“平移”模式下左键拖动
        # 2) 任意模式下按住 Space + 左键拖动
        self.panning = False
        self.pan_last = None
        self.left_pan_active = False
        self.left_pan_last = None
        self.space_down = False

        # 每个撤销状态同时保存孔隙 mask + 辅助线 + 闭合区域 + 边界线
        self.undo_stack = []
        self.redo_stack = []
        self.dirty = False

        self._build_ui()
        self._bind_events()

    def _build_ui(self):
        bar = ttk.Frame(self)
        bar.pack(side=tk.TOP, fill=tk.X, padx=6, pady=5)

        ttk.Button(bar, text="输入图片 / 标尺图", command=self.open_image_dialog).pack(side=tk.LEFT, padx=2)
        ttk.Button(bar, text="输入文件夹", command=self.open_folder_dialog).pack(side=tk.LEFT, padx=2)
        ttk.Button(bar, text="输出文件夹", command=self.choose_output_folder).pack(side=tk.LEFT, padx=2)

        ttk.Button(bar, text="上一张", command=self.prev_image).pack(side=tk.LEFT, padx=(10, 2))
        ttk.Button(bar, text="下一张", command=self.next_image).pack(side=tk.LEFT, padx=2)

        ttk.Separator(bar, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)

        ttk.Radiobutton(
            bar, text="笔刷 [B]", variable=self.mode, value="brush",
            command=self._mode_changed
        ).pack(side=tk.LEFT, padx=2)
        ttk.Radiobutton(
            bar, text="橡皮 [E]", variable=self.mode, value="erase",
            command=self._mode_changed
        ).pack(side=tk.LEFT, padx=2)
        ttk.Radiobutton(
            bar, text="多边形 [P]", variable=self.mode, value="polygon",
            command=self._mode_changed
        ).pack(side=tk.LEFT, padx=2)
        ttk.Radiobutton(
            bar, text="自由圈选填充 [F]", variable=self.mode, value="freehand",
            command=self._mode_changed
        ).pack(side=tk.LEFT, padx=2)
        ttk.Radiobutton(
            bar, text="蓝线 [L]", variable=self.mode, value="line",
            command=self._mode_changed
        ).pack(side=tk.LEFT, padx=2)
        ttk.Radiobutton(
            bar, text="黄色闭合边界 [G]", variable=self.mode, value="boundary",
            command=self._mode_changed
        ).pack(side=tk.LEFT, padx=2)
        ttk.Radiobutton(
            bar, text="平移 [M]", variable=self.mode, value="pan",
            command=self._mode_changed
        ).pack(side=tk.LEFT, padx=2)

        ttk.Label(bar, text="笔刷(px):").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Spinbox(bar, from_=1, to=100, textvariable=self.brush_size, width=5).pack(
            side=tk.LEFT, padx=2
        )
        ttk.Label(bar, text="线宽(px):").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Spinbox(bar, from_=1, to=30, textvariable=self.line_width, width=4).pack(
            side=tk.LEFT, padx=2
        )

        ttk.Button(bar, text="撤销", command=self.undo).pack(side=tk.LEFT, padx=(8, 2))
        ttk.Button(bar, text="重做", command=self.redo).pack(side=tk.LEFT, padx=2)

        ttk.Checkbutton(
            bar, text="显示标注层 [H]", variable=self.overlay_visible, command=self.render
        ).pack(side=tk.LEFT, padx=7)

        ttk.Button(bar, text="适应窗口", command=self.fit_to_window).pack(side=tk.LEFT, padx=2)
        ttk.Button(bar, text="100%", command=self.zoom_100).pack(side=tk.LEFT, padx=2)

        ttk.Button(bar, text="保存 / 拆层 Ctrl+S", command=self.save_layers).pack(
            side=tk.RIGHT, padx=3
        )

        # 标尺校准 + 参考线条理论长 / 宽测量
        mbar = ttk.Frame(self)
        mbar.pack(side=tk.TOP, fill=tk.X, padx=6, pady=(0, 4))

        ttk.Label(mbar, text="标尺已知值:").pack(side=tk.LEFT, padx=(2, 2))
        ttk.Entry(mbar, textvariable=self.calibration_known_var, width=7).pack(side=tk.LEFT, padx=(0, 2))
        ttk.Combobox(
            mbar, textvariable=self.calibration_unit_var,
            values=("µm", "mm", "nm", "cm"), width=5, state="readonly"
        ).pack(side=tk.LEFT, padx=(0, 3))
        ttk.Button(
            mbar, text="标尺校准（点两端）", command=lambda: self.set_mode("calibrate")
        ).pack(side=tk.LEFT, padx=(0, 10))

        ttk.Label(mbar, text="参考线条：").pack(side=tk.LEFT, padx=(2, 4))
        ttk.Button(
            mbar, text="测长度（水平）", command=lambda: self.set_mode("measure_length")
        ).pack(side=tk.LEFT, padx=2)
        ttk.Button(
            mbar, text="测宽度（垂直）", command=lambda: self.set_mode("measure_width")
        ).pack(side=tk.LEFT, padx=2)
        ttk.Button(
            mbar, text="删除最后一次", command=self.delete_last_measurement
        ).pack(side=tk.LEFT, padx=(8, 2))
        ttk.Button(
            mbar, text="清空本图测量", command=self.clear_measurements_current
        ).pack(side=tk.LEFT, padx=2)

        self.measure_summary_var = tk.StringVar(
            value="长度: n=0 mean=-- | 宽度: n=0 mean=-- | L/W=-- | Calibration: --"
        )
        ttk.Label(
            mbar, textvariable=self.measure_summary_var, anchor=tk.W
        ).pack(side=tk.LEFT, padx=12)

        self.canvas = tk.Canvas(self, bg="#202020", highlightthickness=0, cursor="crosshair")
        self.canvas.pack(fill=tk.BOTH, expand=True)

        status = ttk.Frame(self)
        status.pack(side=tk.BOTTOM, fill=tk.X)

        self.status_var = tk.StringVar(value="请选择原图；标尺校准时可先打开标尺图")
        ttk.Label(status, textvariable=self.status_var, anchor=tk.W).pack(
            side=tk.LEFT, fill=tk.X, expand=True, padx=8, pady=3
        )

        self.zoom_var = tk.StringVar(value="Zoom: 100%")
        ttk.Label(status, textvariable=self.zoom_var).pack(side=tk.RIGHT, padx=8)

    def _bind_events(self):
        c = self.canvas
        c.bind("<Configure>", lambda e: self.render())

        c.bind("<ButtonPress-1>", self.on_left_press)
        c.bind("<B1-Motion>", self.on_left_drag)
        c.bind("<ButtonRelease-1>", self.on_left_release)
        c.bind("<Double-Button-1>", self.on_double_left)
        c.bind("<Motion>", self.on_mouse_motion)

        c.bind("<ButtonPress-3>", self.on_right_press)

        c.bind("<ButtonPress-2>", self.on_pan_press)
        c.bind("<B2-Motion>", self.on_pan_drag)
        c.bind("<ButtonRelease-2>", self.on_pan_release)

        c.bind("<MouseWheel>", self.on_mousewheel)
        c.bind("<Button-4>", lambda e: self.zoom_at(e.x, e.y, 1.15))
        c.bind("<Button-5>", lambda e: self.zoom_at(e.x, e.y, 1 / 1.15))

        # Key bindings only act when this frame/canvas has focus.
        c.bind("<KeyPress-b>", lambda e: self.set_mode("brush"))
        c.bind("<KeyPress-e>", lambda e: self.set_mode("erase"))
        c.bind("<KeyPress-p>", lambda e: self.set_mode("polygon"))
        c.bind("<KeyPress-f>", lambda e: self.set_mode("freehand"))
        c.bind("<KeyPress-l>", lambda e: self.set_mode("line"))
        c.bind("<KeyPress-g>", lambda e: self.set_mode("boundary"))
        c.bind("<KeyPress-m>", lambda e: self.set_mode("pan"))
        c.bind("<KeyPress-c>", lambda e: self.set_mode("calibrate"))
        c.bind("<KeyPress-x>", lambda e: self.set_mode("measure_length"))
        c.bind("<KeyPress-y>", lambda e: self.set_mode("measure_width"))
        c.bind("<KeyPress-h>", lambda e: self.toggle_overlay())
        c.bind("<Return>", lambda e: self.commit_polygon())
        c.bind("<Escape>", lambda e: self.cancel_polygon())

        # Photoshop 风格临时平移：Space + 左键拖动
        c.bind("<KeyPress-space>", self.on_space_press)
        c.bind("<KeyRelease-space>", self.on_space_release)

        # App-level shortcuts dispatch to currently visible module.
        self.app.bind_all("<Control-s>", self._ctrl_s)
        self.app.bind_all("<Control-z>", self._ctrl_z)
        self.app.bind_all("<Control-y>", self._ctrl_y)

    def _ctrl_s(self, event=None):
        if self.app.current_module == "annotate":
            self.save_layers()
            return "break"

    def _ctrl_z(self, event=None):
        if self.app.current_module == "annotate":
            self.undo()
            return "break"

    def _ctrl_y(self, event=None):
        if self.app.current_module == "annotate":
            self.redo()
            return "break"

    # ---------------- File handling ----------------

    def open_image_dialog(self):
        initial = self.input_folder or (DEFAULT_FOLDER if DEFAULT_FOLDER.exists() else Path.home())
        path = filedialog.askopenfilename(
            title="选择原图或标尺图",
            initialdir=str(initial),
            filetypes=[("Images", "*.png *.jpg *.jpeg *.tif *.tiff *.bmp *.webp"),
                       ("All files", "*.*")]
        )
        if not path:
            return
        path = Path(path)
        self.input_folder = path.parent
        self._build_image_list(self.input_folder, selected=path)
        self.load_image(path)

    def open_folder_dialog(self):
        initial = self.input_folder or (DEFAULT_FOLDER if DEFAULT_FOLDER.exists() else Path.home())
        folder = filedialog.askdirectory(title="选择原图输入文件夹", initialdir=str(initial))
        if not folder:
            return

        self.input_folder = Path(folder)
        self._build_image_list(self.input_folder)

        if not self.image_files:
            messagebox.showwarning("没有图片", "该文件夹中没有可用原图。")
            return

        self.load_image(self.image_files[0])

    def choose_output_folder(self):
        initial = self.output_root or self.input_folder or DEFAULT_FOLDER
        folder = filedialog.askdirectory(title="选择手绘标注输出文件夹", initialdir=str(initial))
        if folder:
            self.output_root = Path(folder)
            self._update_status("已设置输出文件夹")

    def _build_image_list(self, folder: Path, selected: Path | None = None):
        files = []
        for p in folder.iterdir():
            if not is_image_file(p):
                continue

            lower = p.name.lower()
            if "scale" in lower:
                continue
            if any(tag in lower for tag in ("_mask.", "_overlay.", "_annotation.", "_layer.")):
                continue

            files.append(p)

        files.sort(key=lambda x: x.name.lower())

        if selected is not None and selected not in files:
            files.append(selected)
            files.sort(key=lambda x: x.name.lower())

        self.image_files = files

        if selected is not None:
            try:
                self.image_index = files.index(selected)
            except ValueError:
                self.image_index = -1

    def _annotation_output_dirs(self):
        root = self.output_root or self.input_folder or (self.image_path.parent if self.image_path else DEFAULT_FOLDER)
        ann_dir = root / "manual_annotations"
        mask_dir = root / "manual_masks"
        overlay_dir = root / "manual_overlays"
        guide_dir = root / "manual_guides"
        measurement_dir = root / "manual_measurements"
        region_dir = root / "manual_regions"
        return ann_dir, mask_dir, overlay_dir, guide_dir, measurement_dir, region_dir

    def load_image(self, path: Path):
        # v2.8: 切换图片时绝不自动输出图层。
        # 若当前图层有未保存修改，只询问是否放弃；真正输出只能由③中的“保存”触发。
        if self.dirty and self.image_path is not None and Path(path) != Path(self.image_path):
            if not messagebox.askyesno(
                "存在未保存标注",
                "当前图片的图层修改尚未保存。\n继续切换会放弃这些未保存修改。\n\n仍然切换吗？"
            ):
                return

        try:
            im = Image.open(path).convert("RGB")
        except Exception as exc:
            messagebox.showerror("打开失败", f"{path}\n\n{exc}")
            return

        self.image_path = path
        self.original = im
        self.img_w, self.img_h = im.size

        # Sync index if possible
        if path in self.image_files:
            self.image_index = self.image_files.index(path)

        # Reload existing pore mask and guide-line layer from selected output folder
        _, mask_dir, _, guide_dir, measurement_dir, region_dir = self._annotation_output_dirs()
        mask_path = mask_dir / f"{path.stem}_mask.png"
        guide_path = guide_dir / f"{path.stem}_guide_mask.png"

        if mask_path.exists():
            try:
                m = Image.open(mask_path).convert("L")
                if m.size == im.size:
                    self.mask = m.point(lambda x: 255 if x >= 128 else 0, mode="L")
                else:
                    self.mask = Image.new("L", im.size, 0)
            except Exception:
                self.mask = Image.new("L", im.size, 0)
        else:
            self.mask = Image.new("L", im.size, 0)

        if guide_path.exists():
            try:
                g = Image.open(guide_path).convert("L")
                if g.size == im.size:
                    self.guide = g.point(lambda x: 255 if x >= 128 else 0, mode="L")
                else:
                    self.guide = Image.new("L", im.size, 0)
            except Exception:
                self.guide = Image.new("L", im.size, 0)
        else:
            self.guide = Image.new("L", im.size, 0)

        region_path = region_dir / f"{path.stem}_region_mask.png"
        boundary_path = region_dir / f"{path.stem}_boundary_mask.png"

        if region_path.exists():
            try:
                r = Image.open(region_path).convert("L")
                self.region = r.point(lambda x: 255 if x >= 128 else 0, mode="L") if r.size == im.size else Image.new("L", im.size, 0)
            except Exception:
                self.region = Image.new("L", im.size, 0)
        else:
            self.region = Image.new("L", im.size, 0)

        if boundary_path.exists():
            try:
                b = Image.open(boundary_path).convert("L")
                self.boundary = b.point(lambda x: 255 if x >= 128 else 0, mode="L") if b.size == im.size else Image.new("L", im.size, 0)
            except Exception:
                self.boundary = Image.new("L", im.size, 0)
        else:
            self.boundary = Image.new("L", im.size, 0)

        self.undo_stack.clear()
        self.redo_stack.clear()
        self.polygon_points.clear()
        self.freehand_points.clear()
        self.boundary_points.clear()
        self.measure_start = None
        self.measure_preview = None
        self.calibration_start = None
        self.calibration_preview = None
        self.dirty = False

        self._load_all_measurements_if_needed()
        self._load_calibration_if_needed()
        self._update_measurement_summary()

        self.after(30, self.fit_to_window)
        self.canvas.focus_set()
        self._update_status()

    def prev_image(self):
        if not self.image_files:
            return
        if self.image_index <= 0:
            messagebox.showinfo("提示", "已经是第一张。")
            return
        target = self.image_files[self.image_index - 1]
        self.load_image(target)

    def next_image(self):
        if not self.image_files:
            return
        if self.image_index >= len(self.image_files) - 1:
            messagebox.showinfo("提示", "已经是最后一张。")
            return
        target = self.image_files[self.image_index + 1]
        self.load_image(target)

    # ---------------- Coordinates / render ----------------

    def screen_to_image(self, sx, sy):
        if self.original is None:
            return None
        return (sx - self.pan_x) / self.zoom, (sy - self.pan_y) / self.zoom

    def image_to_screen(self, ix, iy):
        return ix * self.zoom + self.pan_x, iy * self.zoom + self.pan_y

    def inside_image(self, ix, iy):
        return 0 <= ix < self.img_w and 0 <= iy < self.img_h

    def render(self):
        self.canvas.delete("all")
        if self.original is None or self.mask is None or self.guide is None or self.region is None or self.boundary is None:
            return

        cw = max(1, self.canvas.winfo_width())
        ch = max(1, self.canvas.winfo_height())

        x0f = max(0.0, -self.pan_x / self.zoom)
        y0f = max(0.0, -self.pan_y / self.zoom)
        x1f = min(float(self.img_w), (cw - self.pan_x) / self.zoom)
        y1f = min(float(self.img_h), (ch - self.pan_y) / self.zoom)

        if x1f <= x0f or y1f <= y0f:
            self._draw_polygon_preview()
            return

        x0 = max(0, int(x0f))
        y0 = max(0, int(y0f))
        x1 = min(self.img_w, int(x1f + 1))
        y1 = min(self.img_h, int(y1f + 1))

        preview_only = bool(getattr(self, "layer_preview_only", False))
        if preview_only:
            # 一键预览：完全去掉原始底图，只看最终上层。
            base = Image.new("RGB", (x1-x0, y1-y0), (255, 255, 255))
        else:
            base = self.original.crop((x0, y0, x1, y1))

        if self.overlay_visible.get():
            m = self.mask.crop((x0, y0, x1, y1))
            red = Image.new("RGB", base.size, (255, 0, 0))
            if preview_only:
                # 预览模式显示纯红填充。
                base = Image.composite(red, base, m)
            else:
                # 编辑模式保持半透明红色，便于看清原图。
                blended = Image.blend(base, red, OVERLAY_ALPHA)
                base = Image.composite(blended, base, m)

            # 旧辅助线仍可兼容显示为蓝色；正式边界从 v2.8 起固定显示黄色。
            g = self.guide.crop((x0, y0, x1, y1))
            b = self.boundary.crop((x0, y0, x1, y1))
            if g.getbbox():
                blue = Image.new("RGB", base.size, (0, 110, 255))
                base = Image.composite(blue, base, g)
            if b.getbbox():
                yellow = Image.new("RGB", base.size, (255, 215, 0))
                base = Image.composite(yellow, base, b)

        dw = max(1, int(round((x1 - x0) * self.zoom)))
        dh = max(1, int(round((y1 - y0) * self.zoom)))
        resample = Image.Resampling.LANCZOS if self.zoom < 1 else Image.Resampling.BILINEAR
        disp = base.resize((dw, dh), resample)
        self.tk_img = ImageTk.PhotoImage(disp)

        sx = self.pan_x + x0 * self.zoom
        sy = self.pan_y + y0 * self.zoom
        self.canvas.create_image(sx, sy, image=self.tk_img, anchor=tk.NW)

        bx0, by0 = self.image_to_screen(0, 0)
        bx1, by1 = self.image_to_screen(self.img_w, self.img_h)
        self.canvas.create_rectangle(bx0, by0, bx1, by1, outline="#777777", width=1)

        self._draw_polygon_preview()
        self._draw_boundary_preview()
        self._draw_calibration_overlay()
        self._draw_measurements_overlay()
        self.zoom_var.set(f"Zoom: {self.zoom * 100:.0f}%")

    def fit_to_window(self):
        if self.original is None:
            return
        self.update_idletasks()
        cw = max(50, self.canvas.winfo_width())
        ch = max(50, self.canvas.winfo_height())
        z = min((cw - 30) / self.img_w, (ch - 30) / self.img_h)
        self.zoom = clamp(z, MIN_ZOOM, MAX_ZOOM)
        self.pan_x = (cw - self.img_w * self.zoom) / 2
        self.pan_y = (ch - self.img_h * self.zoom) / 2
        self.render()

    def zoom_100(self):
        if self.original is None:
            return
        self.update_idletasks()
        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        self.zoom = 1.0
        self.pan_x = (cw - self.img_w) / 2
        self.pan_y = (ch - self.img_h) / 2
        self.render()

    def on_mousewheel(self, event):
        self.zoom_at(event.x, event.y, 1.15 if event.delta > 0 else 1 / 1.15)

    def zoom_at(self, sx, sy, factor):
        if self.original is None:
            return
        ix, iy = self.screen_to_image(sx, sy)
        new_zoom = clamp(self.zoom * factor, MIN_ZOOM, MAX_ZOOM)
        self.zoom = new_zoom
        self.pan_x = sx - ix * self.zoom
        self.pan_y = sy - iy * self.zoom
        self.render()

    # ---------------- Pan ----------------

    def on_space_press(self, event=None):
        self.space_down = True
        self.canvas.configure(cursor="fleur")

    def on_space_release(self, event=None):
        self.space_down = False
        if not self.left_pan_active:
            self._mode_changed()

    def _start_left_pan(self, event):
        self.left_pan_active = True
        self.left_pan_last = (event.x, event.y)
        self.canvas.configure(cursor="fleur")

    def _drag_left_pan(self, event):
        if not self.left_pan_active or self.left_pan_last is None:
            return
        dx = event.x - self.left_pan_last[0]
        dy = event.y - self.left_pan_last[1]
        self.pan_x += dx
        self.pan_y += dy
        self.left_pan_last = (event.x, event.y)
        self.render()

    def _stop_left_pan(self):
        self.left_pan_active = False
        self.left_pan_last = None
        self._mode_changed()

    # 中键平移仍保留，兼容有中键的鼠标
    def on_pan_press(self, event):
        self.panning = True
        self.pan_last = (event.x, event.y)
        self.canvas.configure(cursor="fleur")

    def on_pan_drag(self, event):
        if not self.panning or self.pan_last is None:
            return
        dx = event.x - self.pan_last[0]
        dy = event.y - self.pan_last[1]
        self.pan_x += dx
        self.pan_y += dy
        self.pan_last = (event.x, event.y)
        self.render()

    def on_pan_release(self, event):
        self.panning = False
        self.pan_last = None
        self._mode_changed()

    # ---------------- Undo / redo ----------------

    def push_undo(self):
        if any(x is None for x in (self.mask, self.guide, self.region, self.boundary)):
            return
        self.undo_stack.append((
            self.mask.copy(), self.guide.copy(), self.region.copy(), self.boundary.copy()
        ))
        if len(self.undo_stack) > UNDO_LIMIT:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def undo(self):
        if any(x is None for x in (self.mask, self.guide, self.region, self.boundary)) or not self.undo_stack:
            return
        self.redo_stack.append((
            self.mask.copy(), self.guide.copy(), self.region.copy(), self.boundary.copy()
        ))
        self.mask, self.guide, self.region, self.boundary = self.undo_stack.pop()
        self.dirty = True
        self.polygon_points.clear()
        self.boundary_points.clear()
        self.render()
        self._update_status("已撤销")

    def redo(self):
        if any(x is None for x in (self.mask, self.guide, self.region, self.boundary)) or not self.redo_stack:
            return
        self.undo_stack.append((
            self.mask.copy(), self.guide.copy(), self.region.copy(), self.boundary.copy()
        ))
        self.mask, self.guide, self.region, self.boundary = self.redo_stack.pop()
        self.dirty = True
        self.render()
        self._update_status("已重做")

    # ---------------- Drawing ----------------

    def set_mode(self, mode):
        self.mode.set(mode)
        self.cancel_polygon()
        self.boundary_points.clear()
        self.measure_start = None
        self.measure_preview = None
        self.calibration_start = None
        self.calibration_preview = None
        self._mode_changed()
        self.render()

    def _mode_changed(self):
        cursors = {
            "brush": "pencil",
            "erase": "dotbox",
            "polygon": "crosshair",
            "freehand": "crosshair",
            "line": "pencil",
            "boundary": "crosshair",
            "pan": "fleur",
            "calibrate": "crosshair",
            "measure_length": "crosshair",
            "measure_width": "crosshair",
        }
        self.canvas.configure(cursor=cursors.get(self.mode.get(), "crosshair"))
        self.canvas.focus_set()
        self._update_status()

    def toggle_overlay(self):
        self.overlay_visible.set(not self.overlay_visible.get())
        self.render()

    def _draw_brush_segment(self, p0, p1, erase=False):
        if self.mask is None:
            return
        draw = ImageDraw.Draw(self.mask)
        size = max(1, int(self.brush_size.get()))
        color = 0 if erase else 255
        x0, y0 = p0
        x1, y1 = p1
        draw.line([(x0, y0), (x1, y1)], fill=color, width=size)
        r = size / 2
        for x, y in ((x0, y0), (x1, y1)):
            draw.ellipse([x-r, y-r, x+r, y+r], fill=color)
        self.dirty = True

    def _draw_guide_segment(self, p0, p1, erase=False):
        """画辅助蓝线。注意：只写入 guide，不写入 mask，因此不参与孔隙率。"""
        if self.guide is None:
            return
        draw = ImageDraw.Draw(self.guide)
        size = max(1, int(self.line_width.get()))
        color = 0 if erase else 255
        x0, y0 = p0
        x1, y1 = p1
        draw.line([(x0, y0), (x1, y1)], fill=color, width=size)
        self.dirty = True

    def on_left_press(self, event):
        if self.original is None:
            return

        self.canvas.focus_set()
        mode = self.mode.get()

        # 独立平移模式，或者任意模式下按住 Space：
        # 左键不画东西，只移动整张图
        if mode == "pan" or self.space_down:
            self._start_left_pan(event)
            return

        p = self.screen_to_image(event.x, event.y)
        if p is None or not self.inside_image(*p):
            return
        ix, iy = p

        if mode == "calibrate":
            self._calibration_click(ix, iy)
            return

        if mode in ("measure_length", "measure_width"):
            self._measurement_click(ix, iy)
            return

        if mode == "boundary":
            self.push_undo()
            self.boundary_points = [(ix, iy)]
            return

        if mode in ("brush", "erase"):
            self.push_undo()
            self.stroke_last_img = (ix, iy)
            self._draw_brush_segment(
                self.stroke_last_img, self.stroke_last_img, erase=(mode == "erase")
            )
            self.render()

        elif mode == "line":
            self.push_undo()
            self.line_last_img = (ix, iy)
            self._draw_guide_segment(self.line_last_img, self.line_last_img)
            self.render()

        elif mode == "polygon":
            self.polygon_points.append((ix, iy))
            self.render()

        elif mode == "freehand":
            self.push_undo()
            self.freehand_points = [(ix, iy)]

    def on_left_drag(self, event):
        if self.original is None:
            return

        if self.left_pan_active:
            self._drag_left_pan(event)
            return

        p = self.screen_to_image(event.x, event.y)
        if p is None:
            return
        ix = clamp(p[0], 0, self.img_w - 1)
        iy = clamp(p[1], 0, self.img_h - 1)
        mode = self.mode.get()

        if mode in ("brush", "erase") and self.stroke_last_img is not None:
            newp = (ix, iy)
            self._draw_brush_segment(
                self.stroke_last_img, newp, erase=(mode == "erase")
            )
            self.stroke_last_img = newp
            self.render()

        elif mode == "line" and self.line_last_img is not None:
            newp = (ix, iy)
            self._draw_guide_segment(self.line_last_img, newp)
            self.line_last_img = newp
            self.render()

        elif mode == "freehand" and self.freehand_points:
            last = self.freehand_points[-1]
            if abs(ix - last[0]) + abs(iy - last[1]) >= 1.0:
                self.freehand_points.append((ix, iy))
                self.render()

        elif mode == "boundary" and self.boundary_points:
            last = self.boundary_points[-1]
            if abs(ix - last[0]) + abs(iy - last[1]) >= 1.0:
                self.boundary_points.append((ix, iy))
                self.render()

    def on_left_release(self, event):
        if self.left_pan_active:
            self._stop_left_pan()
            return

        mode = self.mode.get()

        if mode in ("brush", "erase"):
            self.stroke_last_img = None
            self.render()
            self._update_status("已修改，记得保存")

        elif mode == "line":
            self.line_last_img = None
            self.render()
            self._update_status("辅助蓝线已画出（不参与孔隙面积计算）")

        elif mode == "freehand" and self.freehand_points:
            if len(self.freehand_points) >= 3:
                ImageDraw.Draw(self.mask).polygon(self.freehand_points, fill=255)
                self.dirty = True
            else:
                if self.undo_stack:
                    self.undo_stack.pop()

            self.freehand_points = []
            self.render()
            self._update_status("自由圈选已填充")

        elif mode == "boundary" and self.boundary_points:
            if len(self.boundary_points) >= 3:
                # 新边界替换旧边界；region 只用于整体孔隙率，boundary 只负责蓝色显示。
                self.region = Image.new("L", (self.img_w, self.img_h), 0)
                self.boundary = Image.new("L", (self.img_w, self.img_h), 0)
                ImageDraw.Draw(self.region).polygon(self.boundary_points, fill=255)
                bdraw = ImageDraw.Draw(self.boundary)
                pts = list(self.boundary_points) + [self.boundary_points[0]]
                bdraw.line(pts, fill=255, width=max(1, int(self.line_width.get())))
                self.dirty = True
                self._update_status("黄色闭合边界已建立；该区域将用于整体孔隙率")
            else:
                if self.undo_stack:
                    self.undo_stack.pop()
            self.boundary_points = []
            self.render()

    def on_double_left(self, event):
        if self.mode.get() == "polygon":
            self.commit_polygon()

    def on_right_press(self, event):
        if self.mode.get() == "polygon":
            self.cancel_polygon()
            return
        if self.mode.get() == "boundary":
            self.boundary_points.clear()
            self.render()
            self._update_status("已取消当前黄色闭合边界")
            return
        if self.mode.get() == "calibrate":
            self.calibration_start = None
            self.calibration_preview = None
            self.render()
            self._update_status("已取消当前标尺校准")
            return
        if self.mode.get() in ("measure_length", "measure_width"):
            self.measure_start = None
            self.measure_preview = None
            self.render()
            self._update_status("已取消当前测量")
            return
        if self.original is None:
            return
        p = self.screen_to_image(event.x, event.y)
        if p is None or not self.inside_image(*p):
            return
        self.push_undo()
        if self.mode.get() == "line":
            self._draw_guide_segment(p, p, erase=True)
        else:
            self._draw_brush_segment(p, p, erase=True)
        self.render()

    # ---------------- Scale calibration ----------------

    def _project_root(self):
        return self.output_root or self.input_folder or (self.image_path.parent if self.image_path else DEFAULT_FOLDER)

    def _calibration_csv_path(self):
        _, _, _, _, measurement_dir, _ = self._annotation_output_dirs()
        measurement_dir.mkdir(parents=True, exist_ok=True)
        return measurement_dir / "scale_calibration.csv"

    def _load_calibration_if_needed(self):
        try:
            path = self._calibration_csv_path()
        except Exception:
            return
        root = str(path.parent.resolve())
        if self.calibration_loaded_root == root:
            return
        self.calibration_loaded_root = root
        self.calibration = None
        if not path.exists():
            return
        try:
            with path.open("r", newline="", encoding="utf-8-sig") as f:
                rows = list(csv.DictReader(f))
            if rows:
                r = rows[-1]
                self.calibration = {
                    "source_image": r.get("source_image", ""),
                    "known_value": float(r["known_value"]),
                    "unit": r["unit"],
                    "pixel_distance": float(r["pixel_distance"]),
                    "unit_per_px": float(r["unit_per_px"]),
                    "x1": float(r.get("x1", 0) or 0),
                    "y1": float(r.get("y1", 0) or 0),
                    "x2": float(r.get("x2", 0) or 0),
                    "y2": float(r.get("y2", 0) or 0),
                }
                self.calibration_known_var.set(f"{self.calibration['known_value']:g}")
                self.calibration_unit_var.set(self.calibration["unit"])
        except Exception:
            self.calibration = None

    def _save_calibration(self):
        if not self.calibration:
            return
        path = self._calibration_csv_path()
        with path.open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow([
                "source_image", "known_value", "unit", "pixel_distance",
                "unit_per_px", "x1", "y1", "x2", "y2"
            ])
            c = self.calibration
            writer.writerow([
                c.get("source_image", ""), c["known_value"], c["unit"],
                c["pixel_distance"], c["unit_per_px"],
                c["x1"], c["y1"], c["x2"], c["y2"]
            ])

    def _calibration_click(self, ix, iy):
        if self.calibration_start is None:
            try:
                known = float(self.calibration_known_var.get())
            except Exception:
                messagebox.showerror("输入错误", "标尺已知值必须是数字。")
                return
            if known <= 0:
                messagebox.showerror("输入错误", "标尺已知值必须大于 0。")
                return
            self.calibration_start = (float(ix), float(iy))
            self.calibration_preview = self.calibration_start
            self._update_status("标尺校准：已点第一个端点，请点击第二个端点")
            self.render()
            return

        x1, y1 = self.calibration_start
        x2, y2 = float(ix), float(iy)
        pixel_distance = math.hypot(x2 - x1, y2 - y1)
        if pixel_distance < 1.0:
            self.calibration_start = None
            self.calibration_preview = None
            self._update_status("标尺线过短，未保存校准")
            self.render()
            return

        known = float(self.calibration_known_var.get())
        unit = self.calibration_unit_var.get() or "µm"
        self.calibration = {
            "source_image": self.image_path.name if self.image_path else "",
            "known_value": known,
            "unit": unit,
            "pixel_distance": pixel_distance,
            "unit_per_px": known / pixel_distance,
            "x1": x1, "y1": y1, "x2": x2, "y2": y2,
        }
        self.calibration_start = None
        self.calibration_preview = None
        self._save_calibration()
        self._update_measurement_summary()
        self._save_measurements_csv()
        self.render()
        self._update_status(
            f"标尺校准完成：{known:g} {unit} = {pixel_distance:.2f} px；"
            f"1 px = {self.calibration['unit_per_px']:.6g} {unit}"
        )

    def _draw_calibration_overlay(self):
        if self.original is None:
            return

        # 已保存校准只在校准来源图上显示。
        c = self.calibration
        if c and self.image_path and c.get("source_image") == self.image_path.name:
            sx1, sy1 = self.image_to_screen(c["x1"], c["y1"])
            sx2, sy2 = self.image_to_screen(c["x2"], c["y2"])
            self.canvas.create_line(sx1, sy1, sx2, sy2, fill="#00e5ff", width=3)
            self.canvas.create_oval(sx1-3, sy1-3, sx1+3, sy1+3, fill="#00e5ff", outline="")
            self.canvas.create_oval(sx2-3, sy2-3, sx2+3, sy2+3, fill="#00e5ff", outline="")
            self.canvas.create_text(
                (sx1+sx2)/2, (sy1+sy2)/2 - 8,
                text=f"CAL {c['known_value']:g} {c['unit']} = {c['pixel_distance']:.1f}px",
                fill="#00e5ff", anchor=tk.S, font=("Segoe UI", 9, "bold")
            )

        if self.mode.get() == "calibrate" and self.calibration_start and self.calibration_preview:
            x1, y1 = self.calibration_start
            x2, y2 = self.calibration_preview
            sx1, sy1 = self.image_to_screen(x1, y1)
            sx2, sy2 = self.image_to_screen(x2, y2)
            d = math.hypot(x2-x1, y2-y1)
            self.canvas.create_line(sx1, sy1, sx2, sy2, fill="#00e5ff", width=2, dash=(6,3))
            self.canvas.create_text(
                (sx1+sx2)/2, (sy1+sy2)/2 - 8,
                text=f"{d:.1f}px", fill="#00e5ff", anchor=tk.S,
                font=("Segoe UI", 9, "bold")
            )

    def _draw_boundary_preview(self):
        if not self.boundary_points:
            return
        pts = []
        for ix, iy in self.boundary_points:
            sx, sy = self.image_to_screen(ix, iy)
            pts.extend([sx, sy])
        if len(pts) >= 4:
            self.canvas.create_line(*pts, fill="#008cff", width=2)

    # ---------------- Reference strand measurement ----------------

    def _measurement_key(self):
        return self.image_path.name if self.image_path else None

    def _measurement_records(self):
        key = self._measurement_key()
        if not key:
            return []
        return self.measurements_by_image.setdefault(key, [])

    def _measurement_click(self, ix, iy):
        """两点测量。长度自动锁水平，宽度自动锁垂直。"""
        mode = self.mode.get()
        if mode not in ("measure_length", "measure_width"):
            return

        if self.measure_start is None:
            self.measure_start = (float(ix), float(iy))
            self.measure_preview = self.measure_start
            label = "长度" if mode == "measure_length" else "宽度"
            self._update_status(f"{label}测量：已选第一个点，请点击第二个点")
            self.render()
            return

        x1, y1 = self.measure_start
        x2, y2 = float(ix), float(iy)

        if mode == "measure_length":
            # 理论长度 = 水平方向投影，不受第二点上下偏差影响
            start = (x1, y1)
            end = (x2, y1)
            value = abs(x2 - x1)
            kind = "length"
        else:
            # 理论宽度 = 垂直方向投影，不受第二点左右偏差影响
            start = (x1, y1)
            end = (x1, y2)
            value = abs(y2 - y1)
            kind = "width"

        if value < 1.0:
            self.measure_start = None
            self.measure_preview = None
            self._update_status("测量过短，未记录")
            self.render()
            return

        recs = self._measurement_records()
        same_kind_count = sum(1 for r in recs if r["kind"] == kind)

        recs.append({
            "kind": kind,
            "id": same_kind_count + 1,
            "x1": float(start[0]),
            "y1": float(start[1]),
            "x2": float(end[0]),
            "y2": float(end[1]),
            "value_px": float(value),
        })

        self.measure_start = None
        self.measure_preview = None
        self._update_measurement_summary()
        self._save_measurements_csv()
        self.render()

        label = "长度" if kind == "length" else "宽度"
        self._update_status(f"已记录{label}: {value:.1f} px；可继续点击下一组两端点")

    def on_mouse_motion(self, event):
        mode = self.mode.get()
        active = (
            (mode in ("measure_length", "measure_width") and self.measure_start is not None)
            or (mode == "calibrate" and self.calibration_start is not None)
        )
        if not active:
            return

        p = self.screen_to_image(event.x, event.y)
        if p is None:
            return
        ix = clamp(p[0], 0, self.img_w - 1)
        iy = clamp(p[1], 0, self.img_h - 1)

        if mode == "calibrate":
            self.calibration_preview = (ix, iy)
        else:
            self.measure_preview = (ix, iy)
        self.render()

    def _draw_measurements_overlay(self):
        """仅屏幕显示理论测量线；不进入孔隙 mask、蓝线层或面积计算。"""
        if self.original is None:
            return

        key = self._measurement_key()
        recs = self.measurements_by_image.get(key, []) if key else []

        # 已完成测量：长度=黄色；宽度=紫色
        for r in recs:
            sx1, sy1 = self.image_to_screen(r["x1"], r["y1"])
            sx2, sy2 = self.image_to_screen(r["x2"], r["y2"])

            color = "#ffd400" if r["kind"] == "length" else "#ff66ff"
            prefix = "L" if r["kind"] == "length" else "W"

            self.canvas.create_line(
                sx1, sy1, sx2, sy2,
                fill=color, width=3
            )
            self.canvas.create_oval(
                sx1-3, sy1-3, sx1+3, sy1+3,
                fill=color, outline=""
            )
            self.canvas.create_oval(
                sx2-3, sy2-3, sx2+3, sy2+3,
                fill=color, outline=""
            )
            if self.calibration:
                cv = r["value_px"] * self.calibration["unit_per_px"]
                label_text = f"{prefix}{r['id']}={r['value_px']:.1f}px / {cv:.3f}{self.calibration['unit']}"
            else:
                label_text = f"{prefix}{r['id']}={r['value_px']:.1f}px"
            self.canvas.create_text(
                (sx1 + sx2) / 2,
                (sy1 + sy2) / 2 - 8,
                text=label_text,
                fill=color,
                anchor=tk.S,
                font=("Segoe UI", 9, "bold")
            )

        # 当前未完成测量的预览线
        if (
            self.measure_start is not None and
            self.measure_preview is not None and
            self.mode.get() in ("measure_length", "measure_width")
        ):
            x1, y1 = self.measure_start
            x2, y2 = self.measure_preview

            if self.mode.get() == "measure_length":
                y2 = y1
                value = abs(x2 - x1)
                color = "#ffd400"
                label = f"L={value:.1f}px"
            else:
                x2 = x1
                value = abs(y2 - y1)
                color = "#ff66ff"
                label = f"W={value:.1f}px"

            sx1, sy1 = self.image_to_screen(x1, y1)
            sx2, sy2 = self.image_to_screen(x2, y2)

            self.canvas.create_line(
                sx1, sy1, sx2, sy2,
                fill=color, width=2, dash=(6, 3)
            )
            self.canvas.create_text(
                (sx1 + sx2) / 2,
                (sy1 + sy2) / 2 - 8,
                text=label,
                fill=color,
                anchor=tk.S,
                font=("Segoe UI", 9, "bold")
            )

    def _calibrated_value(self, px_value):
        if not self.calibration:
            return None
        return float(px_value) * float(self.calibration["unit_per_px"])

    def _update_measurement_summary(self):
        recs = self._measurement_records() if self.image_path else []

        lengths = [r["value_px"] for r in recs if r["kind"] == "length"]
        widths = [r["value_px"] for r in recs if r["kind"] == "width"]

        lmean = statistics.mean(lengths) if lengths else None
        wmean = statistics.mean(widths) if widths else None
        ratio = (lmean / wmean) if (lmean is not None and wmean not in (None, 0)) else None

        ltxt = f"{lmean:.1f}px" if lmean is not None else "--"
        wtxt = f"{wmean:.1f}px" if wmean is not None else "--"
        rtxt = f"{ratio:.3f}" if ratio is not None else "--"

        if self.calibration:
            unit = self.calibration["unit"]
            ctext = f"1px={self.calibration['unit_per_px']:.5g}{unit}"
            if lmean is not None:
                ltxt += f" / {self._calibrated_value(lmean):.3f}{unit}"
            if wmean is not None:
                wtxt += f" / {self._calibrated_value(wmean):.3f}{unit}"
        else:
            ctext = "--"

        self.measure_summary_var.set(
            f"长度: n={len(lengths)} mean={ltxt} | "
            f"宽度: n={len(widths)} mean={wtxt} | "
            f"L/W={rtxt} | Calibration: {ctext}"
        )

    def delete_last_measurement(self):
        if not self.image_path:
            return
        recs = self._measurement_records()
        if not recs:
            return
        recs.pop()

        li = 0
        wi = 0
        for r in recs:
            if r["kind"] == "length":
                li += 1
                r["id"] = li
            else:
                wi += 1
                r["id"] = wi

        self._update_measurement_summary()
        self._save_measurements_csv()
        self.render()
        self._update_status("已删除最后一次测量")

    def clear_measurements_current(self):
        if not self.image_path:
            return
        recs = self._measurement_records()
        if not recs:
            return
        if messagebox.askyesno("确认", "清空当前图片的全部长度/宽度测量？"):
            self.measurements_by_image[self._measurement_key()] = []
            self.measure_start = None
            self.measure_preview = None
            self._update_measurement_summary()
            self._save_measurements_csv()
            self.render()

    def _measurement_csv_paths(self):
        _, _, _, _, measurement_dir, _ = self._annotation_output_dirs()
        measurement_dir.mkdir(parents=True, exist_ok=True)
        return (
            measurement_dir / "reference_measurements.csv",
            measurement_dir / "reference_measurements_summary.csv",
        )

    def _load_all_measurements_if_needed(self):
        """一次性加载当前项目的全部测量，避免跨图保存时覆盖其他图片记录。"""
        try:
            detail_path, _ = self._measurement_csv_paths()
        except Exception:
            return
        root = str(detail_path.parent.resolve())
        if self.measurements_loaded_root == root:
            key = self._measurement_key()
            if key and key not in self.measurements_by_image:
                self.measurements_by_image[key] = []
            return

        self.measurements_loaded_root = root
        self.measurements_by_image = {}
        if detail_path.exists():
            try:
                with detail_path.open("r", newline="", encoding="utf-8-sig") as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        image_name = row.get("image_name", "")
                        if not image_name:
                            continue
                        try:
                            rec = {
                                "kind": row["type"],
                                "id": int(row["id"]),
                                "x1": float(row["x1"]),
                                "y1": float(row["y1"]),
                                "x2": float(row["x2"]),
                                "y2": float(row["y2"]),
                                "value_px": float(row["value_px"]),
                            }
                        except Exception:
                            continue
                        self.measurements_by_image.setdefault(image_name, []).append(rec)
            except Exception:
                self.measurements_by_image = {}

        key = self._measurement_key()
        if key and key not in self.measurements_by_image:
            self.measurements_by_image[key] = []

    def _save_measurements_csv(self):
        if not self.image_path:
            return

        self._load_all_measurements_if_needed()
        detail_path, summary_path = self._measurement_csv_paths()
        unit = self.calibration["unit"] if self.calibration else ""
        unit_per_px = self.calibration["unit_per_px"] if self.calibration else None

        with detail_path.open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow([
                "image_name", "type", "id",
                "x1", "y1", "x2", "y2", "value_px",
                "calibrated_value", "unit", "unit_per_px"
            ])
            for image_name in sorted(self.measurements_by_image):
                for r in self.measurements_by_image[image_name]:
                    calibrated = r["value_px"] * unit_per_px if unit_per_px is not None else None
                    writer.writerow([
                        image_name, r["kind"], r["id"],
                        f"{r['x1']:.3f}", f"{r['y1']:.3f}",
                        f"{r['x2']:.3f}", f"{r['y2']:.3f}",
                        f"{r['value_px']:.3f}",
                        "" if calibrated is None else f"{calibrated:.6f}",
                        unit,
                        "" if unit_per_px is None else f"{unit_per_px:.9g}",
                    ])

        with summary_path.open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow([
                "image_name",
                "n_length", "mean_length_px", "sd_length_px",
                "n_width", "mean_width_px", "sd_width_px",
                "ratio_from_means",
                "mean_length_calibrated", "sd_length_calibrated",
                "mean_width_calibrated", "sd_width_calibrated",
                "unit", "unit_per_px"
            ])

            for image_name in sorted(self.measurements_by_image):
                recs = self.measurements_by_image[image_name]
                lengths = [r["value_px"] for r in recs if r["kind"] == "length"]
                widths = [r["value_px"] for r in recs if r["kind"] == "width"]

                lm = statistics.mean(lengths) if lengths else None
                wm = statistics.mean(widths) if widths else None
                lsd = statistics.stdev(lengths) if len(lengths) >= 2 else None
                wsd = statistics.stdev(widths) if len(widths) >= 2 else None
                ratio = (lm / wm) if (lm is not None and wm not in (None, 0)) else None

                def cv(v):
                    return None if v is None or unit_per_px is None else v * unit_per_px

                writer.writerow([
                    image_name,
                    len(lengths), "" if lm is None else f"{lm:.3f}", "" if lsd is None else f"{lsd:.3f}",
                    len(widths), "" if wm is None else f"{wm:.3f}", "" if wsd is None else f"{wsd:.3f}",
                    "" if ratio is None else f"{ratio:.6f}",
                    "" if cv(lm) is None else f"{cv(lm):.6f}",
                    "" if cv(lsd) is None else f"{cv(lsd):.6f}",
                    "" if cv(wm) is None else f"{cv(wm):.6f}",
                    "" if cv(wsd) is None else f"{cv(wsd):.6f}",
                    unit,
                    "" if unit_per_px is None else f"{unit_per_px:.9g}",
                ])

    def _draw_polygon_preview(self):
        if not self.polygon_points:
            return
        pts = []
        for ix, iy in self.polygon_points:
            sx, sy = self.image_to_screen(ix, iy)
            pts.extend([sx, sy])

        if len(pts) >= 4:
            self.canvas.create_line(*pts, fill="#00ffff", width=2)

        for ix, iy in self.polygon_points:
            sx, sy = self.image_to_screen(ix, iy)
            self.canvas.create_oval(sx-3, sy-3, sx+3, sy+3, fill="#00ffff", outline="")

    def commit_polygon(self):
        if self.mode.get() != "polygon":
            return
        if self.mask is None or len(self.polygon_points) < 3:
            self.polygon_points.clear()
            self.render()
            return

        self.push_undo()
        ImageDraw.Draw(self.mask).polygon(self.polygon_points, fill=255)
        self.polygon_points.clear()
        self.dirty = True
        self.render()
        self._update_status("多边形孔隙已填充")

    def cancel_polygon(self):
        if self.polygon_points:
            self.polygon_points.clear()
            self.render()
            self._update_status("已取消当前多边形")

    # ---------------- Save ----------------

    def _binary_mask(self):
        return self.mask.point(lambda x: 255 if x >= 128 else 0, mode="L")

    def save_layers(self, silent=False):
        if self.image_path is None or self.original is None or self.mask is None:
            if not silent:
                messagebox.showwarning("没有图片", "请先打开一张图片。")
            return

        ann_dir, mask_dir, overlay_dir, guide_dir, measurement_dir, region_dir = self._annotation_output_dirs()
        for d in (ann_dir, mask_dir, overlay_dir, guide_dir, measurement_dir, region_dir):
            d.mkdir(parents=True, exist_ok=True)

        stem = self.image_path.stem
        binary = self._binary_mask()
        guide_binary = self.guide.point(lambda x: 255 if x >= 128 else 0, mode="L")
        region_binary = self.region.point(lambda x: 255 if x >= 128 else 0, mode="L")
        boundary_binary = self.boundary.point(lambda x: 255 if x >= 128 else 0, mode="L")

        # 0) 黄色闭合边界：region 用于整体孔隙率；boundary 只负责显示
        region_path = region_dir / f"{stem}_region_mask.png"
        boundary_path = region_dir / f"{stem}_boundary_mask.png"
        region_binary.save(region_path, format="PNG")
        boundary_binary.save(boundary_path, format="PNG")

        # 1) 真正参与 ROI 孔隙率计算的 mask：不包含辅助线
        mask_path = mask_dir / f"{stem}_mask.png"
        binary.save(mask_path, format="PNG")

        # 2) 白底 + 红色孔隙 + 黄色边界辅助线
        white = Image.new("RGB", self.original.size, (255, 255, 255))
        red = Image.new("RGB", self.original.size, (255, 0, 0))
        blue = Image.new("RGB", self.original.size, (0, 0, 255))

        annotation = Image.composite(red, white, binary)
        all_blue = ImageChops.lighter(guide_binary, boundary_binary)
        annotation = Image.composite(blue, annotation, all_blue)
        ann_path = ann_dir / f"{stem}_annotation.png"
        annotation.save(ann_path, format="PNG")

        # 3) 辅助线单独保存：白底 + 蓝线
        guide_rgb = Image.composite(blue, white, all_blue)
        guide_path = guide_dir / f"{stem}_guide.png"
        guide_rgb.save(guide_path, format="PNG")

        # 同时保存一个二值 guide mask，便于重新打开继续编辑
        guide_mask_path = guide_dir / f"{stem}_guide_mask.png"
        guide_binary.save(guide_mask_path, format="PNG")

        # 4) QC overlay：原图 + 半透明孔隙 + 纯蓝辅助线
        blended = Image.blend(self.original, red, OVERLAY_ALPHA)
        overlay = Image.composite(blended, self.original, binary)
        overlay = Image.composite(blue, overlay, all_blue)
        overlay_path = overlay_dir / f"{stem}_overlay.png"
        overlay.save(overlay_path, format="PNG")

        self.mask = binary
        self.guide = guide_binary
        self.region = region_binary
        self.boundary = boundary_binary
        self._save_measurements_csv()
        self.dirty = False
        self._update_status("已保存")

        if not silent:
            messagebox.showinfo(
                "保存完成",
                f"孔隙 Mask（用于计算）:\n{mask_path}\n\n"
                f"白底图层（红色孔隙 + 黄色边界线）:\n{ann_path}\n\n"
                f"辅助蓝线（不参与面积）:\n{guide_path}\n\n"
                f"Overlay:\n{overlay_path}"
            )

    def _update_status(self, prefix=None):
        if self.image_path is None:
            text = "请选择原图；标尺校准时可先打开标尺图"
        else:
            n = len(self.image_files)
            pos = self.image_index + 1 if self.image_index >= 0 else 0
            dirty = " *未保存*" if self.dirty else ""
            mode_names = {
                "brush": "笔刷",
                "erase": "橡皮",
                "polygon": "多边形",
                "freehand": "自由圈选填充",
                "line": "辅助蓝线（不计面积）",
                "boundary": "黄色闭合边界（整体区域）",
                "pan": "平移",
                "calibrate": "标尺校准（两点）",
                "measure_length": "测理论长度（水平投影）",
                "measure_width": "测理论宽度（垂直投影）",
            }
            text = (
                f"{prefix + ' | ' if prefix else ''}"
                f"[{pos}/{n}] {self.image_path.name}{dirty} | "
                f"模式: {mode_names.get(self.mode.get(), self.mode.get())} | "
                f"滚轮缩放；平移模式左键拖动；或按住 Space + 左键拖动"
            )
        self.status_var.set(text)


# ============================================================
# MODULE 2 — ROI CALCULATION
# ============================================================

class ROICalculatorFrame(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app

        self.mask_path: Path | None = None
        self.mask_files: list[Path] = []
        self.mask_index = -1
        self.input_folder: Path | None = None
        self.output_root: Path | None = None

        self.mask: Image.Image | None = None      # L, 0/255
        self.display_rgb: Image.Image | None = None
        self.layer_rgb: Image.Image | None = None
        self.original_rgb: Image.Image | None = None
        self.roi_show_original = False
        self.roi_original_btn_text = tk.StringVar(value="显示原图")
        self.roi_contrast_var = tk.DoubleVar(value=1.0)
        self.roi_contrast_label_var = tk.StringVar(value="1.00×")
        self.tk_img = None

        self.img_w = 0
        self.img_h = 0

        self.zoom = 1.0
        self.pan_x = 0.0
        self.pan_y = 0.0

        # ROI 长度由用户调整；宽度按参考样条平均 L/W 自动锁定。
        self.roi_w_var = tk.StringVar(value="500")      # 水平长度
        self.roi_h_var = tk.StringVar(value="--")       # 垂直宽度，自动计算
        self.ref_mean_length = None
        self.ref_mean_width = None
        self.ref_ratio = None
        self.ref_n_length = 0
        self.ref_n_width = 0
        self.ref_summary_var = tk.StringVar(value="参考样条: --")
        self.calibration = None
        self.region_mask: Image.Image | None = None
        self.region_porosity = None
        self.project_root: Path | None = None
        self.records_loaded_root = None

        self.roi = None  # [x, y, w, h], image coordinates
        self.roi_dragging = False
        self.roi_drag_offset = (0, 0)

        self.panning = False
        self.pan_last = None

        # all records across the session
        self.records_by_image: dict[str, list[dict]] = {}

        self._build_ui()
        self._bind_events()

    def _build_ui(self):
        # Top controls
        top = ttk.Frame(self)
        top.pack(side=tk.TOP, fill=tk.X, padx=6, pady=5)

        ttk.Button(top, text="输入 Mask", command=self.open_mask_dialog).pack(side=tk.LEFT, padx=2)
        ttk.Button(top, text="输入 Mask 文件夹", command=self.open_folder_dialog).pack(side=tk.LEFT, padx=2)
        ttk.Button(top, text="输出文件夹", command=self.choose_output_folder).pack(side=tk.LEFT, padx=2)

        ttk.Button(top, text="上一张", command=self.prev_mask).pack(side=tk.LEFT, padx=(10, 2))
        ttk.Button(top, text="下一张", command=self.next_mask).pack(side=tk.LEFT, padx=2)

        ttk.Separator(top, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)
        ttk.Button(top, text="适应窗口", command=self.fit_to_window).pack(side=tk.LEFT, padx=(2, 2))
        ttk.Button(top, text="100%", command=self.zoom_100).pack(side=tk.LEFT, padx=2)

        ttk.Separator(top, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=7)
        ttk.Button(top, textvariable=self.roi_original_btn_text, command=self.toggle_roi_original).pack(side=tk.LEFT, padx=2)
        ttk.Label(top, text="原图对比度:").pack(side=tk.LEFT, padx=(6, 2))
        ttk.Scale(top, from_=0.35, to=2.50, variable=self.roi_contrast_var, command=self._roi_contrast_changed, length=110).pack(side=tk.LEFT, padx=2)
        ttk.Label(top, textvariable=self.roi_contrast_label_var, width=7).pack(side=tk.LEFT, padx=2)
        ttk.Button(top, text="重置", command=self.reset_roi_contrast).pack(side=tk.LEFT, padx=2)

        ttk.Button(top, text="导出 ROI 结果", command=self.export_results).pack(
            side=tk.RIGHT, padx=3
        )

        roi_ctl = ttk.Frame(self)
        roi_ctl.pack(side=tk.TOP, fill=tk.X, padx=8, pady=(0, 5))

        ttk.Label(roi_ctl, textvariable=self.ref_summary_var).pack(side=tk.LEFT, padx=(2, 12))
        ttk.Label(roi_ctl, text="ROI 长度(px):").pack(side=tk.LEFT)
        ttk.Entry(roi_ctl, textvariable=self.roi_w_var, width=8).pack(side=tk.LEFT, padx=(2, 8))
        ttk.Label(roi_ctl, text="ROI 宽度(px,自动):").pack(side=tk.LEFT)
        ttk.Entry(roi_ctl, textvariable=self.roi_h_var, width=8, state="readonly").pack(side=tk.LEFT, padx=(2, 8))
        ttk.Button(roi_ctl, text="1×样条", command=self.set_roi_one_reference).pack(side=tk.LEFT, padx=(3, 2))
        ttk.Button(roi_ctl, text="生成 ROI", command=self.generate_roi).pack(side=tk.LEFT, padx=3)

        self.region_result_var = tk.StringVar(value="黄色边界内孔隙率: --")
        ttk.Label(roi_ctl, textvariable=self.region_result_var, font=("Segoe UI", 10, "bold")).pack(side=tk.RIGHT, padx=8)

        self.roi_w_var.trace_add("write", lambda *_: self._sync_roi_height_from_ratio())

        # Main area
        main = ttk.Frame(self)
        main.pack(fill=tk.BOTH, expand=True)

        self.canvas = tk.Canvas(main, bg="#202020", highlightthickness=0, cursor="arrow")
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        side = ttk.Frame(main, width=340)
        side.pack(side=tk.RIGHT, fill=tk.Y, padx=(5, 7), pady=5)
        side.pack_propagate(False)

        # Current ROI live panel
        current_box = ttk.LabelFrame(side, text="当前 ROI（实时）")
        current_box.pack(fill=tk.X, pady=(0, 8))

        self.current_text = tk.StringVar(value=(
            "尚未生成 ROI\n\n"
            "先完成样条长/宽测量。\n"
            "ROI 宽度会按平均 L/W 自动锁定。"
        ))
        ttk.Label(
            current_box,
            textvariable=self.current_text,
            justify=tk.LEFT,
            anchor=tk.NW,
            font=("Segoe UI", 10)
        ).pack(fill=tk.X, padx=10, pady=10)

        self.porosity_big = tk.StringVar(value="Porosity: --")
        ttk.Label(
            current_box,
            textvariable=self.porosity_big,
            font=("Segoe UI", 15, "bold")
        ).pack(fill=tk.X, padx=10, pady=(0, 10))

        ttk.Button(
            side,
            text="记录当前 ROI",
            command=self.record_current_roi
        ).pack(fill=tk.X, pady=(0, 8), ipady=4)

        # Recorded ROI table
        rec_box = ttk.LabelFrame(side, text="本图已记录 ROI")
        rec_box.pack(fill=tk.BOTH, expand=True)

        columns = ("id", "x", "y", "w", "h", "porosity")
        self.tree = ttk.Treeview(
            rec_box,
            columns=columns,
            show="headings",
            height=12,
            selectmode="browse"
        )

        headings = {
            "id": "ROI",
            "x": "X",
            "y": "Y",
            "w": "W",
            "h": "H",
            "porosity": "Porosity %",
        }
        widths = {
            "id": 45,
            "x": 45,
            "y": 45,
            "w": 50,
            "h": 50,
            "porosity": 85,
        }

        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor=tk.CENTER)

        self.tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        actions = ttk.Frame(rec_box)
        actions.pack(fill=tk.X, padx=5, pady=(0, 5))

        ttk.Button(actions, text="删除选中 ROI", command=self.delete_selected_record).pack(
            side=tk.LEFT, padx=(0, 5)
        )
        ttk.Button(actions, text="清空本图记录", command=self.clear_current_records).pack(
            side=tk.LEFT
        )

        self.summary_var = tk.StringVar(value="N = 0    Mean = --    SD = --")
        ttk.Label(
            rec_box,
            textvariable=self.summary_var,
            font=("Segoe UI", 10, "bold")
        ).pack(fill=tk.X, padx=7, pady=(0, 8))

        status = ttk.Frame(self)
        status.pack(side=tk.BOTTOM, fill=tk.X)

        self.status_var = tk.StringVar(value="请选择 binary mask")
        ttk.Label(status, textvariable=self.status_var, anchor=tk.W).pack(
            side=tk.LEFT, fill=tk.X, expand=True, padx=8, pady=3
        )

        self.zoom_var = tk.StringVar(value="Zoom: 100%")
        ttk.Label(status, textvariable=self.zoom_var).pack(side=tk.RIGHT, padx=8)

    def _bind_events(self):
        c = self.canvas
        c.bind("<Configure>", lambda e: self.render())

        # ROI left drag
        c.bind("<ButtonPress-1>", self.on_left_press)
        c.bind("<B1-Motion>", self.on_left_drag)
        c.bind("<ButtonRelease-1>", self.on_left_release)

        # Pan
        c.bind("<ButtonPress-2>", self.on_pan_press)
        c.bind("<B2-Motion>", self.on_pan_drag)
        c.bind("<ButtonRelease-2>", self.on_pan_release)

        # Zoom
        c.bind("<MouseWheel>", self.on_mousewheel)
        c.bind("<Button-4>", lambda e: self.zoom_at(e.x, e.y, 1.15))
        c.bind("<Button-5>", lambda e: self.zoom_at(e.x, e.y, 1 / 1.15))

    # ---------------- Input/output ----------------

    def open_mask_dialog(self):
        initial = self.input_folder or (DEFAULT_FOLDER if DEFAULT_FOLDER.exists() else Path.home())
        path = filedialog.askopenfilename(
            title="选择 binary mask",
            initialdir=str(initial),
            filetypes=[("PNG images", "*.png"),
                       ("Images", "*.png *.jpg *.jpeg *.tif *.tiff *.bmp *.webp"),
                       ("All files", "*.*")]
        )
        if not path:
            return

        path = Path(path)
        self.input_folder = path.parent
        self._build_mask_list(self.input_folder, selected=path)
        self.load_mask(path)

    def open_folder_dialog(self):
        initial = self.input_folder or (DEFAULT_FOLDER if DEFAULT_FOLDER.exists() else Path.home())
        folder = filedialog.askdirectory(title="选择 Mask 输入文件夹", initialdir=str(initial))
        if not folder:
            return

        self.input_folder = Path(folder)
        self._build_mask_list(self.input_folder)

        if not self.mask_files:
            messagebox.showwarning("没有 Mask", "该文件夹中没有可用图片。")
            return

        self.mask_index = 0
        self.load_mask(self.mask_files[0])

    def choose_output_folder(self):
        initial = self.output_root or self.input_folder or DEFAULT_FOLDER
        folder = filedialog.askdirectory(title="选择 ROI 结果输出文件夹", initialdir=str(initial))
        if folder:
            self.output_root = Path(folder)
            self.status_var.set(f"输出文件夹：{self.output_root}")

    def _mask_base_stem(self, path: Path | None = None):
        p = path or self.mask_path
        if p is None:
            return ""
        stem = p.stem
        return stem[:-5] if stem.lower().endswith("_mask") else stem

    def _infer_project_root(self, mask_path: Path | None = None):
        p = mask_path or self.mask_path
        if p is None:
            return None
        parent = p.parent
        if parent.name.lower() == "manual_masks":
            return parent.parent
        return parent

    def _load_calibration_from_root(self):
        self.calibration = None
        if not self.project_root:
            return
        cpath = self.project_root / "manual_measurements" / "scale_calibration.csv"
        if not cpath.exists():
            return
        try:
            with cpath.open("r", newline="", encoding="utf-8-sig") as f:
                rows = list(csv.DictReader(f))
            if not rows:
                return
            r = rows[-1]
            self.calibration = {
                "source_image": r.get("source_image", ""),
                "known_value": float(r["known_value"]),
                "unit": r["unit"],
                "pixel_distance": float(r["pixel_distance"]),
                "unit_per_px": float(r["unit_per_px"]),
            }
        except Exception:
            self.calibration = None

    def _load_reference_stats(self):
        self.ref_mean_length = None
        self.ref_mean_width = None
        self.ref_ratio = None
        self.ref_n_length = 0
        self.ref_n_width = 0

        if not self.project_root:
            self.ref_summary_var.set("参考样条: --")
            self.roi_h_var.set("--")
            return

        detail = self.project_root / "manual_measurements" / "reference_measurements.csv"
        if not detail.exists():
            self.ref_summary_var.set("参考样条: 未找到测量数据")
            self.roi_h_var.set("--")
            return

        base = self._mask_base_stem().lower()
        lengths = []
        widths = []
        try:
            with detail.open("r", newline="", encoding="utf-8-sig") as f:
                for row in csv.DictReader(f):
                    image_name = row.get("image_name", "")
                    if Path(image_name).stem.lower() != base:
                        continue
                    try:
                        v = float(row["value_px"])
                    except Exception:
                        continue
                    if row.get("type") == "length":
                        lengths.append(v)
                    elif row.get("type") == "width":
                        widths.append(v)
        except Exception:
            lengths, widths = [], []

        self.ref_n_length = len(lengths)
        self.ref_n_width = len(widths)
        if lengths:
            self.ref_mean_length = statistics.mean(lengths)
        if widths:
            self.ref_mean_width = statistics.mean(widths)
        if self.ref_mean_length is not None and self.ref_mean_width not in (None, 0):
            self.ref_ratio = self.ref_mean_length / self.ref_mean_width

        if self.ref_ratio is None:
            self.ref_summary_var.set(
                f"参考样条: L n={len(lengths)}, W n={len(widths)}；请先完成长度和宽度测量"
            )
        else:
            warn = "" if min(len(lengths), len(widths)) >= 5 else "  [建议各≥5次]"
            self.ref_summary_var.set(
                f"参考样条: L={self.ref_mean_length:.1f}px (n={len(lengths)}), "
                f"W={self.ref_mean_width:.1f}px (n={len(widths)}), L/W={self.ref_ratio:.3f}{warn}"
            )
        self._sync_roi_height_from_ratio()

    def _sync_roi_height_from_ratio(self):
        if self.ref_ratio in (None, 0):
            self.roi_h_var.set("--")
            return
        try:
            length = float(self.roi_w_var.get())
        except Exception:
            self.roi_h_var.set("--")
            return
        if length <= 0:
            self.roi_h_var.set("--")
            return
        width = length / self.ref_ratio
        self.roi_h_var.set(str(int(round(width))))

    def set_roi_one_reference(self):
        if self.ref_mean_length is None:
            messagebox.showwarning("没有参考样条", "请先在手绘标注模块完成样条长度/宽度测量。")
            return
        self.roi_w_var.set(str(int(round(self.ref_mean_length))))
        self._sync_roi_height_from_ratio()

    def _load_region_for_current_mask(self):
        self.region_mask = None
        self.region_porosity = None
        if not self.project_root or self.mask is None:
            self.region_result_var.set("黄色边界内孔隙率: --")
            return
        base = self._mask_base_stem()
        rpath = self.project_root / "manual_regions" / f"{base}_region_mask.png"
        if not rpath.exists():
            self.region_result_var.set("黄色边界内孔隙率: 未设置闭合边界")
            return
        try:
            region = Image.open(rpath).convert("L").point(lambda x: 255 if x >= 128 else 0, mode="L")
            if region.size != self.mask.size:
                self.region_result_var.set("黄色边界内孔隙率: 区域尺寸不匹配")
                return
            self.region_mask = region
            region_pixels = int(sum(region.histogram()[128:]))
            intersection = ImageChops.multiply(self.mask, region)
            pore_pixels = int(sum(intersection.histogram()[128:]))
            porosity = (pore_pixels / region_pixels * 100.0) if region_pixels else None
            if porosity is None:
                self.region_result_var.set("黄色边界内孔隙率: 区域为空")
            else:
                self.region_porosity = {
                    "region_pixels": region_pixels,
                    "pore_pixels": pore_pixels,
                    "porosity_percent": porosity,
                }
                self.region_result_var.set(f"黄色边界内孔隙率: {porosity:.4f} %")
        except Exception:
            self.region_result_var.set("黄色边界内孔隙率: 读取失败")

    def _roi_records_csv_path(self):
        return self._get_output_root() / "roi_records.csv"

    def _load_roi_records_if_needed(self):
        path = self._roi_records_csv_path()
        root = str(path.parent.resolve())
        if self.records_loaded_root == root:
            return
        self.records_loaded_root = root
        self.records_by_image = {}
        if not path.exists():
            return
        try:
            with path.open("r", newline="", encoding="utf-8-sig") as f:
                for row in csv.DictReader(f):
                    image_name = row.get("image_name", "")
                    if not image_name:
                        continue
                    try:
                        rec = {
                            "roi_id": int(row["roi_id"]),
                            "x": int(float(row["x"])),
                            "y": int(float(row["y"])),
                            "width": int(float(row["width"])),
                            "height": int(float(row["height"])),
                            "pore_pixels": int(float(row["pore_pixels"])),
                            "roi_pixels": int(float(row["roi_pixels"])),
                            "porosity_percent": float(row["porosity_percent"]),
                        }
                    except Exception:
                        continue
                    self.records_by_image.setdefault(image_name, []).append(rec)
        except Exception:
            self.records_by_image = {}

    def _save_roi_records_csv(self):
        path = self._roi_records_csv_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow([
                "image_name", "roi_id", "x", "y", "width", "height",
                "pore_pixels", "roi_pixels", "porosity_percent"
            ])
            for image_name in sorted(self.records_by_image):
                for r in self.records_by_image[image_name]:
                    writer.writerow([
                        image_name, r["roi_id"], r["x"], r["y"],
                        r["width"], r["height"], r["pore_pixels"],
                        r["roi_pixels"], f"{r['porosity_percent']:.9f}"
                    ])

    def _build_mask_list(self, folder: Path, selected: Path | None = None):
        files = [p for p in folder.iterdir() if is_image_file(p)]
        files.sort(key=lambda x: x.name.lower())

        if selected is not None and selected not in files:
            files.append(selected)
            files.sort(key=lambda x: x.name.lower())

        self.mask_files = files

        if selected is not None:
            try:
                self.mask_index = files.index(selected)
            except ValueError:
                self.mask_index = -1

    def load_mask(self, path: Path):
        try:
            m = Image.open(path).convert("L")
        except Exception as exc:
            messagebox.showerror("打开失败", f"{path}\n\n{exc}")
            return

        self.mask = m.point(lambda x: 255 if x >= 128 else 0, mode="L")
        self.mask_path = path
        self.img_w, self.img_h = self.mask.size
        self.project_root = self._infer_project_root(path)

        # ROI 工作区优先显示白底红孔+黄边界 annotation；没有时退回二值 mask。
        base = self._mask_base_stem(path)
        ann_path = (self.project_root / "manual_annotations" / f"{base}_annotation.png") if self.project_root else None
        if ann_path and ann_path.exists():
            try:
                disp = Image.open(ann_path).convert("RGB")
                self.layer_rgb = disp if disp.size == self.mask.size else self.mask.convert("RGB")
            except Exception:
                self.layer_rgb = self.mask.convert("RGB")
        else:
            self.layer_rgb = self.mask.convert("RGB")
        self.display_rgb = self.layer_rgb
        self.original_rgb = None
        self.roi_show_original = False
        self.roi_original_btn_text.set("显示原图")

        if path in self.mask_files:
            self.mask_index = self.mask_files.index(path)

        self._load_calibration_from_root()
        self._load_reference_stats()
        self._load_region_for_current_mask()
        self._load_roi_records_if_needed()

        self.roi = None
        self.roi_dragging = False

        self.after(30, self.fit_to_window)
        self.refresh_record_table()
        self.update_live_roi()
        self._update_status()
        self.canvas.focus_set()

    def prev_mask(self):
        if not self.mask_files:
            return
        if self.mask_index <= 0:
            messagebox.showinfo("提示", "已经是第一张。")
            return
        self.mask_index -= 1
        self.load_mask(self.mask_files[self.mask_index])

    def next_mask(self):
        if not self.mask_files:
            return
        if self.mask_index >= len(self.mask_files) - 1:
            messagebox.showinfo("提示", "已经是最后一张。")
            return
        self.mask_index += 1
        self.load_mask(self.mask_files[self.mask_index])

    # ---------------- v2.8 ROI original-image toggle ----------------

    def _roi_contrast_changed(self, value=None):
        try:
            v = clamp(float(self.roi_contrast_var.get()), 0.35, 2.50)
        except Exception:
            v = 1.0
        self.roi_contrast_var.set(v)
        self.roi_contrast_label_var.set(f"{v:.2f}×")
        if self.roi_show_original:
            self._refresh_roi_display_from_original()

    def reset_roi_contrast(self):
        self.roi_contrast_var.set(1.0)
        self.roi_contrast_label_var.set("1.00×")
        if self.roi_show_original:
            self._refresh_roi_display_from_original()

    def _refresh_roi_display_from_original(self):
        # Base class fallback: staged subclass provides the original image and
        # recreates red/blue/yellow overlays.
        if self.roi_show_original and self.original_rgb is not None:
            try:
                v = clamp(float(self.roi_contrast_var.get()), 0.35, 2.50)
            except Exception:
                v = 1.0
            self.display_rgb = ImageEnhance.Contrast(self.original_rgb).enhance(v)
        else:
            self.display_rgb = self.layer_rgb
        self.render()

    def toggle_roi_original(self):
        if self.mask is None:
            return
        if self.original_rgb is None and not self.roi_show_original:
            messagebox.showinfo("未找到原图", "当前 ROI 项目尚未找到对应原图。")
            return
        self.roi_show_original = not self.roi_show_original
        self.roi_original_btn_text.set("隐藏原图" if self.roi_show_original else "显示原图")
        self._refresh_roi_display_from_original()

    # ---------------- Coordinates / render ----------------

    def screen_to_image(self, sx, sy):
        if self.mask is None:
            return None
        return (sx - self.pan_x) / self.zoom, (sy - self.pan_y) / self.zoom

    def image_to_screen(self, ix, iy):
        return ix * self.zoom + self.pan_x, iy * self.zoom + self.pan_y

    def render(self):
        self.canvas.delete("all")
        if self.display_rgb is None:
            return

        cw = max(1, self.canvas.winfo_width())
        ch = max(1, self.canvas.winfo_height())

        x0f = max(0.0, -self.pan_x / self.zoom)
        y0f = max(0.0, -self.pan_y / self.zoom)
        x1f = min(float(self.img_w), (cw - self.pan_x) / self.zoom)
        y1f = min(float(self.img_h), (ch - self.pan_y) / self.zoom)

        if x1f > x0f and y1f > y0f:
            x0 = max(0, int(x0f))
            y0 = max(0, int(y0f))
            x1 = min(self.img_w, int(x1f + 1))
            y1 = min(self.img_h, int(y1f + 1))

            crop = self.display_rgb.crop((x0, y0, x1, y1))
            dw = max(1, int(round((x1 - x0) * self.zoom)))
            dh = max(1, int(round((y1 - y0) * self.zoom)))

            resample = Image.Resampling.NEAREST if self.zoom >= 1 else Image.Resampling.LANCZOS
            disp = crop.resize((dw, dh), resample)
            self.tk_img = ImageTk.PhotoImage(disp)

            sx = self.pan_x + x0 * self.zoom
            sy = self.pan_y + y0 * self.zoom
            self.canvas.create_image(sx, sy, image=self.tk_img, anchor=tk.NW)

        bx0, by0 = self.image_to_screen(0, 0)
        bx1, by1 = self.image_to_screen(self.img_w, self.img_h)
        self.canvas.create_rectangle(bx0, by0, bx1, by1, outline="#777777", width=1)

        if self.roi is not None:
            x, y, w, h = self.roi
            sx0, sy0 = self.image_to_screen(x, y)
            sx1, sy1 = self.image_to_screen(x + w, y + h)

            self.canvas.create_rectangle(
                sx0, sy0, sx1, sy1,
                outline="#00ff66",
                width=3,
                tags="roi"
            )

            # Small title above ROI
            self.canvas.create_text(
                sx0 + 4,
                sy0 - 8,
                text=self._roi_short_text(),
                fill="#00ff66",
                anchor=tk.SW,
                font=("Segoe UI", 10, "bold")
            )

        self.zoom_var.set(f"Zoom: {self.zoom * 100:.0f}%")

    def fit_to_window(self):
        if self.mask is None:
            return
        self.update_idletasks()
        cw = max(50, self.canvas.winfo_width())
        ch = max(50, self.canvas.winfo_height())
        z = min((cw - 30) / self.img_w, (ch - 30) / self.img_h)
        self.zoom = clamp(z, MIN_ZOOM, MAX_ZOOM)
        self.pan_x = (cw - self.img_w * self.zoom) / 2
        self.pan_y = (ch - self.img_h * self.zoom) / 2
        self.render()

    def zoom_100(self):
        if self.mask is None:
            return
        self.update_idletasks()
        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        self.zoom = 1.0
        self.pan_x = (cw - self.img_w) / 2
        self.pan_y = (ch - self.img_h) / 2
        self.render()

    def on_mousewheel(self, event):
        self.zoom_at(event.x, event.y, 1.15 if event.delta > 0 else 1 / 1.15)

    def zoom_at(self, sx, sy, factor):
        if self.mask is None:
            return
        ix, iy = self.screen_to_image(sx, sy)
        self.zoom = clamp(self.zoom * factor, MIN_ZOOM, MAX_ZOOM)
        self.pan_x = sx - ix * self.zoom
        self.pan_y = sy - iy * self.zoom
        self.render()

    # ---------------- Pan ----------------

    def on_pan_press(self, event):
        self.panning = True
        self.pan_last = (event.x, event.y)
        self.canvas.configure(cursor="fleur")

    def on_pan_drag(self, event):
        if not self.panning or self.pan_last is None:
            return
        dx = event.x - self.pan_last[0]
        dy = event.y - self.pan_last[1]
        self.pan_x += dx
        self.pan_y += dy
        self.pan_last = (event.x, event.y)
        self.render()

    def on_pan_release(self, event):
        self.panning = False
        self.pan_last = None
        self.canvas.configure(cursor="arrow")

    # ---------------- ROI ----------------

    def generate_roi(self):
        if self.mask is None:
            messagebox.showwarning("没有 Mask", "请先输入一个 binary mask。")
            return

        if self.ref_ratio in (None, 0):
            messagebox.showwarning(
                "缺少参考样条",
                "当前图片还没有可用的平均长度/宽度。\n\n"
                "请先在①手绘标注中测量样条长度和宽度；建议各至少 5 次。"
            )
            return

        try:
            w = int(round(float(self.roi_w_var.get())))
            h = int(round(w / self.ref_ratio))
        except Exception:
            messagebox.showerror("输入错误", "ROI 长度必须是数字。")
            return

        if w <= 0 or h <= 0:
            messagebox.showerror("输入错误", "ROI 长度和自动宽度必须大于 0。")
            return

        if w > self.img_w or h > self.img_h:
            messagebox.showerror(
                "ROI 太大",
                f"当前图片尺寸为 {self.img_w} × {self.img_h} px。\n"
                f"按样条比例生成的 ROI 为 {w} × {h} px，超过图片范围。"
            )
            return

        self.roi_h_var.set(str(h))
        x = (self.img_w - w) // 2
        y = (self.img_h - h) // 2
        self.roi = [x, y, w, h]

        self.update_live_roi()
        self.render()
        self.status_var.set(
            f"已生成比例锁定 ROI：{w} × {h} px（L/W={self.ref_ratio:.3f}）。"
            f"直接用左键拖动方框，孔隙率实时更新。"
        )

    def _point_inside_roi(self, ix, iy):
        if self.roi is None:
            return False
        x, y, w, h = self.roi
        return x <= ix <= x + w and y <= iy <= y + h

    def on_left_press(self, event):
        if self.mask is None or self.roi is None:
            return

        p = self.screen_to_image(event.x, event.y)
        if p is None:
            return

        ix, iy = p

        if self._point_inside_roi(ix, iy):
            x, y, w, h = self.roi
            self.roi_dragging = True
            self.roi_drag_offset = (ix - x, iy - y)
            self.canvas.configure(cursor="fleur")

    def on_left_drag(self, event):
        if not self.roi_dragging or self.roi is None:
            return

        p = self.screen_to_image(event.x, event.y)
        if p is None:
            return

        ix, iy = p
        _, _, w, h = self.roi
        ox, oy = self.roi_drag_offset

        new_x = int(round(ix - ox))
        new_y = int(round(iy - oy))

        new_x = int(clamp(new_x, 0, self.img_w - w))
        new_y = int(clamp(new_y, 0, self.img_h - h))

        self.roi[0] = new_x
        self.roi[1] = new_y

        # Real-time calculation during movement
        self.update_live_roi()
        self.render()

    def on_left_release(self, event):
        if self.roi_dragging:
            self.roi_dragging = False
            self.canvas.configure(cursor="arrow")
            self.update_live_roi()
            self.render()

    def calculate_current_roi(self):
        if self.mask is None or self.roi is None:
            return None

        x, y, w, h = [int(v) for v in self.roi]

        # crop is [left, upper, right, lower]
        crop = self.mask.crop((x, y, x + w, y + h))

        # Binary mask: white 255 means pore
        hist = crop.histogram()
        pore_pixels = int(sum(hist[128:]))
        roi_pixels = int(w * h)

        porosity = (pore_pixels / roi_pixels * 100.0) if roi_pixels else 0.0

        return {
            "x": x,
            "y": y,
            "width": w,
            "height": h,
            "pore_pixels": pore_pixels,
            "roi_pixels": roi_pixels,
            "porosity_percent": porosity,
        }

    def update_live_roi(self):
        result = self.calculate_current_roi()

        if result is None:
            self.current_text.set(
                "尚未生成 ROI\n\n"
                "ROI 长度可调整；宽度按样条平均 L/W 自动锁定。\n"
                "建议样条长度、宽度各至少测量 5 次。"
            )
            self.porosity_big.set("Porosity: --")
            return

        self.current_text.set(
            f"X = {result['x']} px\n"
            f"Y = {result['y']} px\n"
            f"Width = {result['width']} px\n"
            f"Height = {result['height']} px\n\n"
            f"Pore pixels = {result['pore_pixels']:,}\n"
            f"ROI pixels = {result['roi_pixels']:,}"
        )
        self.porosity_big.set(
            f"Porosity: {result['porosity_percent']:.4f} %"
        )

    def _roi_short_text(self):
        r = self.calculate_current_roi()
        if r is None:
            return ""
        return f"{r['porosity_percent']:.3f}%"

    # ---------------- Record ROI ----------------

    def _current_image_key(self):
        return self.mask_path.name if self.mask_path else None

    def record_current_roi(self):
        if self.mask_path is None or self.roi is None:
            messagebox.showwarning("没有 ROI", "请先生成并定位 ROI。")
            return

        r = self.calculate_current_roi()
        key = self._current_image_key()

        records = self.records_by_image.setdefault(key, [])
        record = {
            "roi_id": len(records) + 1,
            **r
        }
        records.append(record)
        self._save_roi_records_csv()

        self.refresh_record_table()

        self.status_var.set(
            f"已记录 {key} 的 ROI {record['roi_id']}："
            f"{record['porosity_percent']:.4f}%"
        )

    def refresh_record_table(self):
        for item in self.tree.get_children():
            self.tree.delete(item)

        key = self._current_image_key()
        records = self.records_by_image.get(key, []) if key else []

        for r in records:
            self.tree.insert(
                "",
                tk.END,
                values=(
                    r["roi_id"],
                    r["x"],
                    r["y"],
                    r["width"],
                    r["height"],
                    f"{r['porosity_percent']:.4f}",
                )
            )

        vals = [r["porosity_percent"] for r in records]
        if not vals:
            self.summary_var.set("N = 0    Mean = --    SD = --")
        elif len(vals) == 1:
            self.summary_var.set(
                f"N = 1    Mean = {vals[0]:.4f}%    SD = --"
            )
        else:
            mean = statistics.mean(vals)
            sd = statistics.stdev(vals)
            self.summary_var.set(
                f"N = {len(vals)}    Mean = {mean:.4f}%    SD = {sd:.4f}%"
            )

    def delete_selected_record(self):
        key = self._current_image_key()
        if not key:
            return

        selected = self.tree.selection()
        if not selected:
            return

        values = self.tree.item(selected[0], "values")
        if not values:
            return

        roi_id = int(values[0])
        records = self.records_by_image.get(key, [])

        records = [r for r in records if r["roi_id"] != roi_id]

        # Renumber
        for i, r in enumerate(records, 1):
            r["roi_id"] = i

        self.records_by_image[key] = records
        self._save_roi_records_csv()
        self.refresh_record_table()

    def clear_current_records(self):
        key = self._current_image_key()
        if not key:
            return

        if not self.records_by_image.get(key):
            return

        if messagebox.askyesno("确认", "清空当前图片的所有已记录 ROI？"):
            self.records_by_image[key] = []
            self._save_roi_records_csv()
            self.refresh_record_table()

    # ---------------- Export ----------------

    def _get_output_root(self):
        if self.output_root:
            return self.output_root
        if self.project_root:
            return self.project_root / "ROI_results"
        if self.input_folder:
            return self.input_folder / "ROI_results"
        return DEFAULT_FOLDER / "ROI_results"

    def export_results(self):
        all_records = []
        for image_name, records in self.records_by_image.items():
            for r in records:
                all_records.append({
                    "image_name": image_name,
                    **r
                })

        if not all_records:
            messagebox.showwarning("没有记录", "还没有记录任何 ROI。")
            return

        if Workbook is None:
            messagebox.showerror(
                "缺少 openpyxl",
                "导出 Excel 需要 openpyxl。\n\n请运行：pip install openpyxl"
            )
            return

        root = self._get_output_root()
        overlay_dir = root / "ROI_overlays"
        root.mkdir(parents=True, exist_ok=True)
        overlay_dir.mkdir(parents=True, exist_ok=True)

        xlsx_path = root / "porosity_ROI_results.xlsx"

        wb = Workbook()
        ws = wb.active
        ws.title = "ROI_records"

        headers = [
            "image_name", "roi_id", "x", "y", "width", "height",
            "pore_pixels", "roi_pixels", "porosity_percent"
        ]
        ws.append(headers)
        for cell in ws[1]:
            cell.font = Font(bold=True)

        for row in all_records:
            ws.append([
                row["image_name"],
                row["roi_id"],
                row["x"],
                row["y"],
                row["width"],
                row["height"],
                row["pore_pixels"],
                row["roi_pixels"],
                row["porosity_percent"],
            ])

        # Summary sheet
        ws2 = wb.create_sheet("image_summary")
        ws2.append(["image_name", "n_roi", "mean_porosity_percent", "sd_porosity_percent"])
        for cell in ws2[1]:
            cell.font = Font(bold=True)

        for image_name in sorted(self.records_by_image.keys()):
            records = self.records_by_image[image_name]
            if not records:
                continue
            vals = [r["porosity_percent"] for r in records]
            mean = statistics.mean(vals)
            sd = statistics.stdev(vals) if len(vals) >= 2 else None
            ws2.append([image_name, len(vals), mean, sd])

        wb.save(xlsx_path)

        # Save overlay images for masks currently reachable from the input folder/list.
        path_lookup = {p.name: p for p in self.mask_files}
        if self.mask_path:
            path_lookup[self.mask_path.name] = self.mask_path

        for image_name, records in self.records_by_image.items():
            if not records:
                continue
            p = path_lookup.get(image_name)
            if p is None or not p.exists():
                continue

            try:
                base = Image.open(p).convert("RGB")
            except Exception:
                continue

            draw = ImageDraw.Draw(base)

            # Colors are for exported QC only
            for r in records:
                x, y = r["x"], r["y"]
                w, h = r["width"], r["height"]
                draw.rectangle([x, y, x+w, y+h], outline=(0, 255, 0), width=3)
                label = f"ROI{r['roi_id']} {r['porosity_percent']:.3f}%"
                draw.text((x + 4, max(0, y + 4)), label, fill=(0, 255, 0))

            out = overlay_dir / f"{p.stem}_ROI_overlay.png"
            base.save(out, format="PNG")

        messagebox.showinfo(
            "导出完成",
            f"Excel:\n{xlsx_path}\n\n"
            f"ROI overlays:\n{overlay_dir}"
        )
        self.status_var.set(f"已导出：{xlsx_path}")

    def _update_status(self):
        if self.mask_path is None:
            self.status_var.set("请选择 binary mask")
            return
        n = len(self.mask_files)
        pos = self.mask_index + 1 if self.mask_index >= 0 else 0
        self.status_var.set(
            f"[{pos}/{n}] {self.mask_path.name} | "
            f"生成 ROI 后，左键拖动方框，孔隙率实时自动更新"
        )


# ============================================================
# MODULE 3 — FINAL REPORT
# ============================================================

class ReportFrame(ttk.Frame):
    """汇总黄色边界整体孔隙率、ROI 孔隙率、样条长宽单次/平均和标尺校准。"""

    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.project_root: Path | None = None
        self.output_root: Path | None = None
        self.preview_rows = []
        self._build_ui()

    def _build_ui(self):
        top = ttk.Frame(self)
        top.pack(fill=tk.X, padx=8, pady=8)

        ttk.Button(top, text="选择项目文件夹", command=self.choose_project_root).pack(side=tk.LEFT, padx=2)
        ttk.Button(top, text="使用当前项目", command=self.use_current_project).pack(side=tk.LEFT, padx=2)
        ttk.Button(top, text="报告输出文件夹", command=self.choose_output_root).pack(side=tk.LEFT, padx=2)
        ttk.Button(top, text="刷新预览", command=self.refresh_preview).pack(side=tk.LEFT, padx=(12, 2))
        ttk.Button(top, text="生成最终报告", command=self.generate_report).pack(side=tk.RIGHT, padx=2, ipadx=16, ipady=4)

        self.path_var = tk.StringVar(value="项目文件夹：--")
        ttk.Label(self, textvariable=self.path_var, anchor=tk.W).pack(fill=tk.X, padx=10, pady=(0, 6))

        info = ttk.LabelFrame(self, text="v2.4 最终报告内容")
        info.pack(fill=tk.X, padx=8, pady=(0, 8))
        ttk.Label(
            info,
            text=(
                "黄色边界内整体孔隙率 + 每个已记录 ROI 的孔隙率及 Mean/SD + "
                "参考样条每次 Length/Width + 平均值/SD + L/W + 标尺换算（如已校准）。\n"
                "黄色边界线本身只用于显示；整体孔隙率使用其闭合区域 mask。"
            ),
            justify=tk.LEFT,
            anchor=tk.W,
        ).pack(fill=tk.X, padx=10, pady=8)

        frame = ttk.Frame(self)
        frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=(0, 8))

        columns = (
            "image", "blue", "nroi", "roimean",
            "nl", "lmean", "nw", "wmean", "ratio"
        )
        self.tree = ttk.Treeview(frame, columns=columns, show="headings", selectmode="browse")
        headings = {
            "image": "Image",
            "blue": "Yellow region %",
            "nroi": "N ROI",
            "roimean": "ROI Mean %",
            "nl": "N Length",
            "lmean": "Mean L px",
            "nw": "N Width",
            "wmean": "Mean W px",
            "ratio": "L/W",
        }
        widths = {
            "image": 190, "blue": 110, "nroi": 70, "roimean": 110,
            "nl": 75, "lmean": 100, "nw": 75, "wmean": 100, "ratio": 90,
        }
        for c in columns:
            self.tree.heading(c, text=headings[c])
            self.tree.column(c, width=widths[c], anchor=tk.CENTER)
        self.tree.pack(fill=tk.BOTH, expand=True)

        bottom = ttk.Frame(self)
        bottom.pack(fill=tk.X, padx=8, pady=(0, 8))
        self.status_var = tk.StringVar(value="选择项目文件夹后刷新预览。")
        ttk.Label(bottom, textvariable=self.status_var, anchor=tk.W).pack(side=tk.LEFT, fill=tk.X, expand=True)

    def choose_project_root(self):
        initial = self.project_root or DEFAULT_FOLDER
        folder = filedialog.askdirectory(title="选择项目根目录", initialdir=str(initial))
        if not folder:
            return
        self.project_root = Path(folder)
        self.path_var.set(f"项目文件夹：{self.project_root}")
        self.refresh_preview()

    def choose_output_root(self):
        initial = self.output_root or (self.project_root / "final_report" if self.project_root else DEFAULT_FOLDER)
        folder = filedialog.askdirectory(title="选择最终报告输出文件夹", initialdir=str(initial))
        if folder:
            self.output_root = Path(folder)
            self.status_var.set(f"报告输出文件夹：{self.output_root}")

    def use_current_project(self):
        root = None
        if getattr(self.app.roi_calc, "project_root", None):
            root = self.app.roi_calc.project_root
        elif getattr(self.app.annotator, "image_path", None):
            root = self.app.annotator._project_root()
        if root:
            self.project_root = Path(root)
            self.path_var.set(f"项目文件夹：{self.project_root}")
            self.refresh_preview()
        else:
            messagebox.showinfo("提示", "当前还没有打开项目图片或 Mask。")

    def _find_roi_csv(self, root: Path):
        preferred = root / "ROI_results" / "roi_records.csv"
        if preferred.exists():
            return preferred
        try:
            found = list(root.rglob("roi_records.csv"))
        except Exception:
            found = []
        return found[0] if found else None

    @staticmethod
    def _base_from_mask_name(name: str):
        stem = Path(name).stem
        return stem[:-5] if stem.lower().endswith("_mask") else stem

    @staticmethod
    def _safe_mean(vals):
        return statistics.mean(vals) if vals else None

    @staticmethod
    def _safe_sd(vals):
        return statistics.stdev(vals) if len(vals) >= 2 else None

    def _read_calibration(self, root: Path):
        path = root / "manual_measurements" / "scale_calibration.csv"
        if not path.exists():
            return None
        try:
            with path.open("r", newline="", encoding="utf-8-sig") as f:
                rows = list(csv.DictReader(f))
            if not rows:
                return None
            r = rows[-1]
            return {
                "source_image": r.get("source_image", ""),
                "known_value": float(r["known_value"]),
                "unit": r["unit"],
                "pixel_distance": float(r["pixel_distance"]),
                "unit_per_px": float(r["unit_per_px"]),
            }
        except Exception:
            return None

    def _read_measurements(self, root: Path):
        path = root / "manual_measurements" / "reference_measurements.csv"
        by_stem = {}
        if not path.exists():
            return by_stem
        try:
            with path.open("r", newline="", encoding="utf-8-sig") as f:
                for row in csv.DictReader(f):
                    image_name = row.get("image_name", "")
                    if not image_name:
                        continue
                    stem = Path(image_name).stem
                    try:
                        rec = {
                            "image_name": image_name,
                            "type": row.get("type", ""),
                            "id": int(row.get("id", 0)),
                            "value_px": float(row.get("value_px", "nan")),
                        }
                    except Exception:
                        continue
                    by_stem.setdefault(stem, []).append(rec)
        except Exception:
            return {}
        return by_stem

    def _read_roi_records(self, root: Path):
        path = self._find_roi_csv(root)
        by_stem = {}
        if path is None:
            # 同一运行会话中，即便 ROI 输出目录被用户改到项目外，也尽量使用内存记录。
            try:
                for image_name, rows in self.app.roi_calc.records_by_image.items():
                    stem = self._base_from_mask_name(image_name)
                    by_stem[stem] = [dict(r, image_name=image_name) for r in rows]
            except Exception:
                pass
            return by_stem, None
        try:
            with path.open("r", newline="", encoding="utf-8-sig") as f:
                for row in csv.DictReader(f):
                    image_name = row.get("image_name", "")
                    if not image_name:
                        continue
                    stem = self._base_from_mask_name(image_name)
                    try:
                        rec = {
                            "image_name": image_name,
                            "roi_id": int(row["roi_id"]),
                            "x": int(float(row["x"])),
                            "y": int(float(row["y"])),
                            "width": int(float(row["width"])),
                            "height": int(float(row["height"])),
                            "pore_pixels": int(float(row["pore_pixels"])),
                            "roi_pixels": int(float(row["roi_pixels"])),
                            "porosity_percent": float(row["porosity_percent"]),
                        }
                    except Exception:
                        continue
                    by_stem.setdefault(stem, []).append(rec)
        except Exception:
            return {}, path
        return by_stem, path

    def _collect_data(self):
        root = self.project_root
        if root is None:
            return None
        mask_dir = root / "manual_masks"
        if not mask_dir.exists():
            return {
                "root": root, "images": [], "calibration": self._read_calibration(root),
                "measurement_by_stem": self._read_measurements(root),
                "roi_by_stem": {}, "roi_csv": None,
            }

        masks = sorted([p for p in mask_dir.iterdir() if is_image_file(p)], key=lambda p: p.name.lower())
        calibration = self._read_calibration(root)
        measurement_by_stem = self._read_measurements(root)
        roi_by_stem, roi_csv = self._read_roi_records(root)
        images = []

        for mask_path in masks:
            stem = self._base_from_mask_name(mask_path.name)
            try:
                mask = Image.open(mask_path).convert("L").point(lambda x: 255 if x >= 128 else 0, mode="L")
            except Exception:
                continue

            region_path = root / "manual_regions" / f"{stem}_region_mask.png"
            blue = {
                "region_pixels": None,
                "pore_pixels": None,
                "porosity_percent": None,
            }
            if region_path.exists():
                try:
                    region = Image.open(region_path).convert("L").point(lambda x: 255 if x >= 128 else 0, mode="L")
                    if region.size == mask.size:
                        rp = int(sum(region.histogram()[128:]))
                        inter = ImageChops.multiply(mask, region)
                        pp = int(sum(inter.histogram()[128:]))
                        blue = {
                            "region_pixels": rp,
                            "pore_pixels": pp,
                            "porosity_percent": (pp / rp * 100.0) if rp else None,
                        }
                except Exception:
                    pass

            mrows = measurement_by_stem.get(stem, [])
            lengths = sorted([r for r in mrows if r["type"] == "length"], key=lambda r: r["id"])
            widths = sorted([r for r in mrows if r["type"] == "width"], key=lambda r: r["id"])
            lv = [r["value_px"] for r in lengths]
            wv = [r["value_px"] for r in widths]
            lm = self._safe_mean(lv)
            wm = self._safe_mean(wv)
            ratio = (lm / wm) if (lm is not None and wm not in (None, 0)) else None

            roi_rows = sorted(roi_by_stem.get(stem, []), key=lambda r: r["roi_id"])
            roi_vals = [r["porosity_percent"] for r in roi_rows]

            images.append({
                "stem": stem,
                "mask_path": mask_path,
                "blue": blue,
                "roi_rows": roi_rows,
                "roi_mean": self._safe_mean(roi_vals),
                "roi_sd": self._safe_sd(roi_vals),
                "length_rows": lengths,
                "width_rows": widths,
                "mean_length_px": lm,
                "sd_length_px": self._safe_sd(lv),
                "mean_width_px": wm,
                "sd_width_px": self._safe_sd(wv),
                "ratio_from_means": ratio,
            })

        return {
            "root": root,
            "images": images,
            "calibration": calibration,
            "measurement_by_stem": measurement_by_stem,
            "roi_by_stem": roi_by_stem,
            "roi_csv": roi_csv,
        }

    def refresh_preview(self):
        if self.project_root is None:
            root = getattr(self.app.roi_calc, "project_root", None)
            if root:
                self.project_root = Path(root)
                self.path_var.set(f"项目文件夹：{self.project_root}")
            else:
                return

        data = self._collect_data()
        for item in self.tree.get_children():
            self.tree.delete(item)
        if not data or not data["images"]:
            self.status_var.set("没有找到 manual_masks 中的结果图片。")
            return

        for d in data["images"]:
            b = d["blue"]["porosity_percent"]
            self.tree.insert("", tk.END, values=(
                d["stem"],
                "--" if b is None else f"{b:.4f}",
                len(d["roi_rows"]),
                "--" if d["roi_mean"] is None else f"{d['roi_mean']:.4f}",
                len(d["length_rows"]),
                "--" if d["mean_length_px"] is None else f"{d['mean_length_px']:.2f}",
                len(d["width_rows"]),
                "--" if d["mean_width_px"] is None else f"{d['mean_width_px']:.2f}",
                "--" if d["ratio_from_means"] is None else f"{d['ratio_from_means']:.3f}",
            ))

        cal = data["calibration"]
        ctext = (
            f"Calibration: 1 px = {cal['unit_per_px']:.6g} {cal['unit']}"
            if cal else "Calibration: none"
        )
        self.status_var.set(f"检测到 {len(data['images'])} 张结果图。{ctext}")

    @staticmethod
    def _style_sheet(ws):
        if ws.max_row >= 1:
            for cell in ws[1]:
                cell.font = Font(bold=True)
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
        for col_cells in ws.columns:
            letter = col_cells[0].column_letter
            max_len = 0
            for cell in col_cells[:200]:
                try:
                    max_len = max(max_len, len(str(cell.value)) if cell.value is not None else 0)
                except Exception:
                    pass
            ws.column_dimensions[letter].width = min(max(max_len + 2, 10), 34)

    def generate_report(self):
        if self.project_root is None:
            messagebox.showwarning("没有项目", "请先选择项目文件夹。")
            return
        if Workbook is None:
            messagebox.showerror("缺少 openpyxl", "请先运行：pip install openpyxl")
            return

        data = self._collect_data()
        if not data or not data["images"]:
            messagebox.showwarning("没有结果", "未找到 manual_masks 中的结果图片。")
            return

        root = self.output_root or (self.project_root / "final_report")
        root.mkdir(parents=True, exist_ok=True)
        overlay_dir = root / "report_overlays"
        overlay_dir.mkdir(parents=True, exist_ok=True)

        xlsx_path = root / "porosity_final_report.xlsx"
        txt_path = root / "porosity_final_summary.txt"
        wb = Workbook()

        # README
        ws0 = wb.active
        ws0.title = "README"
        readme_rows = [
            ["Manual Pore Annotator v2.11 final report"],
            ["Yellow-region porosity", "pore pixels inside closed yellow region / pixels inside closed yellow region × 100%"],
            ["ROI porosity", "pore pixels inside recorded ROI / ROI pixels × 100%"],
            ["Reference length", "horizontal projection |x2-x1|; comparative/theoretical length"],
            ["Reference width", "vertical projection |y2-y1|; comparative/theoretical width"],
            ["ROI shape", "width is automatically locked by mean reference L/W; user changes ROI length"],
            ["Calibration", "known physical scale / clicked pixel distance; optional batch conversion"],
        ]
        for row in readme_rows:
            ws0.append(row)
        ws0.column_dimensions["A"].width = 28
        ws0.column_dimensions["B"].width = 90

        calibration = data["calibration"]
        upp = calibration["unit_per_px"] if calibration else None
        unit = calibration["unit"] if calibration else ""

        # Combined image summary
        ws = wb.create_sheet("image_summary")
        headers = [
            "image_name",
            "blue_region_porosity_percent",
            "n_roi", "mean_roi_porosity_percent", "sd_roi_porosity_percent",
            "n_length", "mean_length_px", "sd_length_px",
            "n_width", "mean_width_px", "sd_width_px",
            "ratio_from_means",
            f"mean_length_{unit}" if unit else "mean_length_calibrated",
            f"mean_width_{unit}" if unit else "mean_width_calibrated",
            "calibration_unit", "unit_per_px",
        ]
        ws.append(headers)
        for d in data["images"]:
            ws.append([
                d["stem"], d["blue"]["porosity_percent"],
                len(d["roi_rows"]), d["roi_mean"], d["roi_sd"],
                len(d["length_rows"]), d["mean_length_px"], d["sd_length_px"],
                len(d["width_rows"]), d["mean_width_px"], d["sd_width_px"],
                d["ratio_from_means"],
                d["mean_length_px"] * upp if (upp is not None and d["mean_length_px"] is not None) else None,
                d["mean_width_px"] * upp if (upp is not None and d["mean_width_px"] is not None) else None,
                unit, upp,
            ])
        self._style_sheet(ws)

        # Blue region
        ws = wb.create_sheet("blue_region")
        ws.append([
            "image_name", "region_pixels", "pore_pixels_inside_region",
            "porosity_percent", "region_area_calibrated_sq", "pore_area_calibrated_sq", "unit_squared"
        ])
        for d in data["images"]:
            b = d["blue"]
            area_factor = upp * upp if upp is not None else None
            ws.append([
                d["stem"], b["region_pixels"], b["pore_pixels"], b["porosity_percent"],
                b["region_pixels"] * area_factor if (area_factor is not None and b["region_pixels"] is not None) else None,
                b["pore_pixels"] * area_factor if (area_factor is not None and b["pore_pixels"] is not None) else None,
                f"{unit}^2" if unit else "",
            ])
        self._style_sheet(ws)

        # ROI records and summary
        ws = wb.create_sheet("ROI_records")
        ws.append([
            "image_name", "roi_id", "x", "y", "length_px", "width_px",
            "pore_pixels", "roi_pixels", "porosity_percent",
            f"length_{unit}" if unit else "length_calibrated",
            f"width_{unit}" if unit else "width_calibrated",
        ])
        for d in data["images"]:
            for r in d["roi_rows"]:
                ws.append([
                    d["stem"], r["roi_id"], r["x"], r["y"], r["width"], r["height"],
                    r["pore_pixels"], r["roi_pixels"], r["porosity_percent"],
                    r["width"] * upp if upp is not None else None,
                    r["height"] * upp if upp is not None else None,
                ])
        self._style_sheet(ws)

        ws = wb.create_sheet("ROI_summary")
        ws.append(["image_name", "n_roi", "mean_porosity_percent", "sd_porosity_percent"])
        for d in data["images"]:
            ws.append([d["stem"], len(d["roi_rows"]), d["roi_mean"], d["roi_sd"]])
        self._style_sheet(ws)

        # Strand single measurements paired by id
        ws = wb.create_sheet("strand_measurements")
        ws.append([
            "image_name", "reference_id",
            "length_px", "width_px", "length_over_width",
            f"length_{unit}" if unit else "length_calibrated",
            f"width_{unit}" if unit else "width_calibrated",
            "unit"
        ])
        for d in data["images"]:
            ldict = {r["id"]: r["value_px"] for r in d["length_rows"]}
            wdict = {r["id"]: r["value_px"] for r in d["width_rows"]}
            ids = sorted(set(ldict) | set(wdict))
            for i in ids:
                lv = ldict.get(i)
                wv = wdict.get(i)
                ratio = lv / wv if (lv is not None and wv not in (None, 0)) else None
                ws.append([
                    d["stem"], i, lv, wv, ratio,
                    lv * upp if (upp is not None and lv is not None) else None,
                    wv * upp if (upp is not None and wv is not None) else None,
                    unit,
                ])
        self._style_sheet(ws)

        ws = wb.create_sheet("strand_summary")
        ws.append([
            "image_name",
            "n_length", "mean_length_px", "sd_length_px",
            "n_width", "mean_width_px", "sd_width_px",
            "ratio_from_means",
            f"mean_length_{unit}" if unit else "mean_length_calibrated",
            f"sd_length_{unit}" if unit else "sd_length_calibrated",
            f"mean_width_{unit}" if unit else "mean_width_calibrated",
            f"sd_width_{unit}" if unit else "sd_width_calibrated",
            "unit"
        ])
        for d in data["images"]:
            ws.append([
                d["stem"],
                len(d["length_rows"]), d["mean_length_px"], d["sd_length_px"],
                len(d["width_rows"]), d["mean_width_px"], d["sd_width_px"],
                d["ratio_from_means"],
                d["mean_length_px"] * upp if (upp is not None and d["mean_length_px"] is not None) else None,
                d["sd_length_px"] * upp if (upp is not None and d["sd_length_px"] is not None) else None,
                d["mean_width_px"] * upp if (upp is not None and d["mean_width_px"] is not None) else None,
                d["sd_width_px"] * upp if (upp is not None and d["sd_width_px"] is not None) else None,
                unit,
            ])
        self._style_sheet(ws)

        # Calibration
        ws = wb.create_sheet("calibration")
        ws.append(["source_image", "known_value", "unit", "pixel_distance_px", "unit_per_px"])
        if calibration:
            ws.append([
                calibration["source_image"], calibration["known_value"], calibration["unit"],
                calibration["pixel_distance"], calibration["unit_per_px"]
            ])
        self._style_sheet(ws)

        wb.save(xlsx_path)

        # Human-readable summary + QC overlays
        lines = ["Manual Pore Annotator v2.11 — Final Summary", "=" * 56, ""]
        if calibration:
            lines.extend([
                f"Calibration: {calibration['known_value']:g} {unit} = {calibration['pixel_distance']:.3f} px",
                f"1 px = {upp:.9g} {unit}", ""
            ])
        else:
            lines.extend(["Calibration: none (pixel results only)", ""])

        for d in data["images"]:
            lines.append(f"Image: {d['stem']}")
            b = d["blue"]["porosity_percent"]
            lines.append(f"  Yellow-region porosity: {'--' if b is None else f'{b:.4f} %'}")
            if d["roi_mean"] is None:
                lines.append("  ROI porosity: no recorded ROI")
            else:
                sd_txt = "--" if d["roi_sd"] is None else f"{d['roi_sd']:.4f} %"
                lines.append(f"  ROI porosity: N={len(d['roi_rows'])}, Mean={d['roi_mean']:.4f} %, SD={sd_txt}")
            ltxt = "--" if d["mean_length_px"] is None else f"{d['mean_length_px']:.3f} px"
            wtxt = "--" if d["mean_width_px"] is None else f"{d['mean_width_px']:.3f} px"
            if upp is not None and d["mean_length_px"] is not None:
                ltxt += f" = {d['mean_length_px']*upp:.4f} {unit}"
            if upp is not None and d["mean_width_px"] is not None:
                wtxt += f" = {d['mean_width_px']*upp:.4f} {unit}"
            lines.append(f"  Mean length: {ltxt} (N={len(d['length_rows'])})")
            lines.append(f"  Mean width:  {wtxt} (N={len(d['width_rows'])})")
            ratio_txt = "--" if d["ratio_from_means"] is None else f"{d['ratio_from_means']:.4f}"
            lines.append(f"  L/W from means: {ratio_txt}")
            lines.append("")

            ann = self.project_root / "manual_annotations" / f"{d['stem']}_annotation.png"
            try:
                if ann.exists():
                    base = Image.open(ann).convert("RGB")
                else:
                    base = Image.open(d["mask_path"]).convert("RGB")
                draw = ImageDraw.Draw(base)
                for r in d["roi_rows"]:
                    x, y, w, h = r["x"], r["y"], r["width"], r["height"]
                    draw.rectangle([x, y, x+w, y+h], outline=(0, 180, 0), width=3)
                    draw.text((x+4, y+4), f"ROI{r['roi_id']} {r['porosity_percent']:.3f}%", fill=(0, 180, 0))
                base.save(overlay_dir / f"{d['stem']}_final_overlay.png", format="PNG")
            except Exception:
                pass

        txt_path.write_text("\n".join(lines), encoding="utf-8")

        self.refresh_preview()
        self.status_var.set(f"最终报告已生成：{xlsx_path}")
        messagebox.showinfo(
            "最终报告完成",
            f"Excel:\n{xlsx_path}\n\n"
            f"Summary:\n{txt_path}\n\n"
            f"QC overlays:\n{overlay_dir}"
        )



# ============================================================
# v2.8 LEGACY STAGED FRONTEND (overridden by v2.11 below)
# ============================================================

class StagedAnnotatorFrame(AnnotatorFrame):
    """
    v2.11 staged workflow.

    ① 标尺校准（可跳过）
    ② 尺寸/面积测量：日志与图上显示彻底分离；可按组隐藏/恢复；锁定时生成快照
    ③ 图层标注：拖动自由圈选填充 + 蓝色自由参考线 + 黄色正交计算边界 + 对象选择删除 + 一键预览 + 手动保存
    """

    def __init__(self, parent, app):
        self.workspace = "calibrate"
        self.measure_area_points = []

        self.measurement_locked_by_image = {}
        self.measurement_lock_snapshots_by_image = {}
        self.measurement_lock_loaded_root = None

        # 仅控制“图上显示”，绝不删除右侧日志/CSV。
        self.measurement_hidden_kinds_by_image = {}
        self.measurement_visibility_phase_by_image = {}   # hide / show

        # 图层预览只影响屏幕显示，不自动写文件。
        self.layer_preview_only = False

        # v2.8 measurement-view alignment.
        # The raw image is never rewritten. Each image can store one small view rotation
        # that is used only in Step 2, before Length/Width measurements are made.
        self.rotation_angles_by_image = {}
        self.rotation_loaded_root = None
        self.alignment_active = False
        self.alignment_dragging = False
        self.alignment_drag_start_x = None
        self.alignment_drag_start_angle = 0.0
        self._display_cache_key = None
        self._display_cache_image = None

        # 黄色边界：严格正交矩形。
        # P1 任意；P2 自动锁定与 P1 同 y；P3 自动锁定与 P2 同 x；
        # 第四次点击无论在哪里，P4 自动取 (P1.x, P3.y) 并闭合。
        self.boundary_hover = None

        # ③ 图层对象选择 / 删除：
        # red pore = mask 的连通区域；blue guide = guide 的连通区域；
        # yellow boundary = 当前整套计算边界 + region。
        self.selected_object = None

        super().__init__(parent, app)

        # 仅 staged 版本使用的快捷键。
        self.canvas.bind("<KeyPress-s>", lambda e: self.set_mode("select"))
        self.canvas.bind("<Delete>", lambda e: self.delete_selected_object())

    # ========================================================
    # UI
    # ========================================================

    def _build_ui(self):
        common = ttk.Frame(self)
        common.pack(side=tk.TOP, fill=tk.X, padx=7, pady=(6, 3))
        self.common_bar = common

        ttk.Button(common, text="打开图片", command=self.open_image_dialog).pack(side=tk.LEFT, padx=2)
        ttk.Button(common, text="打开文件夹", command=self.open_folder_dialog).pack(side=tk.LEFT, padx=2)
        ttk.Button(common, text="移除当前图片", command=self.close_current_image).pack(side=tk.LEFT, padx=2)
        ttk.Button(common, text="输出目录", command=self.choose_output_folder).pack(side=tk.LEFT, padx=2)
        ttk.Button(common, text="上一张", command=self.prev_image).pack(side=tk.LEFT, padx=(10, 2))
        ttk.Button(common, text="下一张", command=self.next_image).pack(side=tk.LEFT, padx=2)

        ttk.Separator(common, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=8)
        ttk.Button(common, text="适应窗口", command=self.fit_to_window).pack(side=tk.LEFT, padx=2)
        ttk.Button(common, text="100%", command=self.zoom_100).pack(side=tk.LEFT, padx=2)

        ttk.Separator(common, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=7)
        ttk.Label(common, text="显示对比度:").pack(side=tk.LEFT, padx=(0, 3))
        self.contrast_scale = ttk.Scale(
            common, from_=0.35, to=2.50, variable=self.contrast_var,
            command=self._contrast_changed, length=125
        )
        self.contrast_scale.pack(side=tk.LEFT, padx=2)
        ttk.Label(common, textvariable=self.contrast_label_var, width=12).pack(side=tk.LEFT, padx=(2, 2))
        ttk.Button(common, text="重置", command=self.reset_contrast).pack(side=tk.LEFT, padx=(0, 5))

        self.stage_hint_var = tk.StringVar(value="")
        ttk.Label(
            common, textvariable=self.stage_hint_var,
            anchor=tk.E, font=("Segoe UI", 9, "bold")
        ).pack(side=tk.RIGHT, padx=6)

        self.stage_host = ttk.Frame(self)
        self.stage_host.pack(side=tk.TOP, fill=tk.X, padx=7, pady=(0, 4))
        self.stage_host.columnconfigure(0, weight=1)

        self.cal_bar = ttk.LabelFrame(self.stage_host, text="① 标尺校准（可选）")
        self.measure_bar = ttk.LabelFrame(self.stage_host, text="② 尺寸 / 面积测量")
        self.annotate_bar = ttk.LabelFrame(self.stage_host, text="③ 图层标注")
        for f in (self.cal_bar, self.measure_bar, self.annotate_bar):
            f.grid(row=0, column=0, sticky="ew")

        # ① 标尺
        cb = self.cal_bar
        ttk.Label(cb, text="已知长度:").pack(side=tk.LEFT, padx=(8, 2), pady=5)
        self.cal_known_entry = ttk.Entry(cb, textvariable=self.calibration_known_var, width=9)
        self.cal_known_entry.pack(side=tk.LEFT, padx=(0, 3), pady=5)
        self.cal_unit_combo = ttk.Combobox(
            cb, textvariable=self.calibration_unit_var,
            values=("µm", "mm", "nm", "cm"), width=6, state="readonly"
        )
        self.cal_unit_combo.pack(side=tk.LEFT, padx=(0, 8), pady=5)
        ttk.Button(cb, text="点标尺两端并校准", command=self.start_calibration_mode).pack(side=tk.LEFT, padx=3, pady=4)
        ttk.Button(cb, text="解除尺寸锁定", command=self.unlock_calibration).pack(side=tk.LEFT, padx=3, pady=4)
        self.calibration_badge_var = tk.StringVar(value="○ 未校准：后续仍可按 px / px² 工作")
        ttk.Label(cb, textvariable=self.calibration_badge_var, font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=14, pady=5)

        # ② 测量：按钮少而明确；隐藏按钮只影响画布，不碰日志。
        mb = self.measure_bar
        ttk.Button(mb, text="测长度", command=lambda: self.set_mode("measure_length")).pack(side=tk.LEFT, padx=(8, 3), pady=4)
        ttk.Button(mb, text="测宽度", command=lambda: self.set_mode("measure_width")).pack(side=tk.LEFT, padx=3, pady=4)
        ttk.Button(mb, text="自由圈选面积", command=lambda: self.set_mode("measure_area")).pack(side=tk.LEFT, padx=3, pady=4)

        ttk.Separator(mb, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=7, pady=3)
        ttk.Button(mb, text="水平校正", command=self.start_alignment_mode).pack(side=tk.LEFT, padx=3, pady=4)
        ttk.Button(mb, text="确认角度", command=self.confirm_alignment).pack(side=tk.LEFT, padx=3, pady=4)
        ttk.Button(mb, text="恢复 0°", command=self.reset_alignment).pack(side=tk.LEFT, padx=3, pady=4)
        self.alignment_angle_var = tk.StringVar(value="旋转 0.0°")
        ttk.Label(mb, textvariable=self.alignment_angle_var, width=12, font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=(2, 6))

        ttk.Button(mb, text="隐藏 / 恢复显示", command=self.toggle_measurement_visibility_cycle).pack(side=tk.LEFT, padx=(6, 3), pady=4)
        self.measure_visibility_var = tk.StringVar(value="显示: 全部")
        ttk.Label(mb, textvariable=self.measure_visibility_var).pack(side=tk.LEFT, padx=(2, 8))

        ttk.Separator(mb, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=7, pady=3)
        ttk.Button(mb, text="锁定本图测量", command=self.lock_current_measurements).pack(side=tk.LEFT, padx=3, pady=4)
        ttk.Button(mb, text="解除锁定", command=self.unlock_current_measurements).pack(side=tk.LEFT, padx=3, pady=4)
        ttk.Button(mb, text="删除日志选中项", command=self.delete_selected_measurement).pack(side=tk.LEFT, padx=(8, 3), pady=4)
        ttk.Button(mb, text="清空本图", command=self.clear_measurements_current).pack(side=tk.LEFT, padx=3, pady=4)
        self.measure_lock_badge_var = tk.StringVar(value="○ 测量未锁定")
        ttk.Label(mb, textvariable=self.measure_lock_badge_var, font=("Segoe UI", 9, "bold")).pack(side=tk.RIGHT, padx=10)

        # ③ 图层：去掉点点式孔隙多边形；自由圈选按住拖动、松开即闭合填充。
        ab = self.annotate_bar
        tools = [
            ("画笔 [B]", "brush"),
            ("橡皮 [E]", "erase"),
            ("自由圈选填充 [F]", "freehand"),
            ("蓝色自由参考线 [L]", "line"),
            ("黄色正交计算边界 [G]", "boundary"),
            ("选择对象 [S]", "select"),
            ("平移 [M]", "pan"),
        ]
        for label, value in tools:
            ttk.Radiobutton(ab, text=label, variable=self.mode, value=value, command=self._mode_changed).pack(side=tk.LEFT, padx=2, pady=4)

        ttk.Label(ab, text="笔刷:").pack(side=tk.LEFT, padx=(8, 0))
        ttk.Spinbox(ab, from_=1, to=100, textvariable=self.brush_size, width=5).pack(side=tk.LEFT, padx=2)
        ttk.Label(ab, text="边界线宽:").pack(side=tk.LEFT, padx=(6, 0))
        ttk.Spinbox(ab, from_=1, to=30, textvariable=self.line_width, width=4).pack(side=tk.LEFT, padx=2)
        ttk.Button(ab, text="撤销", command=self.undo).pack(side=tk.LEFT, padx=(8, 2))
        ttk.Button(ab, text="重做", command=self.redo).pack(side=tk.LEFT, padx=2)
        ttk.Button(ab, text="删除选中", command=self.delete_selected_object).pack(side=tk.LEFT, padx=(8, 2))

        self.preview_btn_text = tk.StringVar(value="一键预览（去底图）")
        ttk.Button(ab, textvariable=self.preview_btn_text, command=self.toggle_layer_preview).pack(side=tk.RIGHT, padx=(3, 6), pady=4)
        ttk.Button(ab, text="保存", command=self.save_layers).pack(side=tk.RIGHT, padx=3, pady=4)

        # Main content
        self.content = ttk.Frame(self)
        self.content.pack(fill=tk.BOTH, expand=True)
        self.canvas = tk.Canvas(self.content, bg="#202020", highlightthickness=0, cursor="crosshair")
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.measure_log_frame = ttk.LabelFrame(self.content, text="实时测量日志")
        self.measure_log_frame.configure(width=345)
        self.measure_log_frame.pack_propagate(False)

        cols = ("type", "id", "pixel", "physical")
        self.measure_tree = ttk.Treeview(self.measure_log_frame, columns=cols, show="headings", selectmode="browse", height=18)
        self.measure_tree.heading("type", text="类型")
        self.measure_tree.heading("id", text="#")
        self.measure_tree.heading("pixel", text="像素值")
        self.measure_tree.heading("physical", text="换算值")
        self.measure_tree.column("type", width=72, anchor=tk.CENTER)
        self.measure_tree.column("id", width=38, anchor=tk.CENTER)
        self.measure_tree.column("pixel", width=95, anchor=tk.E)
        self.measure_tree.column("physical", width=120, anchor=tk.E)
        self.measure_tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=(5, 3))

        self.measure_summary_var = tk.StringVar(value="Length n=0 | Width n=0 | Area n=0 | L/W=--")
        ttk.Label(
            self.measure_log_frame, textvariable=self.measure_summary_var,
            justify=tk.LEFT, anchor=tk.W, font=("Segoe UI", 9, "bold"), wraplength=325
        ).pack(fill=tk.X, padx=7, pady=(2, 7))

        status = ttk.Frame(self)
        status.pack(side=tk.BOTTOM, fill=tk.X)
        self.status_var = tk.StringVar(value="请选择图片")
        ttk.Label(status, textvariable=self.status_var, anchor=tk.W).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=8, pady=3)
        self.zoom_var = tk.StringVar(value="Zoom: 100%")
        ttk.Label(status, textvariable=self.zoom_var).pack(side=tk.RIGHT, padx=8)

        self.set_workspace("calibrate")

    def set_workspace(self, which):
        self.workspace = which
        for f in (self.cal_bar, self.measure_bar, self.annotate_bar):
            f.grid_remove()
        self.measure_log_frame.pack_forget()

        # 去底图预览只属于③，进入其它页面自动恢复编辑底图，但不改变数据。
        if which != "annotate" and self.layer_preview_only:
            self.layer_preview_only = False
            self.preview_btn_text.set("一键预览（去底图）")

        if which == "calibrate":
            self.cal_bar.grid()
            self.stage_hint_var.set("Step 1 / 5 · 可跳过；校准后物理尺寸保持锁定")
            self.mode.set("calibrate")
        elif which == "measure":
            self.measure_bar.grid()
            self.measure_log_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(5, 7), pady=5)
            self.stage_hint_var.set("Step 2 / 5 · 可先水平校正再测量；旋转只改变测量视图，不改原图")
            if self.mode.get() not in ("measure_length", "measure_width", "measure_area", "pan"):
                self.mode.set("measure_length")
        else:
            self.annotate_bar.grid()
            self.stage_hint_var.set("Step 3 / 5 · 蓝线仅参考；黄色边界严格水平/垂直并参与计算；对象可选择删除")
            if self.mode.get() not in ("brush", "erase", "freehand", "line", "boundary", "select", "pan"):
                self.mode.set("freehand")

        self.measure_area_points = []
        self.measure_start = None
        self.measure_preview = None
        self.calibration_start = None
        self.calibration_preview = None
        self.boundary_hover = None
        self._mode_changed()
        self.refresh_measurement_log()
        self.refresh_lock_badges()
        self.refresh_measurement_visibility_badge()
        self.render()

    def _mode_changed(self):
        cursors = {
            "brush": "pencil", "erase": "dotbox", "freehand": "crosshair",
            "line": "pencil", "boundary": "crosshair", "select": "hand2",
            "pan": "fleur", "calibrate": "crosshair",
            "measure_length": "crosshair", "measure_width": "crosshair", "measure_area": "crosshair",
        }
        self.canvas.configure(cursor=cursors.get(self.mode.get(), "crosshair"))
        self.canvas.focus_set()
        self._update_status()

    def set_mode(self, mode):
        self.measure_area_points = []
        if mode != "boundary":
            self.boundary_hover = None
            self.boundary_points = []
        if mode != "select":
            self.selected_object = None
        super().set_mode(mode)

    # ========================================================
    # v2.8 Display contrast + measurement-view alignment
    # ========================================================

    def _contrast_changed(self, value=None):
        try:
            v = float(self.contrast_var.get())
        except Exception:
            v = 1.0
        v = clamp(v, 0.35, 5.00)
        self.contrast_var.set(v)
        self.contrast_label_var.set(f"对比度 {v:.2f}×")
        self._display_cache_key = None
        self.render()

    def reset_contrast(self):
        self.contrast_var.set(1.0)
        self.contrast_label_var.set("对比度 1.00×")
        self._display_cache_key = None
        self.render()
        self._update_status("显示对比度已恢复 1.00×；原始图像从未被修改")

    def _rotation_path(self):
        _, _, _, _, measurement_dir, _ = self._annotation_output_dirs()
        measurement_dir.mkdir(parents=True, exist_ok=True)
        return measurement_dir / "view_rotation.csv"

    def _load_rotation_angles(self):
        try:
            path = self._rotation_path()
        except Exception:
            return
        root = str(path.parent.resolve())
        if self.rotation_loaded_root == root:
            return
        self.rotation_loaded_root = root
        self.rotation_angles_by_image = {}
        if not path.exists():
            return
        try:
            with path.open("r", newline="", encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    name = (r.get("image_name") or "").strip()
                    if not name:
                        continue
                    try:
                        a = float(r.get("rotation_deg", 0) or 0)
                    except Exception:
                        a = 0.0
                    self.rotation_angles_by_image[name] = clamp(a, -45.0, 45.0)
        except Exception:
            self.rotation_angles_by_image = {}

    def _save_rotation_angles(self):
        path = self._rotation_path()
        with path.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["image_name", "rotation_deg", "note"])
            for name in sorted(self.rotation_angles_by_image):
                w.writerow([
                    name, f"{float(self.rotation_angles_by_image.get(name, 0.0)):.6f}",
                    "Display/measurement alignment only; source image unchanged."
                ])

    def _current_rotation_angle(self):
        self._load_rotation_angles()
        key = self._measurement_key()
        if not key:
            return 0.0
        try:
            return float(self.rotation_angles_by_image.get(key, 0.0))
        except Exception:
            return 0.0

    def _refresh_alignment_badge(self):
        if hasattr(self, "alignment_angle_var"):
            self.alignment_angle_var.set(f"旋转 {self._current_rotation_angle():+.1f}°")

    def _alignment_edit_allowed(self):
        if not self.image_path:
            messagebox.showwarning("没有图片", "请先打开要校正的图片。")
            return False
        recs = self._measurement_records()
        if recs:
            messagebox.showinfo(
                "已有测量记录",
                "水平校正必须在本图正式测量之前完成。\n"
                "当前已有测量记录，为避免旧测量线与新坐标方向错位，角度不会改变。\n\n"
                "如需重新校正，请先清空本图测量。"
            )
            return False
        return True

    def start_alignment_mode(self):
        if self.workspace != "measure":
            return
        if not self._alignment_edit_allowed():
            return
        self.alignment_active = True
        self.alignment_dragging = False
        self._refresh_alignment_badge()
        self.render()
        self._update_status("水平校正：按住图片左右拖动旋转；让样条与中央水平线平行，然后点击“确认角度”")

    def confirm_alignment(self):
        if not self.image_path:
            return
        self.alignment_active = False
        self.alignment_dragging = False
        self.alignment_drag_start_x = None
        self._save_rotation_angles()
        self._refresh_alignment_badge()
        self.render()
        self._update_status(f"水平校正已确认：{self._current_rotation_angle():+.2f}°；原图未修改")

    def reset_alignment(self):
        if self.workspace != "measure":
            return
        if not self._alignment_edit_allowed():
            return
        key = self._measurement_key()
        if not key:
            return
        self.rotation_angles_by_image[key] = 0.0
        self.alignment_active = False
        self.alignment_dragging = False
        self._display_cache_key = None
        self._save_rotation_angles()
        self._refresh_alignment_badge()
        self.render()
        self._update_status("本图测量视图已恢复 0°；原图未修改")

    def _display_original_for_workspace(self):
        if self.original is None:
            return None
        try:
            contrast = float(self.contrast_var.get())
        except Exception:
            contrast = 1.0
        contrast = clamp(contrast, 0.35, 5.00)
        angle = self._current_rotation_angle() if self.workspace == "measure" else 0.0
        key = (
            str(self.image_path) if self.image_path else "",
            round(contrast, 3), round(angle, 3), self.workspace
        )
        if self._display_cache_key == key and self._display_cache_image is not None:
            return self._display_cache_image

        img = self.original
        if abs(contrast - 1.0) > 1e-6:
            img = ImageEnhance.Contrast(img).enhance(contrast)
        else:
            img = img.copy()
        if self.workspace == "measure" and abs(angle) > 1e-6:
            img = img.rotate(
                angle, resample=Image.Resampling.BICUBIC, expand=False,
                fillcolor=(32, 32, 32)
            )
        self._display_cache_key = key
        self._display_cache_image = img
        return img

    def _draw_alignment_guide(self):
        if self.workspace != "measure" or not self.alignment_active or self.original is None:
            return
        cy = self.canvas.winfo_height() / 2
        cw = self.canvas.winfo_width()
        self.canvas.create_line(20, cy, max(21, cw-20), cy, fill="#00e5ff", width=2, dash=(10, 5))
        self.canvas.create_text(
            cw/2, cy-10, text=f"水平参考 · {self._current_rotation_angle():+.2f}°",
            fill="#00e5ff", anchor=tk.S, font=("Segoe UI", 10, "bold")
        )

    # ========================================================
    # Current image lifecycle
    # ========================================================

    def close_current_image(self):
        """
        只把当前图片从画布关闭。
        不删除源文件，不删除 calibration，不删除测量日志，也不删除已锁定的 L/W 快照。
        """
        if self.image_path is None:
            return

        current_name = self.image_path.name

        # 测量数据先持久化；图层仍然遵循“不自动保存”。
        try:
            self._save_measurements_csv()
            self._save_measurement_locks()
            if self.calibration:
                self._save_calibration()
            self._save_rotation_angles()
        except Exception:
            pass

        if self.dirty:
            if not messagebox.askyesno(
                "移除当前图片",
                "当前图片存在尚未保存的图层修改。\n"
                "移除图片只会放弃这些未保存图层；测量日志、尺寸锁定和标尺校准都保留。\n\n"
                "仍然移除吗？"
            ):
                return

        self.image_path = None
        self.original = None
        self.mask = None
        self.guide = None
        self.region = None
        self.boundary = None
        self.tk_img = None
        self.img_w = 0
        self.img_h = 0
        self.image_index = -1

        self.stroke_last_img = None
        self.line_last_img = None
        self.freehand_points = []
        self.polygon_points = []
        self.boundary_points = []
        self.boundary_hover = None
        self.measure_start = None
        self.measure_preview = None
        self.measure_area_points = []
        self.calibration_start = None
        self.calibration_preview = None
        self.selected_object = None
        self.alignment_active = False
        self.alignment_dragging = False
        self.alignment_drag_start_x = None
        self._display_cache_key = None
        self._display_cache_image = None

        self.undo_stack.clear()
        self.redo_stack.clear()
        self.dirty = False
        self.layer_preview_only = False
        if hasattr(self, "preview_btn_text"):
            self.preview_btn_text.set("一键预览（去底图）")

        self.canvas.delete("all")
        self.refresh_measurement_log()
        self.refresh_lock_badges()
        self.refresh_measurement_visibility_badge()
        self._update_status(
            f"已从画布移除 {current_name}；测量日志 / 尺寸锁定 / 标尺校准均保留"
        )
        try:
            self.app.refresh_global_state()
        except Exception:
            pass

    # ========================================================
    # Output-folder migration
    # ========================================================

    def choose_output_folder(self):
        initial = self.output_root or self.input_folder or DEFAULT_FOLDER
        folder = filedialog.askdirectory(title="选择项目输出文件夹", initialdir=str(initial))
        if not folder:
            return

        # 保留当前内存日志；切换根目录后把内部日志/锁定/标尺同步到新项目目录。
        mem_measure = {k: [dict(r) for r in v] for k, v in self.measurements_by_image.items()}
        mem_locks = dict(self.measurement_locked_by_image)
        mem_snaps = {k: dict(v) for k, v in self.measurement_lock_snapshots_by_image.items()}
        mem_rot = dict(self.rotation_angles_by_image)
        cal = dict(self.calibration) if self.calibration else None

        self.output_root = Path(folder)
        _, _, _, _, mdir, _ = self._annotation_output_dirs()
        mdir.mkdir(parents=True, exist_ok=True)
        self.measurements_loaded_root = str(mdir.resolve())
        self.measurement_lock_loaded_root = str(mdir.resolve())
        self.calibration_loaded_root = str(mdir.resolve())
        self.rotation_loaded_root = str(mdir.resolve())

        self.measurements_by_image = mem_measure
        self.measurement_locked_by_image = mem_locks
        self.measurement_lock_snapshots_by_image = mem_snaps
        self.rotation_angles_by_image = mem_rot
        self.calibration = cal

        if self.image_path:
            self._save_measurements_csv()
            self._save_measurement_locks()
            if self.calibration:
                try:
                    self._save_calibration()
                except Exception:
                    pass
            try:
                self._save_rotation_angles()
            except Exception:
                pass
        self._update_status(f"输出目录：{self.output_root}")

    # ========================================================
    # ① Calibration lock
    # ========================================================

    def start_calibration_mode(self):
        if self.calibration:
            messagebox.showinfo("尺寸已锁定", "当前项目已经完成标尺校准。\n如需重新校准，请先在①中点击“解除尺寸锁定”。")
            return
        self.set_mode("calibrate")
        self._update_status("请输入标尺值/单位，然后依次点击标尺两个端点")

    def _calibration_click(self, ix, iy):
        if self.calibration:
            messagebox.showinfo("尺寸已锁定", "请先在① 标尺校准页面解除尺寸锁定。")
            return
        before = self.calibration
        super()._calibration_click(ix, iy)
        if before is None and self.calibration is not None:
            self.refresh_lock_badges()
            self.refresh_measurement_log()
            try:
                self.app.refresh_global_state()
            except Exception:
                pass

    def _draw_calibration_overlay(self):
        # 校准线只在①显示，避免污染后续画面。
        if self.workspace != "calibrate":
            return
        super()._draw_calibration_overlay()

    def unlock_calibration(self):
        if not self.calibration:
            messagebox.showinfo("提示", "当前项目没有已锁定的标尺校准。")
            return
        if not messagebox.askyesno("解除尺寸锁定", "解除后物理单位换算取消，但 px / px² 原始测量仍保留。\n确定解除吗？"):
            return
        try:
            p = self._calibration_csv_path()
            if p.exists():
                p.unlink()
        except Exception:
            pass
        self.calibration = None
        self.calibration_start = None
        self.calibration_preview = None
        self.calibration_loaded_root = None
        self._save_measurements_csv()
        self.refresh_lock_badges()
        self.refresh_measurement_log()
        self.render()
        self._update_status("尺寸锁定已解除；后续按 px / px² 工作")
        try:
            self.app.refresh_global_state()
        except Exception:
            pass

    # ========================================================
    # ② Measurement lock snapshot
    # ========================================================

    def _measurement_lock_path(self):
        _, _, _, _, measurement_dir, _ = self._annotation_output_dirs()
        measurement_dir.mkdir(parents=True, exist_ok=True)
        return measurement_dir / "measurement_locks.csv"

    def _load_measurement_locks(self):
        try:
            path = self._measurement_lock_path()
        except Exception:
            return
        root = str(path.parent.resolve())
        if self.measurement_lock_loaded_root == root:
            return
        self.measurement_lock_loaded_root = root
        self.measurement_locked_by_image = {}
        self.measurement_lock_snapshots_by_image = {}
        if not path.exists():
            return
        try:
            with path.open("r", newline="", encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    name = r.get("image_name", "")
                    if not name:
                        continue
                    locked = str(r.get("locked", "1")).strip() not in ("0", "false", "False", "")
                    if not locked:
                        continue
                    self.measurement_locked_by_image[name] = True
                    def num(k, default=None):
                        try:
                            v = r.get(k, "")
                            return float(v) if v not in (None, "") else default
                        except Exception:
                            return default
                    def intval(k):
                        try:
                            return int(float(r.get(k, 0) or 0))
                        except Exception:
                            return 0
                    self.measurement_lock_snapshots_by_image[name] = {
                        "n_length": intval("n_length"),
                        "mean_length_px": num("mean_length_px"),
                        "sd_length_px": num("sd_length_px"),
                        "n_width": intval("n_width"),
                        "mean_width_px": num("mean_width_px"),
                        "sd_width_px": num("sd_width_px"),
                        "ratio_from_means": num("ratio_from_means"),
                        "n_area": intval("n_area"),
                        "mean_area_px2": num("mean_area_px2"),
                        "sd_area_px2": num("sd_area_px2"),
                    }
        except Exception:
            self.measurement_locked_by_image = {}
            self.measurement_lock_snapshots_by_image = {}

    def _save_measurement_locks(self):
        path = self._measurement_lock_path()
        with path.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow([
                "image_name", "locked",
                "n_length", "mean_length_px", "sd_length_px",
                "n_width", "mean_width_px", "sd_width_px", "ratio_from_means",
                "n_area", "mean_area_px2", "sd_area_px2"
            ])
            for name in sorted(self.measurement_locked_by_image):
                if not self.measurement_locked_by_image.get(name):
                    continue
                s = self.measurement_lock_snapshots_by_image.get(name, {})
                w.writerow([
                    name, 1,
                    s.get("n_length", 0), s.get("mean_length_px"), s.get("sd_length_px"),
                    s.get("n_width", 0), s.get("mean_width_px"), s.get("sd_width_px"), s.get("ratio_from_means"),
                    s.get("n_area", 0), s.get("mean_area_px2"), s.get("sd_area_px2"),
                ])

    def _is_measurement_locked(self):
        self._load_measurement_locks()
        key = self._measurement_key()
        return bool(key and self.measurement_locked_by_image.get(key, False))

    def _measurement_edit_allowed(self, popup=True):
        if self._is_measurement_locked():
            if popup:
                messagebox.showinfo("测量已锁定", "当前图片的测量数据已锁定。\n若要修改，请先在②中解除锁定。")
            return False
        return True

    @staticmethod
    def _stats(vals):
        if not vals:
            return None, None
        return statistics.mean(vals), statistics.stdev(vals) if len(vals) >= 2 else None

    def lock_current_measurements(self):
        if not self.image_path:
            messagebox.showwarning("没有图片", "请先打开要测量的图片。")
            return
        recs = self._measurement_records()
        lv = [r["value_px"] for r in recs if r.get("kind") == "length"]
        wv = [r["value_px"] for r in recs if r.get("kind") == "width"]
        av = [r["value_px"] for r in recs if r.get("kind") == "area"]
        if not (lv or wv or av):
            messagebox.showwarning("没有测量", "当前图片还没有任何测量记录。")
            return
        if min(len(lv), len(wv)) < 5:
            if not messagebox.askyesno("测量次数较少", f"当前长度 N={len(lv)}，宽度 N={len(wv)}。\n建议长度和宽度各至少 5 次。\n仍然锁定吗？"):
                return

        lm, lsd = self._stats(lv)
        wm, wsd = self._stats(wv)
        am, asd = self._stats(av)
        ratio = lm / wm if (lm is not None and wm not in (None, 0)) else None
        key = self._measurement_key()
        self.measurement_locked_by_image[key] = True
        self.measurement_lock_snapshots_by_image[key] = {
            "n_length": len(lv), "mean_length_px": lm, "sd_length_px": lsd,
            "n_width": len(wv), "mean_width_px": wm, "sd_width_px": wsd,
            "ratio_from_means": ratio,
            "n_area": len(av), "mean_area_px2": am, "sd_area_px2": asd,
        }
        self._save_measurement_locks()
        self._save_measurements_csv()
        self.refresh_lock_badges()
        self.refresh_measurement_log()
        msg = "当前图片测量已锁定。"
        if ratio is not None:
            msg += f" ROI 比例快照 L/W = {ratio:.4f}，除非解除锁定并重新锁定，否则不会改变。"
        self._update_status(msg)
        try:
            self.app.refresh_global_state()
        except Exception:
            pass

    def unlock_current_measurements(self):
        if not self.image_path:
            return
        key = self._measurement_key()
        self._load_measurement_locks()
        if not self.measurement_locked_by_image.get(key, False):
            messagebox.showinfo("提示", "当前图片的测量数据尚未锁定。")
            return
        if not messagebox.askyesno("解除测量锁定", "解除后可以继续增加、删除或重测。\nROI 只有在再次锁定后才会使用新的平均比例。\n确定吗？"):
            return
        self.measurement_locked_by_image.pop(key, None)
        self.measurement_lock_snapshots_by_image.pop(key, None)
        self._save_measurement_locks()
        self._save_measurements_csv()
        self.refresh_lock_badges()
        self.refresh_measurement_log()
        try:
            self.app.refresh_global_state()
        except Exception:
            pass

    def refresh_lock_badges(self):
        if hasattr(self, "calibration_badge_var"):
            if self.calibration:
                c = self.calibration
                self.calibration_badge_var.set(
                    f"🔒 尺寸已锁定 · {c['known_value']:g} {c['unit']} = {c['pixel_distance']:.2f} px · 1 px = {c['unit_per_px']:.6g} {c['unit']}"
                )
            else:
                self.calibration_badge_var.set("○ 未校准：后续仍可按 px / px² 工作")

        if hasattr(self, "measure_lock_badge_var"):
            key = self._measurement_key()
            if key and self._is_measurement_locked():
                snap = self.measurement_lock_snapshots_by_image.get(key, {})
                r = snap.get("ratio_from_means")
                self.measure_lock_badge_var.set("🔒 测量已锁定" + (f" · L/W={r:.4f}" if r is not None else ""))
            else:
                self.measure_lock_badge_var.set("○ 测量未锁定")

    # ========================================================
    # Measurement visual hide / restore cycle
    # ========================================================

    def _hidden_kinds(self):
        key = self._measurement_key()
        if not key:
            return set()
        return self.measurement_hidden_kinds_by_image.setdefault(key, set())

    def refresh_measurement_visibility_badge(self):
        if not hasattr(self, "measure_visibility_var"):
            return
        hidden = self._hidden_kinds() if self.image_path else set()
        names = {"length": "长度", "width": "宽度", "area": "面积"}
        if not hidden:
            self.measure_visibility_var.set("显示: 全部")
        else:
            self.measure_visibility_var.set("已隐藏: " + "/".join(names[k] for k in ("length", "width", "area") if k in hidden))

    def toggle_measurement_visibility_cycle(self):
        if not self.image_path:
            return
        recs = self._measurement_records()
        order = [k for k in ("length", "width", "area") if any(r.get("kind") == k for r in recs)]
        if not order:
            messagebox.showinfo("提示", "当前图片还没有测量记录。")
            return
        key = self._measurement_key()
        hidden = self._hidden_kinds()
        phase = self.measurement_visibility_phase_by_image.get(key, "hide")
        names = {"length": "长度", "width": "宽度", "area": "面积"}

        if phase == "hide":
            visible = [k for k in order if k not in hidden]
            if visible:
                k = visible[0]
                hidden.add(k)
                self._update_status(f"已隐藏图上的{names[k]}测量；右侧日志仍保留")
            else:
                # 当前都已隐藏：从第一次隐藏的类型开始恢复。
                self.measurement_visibility_phase_by_image[key] = "show"
                k = next((x for x in order if x in hidden), None)
                if k:
                    hidden.remove(k)
                    self._update_status(f"已恢复图上的{names[k]}测量")
                    if not hidden:
                        self.measurement_visibility_phase_by_image[key] = "hide"
        else:  # show phase
            k = next((x for x in order if x in hidden), None)
            if k:
                hidden.remove(k)
                self._update_status(f"已恢复图上的{names[k]}测量")
            if not hidden:
                self.measurement_visibility_phase_by_image[key] = "hide"

        self.refresh_measurement_visibility_badge()
        self.render()

    # ========================================================
    # Measurement & free-area events
    # ========================================================

    @staticmethod
    def _serialize_points(points):
        return ";".join(f"{float(x):.3f}:{float(y):.3f}" for x, y in points)

    @staticmethod
    def _parse_points(s):
        pts = []
        if not s:
            return pts
        for item in str(s).split(";"):
            try:
                x, y = item.split(":", 1)
                pts.append((float(x), float(y)))
            except Exception:
                pass
        return pts

    def _measurement_click(self, ix, iy):
        if not self._measurement_edit_allowed():
            return
        super()._measurement_click(ix, iy)
        self.refresh_measurement_log()
        self.refresh_measurement_visibility_badge()

    def on_left_press(self, event):
        if self.original is None:
            return
        mode = self.mode.get()

        if self.workspace == "measure" and self.alignment_active:
            self.canvas.focus_set()
            self.alignment_dragging = True
            self.alignment_drag_start_x = event.x
            self.alignment_drag_start_angle = self._current_rotation_angle()
            return

        if mode == "measure_area":
            if not self._measurement_edit_allowed():
                return
            if self.space_down:
                self._start_left_pan(event)
                return
            p = self.screen_to_image(event.x, event.y)
            if p is None or not self.inside_image(*p):
                return
            self.measure_area_points = [p]
            self.canvas.focus_set()
            return

        if mode == "select":
            if self.space_down:
                self._start_left_pan(event)
                return
            p = self.screen_to_image(event.x, event.y)
            if p is None or not self.inside_image(*p):
                return
            self._select_layer_object_at(p[0], p[1])
            return

        if mode == "boundary":
            if self.space_down:
                self._start_left_pan(event)
                return
            p = self.screen_to_image(event.x, event.y)
            if p is None or not self.inside_image(*p):
                return
            ix, iy = p

            if not self.boundary_points:
                self.push_undo()
                self.boundary_points = [(ix, iy)]
                self.boundary_hover = (ix, iy)
                self._update_status("黄色边界 P1 已确定；第二点将自动锁为水平边")
                self.render()
                return

            if len(self.boundary_points) == 1:
                x1, y1 = self.boundary_points[0]
                p2 = (ix, y1)
                if abs(p2[0] - x1) < 1:
                    self._update_status("黄色边界宽度过小，请重新点第二点")
                    return
                self.boundary_points.append(p2)
                self.boundary_hover = p2
                self._update_status("P2 已锁定水平；第三点将自动锁为垂直边")
                self.render()
                return

            if len(self.boundary_points) == 2:
                x2, y2 = self.boundary_points[1]
                p3 = (x2, iy)
                if abs(p3[1] - y2) < 1:
                    self._update_status("黄色边界高度过小，请重新点第三点")
                    return
                self.boundary_points.append(p3)
                self.boundary_hover = (self.boundary_points[0][0], p3[1])
                self._update_status("P3 已锁定垂直；第四次点击任意位置即可自动生成 P4 并闭合")
                self.render()
                return

            # 第四次点击的鼠标位置不参与几何值：
            # P4 永远由 P1.x 与 P3.y 决定。
            if len(self.boundary_points) >= 3:
                p1 = self.boundary_points[0]
                p3 = self.boundary_points[2]
                p4 = (p1[0], p3[1])
                self.boundary_points = self.boundary_points[:3] + [p4]
                self._commit_yellow_boundary()
                return

        super().on_left_press(event)

    def on_left_drag(self, event):
        if self.alignment_dragging and self.workspace == "measure":
            if self.alignment_drag_start_x is None:
                return
            dx = event.x - self.alignment_drag_start_x
            angle = clamp(self.alignment_drag_start_angle + dx * 0.12, -45.0, 45.0)
            key = self._measurement_key()
            if key:
                self.rotation_angles_by_image[key] = float(angle)
            self._display_cache_key = None
            self._refresh_alignment_badge()
            self.render()
            return
        if self.left_pan_active:
            super().on_left_drag(event)
            return
        if self.mode.get() == "measure_area":
            p = self.screen_to_image(event.x, event.y)
            if p is None:
                return
            ix = clamp(p[0], 0, self.img_w-1)
            iy = clamp(p[1], 0, self.img_h-1)
            if not self.measure_area_points or abs(ix-self.measure_area_points[-1][0]) + abs(iy-self.measure_area_points[-1][1]) >= 1:
                self.measure_area_points.append((ix, iy))
                self.render()
            return
        if self.mode.get() == "boundary":
            return
        super().on_left_drag(event)

    def on_left_release(self, event):
        if self.alignment_dragging and self.workspace == "measure":
            self.alignment_dragging = False
            self.alignment_drag_start_x = None
            self._refresh_alignment_badge()
            self.render()
            self._update_status(f"当前校正角度 {self._current_rotation_angle():+.2f}°；满意后点击“确认角度”")
            return
        if self.left_pan_active:
            super().on_left_release(event)
            return
        if self.mode.get() == "measure_area":
            if not self.measure_area_points:
                return
            pts = self.measure_area_points
            self.measure_area_points = []
            if len(pts) < 3:
                self.render()
                self._update_status("面积圈选点太少，未记录")
                return
            tmp = Image.new("L", (self.img_w, self.img_h), 0)
            ImageDraw.Draw(tmp).polygon(pts, fill=255)
            area_px2 = int(tmp.histogram()[255])
            if area_px2 <= 0:
                self.render()
                return
            xs, ys = [p[0] for p in pts], [p[1] for p in pts]
            recs = self._measurement_records()
            aid = sum(1 for r in recs if r.get("kind") == "area") + 1
            recs.append({
                "kind": "area", "id": aid,
                "x1": float(min(xs)), "y1": float(min(ys)),
                "x2": float(max(xs)), "y2": float(max(ys)),
                "value_px": float(area_px2), "points": pts,
            })
            self._save_measurements_csv()
            self.refresh_measurement_log()
            self.refresh_measurement_visibility_badge()
            self.render()
            if self.calibration:
                av = area_px2 * (self.calibration["unit_per_px"] ** 2)
                self._update_status(f"已记录面积 A{aid}: {area_px2} px² = {av:.4f} {self.calibration['unit']}²")
            else:
                self._update_status(f"已记录面积 A{aid}: {area_px2} px²")
            return
        if self.mode.get() == "boundary":
            return
        super().on_left_release(event)

    def on_mouse_motion(self, event):
        super().on_mouse_motion(event)
        if self.mode.get() == "boundary" and self.boundary_points:
            p = self.screen_to_image(event.x, event.y)
            if p is not None:
                ix = clamp(p[0], 0, self.img_w-1)
                iy = clamp(p[1], 0, self.img_h-1)
                if len(self.boundary_points) == 1:
                    x1, y1 = self.boundary_points[0]
                    self.boundary_hover = (ix, y1)
                elif len(self.boundary_points) == 2:
                    x2, y2 = self.boundary_points[1]
                    self.boundary_hover = (x2, iy)
                else:
                    p1 = self.boundary_points[0]
                    p3 = self.boundary_points[2]
                    self.boundary_hover = (p1[0], p3[1])
                self.render()

    def on_double_left(self, event):
        if self.mode.get() == "boundary" and len(self.boundary_points) >= 3:
            p1 = self.boundary_points[0]
            p3 = self.boundary_points[2]
            self.boundary_points = self.boundary_points[:3] + [(p1[0], p3[1])]
            self._commit_yellow_boundary()
            return
        super().on_double_left(event)

    def on_right_press(self, event):
        if self.mode.get() == "measure_area":
            self.measure_area_points = []
            self.render()
            self._update_status("已取消当前面积圈选")
            return
        if self.mode.get() == "boundary":
            self.boundary_points = []
            self.boundary_hover = None
            self.render()
            self._update_status("已取消当前黄色边界")
            return
        super().on_right_press(event)

    def _commit_yellow_boundary(self):
        if len(self.boundary_points) < 3:
            return

        p1 = self.boundary_points[0]
        p2_raw = self.boundary_points[1]
        p3_raw = self.boundary_points[2]

        # 无论实际点击有多歪，正式几何始终为严格正交矩形。
        p2 = (p2_raw[0], p1[1])
        p3 = (p2[0], p3_raw[1])
        p4 = (p1[0], p3[1])

        if abs(p2[0] - p1[0]) < 1 or abs(p3[1] - p2[1]) < 1:
            self._update_status("黄色边界尺寸过小，未建立")
            self.boundary_points = []
            self.boundary_hover = None
            self.render()
            return

        clean = [p1, p2, p3, p4]

        self.region = Image.new("L", (self.img_w, self.img_h), 0)
        self.boundary = Image.new("L", (self.img_w, self.img_h), 0)
        ImageDraw.Draw(self.region).polygon(clean, fill=255)
        ImageDraw.Draw(self.boundary).line(
            clean + [clean[0]],
            fill=255,
            width=max(1, int(self.line_width.get()))
        )

        self.boundary_points = []
        self.boundary_hover = None
        self.selected_object = None
        self.dirty = True
        self.render()
        self._update_status("黄色正交计算边界已建立；仅该区域参与整体孔隙率计算")

    def _draw_boundary_preview(self):
        if not self.boundary_points:
            return

        # 已确认的点。
        pts_screen = [self.image_to_screen(*p) for p in self.boundary_points]
        if len(pts_screen) >= 2:
            flat = []
            for sx, sy in pts_screen:
                flat.extend([sx, sy])
            self.canvas.create_line(*flat, fill="#ffd700", width=2)

        for sx, sy in pts_screen:
            self.canvas.create_oval(sx-3, sy-3, sx+3, sy+3, fill="#ffd700", outline="")

        # 下一条边严格水平/垂直；有 3 点后 P4 已唯一确定。
        if self.boundary_hover is not None:
            last = self.boundary_points[-1]
            lx, ly = self.image_to_screen(*last)
            hx, hy = self.image_to_screen(*self.boundary_hover)
            self.canvas.create_line(lx, ly, hx, hy, fill="#ffd700", width=2, dash=(5, 3))

            if len(self.boundary_points) >= 3:
                fx, fy = self.image_to_screen(*self.boundary_points[0])
                self.canvas.create_line(hx, hy, fx, fy, fill="#ffd700", width=2, dash=(5, 3))

    # Enter 可在已有 P1/P2/P3 后直接自动生成 P4 并闭合。
    def commit_polygon(self):
        if self.mode.get() == "boundary":
            if len(self.boundary_points) >= 3:
                p1 = self.boundary_points[0]
                p3 = self.boundary_points[2]
                self.boundary_points = self.boundary_points[:3] + [(p1[0], p3[1])]
                self._commit_yellow_boundary()
            return
        # v2.8 no longer exposes pore-polygon point tool.

    # ========================================================
    # ③ Layer-object selection / deletion
    # ========================================================

    def _find_nonzero_seed(self, layer, ix, iy, radius_screen=8):
        if layer is None:
            return None
        x0 = int(round(ix))
        y0 = int(round(iy))
        radius = int(max(2, min(60, round(radius_screen / max(self.zoom, 1e-9)))))
        px = layer.load()
        best = None
        best_d2 = None
        for y in range(max(0, y0-radius), min(self.img_h, y0+radius+1)):
            for x in range(max(0, x0-radius), min(self.img_w, x0+radius+1)):
                if px[x, y] <= 0:
                    continue
                d2 = (x-x0)*(x-x0) + (y-y0)*(y-y0)
                if best_d2 is None or d2 < best_d2:
                    best = (x, y)
                    best_d2 = d2
        return best

    def _connected_component(self, layer, seed):
        if layer is None or seed is None:
            return None
        work = layer.copy().convert("L")
        if work.getpixel(seed) <= 0:
            return None
        # Pillow floodfill 将当前白色连通区临时改为 128，再提取该区域。
        ImageDraw.floodfill(work, seed, 128, thresh=0)
        comp = work.point(lambda p: 255 if p == 128 else 0, mode="L")
        return comp if comp.getbbox() else None

    def _select_layer_object_at(self, ix, iy):
        if self.workspace != "annotate" or self.original is None:
            return

        # 选择优先级：黄色边界线 > 蓝色参考线 > 红色孔隙 > 黄色区域内部。
        seed = self._find_nonzero_seed(self.boundary, ix, iy)
        if seed is not None:
            self.selected_object = {
                "kind": "boundary",
                "label": "黄色计算边界",
                "mask": self.boundary.copy(),
            }
            self.render()
            self._update_status("已选择：黄色计算边界；按 Delete 或点击“删除选中”")
            return

        seed = self._find_nonzero_seed(self.guide, ix, iy)
        if seed is not None:
            comp = self._connected_component(self.guide, seed)
            if comp is not None:
                self.selected_object = {
                    "kind": "guide",
                    "label": "蓝色参考线",
                    "mask": comp,
                }
                self.render()
                self._update_status("已选择：蓝色参考线；按 Delete 或点击“删除选中”")
                return

        x = int(clamp(round(ix), 0, self.img_w-1))
        y = int(clamp(round(iy), 0, self.img_h-1))
        if self.mask is not None and self.mask.getpixel((x, y)) > 0:
            comp = self._connected_component(self.mask, (x, y))
            if comp is not None:
                self.selected_object = {
                    "kind": "pore",
                    "label": "红色孔隙区域",
                    "mask": comp,
                }
                self.render()
                self._update_status("已选择：红色孔隙区域；按 Delete 或点击“删除选中”")
                return

        if self.region is not None and self.region.getpixel((x, y)) > 0:
            self.selected_object = {
                "kind": "boundary",
                "label": "黄色计算边界",
                "mask": self.boundary.copy(),
            }
            self.render()
            self._update_status("已选择：黄色计算区域；按 Delete 或点击“删除选中”")
            return

        self.selected_object = None
        self.render()
        self._update_status("当前位置没有可选择的图层对象")

    def delete_selected_object(self):
        if not self.selected_object or self.original is None:
            return

        kind = self.selected_object.get("kind")
        comp = self.selected_object.get("mask")
        label = self.selected_object.get("label", "对象")

        self.push_undo()

        if kind == "boundary":
            self.region = Image.new("L", (self.img_w, self.img_h), 0)
            self.boundary = Image.new("L", (self.img_w, self.img_h), 0)
            self.boundary_points = []
            self.boundary_hover = None
        elif kind == "guide" and comp is not None:
            self.guide = ImageChops.subtract(self.guide, comp)
        elif kind == "pore" and comp is not None:
            self.mask = ImageChops.subtract(self.mask, comp)
        else:
            if self.undo_stack:
                self.undo_stack.pop()
            return

        self.selected_object = None
        self.dirty = True
        self.render()
        self._update_status(f"已删除：{label}；日志 / 尺寸锁定不受影响")

    def _draw_selected_object_box(self):
        if not self.selected_object:
            return
        comp = self.selected_object.get("mask")
        if comp is None:
            return
        bbox = comp.getbbox()
        if not bbox:
            return
        x0, y0, x1, y1 = bbox
        sx0, sy0 = self.image_to_screen(x0, y0)
        sx1, sy1 = self.image_to_screen(x1, y1)
        self.canvas.create_rectangle(
            sx0, sy0, sx1, sy1,
            outline="#00ffff", width=2, dash=(6, 3)
        )
        self.canvas.create_text(
            sx0 + 4, sy0 - 4,
            text=self.selected_object.get("label", "已选择"),
            fill="#00ffff", anchor=tk.SW,
            font=("Segoe UI", 9, "bold")
        )

    def render(self):
        # Display transforms are deliberately temporary: all scientific layers and
        # the raw source stay in their original files/arrays.
        raw_original = self.original
        raw_mask = self.mask
        raw_guide = self.guide
        raw_region = self.region
        raw_boundary = self.boundary

        try:
            if raw_original is not None:
                self.original = self._display_original_for_workspace()

            # Step 2 is a geometry-measurement workspace. Suppress pore/guide/region
            # overlays here so that a rotated view can never be mistaken for rotated
            # scientific masks. Only the raw display is rotated; measurement values
            # are made in that aligned view before the measurement set is locked.
            if self.workspace == "measure" and raw_original is not None:
                blank = Image.new("L", raw_original.size, 0)
                self.mask = blank
                self.guide = blank
                self.region = blank
                self.boundary = blank

            super().render()
        finally:
            self.original = raw_original
            self.mask = raw_mask
            self.guide = raw_guide
            self.region = raw_region
            self.boundary = raw_boundary

        if self.workspace == "annotate":
            self._draw_selected_object_box()
        elif self.workspace == "measure":
            self._draw_alignment_guide()

    # ========================================================
    # Draw measurements only in ② and respect visual hidden groups
    # ========================================================

    def _draw_measurements_overlay(self):
        if self.workspace != "measure" or self.original is None:
            return
        key = self._measurement_key()
        recs = self.measurements_by_image.get(key, []) if key else []
        hidden = self._hidden_kinds()

        for r in recs:
            kind = r.get("kind")
            if kind in hidden:
                continue
            if kind == "area":
                pts = r.get("points") or []
                if len(pts) >= 3:
                    flat = []
                    for x, y in pts:
                        sx, sy = self.image_to_screen(x, y)
                        flat.extend([sx, sy])
                    flat.extend(flat[:2])
                    self.canvas.create_line(*flat, fill="#00ff88", width=2)
                    cx = sum(p[0] for p in pts) / len(pts)
                    cy = sum(p[1] for p in pts) / len(pts)
                    sx, sy = self.image_to_screen(cx, cy)
                    txt = f"A{r['id']}={r['value_px']:.0f}px²"
                    if self.calibration:
                        av = r["value_px"] * (self.calibration["unit_per_px"] ** 2)
                        txt += f" / {av:.3f}{self.calibration['unit']}²"
                    self.canvas.create_text(sx, sy, text=txt, fill="#00ff88", font=("Segoe UI", 9, "bold"))
                continue

            try:
                sx1, sy1 = self.image_to_screen(r["x1"], r["y1"])
                sx2, sy2 = self.image_to_screen(r["x2"], r["y2"])
            except Exception:
                continue
            color = "#ffd400" if kind == "length" else "#ff66ff"
            prefix = "L" if kind == "length" else "W"
            self.canvas.create_line(sx1, sy1, sx2, sy2, fill=color, width=3)
            self.canvas.create_oval(sx1-3, sy1-3, sx1+3, sy1+3, fill=color, outline="")
            self.canvas.create_oval(sx2-3, sy2-3, sx2+3, sy2+3, fill=color, outline="")
            label = f"{prefix}{r['id']}={r['value_px']:.1f}px"
            if self.calibration:
                cv = r["value_px"] * self.calibration["unit_per_px"]
                label += f" / {cv:.3f}{self.calibration['unit']}"
            self.canvas.create_text((sx1+sx2)/2, (sy1+sy2)/2-8, text=label, fill=color, anchor=tk.S, font=("Segoe UI", 9, "bold"))

        # 当前正在测量的预览线仍显示，便于继续工作。
        if self.measure_start is not None and self.measure_preview is not None and self.mode.get() in ("measure_length", "measure_width"):
            x1, y1 = self.measure_start
            x2, y2 = self.measure_preview
            if self.mode.get() == "measure_length":
                y2 = y1; value = abs(x2-x1); color = "#ffd400"; label = f"L={value:.1f}px"
            else:
                x2 = x1; value = abs(y2-y1); color = "#ff66ff"; label = f"W={value:.1f}px"
            sx1, sy1 = self.image_to_screen(x1, y1)
            sx2, sy2 = self.image_to_screen(x2, y2)
            self.canvas.create_line(sx1, sy1, sx2, sy2, fill=color, width=2, dash=(6,3))
            self.canvas.create_text((sx1+sx2)/2, (sy1+sy2)/2-8, text=label, fill=color, anchor=tk.S)

        if self.measure_area_points:
            flat = []
            for x, y in self.measure_area_points:
                sx, sy = self.image_to_screen(x, y)
                flat.extend([sx, sy])
            if len(flat) >= 4:
                self.canvas.create_line(*flat, fill="#00ff88", width=2)

    # ========================================================
    # Logs
    # ========================================================

    def _update_measurement_summary(self):
        recs = self._measurement_records() if self.image_path else []
        lengths = [r["value_px"] for r in recs if r.get("kind") == "length"]
        widths = [r["value_px"] for r in recs if r.get("kind") == "width"]
        areas = [r["value_px"] for r in recs if r.get("kind") == "area"]
        lm = statistics.mean(lengths) if lengths else None
        wm = statistics.mean(widths) if widths else None
        am = statistics.mean(areas) if areas else None
        ratio = lm / wm if (lm is not None and wm not in (None, 0)) else None

        def fmt_linear(v):
            if v is None: return "--"
            s = f"{v:.1f}px"
            if self.calibration:
                s += f" / {v*self.calibration['unit_per_px']:.3f}{self.calibration['unit']}"
            return s
        def fmt_area(v):
            if v is None: return "--"
            s = f"{v:.0f}px²"
            if self.calibration:
                s += f" / {v*(self.calibration['unit_per_px']**2):.3f}{self.calibration['unit']}²"
            return s

        self.measure_summary_var.set(
            f"Length: n={len(lengths)} mean={fmt_linear(lm)}\n"
            f"Width:  n={len(widths)} mean={fmt_linear(wm)}\n"
            f"Area:   n={len(areas)} mean={fmt_area(am)}\n"
            f"L/W from means: {'--' if ratio is None else f'{ratio:.4f}'}"
        )

    def refresh_measurement_log(self):
        if not hasattr(self, "measure_tree"):
            return
        if self.image_path:
            self.measure_log_frame.configure(text=f"实时测量日志 · {self.image_path.name}")
        else:
            self.measure_log_frame.configure(text="实时测量日志")
        for item in self.measure_tree.get_children():
            self.measure_tree.delete(item)
        recs = self._measurement_records() if self.image_path else []
        for r in recs:
            kind = r.get("kind")
            if kind == "length":
                typ = "Length"; px = f"{r['value_px']:.1f} px"
                physical = f"{r['value_px']*self.calibration['unit_per_px']:.3f} {self.calibration['unit']}" if self.calibration else "--"
            elif kind == "width":
                typ = "Width"; px = f"{r['value_px']:.1f} px"
                physical = f"{r['value_px']*self.calibration['unit_per_px']:.3f} {self.calibration['unit']}" if self.calibration else "--"
            else:
                typ = "Area"; px = f"{r['value_px']:.0f} px²"
                physical = f"{r['value_px']*(self.calibration['unit_per_px']**2):.3f} {self.calibration['unit']}²" if self.calibration else "--"
            iid = f"{kind}:{r.get('id',0)}"
            self.measure_tree.insert("", tk.END, iid=iid, values=(typ, r.get("id", ""), px, physical))
        self._update_measurement_summary()
        self.refresh_measurement_visibility_badge()

    def delete_selected_measurement(self):
        if not self._measurement_edit_allowed():
            return
        selected = self.measure_tree.selection()
        if not selected:
            messagebox.showinfo("提示", "请先在右侧日志中选择一条记录。")
            return
        try:
            kind, sid = selected[0].split(":", 1)
            rid = int(sid)
        except Exception:
            return
        recs = self._measurement_records()
        removed = False
        new = []
        for r in recs:
            if not removed and r.get("kind") == kind and int(r.get("id", 0)) == rid:
                removed = True
                continue
            new.append(r)
        counters = {"length": 0, "width": 0, "area": 0}
        for r in new:
            k = r.get("kind")
            counters[k] = counters.get(k, 0) + 1
            r["id"] = counters[k]
        self.measurements_by_image[self._measurement_key()] = new
        self._save_measurements_csv()
        self.refresh_measurement_log()
        self.render()

    def delete_last_measurement(self):
        if not self._measurement_edit_allowed():
            return
        super().delete_last_measurement()
        self.refresh_measurement_log()

    def clear_measurements_current(self):
        if not self._measurement_edit_allowed():
            return
        if not self.image_path:
            return
        recs = self._measurement_records()
        if not recs:
            return
        if messagebox.askyesno("确认", "清空当前图片的全部长度、宽度和面积测量？"):
            key = self._measurement_key()
            self.measurements_by_image[key] = []
            self.measurement_hidden_kinds_by_image[key] = set()
            self.measurement_visibility_phase_by_image[key] = "hide"
            self.measure_start = None
            self.measure_preview = None
            self.measure_area_points = []
            self._save_measurements_csv()
            self.refresh_measurement_log()
            self.render()

    # ========================================================
    # Extended measurement persistence
    # ========================================================

    def _load_all_measurements_if_needed(self):
        try:
            detail_path, _ = self._measurement_csv_paths()
        except Exception:
            return
        root = str(detail_path.parent.resolve())
        if self.measurements_loaded_root == root:
            key = self._measurement_key()
            if key and key not in self.measurements_by_image:
                self.measurements_by_image[key] = []
            return
        self.measurements_loaded_root = root
        self.measurements_by_image = {}
        if detail_path.exists():
            try:
                with detail_path.open("r", newline="", encoding="utf-8-sig") as f:
                    for row in csv.DictReader(f):
                        image_name = row.get("image_name", "")
                        if not image_name:
                            continue
                        kind = row.get("type", "")
                        try:
                            rec = {
                                "kind": kind,
                                "id": int(float(row.get("id", 0) or 0)),
                                "x1": float(row.get("x1", 0) or 0), "y1": float(row.get("y1", 0) or 0),
                                "x2": float(row.get("x2", 0) or 0), "y2": float(row.get("y2", 0) or 0),
                                "value_px": float(row.get("value_px", 0) or 0),
                            }
                        except Exception:
                            continue
                        if kind == "area":
                            rec["points"] = self._parse_points(row.get("points", ""))
                        self.measurements_by_image.setdefault(image_name, []).append(rec)
            except Exception:
                self.measurements_by_image = {}
        key = self._measurement_key()
        if key and key not in self.measurements_by_image:
            self.measurements_by_image[key] = []

    def _save_measurements_csv(self):
        if not self.image_path:
            return
        detail_path, summary_path = self._measurement_csv_paths()
        detail_path.parent.mkdir(parents=True, exist_ok=True)
        unit = self.calibration["unit"] if self.calibration else ""
        upp = self.calibration["unit_per_px"] if self.calibration else None

        with detail_path.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow([
                "image_name", "type", "id", "x1", "y1", "x2", "y2", "value_px", "points",
                "calibrated_value", "unit", "unit_per_px"
            ])
            for image_name in sorted(self.measurements_by_image):
                for r in self.measurements_by_image[image_name]:
                    kind = r.get("kind", "")
                    if upp is None:
                        cv = None
                    elif kind == "area":
                        cv = r["value_px"] * (upp ** 2)
                    else:
                        cv = r["value_px"] * upp
                    w.writerow([
                        image_name, kind, r.get("id", 0),
                        f"{r.get('x1',0):.3f}", f"{r.get('y1',0):.3f}",
                        f"{r.get('x2',0):.3f}", f"{r.get('y2',0):.3f}",
                        f"{r.get('value_px',0):.6f}",
                        self._serialize_points(r.get("points", [])) if kind == "area" else "",
                        "" if cv is None else f"{cv:.9f}", unit,
                        "" if upp is None else f"{upp:.12g}",
                    ])

        with summary_path.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow([
                "image_name", "n_length", "mean_length_px", "sd_length_px",
                "n_width", "mean_width_px", "sd_width_px", "ratio_from_means",
                "n_area", "mean_area_px2", "sd_area_px2",
                "mean_length_calibrated", "mean_width_calibrated", "mean_area_calibrated_sq",
                "unit", "unit_per_px", "measurement_locked"
            ])
            for image_name in sorted(self.measurements_by_image):
                recs = self.measurements_by_image[image_name]
                lv = [r["value_px"] for r in recs if r.get("kind") == "length"]
                wv = [r["value_px"] for r in recs if r.get("kind") == "width"]
                av = [r["value_px"] for r in recs if r.get("kind") == "area"]
                lm, lsd = self._stats(lv)
                wm, wsd = self._stats(wv)
                am, asd = self._stats(av)
                ratio = lm/wm if (lm is not None and wm not in (None,0)) else None
                w.writerow([
                    image_name, len(lv), lm, lsd, len(wv), wm, wsd, ratio,
                    len(av), am, asd,
                    lm*upp if (lm is not None and upp is not None) else None,
                    wm*upp if (wm is not None and upp is not None) else None,
                    am*(upp**2) if (am is not None and upp is not None) else None,
                    unit, upp, 1 if self.measurement_locked_by_image.get(image_name, False) else 0,
                ])

    # ========================================================
    # ③ One-click preview + deliberate save
    # ========================================================

    def _refresh_preview_button_text(self):
        if not hasattr(self,'zc_preview_txt'):
            return
        mode=int(getattr(self,'_zc_preview_mode',0))
        if mode==0:
            self.zc_preview_txt.set(self._t('预览孔区','Pore preview'))
        elif mode==1:
            self.zc_preview_txt.set(self._t('仅看原图','Original only'))
        else:
            self.zc_preview_txt.set(self._t('恢复全部','Restore all'))

    def _render_refine_preview(self):
        """
        Preview states:
          1 = white background + red pore mask only
          2 = original image only
        State 0 uses the normal full render.
        """
        self.canvas.delete('all')
        if self.original is None:
            return

        cw=max(1,self.canvas.winfo_width())
        ch=max(1,self.canvas.winfo_height())

        x0f=max(0.0,-self.pan_x/self.zoom)
        y0f=max(0.0,-self.pan_y/self.zoom)
        x1f=min(float(self.img_w),(cw-self.pan_x)/self.zoom)
        y1f=min(float(self.img_h),(ch-self.pan_y)/self.zoom)
        if x1f<=x0f or y1f<=y0f:
            return

        x0=max(0,int(x0f)); y0=max(0,int(y0f))
        x1=min(self.img_w,int(x1f+1)); y1=min(self.img_h,int(y1f+1))

        mode=int(getattr(self,'_zc_preview_mode',0))
        if mode==1:
            # White + red only. No yellow/blue/measurement/calibration overlays.
            base=Image.new('RGB',(x1-x0,y1-y0),(255,255,255))
            if self.mask is not None:
                m=self.mask.crop((x0,y0,x1,y1))
                red=Image.new('RGB',base.size,(255,0,0))
                base=Image.composite(red,base,m)
        else:
            # Pure bottom/original image only.
            base=self.original.crop((x0,y0,x1,y1))

        dw=max(1,int(round((x1-x0)*self.zoom)))
        dh=max(1,int(round((y1-y0)*self.zoom)))
        resample=Image.Resampling.LANCZOS if self.zoom<1 else Image.Resampling.BILINEAR
        disp=base.resize((dw,dh),resample)
        self.tk_img=ImageTk.PhotoImage(disp)

        sx=self.pan_x+x0*self.zoom
        sy=self.pan_y+y0*self.zoom
        self.canvas.create_image(sx,sy,image=self.tk_img,anchor=tk.NW)

        bx0,by0=self.image_to_screen(0,0)
        bx1,by1=self.image_to_screen(self.img_w,self.img_h)
        self.canvas.create_rectangle(bx0,by0,bx1,by1,outline='#777777',width=1)
        self.zoom_var.set(f'Zoom: {self.zoom*100:.0f}%')

    def render(self):
        # Display transforms are deliberately temporary: all scientific layers and
        # the raw source stay in their original files/arrays.
        raw_original = self.original
        raw_mask = self.mask
        raw_guide = self.guide
        raw_region = self.region
        raw_boundary = self.boundary

        try:
            if raw_original is not None:
                self.original = self._display_original_for_workspace()

            # Step 2 is a geometry-measurement workspace. Suppress pore/guide/region
            # overlays here so that a rotated view can never be mistaken for rotated
            # scientific masks. Only the display is rotated; the raw scientific
            # layers remain unchanged.
            if self.workspace == "measure" and raw_original is not None:
                blank = Image.new("L", raw_original.size, 0)
                self.mask = blank
                self.guide = blank
                self.region = blank
                self.boundary = blank

            super().render()
        finally:
            self.original = raw_original
            self.mask = raw_mask
            self.guide = raw_guide
            self.region = raw_region
            self.boundary = raw_boundary

        if self.workspace == "annotate":
            self._draw_selected_object_box()
        elif self.workspace == "measure":
            # Critical legacy Step-2 overlay: movable cyan horizontal guide.
            self._draw_alignment_guide()

    def toggle_layer_preview(self):
        if self.workspace != "annotate":
            return
        self.layer_preview_only = not self.layer_preview_only
        self.preview_btn_text.set("返回原图编辑" if self.layer_preview_only else "一键预览（去底图）")
        self.render()
        self._update_status("当前仅预览上层，尚未保存" if self.layer_preview_only else "已返回原图编辑模式")

    def _write_measurement_markdown(self, path: Path):
        recs = self._measurement_records()
        lv = [r["value_px"] for r in recs if r.get("kind") == "length"]
        wv = [r["value_px"] for r in recs if r.get("kind") == "width"]
        av = [r["value_px"] for r in recs if r.get("kind") == "area"]
        lm, lsd = self._stats(lv); wm, wsd = self._stats(wv); am, asd = self._stats(av)
        ratio = lm/wm if (lm is not None and wm not in (None,0)) else None
        locked = self._is_measurement_locked()
        snap = self.measurement_lock_snapshots_by_image.get(self._measurement_key(), {}) if locked else {}

        lines = [f"# {self.image_path.name}", "", "## Calibration"]
        if self.calibration:
            c = self.calibration
            lines += [
                f"- Status: locked",
                f"- Known scale: {c['known_value']:g} {c['unit']}",
                f"- Pixel distance: {c['pixel_distance']:.4f} px",
                f"- Conversion: 1 px = {c['unit_per_px']:.9g} {c['unit']}",
            ]
        else:
            lines += ["- Status: not calibrated (px / px² only)"]

        angle = self._current_rotation_angle()
        lines += [
            "", "## Measurement view",
            f"- Rotation correction: {angle:+.4f} deg",
            "- Rotation is display/measurement alignment only; the source image is unchanged.",
            "", "## Measurements", f"- Measurement lock: {'locked' if locked else 'unlocked'}", ""
        ]
        for kind, title, prefix in (("length", "Length", "L"), ("width", "Width", "W"), ("area", "Area", "A")):
            rows = [r for r in recs if r.get("kind") == kind]
            lines.append(f"### {title}")
            if not rows:
                lines.append("- None")
            for r in rows:
                if kind == "area":
                    s = f"- {prefix}{r['id']}: {r['value_px']:.0f} px²"
                    if self.calibration:
                        s += f" = {r['value_px']*(self.calibration['unit_per_px']**2):.6g} {self.calibration['unit']}²"
                else:
                    s = f"- {prefix}{r['id']}: {r['value_px']:.3f} px"
                    if self.calibration:
                        s += f" = {r['value_px']*self.calibration['unit_per_px']:.6g} {self.calibration['unit']}"
                lines.append(s)
            lines.append("")

        lines += ["## Current summary"]
        lines.append(f"- Length: N={len(lv)}, Mean={lm if lm is not None else '--'} px, SD={lsd if lsd is not None else '--'} px")
        lines.append(f"- Width: N={len(wv)}, Mean={wm if wm is not None else '--'} px, SD={wsd if wsd is not None else '--'} px")
        lines.append(f"- L/W from means: {ratio if ratio is not None else '--'}")
        lines.append(f"- Free area: N={len(av)}, Mean={am if am is not None else '--'} px², SD={asd if asd is not None else '--'} px²")
        if locked:
            lines += ["", "## Locked ROI geometry snapshot"]
            lines.append(f"- Mean L: {snap.get('mean_length_px', '--')} px")
            lines.append(f"- Mean W: {snap.get('mean_width_px', '--')} px")
            lines.append(f"- Locked L/W: {snap.get('ratio_from_means', '--')}")
            lines.append("- Note: ROI geometry changes only after Step 2 is unlocked, edited, and locked again.")

        path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    def save_layers(self, silent=False):
        if self.image_path is None or self.original is None or self.mask is None:
            if not silent:
                messagebox.showwarning("没有图片", "请先打开一张图片。")
            return
        if self.boundary_points:
            if not silent:
                messagebox.showwarning("黄色边界尚未闭合", "请先点击首点、双击或按 Enter 完成黄色直线边界，再保存。")
            return

        ann_dir, mask_dir, overlay_dir, guide_dir, measurement_dir, region_dir = self._annotation_output_dirs()
        # v2.8 用户可见输出只放一张上层图 + 一个小型 md；以下文件夹仅保存计算所需内部数据。
        root = self.output_root or self.input_folder or self.image_path.parent
        root = Path(root)
        root.mkdir(parents=True, exist_ok=True)
        for d in (mask_dir, guide_dir, measurement_dir, region_dir):
            d.mkdir(parents=True, exist_ok=True)

        # Keep a lightweight source-path manifest so Step 4 can temporarily
        # bring the raw image back underneath ROI overlays without copying or
        # modifying the scientific source image.
        try:
            manifest = measurement_dir / "source_images.csv"
            mapping = {}
            if manifest.exists():
                with manifest.open("r", newline="", encoding="utf-8-sig") as f:
                    for rr in csv.DictReader(f):
                        if rr.get("image_name"):
                            mapping[rr["image_name"]] = rr.get("source_path", "")
            mapping[self.image_path.name] = str(self.image_path.resolve())
            with manifest.open("w", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)
                w.writerow(["image_name", "source_path"])
                for nm in sorted(mapping):
                    w.writerow([nm, mapping[nm]])
        except Exception:
            pass

        try:
            self._save_rotation_angles()
        except Exception:
            pass

        stem = self.image_path.stem
        binary = self._binary_mask()
        guide_binary = self.guide.point(lambda x: 255 if x >= 128 else 0, mode="L")
        region_binary = self.region.point(lambda x: 255 if x >= 128 else 0, mode="L")
        boundary_binary = self.boundary.point(lambda x: 255 if x >= 128 else 0, mode="L")

        # Internal project data
        mask_path = mask_dir / f"{stem}_mask.png"
        guide_mask_path = guide_dir / f"{stem}_guide_mask.png"
        region_path = region_dir / f"{stem}_region_mask.png"
        boundary_path = region_dir / f"{stem}_boundary_mask.png"
        binary.save(mask_path, format="PNG")
        guide_binary.save(guide_mask_path, format="PNG")
        region_binary.save(region_path, format="PNG")
        boundary_binary.save(boundary_path, format="PNG")

        # User-facing top layer:
        # white + red pore + blue free reference line + yellow calculation boundary.
        # Blue never enters porosity math; yellow region mask is the formal overall denominator.
        white = Image.new("RGB", self.original.size, (255, 255, 255))
        red = Image.new("RGB", self.original.size, (255, 0, 0))
        blue = Image.new("RGB", self.original.size, (0, 110, 255))
        yellow = Image.new("RGB", self.original.size, (255, 215, 0))
        layer = Image.composite(red, white, binary)
        layer = Image.composite(blue, layer, guide_binary)
        layer = Image.composite(yellow, layer, boundary_binary)
        layer_path = root / f"{stem}_layer.png"
        layer.save(layer_path, format="PNG")

        # Persistent logs / lock snapshot for ROI and final report
        self._save_measurements_csv()
        self._save_measurement_locks()
        md_path = root / f"{stem}_measurements.md"
        self._write_measurement_markdown(md_path)

        self.mask = binary
        self.region = region_binary
        self.boundary = boundary_binary
        self.dirty = False
        self._update_status(f"已保存：{layer_path.name} + {md_path.name}")

        if not silent:
            messagebox.showinfo("保存完成", f"上层分层图：\n{layer_path}\n\n测量记录：\n{md_path}\n\nROI/报告所需二值数据已作为内部项目数据保存。")

    # ========================================================
    # Load image / refresh states
    # ========================================================

    def load_image(self, path: Path):
        before = self.image_path
        super().load_image(path)
        # 如果用户取消了未保存切换，base 会直接 return；此时 image_path 未改变。
        if before is not None and self.image_path == before and Path(path) != Path(before) and self.dirty:
            return
        self.layer_preview_only = False
        if hasattr(self, "preview_btn_text"):
            self.preview_btn_text.set("一键预览（去底图）")
        self.boundary_hover = None
        self.selected_object = None
        self.alignment_active = False
        self.alignment_dragging = False
        self._display_cache_key = None
        self._display_cache_image = None
        self._load_rotation_angles()
        self._refresh_alignment_badge()
        self._load_measurement_locks()
        key = self._measurement_key()
        if key:
            self.measurement_visibility_phase_by_image.setdefault(key, "hide")
            self.measurement_hidden_kinds_by_image.setdefault(key, set())
        self.refresh_measurement_log()
        self.refresh_lock_badges()
        self.refresh_measurement_visibility_badge()
        try:
            self.app.refresh_global_state()
        except Exception:
            pass


class StagedROICalculatorFrame(ROICalculatorFrame):
    """④ ROI reads the immutable geometry snapshot created when Step 2 is locked."""

    def _load_source_original(self):
        self.original_rgb = None
        if self.mask is None:
            return
        base = self._mask_base_stem().lower()

        # Fast path: same image is still open in Steps 1–3.
        try:
            ann = self.app.annotator
            if ann.image_path and ann.original is not None and ann.image_path.stem.lower() == base:
                if ann.original.size == self.mask.size:
                    self.original_rgb = ann.original.copy()
                    return
        except Exception:
            pass

        # Persistent path manifest written by Step 3 save.
        if self.project_root:
            manifest = self.project_root / "manual_measurements" / "source_images.csv"
            if manifest.exists():
                try:
                    with manifest.open("r", newline="", encoding="utf-8-sig") as f:
                        for r in csv.DictReader(f):
                            nm = r.get("image_name", "")
                            if Path(nm).stem.lower() != base:
                                continue
                            p = Path(r.get("source_path", ""))
                            if p.exists():
                                im = Image.open(p).convert("RGB")
                                if im.size == self.mask.size:
                                    self.original_rgb = im
                                    return
                except Exception:
                    pass

        # Portable fallback: look for a same-stem image in the project root.
        if self.project_root:
            for ext in (".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"):
                p = self.project_root / f"{self._mask_base_stem()}{ext}"
                if p.exists():
                    try:
                        im = Image.open(p).convert("RGB")
                        if im.size == self.mask.size:
                            self.original_rgb = im
                            return
                    except Exception:
                        pass

    def _refresh_roi_display_from_original(self):
        if not self.roi_show_original or self.original_rgb is None or self.mask is None:
            self.display_rgb = self.layer_rgb
            self.render()
            return

        try:
            contrast = clamp(float(self.roi_contrast_var.get()), 0.35, 2.50)
        except Exception:
            contrast = 1.0
        base = ImageEnhance.Contrast(self.original_rgb).enhance(contrast)

        # Red pore overlay (semi-transparent)
        red = Image.new("RGB", base.size, (255, 0, 0))
        blended = Image.blend(base, red, OVERLAY_ALPHA)
        base = Image.composite(blended, base, self.mask)

        if self.project_root:
            stem = self._mask_base_stem()
            gpath = self.project_root / "manual_guides" / f"{stem}_guide_mask.png"
            bpath = self.project_root / "manual_regions" / f"{stem}_boundary_mask.png"
            try:
                if gpath.exists():
                    g = Image.open(gpath).convert("L")
                    if g.size == base.size:
                        base = Image.composite(Image.new("RGB", base.size, (0, 110, 255)), base, g)
            except Exception:
                pass
            try:
                if bpath.exists():
                    b = Image.open(bpath).convert("L")
                    if b.size == base.size:
                        base = Image.composite(Image.new("RGB", base.size, (255, 215, 0)), base, b)
            except Exception:
                pass

        self.display_rgb = base
        self.render()

    def toggle_roi_original(self):
        if self.mask is None:
            return
        if self.original_rgb is None:
            self._load_source_original()
        if self.original_rgb is None:
            messagebox.showinfo(
                "未找到原图",
                "没有找到与当前 Mask 对应的原图。\n"
                "如果从③直接进入④，或原图仍位于保存时的路径，一键原图即可使用。"
            )
            return
        self.roi_show_original = not self.roi_show_original
        self.roi_original_btn_text.set("隐藏原图" if self.roi_show_original else "显示原图")
        self._refresh_roi_display_from_original()

    def _read_locked_snapshot(self):
        if not self.project_root or not self.mask_path:
            return None
        path = self.project_root / "manual_measurements" / "measurement_locks.csv"
        if not path.exists():
            return None
        base = self._mask_base_stem().lower()
        try:
            with path.open("r", newline="", encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    if Path(r.get("image_name", "")).stem.lower() != base:
                        continue
                    locked = str(r.get("locked", "1")).strip() not in ("0", "false", "False", "")
                    if not locked:
                        return None
                    def num(k):
                        try:
                            v = r.get(k, "")
                            return float(v) if v not in (None, "") else None
                        except Exception:
                            return None
                    def intval(k):
                        try:
                            return int(float(r.get(k, 0) or 0))
                        except Exception:
                            return 0
                    return {
                        "n_length": intval("n_length"),
                        "mean_length_px": num("mean_length_px"),
                        "n_width": intval("n_width"),
                        "mean_width_px": num("mean_width_px"),
                        "ratio_from_means": num("ratio_from_means"),
                    }
        except Exception:
            return None
        return None

    def _reference_is_locked(self):
        return self._read_locked_snapshot() is not None

    def _load_reference_stats(self):
        self.ref_mean_length = None
        self.ref_mean_width = None
        self.ref_ratio = None
        self.ref_n_length = 0
        self.ref_n_width = 0

        snap = self._read_locked_snapshot()
        if not snap:
            self.ref_summary_var.set("参考样条: 未锁定；请回到②测量并锁定本图")
            self.roi_h_var.set("--")
            return

        self.ref_mean_length = snap.get("mean_length_px")
        self.ref_mean_width = snap.get("mean_width_px")
        self.ref_ratio = snap.get("ratio_from_means")
        self.ref_n_length = snap.get("n_length", 0)
        self.ref_n_width = snap.get("n_width", 0)

        if self.ref_ratio in (None, 0) or self.ref_mean_length is None or self.ref_mean_width is None:
            self.ref_summary_var.set("🔒 已锁定，但没有完整 Length + Width；无法建立 ROI 比例")
            self.ref_ratio = None
            self.roi_h_var.set("--")
            return

        self.ref_summary_var.set(
            f"🔒 锁定参考样条: L={self.ref_mean_length:.1f}px (n={self.ref_n_length}), "
            f"W={self.ref_mean_width:.1f}px (n={self.ref_n_width}), L/W={self.ref_ratio:.4f}"
        )
        self._sync_roi_height_from_ratio()

    def _load_region_for_current_mask(self):
        super()._load_region_for_current_mask()
        try:
            self.region_result_var.set(self.region_result_var.get().replace("蓝线", "黄色边界").replace("蓝色", "黄色"))
        except Exception:
            pass

    def load_mask(self, path: Path):
        super().load_mask(path)
        # v2.8 优先显示用户保存的单张上层图（白底+红孔+蓝参考+黄边界）。
        if self.project_root and self.mask is not None:
            base = self._mask_base_stem(path)
            layer_path = self.project_root / f"{base}_layer.png"
            if layer_path.exists():
                try:
                    disp = Image.open(layer_path).convert("RGB")
                    if disp.size == self.mask.size:
                        self.layer_rgb = disp
                        self.display_rgb = disp
                except Exception:
                    pass
            self._load_source_original()
            self.roi_show_original = False
            self.roi_original_btn_text.set("显示原图")
            self.render()

    def refresh_stage_state(self):
        # 从③当前图片自动接管已保存 mask，减少再次选择文件。
        try:
            ann = self.app.annotator
            if ann.image_path:
                root = ann._project_root()
                p = root / "manual_masks" / f"{ann.image_path.stem}_mask.png"
                if p.exists() and (self.mask_path is None or Path(self.mask_path) != p):
                    self.input_folder = p.parent
                    self._build_mask_list(p.parent, selected=p)
                    self.load_mask(p)
                    return
                elif not p.exists():
                    self.ref_summary_var.set("请先在③ 图层标注中点击保存，再执行 ROI")
        except Exception:
            pass

        if self.mask_path:
            self.project_root = self._infer_project_root(self.mask_path)
            self._load_calibration_from_root()
            self._load_reference_stats()
            self._load_region_for_current_mask()
            try:
                self.app.refresh_global_state()
            except Exception:
                pass


class StagedReportFrame(ReportFrame):
    """⑤ Final report: yellow-region porosity + ROI + locked L/W/area logs."""

    def _read_measurement_locks(self, root: Path):
        path = root / "manual_measurements" / "measurement_locks.csv"
        locks = {}
        if not path.exists():
            return locks
        try:
            with path.open("r", newline="", encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    name = r.get("image_name", "")
                    if name:
                        locks[Path(name).stem] = str(r.get("locked", "1")).strip() not in ("0", "false", "False", "")
        except Exception:
            pass
        return locks

    def _collect_data(self):
        data = super()._collect_data()
        if not data:
            return data
        locks = self._read_measurement_locks(data["root"])
        mby = data.get("measurement_by_stem", {})
        for d in data.get("images", []):
            locked = bool(locks.get(d["stem"], False))
            d["measurement_locked"] = locked
            mrows = mby.get(d["stem"], [])
            areas = sorted([r for r in mrows if r.get("type") == "area"], key=lambda r: r.get("id", 0)) if locked else []
            av = [r["value_px"] for r in areas]
            d["area_rows"] = areas
            d["mean_area_px2"] = statistics.mean(av) if av else None
            d["sd_area_px2"] = statistics.stdev(av) if len(av) >= 2 else None
            if not locked:
                # Formal report uses only locked geometry; raw logs remain in per-image md/CSV.
                d["length_rows"] = []
                d["width_rows"] = []
                d["mean_length_px"] = None
                d["sd_length_px"] = None
                d["mean_width_px"] = None
                d["sd_width_px"] = None
                d["ratio_from_means"] = None
        data["measurement_locks"] = locks
        return data

    def generate_report(self):
        super().generate_report()
        if self.project_root is None or Workbook is None:
            return
        root = self.output_root or (self.project_root / "final_report")
        xlsx_path = root / "porosity_final_report.xlsx"
        txt_path = root / "porosity_final_summary.txt"
        if not xlsx_path.exists():
            return
        try:
            from openpyxl import load_workbook
            data = self._collect_data()
            wb = load_workbook(xlsx_path)
            for s in ("area_measurements", "area_summary", "measurement_lock"):
                if s in wb.sheetnames:
                    del wb[s]
            # Rename legacy sheet label if present; data semantics are unchanged.
            if "blue_region" in wb.sheetnames and "yellow_region" not in wb.sheetnames:
                wb["blue_region"].title = "yellow_region"

            cal = data.get("calibration")
            upp = cal["unit_per_px"] if cal else None
            unit = cal["unit"] if cal else ""

            ws = wb.create_sheet("area_measurements")
            ws.append(["image_name", "area_id", "area_px2", f"area_{unit}2" if unit else "area_calibrated_sq", "unit_squared"])
            for d in data.get("images", []):
                for r in d.get("area_rows", []):
                    av = r["value_px"] * (upp**2) if upp is not None else None
                    ws.append([d["stem"], r["id"], r["value_px"], av, f"{unit}^2" if unit else ""])
            self._style_sheet(ws)

            ws = wb.create_sheet("area_summary")
            ws.append(["image_name", "measurement_locked", "n_area", "mean_area_px2", "sd_area_px2", f"mean_area_{unit}2" if unit else "mean_area_calibrated_sq"])
            for d in data.get("images", []):
                mean_a = d.get("mean_area_px2")
                ws.append([
                    d["stem"], 1 if d.get("measurement_locked") else 0,
                    len(d.get("area_rows", [])), mean_a, d.get("sd_area_px2"),
                    mean_a*(upp**2) if (mean_a is not None and upp is not None) else None,
                ])
            self._style_sheet(ws)

            ws = wb.create_sheet("measurement_lock")
            ws.append(["image_name", "measurement_locked", "note"])
            for d in data.get("images", []):
                ws.append([
                    d["stem"], 1 if d.get("measurement_locked") else 0,
                    "ROI geometry is frozen from the Step-2 lock snapshot. Unlock/edit/re-lock to update it."
                ])
            self._style_sheet(ws)
            wb.save(xlsx_path)

            with txt_path.open("a", encoding="utf-8") as f:
                f.write("\n\nLocked free-area measurements\n" + "-"*32 + "\n")
                for d in data.get("images", []):
                    if not d.get("measurement_locked"):
                        f.write(f"{d['stem']}: measurement set not locked; formal geometry/area omitted\n")
                        continue
                    rows = d.get("area_rows", [])
                    if not rows:
                        f.write(f"{d['stem']}: no free-area measurements\n")
                        continue
                    mean_a = d.get("mean_area_px2")
                    sd_a = d.get("sd_area_px2")
                    line = f"{d['stem']}: N={len(rows)}, Mean={mean_a:.3f} px^2"
                    if sd_a is not None:
                        line += f", SD={sd_a:.3f} px^2"
                    if upp is not None:
                        line += f", Mean={mean_a*(upp**2):.4f} {unit}^2"
                    f.write(line + "\n")
        except Exception as e:
            self.status_var.set(f"主体报告已生成；面积/锁定附加表写入失败：{e}")



# ============================================================
# v2.11 CONSOLIDATED UX / PORTABLE PROJECT OVERRIDES
# ============================================================

import json as _json
import zipfile as _zipfile
import tempfile as _tempfile
import shutil as _shutil
from datetime import datetime as _datetime


class _HoverTip:
    """Desktop hover help; click also keeps the help visible for ~3 s (tablet-ready behavior)."""
    def __init__(self, widget, text_getter, delay=450):
        self.widget = widget
        self.text_getter = text_getter
        self.delay = delay
        self.after_id = None
        self.tip = None
        widget.bind('<Enter>', self._enter, add='+')
        widget.bind('<Leave>', self._leave, add='+')
        widget.bind('<ButtonPress-1>', self._clicked, add='+')

    def _enter(self, _e=None):
        self._cancel()
        self.after_id = self.widget.after(self.delay, self.show)

    def _leave(self, _e=None):
        self._cancel()
        self.hide()

    def _clicked(self, _e=None):
        self._cancel()
        self.show()
        self.widget.after(3000, self.hide)

    def _cancel(self):
        if self.after_id is not None:
            try:
                self.widget.after_cancel(self.after_id)
            except Exception:
                pass
            self.after_id = None

    def show(self):
        self.hide()
        try:
            text = self.text_getter() if callable(self.text_getter) else str(self.text_getter)
        except Exception:
            text = ''
        if not text:
            return
        try:
            x = self.widget.winfo_rootx() + 8
            y = self.widget.winfo_rooty() + self.widget.winfo_height() + 5
            self.tip = tk.Toplevel(self.widget)
            self.tip.wm_overrideredirect(True)
            self.tip.wm_geometry(f'+{x}+{y}')
            ttk.Label(
                self.tip, text=text, justify=tk.LEFT,
                padding=(8, 5), wraplength=340
            ).pack()
        except Exception:
            self.tip = None

    def hide(self):
        if self.tip is not None:
            try:
                self.tip.destroy()
            except Exception:
                pass
            self.tip = None


_StagedAnnotatorFrameV28 = StagedAnnotatorFrame


class StagedAnnotatorFrame(_StagedAnnotatorFrameV28):
    """v2.11: stage-specific toolbars, movable alignment guide, compact log, delete mode, portable project."""

    def __init__(self, parent, app):
        self._i18n_widgets = []
        self._tooltips = []
        self.alignment_guide_fracs_by_image = {}
        self.alignment_guide_dragging = False
        self._pan_mode_active = False
        self._pan_previous_mode = None
        super().__init__(parent, app)
        self.canvas.bind('<KeyPress-d>', lambda e: self.set_mode('delete'))
        self.canvas.bind('<Delete>', lambda e: self._delete_at_canvas_pointer())
        # M toggles persistent pan mode. Space + left mouse remains temporary pan.
        self.canvas.bind('<KeyPress-m>', lambda e: self.toggle_pan_mode())

    def _t(self, zh, en):
        return self.app.tr(zh, en) if hasattr(self.app, 'tr') else zh

    def _reg(self, widget, zh, en, tip_zh=None, tip_en=None):
        self._i18n_widgets.append((widget, zh, en))
        try:
            widget.configure(text=self._t(zh, en))
        except Exception:
            pass
        if tip_zh or tip_en:
            tip_zh = tip_zh or zh
            tip_en = tip_en or en
            self._tooltips.append(_HoverTip(widget, lambda z=tip_zh, e=tip_en: self._t(z, e)))
        return widget

    def _button(self, parent, zh, en, command, tip_zh=None, tip_en=None, **pack_kw):
        b = ttk.Button(parent, command=command)
        self._reg(b, zh, en, tip_zh, tip_en)
        b.pack(**pack_kw)
        return b

    def _build_ui(self):
        # ---------- row 2: common image controls ----------
        common = ttk.Frame(self)
        common.pack(side=tk.TOP, fill=tk.X, padx=7, pady=(6, 3))
        self.common_bar = common

        self.open_image_btn = self._button(common, '打开图片', 'Open image', self.open_image_dialog,
            '打开单张显微图或标尺图。', 'Open one microscopy image or scale image.', side=tk.LEFT, padx=2)
        self.open_folder_btn = self._button(common, '打开文件夹', 'Open folder', self.open_folder_dialog,
            '载入一个图片文件夹，之后可用上一张/下一张连续处理。', 'Load an image folder for previous/next navigation.', side=tk.LEFT, padx=2)
        self.remove_image_btn = self._button(common, '移除当前图片', 'Remove image', self.close_current_image,
            '只从画布移除当前图片；不会删除源文件、标尺或已保存数据。', 'Unload the current image only; source files and saved data are not deleted.', side=tk.LEFT, padx=2)
        self.prev_btn = self._button(common, '上一张', 'Previous', self.prev_image,
            '切换到文件夹中的上一张图片。', 'Go to the previous image in the loaded folder.', side=tk.LEFT, padx=(10,2))
        self.next_btn = self._button(common, '下一张', 'Next', self.next_image,
            '切换到文件夹中的下一张图片。', 'Go to the next image in the loaded folder.', side=tk.LEFT, padx=2)
        self.fit_btn = self._button(common, '适应窗口', 'Fit window', self.fit_to_window,
            '自动缩放并居中，使整张图片适合当前画布。', 'Fit and center the whole image in the canvas.', side=tk.LEFT, padx=(10,2))
        self.pan_btn = self._button(common, '平移', 'Pan', self.toggle_pan_mode,
            '点击此按钮或按快捷键 M 进入/退出持续平移模式；开启时按钮高亮。任意工具下也可按住 Space + 鼠标左键临时平移。',
            'Click this button or press M to toggle persistent pan mode; the button stays highlighted while active. In any tool, hold Space + left mouse to pan temporarily.',
            side=tk.LEFT, padx=2)

        # calibration-only output + language
        self.cal_only_frame = ttk.Frame(common)
        self.output_btn = self._button(self.cal_only_frame, '输出目录', 'Output folder', self.choose_output_folder,
            '设置当前工作数据与项目文件的保存位置。', 'Choose where working data and project files are saved.', side=tk.LEFT, padx=(8,2))
        self.lang_zh_btn = ttk.Button(self.cal_only_frame, text='中文', command=lambda: self.app.set_language('zh'))
        self.lang_zh_btn.pack(side=tk.LEFT, padx=(10,2))
        self.lang_en_btn = ttk.Button(self.cal_only_frame, text='English', command=lambda: self.app.set_language('en'))
        self.lang_en_btn.pack(side=tk.LEFT, padx=2)
        self._tooltips.append(_HoverTip(self.lang_zh_btn, lambda: '切换整个软件为中文界面。'))
        self._tooltips.append(_HoverTip(self.lang_en_btn, lambda: 'Switch the whole interface to English.'))

        # measurement-only contrast controls
        self.contrast_frame = ttk.Frame(common)
        self.contrast_label_widget = ttk.Label(self.contrast_frame)
        self.contrast_label_widget.pack(side=tk.LEFT, padx=(8,3))
        self.contrast_scale = ttk.Scale(
            self.contrast_frame, from_=0.35, to=5.00, variable=self.contrast_var,
            command=self._contrast_changed, length=125
        )
        self.contrast_scale.pack(side=tk.LEFT, padx=2)
        ttk.Label(self.contrast_frame, textvariable=self.contrast_label_var, width=12).pack(side=tk.LEFT, padx=(2,2))
        self.contrast_reset_btn = self._button(self.contrast_frame, '重置', 'Reset', self.reset_contrast,
            '恢复原始显示对比度 1.00×；不会改变原始图。', 'Restore display contrast to 1.00×; source pixels are unchanged.', side=tk.LEFT, padx=(0,5))
        self.measure_cal_status_var = tk.StringVar(value='○ 标尺未锁定')
        ttk.Label(self.contrast_frame, textvariable=self.measure_cal_status_var, font=('Segoe UI',9,'bold')).pack(side=tk.LEFT, padx=(5,3))
        self._tooltips.append(_HoverTip(self.contrast_scale, lambda: self._t(
            '仅调节屏幕显示对比度，不改变原图和任何定量数据。',
            'Display-only contrast adjustment; source pixels and quantitative data are unchanged.'
        )))

        # annotation-only quick actions live on row 2, where contrast would otherwise be
        self.annotate_quick_frame = ttk.Frame(common)
        self.delete_mode_btn = self._button(self.annotate_quick_frame, '删除', 'Delete', lambda: self.set_mode('delete'),
            '进入删除模式后，直接点击红色孔隙、蓝色参考线或黄色边界即可删除。',
            'Enter delete mode, then click a red pore, blue guide, or yellow boundary to remove it.', side=tk.LEFT, padx=(8,2))
        self.clear_annotation_btn = self._button(self.annotate_quick_frame, '一键清空', 'Clear all', self.clear_annotation_layers,
            '清空当前图的红色孔隙、蓝色参考线和黄色计算边界；不会删除标尺或第二步测量。',
            'Clear current red pores, blue guides and yellow boundary; calibration and Step-2 measurements remain.', side=tk.LEFT, padx=2)
        self.preview_btn_text = tk.StringVar(value='一键预览（去底图）')
        self.preview_btn = ttk.Button(self.annotate_quick_frame, textvariable=self.preview_btn_text, command=self.toggle_layer_preview)
        self.preview_btn.pack(side=tk.LEFT, padx=(8,2))
        self._tooltips.append(_HoverTip(self.preview_btn, lambda: self._t(
            '在原图编辑视图与白底结果预览之间切换；不会自动保存。',
            'Toggle between raw-image editing and white-background result preview; this does not save.'
        )))
        self.save_btn = self._button(self.annotate_quick_frame, '保存', 'Save', self.save_layers,
            '保存图层结果并生成一个可直接交给 ROI 页使用的 .poreproj 单文件项目包。',
            'Save layer results and create one portable .poreproj file that can be opened directly in the ROI stage.', side=tk.LEFT, padx=2)

        self.stage_hint_var = tk.StringVar(value='')
        ttk.Label(common, textvariable=self.stage_hint_var, anchor=tk.E, font=('Segoe UI',9,'bold')).pack(side=tk.RIGHT, padx=6)

        # ---------- stage-specific row 3 ----------
        self.stage_host = ttk.Frame(self)
        self.stage_host.pack(side=tk.TOP, fill=tk.X, padx=7, pady=(0,4))
        self.stage_host.columnconfigure(0, weight=1)
        self.cal_bar = ttk.LabelFrame(self.stage_host)
        self.measure_bar = ttk.LabelFrame(self.stage_host)
        self.annotate_bar = ttk.LabelFrame(self.stage_host)
        for f in (self.cal_bar, self.measure_bar, self.annotate_bar):
            f.grid(row=0, column=0, sticky='ew')

        # Stage 1 calibration controls unchanged in function
        cb = self.cal_bar
        self.cal_known_label = ttk.Label(cb)
        self.cal_known_label.pack(side=tk.LEFT, padx=(8,2), pady=5)
        self.cal_known_entry = ttk.Entry(cb, textvariable=self.calibration_known_var, width=9)
        self.cal_known_entry.pack(side=tk.LEFT, padx=(0,3), pady=5)
        self.cal_unit_combo = ttk.Combobox(cb, textvariable=self.calibration_unit_var, values=('µm','mm','nm','cm'), width=6, state='readonly')
        self.cal_unit_combo.pack(side=tk.LEFT, padx=(0,8), pady=5)
        self.calibrate_btn = self._button(cb, '点标尺两端并校准', 'Calibrate from two points', self.start_calibration_mode,
            '输入已知标尺长度后，依次点击标尺两端以计算物理尺寸换算。',
            'Enter the known scale length, then click both scale-bar endpoints to compute physical calibration.', side=tk.LEFT, padx=3, pady=4)
        self.unlock_cal_btn = self._button(cb, '解除尺寸锁定', 'Unlock calibration', self.unlock_calibration,
            '解除当前批次的标尺锁定，之后才允许重新校准。',
            'Unlock the current calibration so a new scale can be defined.', side=tk.LEFT, padx=3, pady=4)
        self.calibration_badge_var = tk.StringVar(value='○ 未校准：后续仍可按 px / px² 工作')
        ttk.Label(cb, textvariable=self.calibration_badge_var, font=('Segoe UI',9,'bold')).pack(side=tk.LEFT, padx=14, pady=5)

        # Stage 2
        mb = self.measure_bar
        self.measure_length_btn = self._button(mb, '测长度', 'Measure length', lambda: self.set_mode('measure_length'),
            '记录校正视图中的水平投影长度。', 'Measure horizontal projected length in the aligned view.', side=tk.LEFT, padx=(8,3), pady=4)
        self.measure_width_btn = self._button(mb, '测宽度', 'Measure width', lambda: self.set_mode('measure_width'),
            '记录校正视图中的垂直投影宽度。', 'Measure vertical projected width in the aligned view.', side=tk.LEFT, padx=3, pady=4)
        self.measure_area_btn = self._button(mb, '自由圈选面积', 'Freehand area', lambda: self.set_mode('measure_area'),
            '按住拖动自由圈选，松开后闭合并记录面积。', 'Drag a freehand closed region and release to record its area.', side=tk.LEFT, padx=3, pady=4)
        ttk.Separator(mb, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=7, pady=3)
        self.align_btn = self._button(mb, '水平校正', 'Horizontal alignment', self.start_alignment_mode,
            '显示可上下移动的水平参考线；拖动参考线调位置，拖动其他区域旋转图片。',
            'Show a vertically movable horizontal guide; drag the guide to reposition it and drag elsewhere to rotate the image.', side=tk.LEFT, padx=3, pady=4)
        self.align_confirm_btn = self._button(mb, '确认角度', 'Confirm angle', self.confirm_alignment,
            '确认当前旋转角；之后按该校正坐标测量。', 'Confirm the current view rotation for subsequent measurements.', side=tk.LEFT, padx=3, pady=4)
        self.align_reset_btn = self._button(mb, '恢复 0°', 'Reset to 0°', self.reset_alignment,
            '在尚无正式测量记录时恢复零旋转。', 'Return to zero rotation before formal measurements are recorded.', side=tk.LEFT, padx=3, pady=4)
        self.alignment_angle_var = tk.StringVar(value='旋转 0.0°')
        ttk.Label(mb, textvariable=self.alignment_angle_var, width=12, font=('Segoe UI',9,'bold')).pack(side=tk.LEFT, padx=(2,6))
        self.visibility_btn = self._button(mb, '隐藏', 'Hide', self.toggle_all_measurement_visibility,
            '隐藏当前图片画布上的全部长度、宽度和面积测量图形；右侧日志和数据完全保留。再次点击同一按钮可恢复显示。',
            'Hide all length, width and area graphics on the current image while keeping every log record and value. Click the same button again to restore them.',
            side=tk.LEFT, padx=(6,3), pady=4)
        ttk.Separator(mb, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=7, pady=3)
        self.undo_measure_btn = self._button(mb, '撤销', 'Undo', self.undo_last_measurement,
            '撤销当前图片最近完成的一次长度、宽度或面积测量。也可以在没有正在绘制的测量时点击鼠标右键撤销最近一步。',
            'Undo the most recently completed length, width or area measurement. You can also right-click when no measurement is currently being drawn.',
            side=tk.LEFT, padx=3, pady=4)
        self.delete_log_btn = self._button(mb, '删除日志选中项', 'Delete selected log', self.delete_selected_measurement,
            '在右侧日志中任选一条记录后，只删除该条测量。', 'Select any one record in the log and delete only that measurement.', side=tk.LEFT, padx=(6,3), pady=4)
        self.clear_measure_btn = self._button(mb, '清空本图', 'Clear image measurements', self.clear_measurements_current,
            '清空当前图片全部长度、宽度和面积测量；标尺校准不受影响。', 'Clear all length, width and area measurements for the current image; calibration is retained.', side=tk.LEFT, padx=3, pady=4)

        # Stage 3 drawing tools only; quick actions are on row 2
        ab = self.annotate_bar
        self.annotation_radios = []
        for zh, en, value, tip_zh, tip_en in [
            ('画笔 [B]', 'Brush [B]', 'brush', '直接涂画红色孔隙区域。', 'Paint red pore regions directly.'),
            ('橡皮 [E]', 'Eraser [E]', 'erase', '擦除红色孔隙标注。', 'Erase red pore annotation.'),
            ('自由圈选填充 [F]', 'Freehand fill [F]', 'freehand', '拖动圈出不规则孔隙，松开后自动闭合填充。', 'Drag around an irregular pore and release to close and fill it.'),
            ('蓝色自由参考线 [L]', 'Blue free guide [L]', 'line', '绘制自由蓝色参考线；仅视觉参考，不参与计算。', 'Draw a free blue guide; visual reference only, never used in calculations.'),
            ('黄色正交计算边界 [G]', 'Yellow orthogonal boundary [G]', 'boundary', '建立严格水平/垂直的正式计算区域。', 'Create the formal strictly horizontal/vertical calculation region.'),
        ]:
            rb = ttk.Radiobutton(ab, variable=self.mode, value=value, command=self._mode_changed)
            self._reg(rb, zh, en, tip_zh, tip_en)
            rb.pack(side=tk.LEFT, padx=2, pady=4)
            self.annotation_radios.append(rb)
        self.brush_label = ttk.Label(ab)
        self.brush_label.pack(side=tk.LEFT, padx=(8,0))
        ttk.Spinbox(ab, from_=1, to=100, textvariable=self.brush_size, width=5).pack(side=tk.LEFT, padx=2)
        self.boundary_width_label = ttk.Label(ab)
        self.boundary_width_label.pack(side=tk.LEFT, padx=(6,0))
        ttk.Spinbox(ab, from_=1, to=30, textvariable=self.line_width, width=4).pack(side=tk.LEFT, padx=2)

        # Main content
        self.content = ttk.Frame(self)
        self.content.pack(fill=tk.BOTH, expand=True)
        self.canvas = tk.Canvas(self.content, bg='#202020', highlightthickness=0, cursor='crosshair')
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.measure_log_frame = ttk.LabelFrame(self.content)
        self.measure_log_frame.configure(width=315)
        self.measure_log_frame.pack_propagate(False)
        cols = ('type','id','value')
        self.measure_tree = ttk.Treeview(self.measure_log_frame, columns=cols, show='headings', selectmode='browse', height=18)
        self.measure_tree.column('type', width=80, anchor=tk.CENTER)
        self.measure_tree.column('id', width=38, anchor=tk.CENTER)
        self.measure_tree.column('value', width=155, anchor=tk.E)
        self.measure_tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=(5,3))
        self.measure_summary_var = tk.StringVar(value='Length n=0 | Width n=0 | Area n=0 | L/W=--')
        ttk.Label(self.measure_log_frame, textvariable=self.measure_summary_var, justify=tk.LEFT, anchor=tk.W,
                  font=('Segoe UI',9,'bold'), wraplength=295).pack(fill=tk.X, padx=7, pady=(2,7))

        status = ttk.Frame(self)
        status.pack(side=tk.BOTTOM, fill=tk.X)
        self.status_var = tk.StringVar(value='请选择图片')
        ttk.Label(status, textvariable=self.status_var, anchor=tk.W).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=8, pady=3)
        self.zoom_var = tk.StringVar(value='Zoom: 100%')
        ttk.Label(status, textvariable=self.zoom_var).pack(side=tk.RIGHT, padx=8)

        self.apply_language()
        self.set_workspace('calibrate')

    def apply_language(self):
        for widget, zh, en in getattr(self, '_i18n_widgets', []):
            try:
                widget.configure(text=self._t(zh, en))
            except Exception:
                pass
        if hasattr(self, 'cal_bar'):
            self.cal_bar.configure(text=self._t('① 标尺校准（可选）', '① Scale calibration (optional)'))
            self.measure_bar.configure(text=self._t('② 尺寸 / 面积测量', '② Dimension / area measurement'))
            self.annotate_bar.configure(text=self._t('③ 图层标注', '③ Layer annotation'))
            self.cal_known_label.configure(text=self._t('已知长度:', 'Known length:'))
            self.brush_label.configure(text=self._t('笔刷:', 'Brush:'))
            self.boundary_width_label.configure(text=self._t('边界线宽:', 'Boundary width:'))
            self.contrast_label_widget.configure(text=self._t('显示对比度:', 'Display contrast:'))
            self.measure_tree.heading('type', text=self._t('类型', 'Type'))
            self.measure_tree.heading('id', text='#')
            self.measure_tree.heading('value', text=self._t('测量值', 'Value'))
        if hasattr(self, 'preview_btn_text'):
            if self.layer_preview_only:
                self.preview_btn_text.set(self._t('返回原图编辑', 'Back to image'))
            else:
                self.preview_btn_text.set(self._t('一键预览（去底图）', 'Preview (hide source)'))
        self.refresh_lock_badges()
        self.refresh_measurement_log()
        if getattr(self, 'workspace', None):
            self._refresh_stage_hint()

    def _refresh_stage_hint(self):
        if self.workspace == 'calibrate':
            self.stage_hint_var.set(self._t('Step 1 / 5 · 可跳过；校准后物理尺寸保持锁定',
                                            'Step 1 / 5 · Optional; physical calibration stays locked'))
        elif self.workspace == 'measure':
            self.stage_hint_var.set(self._t('Step 2 / 5 · 先校正方向，再测长度/宽度/面积',
                                            'Step 2 / 5 · Align first, then measure length / width / area'))
        else:
            self.stage_hint_var.set(self._t('Step 3 / 5 · 蓝线仅参考；黄色区域参与计算；保存生成 .poreproj',
                                            'Step 3 / 5 · Blue is reference only; yellow is formal; Save creates .poreproj'))

    def set_workspace(self, which):
        self.workspace = which
        self._set_pan_visual(False)
        self._pan_previous_mode = None
        for f in (self.cal_bar, self.measure_bar, self.annotate_bar):
            f.grid_remove()
        self.measure_log_frame.pack_forget()
        self.cal_only_frame.pack_forget()
        self.contrast_frame.pack_forget()
        self.annotate_quick_frame.pack_forget()
        if which != 'annotate' and self.layer_preview_only:
            self.layer_preview_only = False
            self.preview_btn_text.set(self._t('一键预览（去底图）', 'Preview (hide source)'))
        if which == 'calibrate':
            self.cal_bar.grid()
            self.cal_only_frame.pack(side=tk.LEFT)
            self.mode.set('calibrate')
        elif which == 'measure':
            self.measure_bar.grid()
            self.contrast_frame.pack(side=tk.LEFT)
            self.measure_log_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(5,7), pady=5)
            if self.mode.get() not in ('measure_length','measure_width','measure_area','pan'):
                self.mode.set('measure_length')
        else:
            self.annotate_bar.grid()
            self.annotate_quick_frame.pack(side=tk.LEFT)
            if self.mode.get() not in ('brush','erase','freehand','line','boundary','delete','pan'):
                self.mode.set('freehand')
        self.measure_area_points = []
        self.measure_start = None
        self.measure_preview = None
        self.calibration_start = None
        self.calibration_preview = None
        self.boundary_hover = None
        self._refresh_stage_hint()
        self._mode_changed()
        self.refresh_measurement_log()
        self.refresh_lock_badges()
        self.refresh_measurement_visibility_badge()
        self.render()

    def _mode_changed(self):
        cursors = {
            'brush':'pencil', 'erase':'dotbox', 'freehand':'crosshair', 'line':'pencil',
            'boundary':'crosshair', 'delete':'hand2', 'pan':'fleur', 'calibrate':'crosshair',
            'measure_length':'crosshair','measure_width':'crosshair','measure_area':'crosshair'
        }
        self.canvas.configure(cursor=cursors.get(self.mode.get(), 'crosshair'))
        self.canvas.focus_set()
        self._update_status()

    # ---------- persistent pan toggle + compact measurement controls ----------
    def _set_pan_visual(self, active):
        self._pan_mode_active = bool(active)
        if hasattr(self, 'pan_btn'):
            try:
                if active:
                    self.pan_btn.state(['pressed'])
                else:
                    self.pan_btn.state(['!pressed'])
            except Exception:
                pass

    def _default_mode_for_workspace(self):
        if self.workspace == 'calibrate':
            return 'calibrate'
        if self.workspace == 'measure':
            return 'measure_length'
        return 'freehand'

    def toggle_pan_mode(self):
        if self._pan_mode_active or self.mode.get() == 'pan':
            restore = self._pan_previous_mode or self._default_mode_for_workspace()
            if restore == 'pan':
                restore = self._default_mode_for_workspace()
            self._set_pan_visual(False)
            self._pan_previous_mode = None
            super().set_mode(restore)
            self._update_status(self._t(
                '持续平移模式已关闭。仍可随时按住 Space + 鼠标左键临时平移。',
                'Persistent pan mode is off. You can still hold Space + left mouse for temporary panning.'
            ))
        else:
            self._pan_previous_mode = self.mode.get()
            super().set_mode('pan')
            self._set_pan_visual(True)
            self._update_status(self._t(
                '平移模式已开启；按钮保持高亮。再次点击“平移”或按 M 退出；也可在任意工具中使用 Space + 鼠标左键临时平移。',
                'Pan mode is on and the button remains highlighted. Click Pan again or press M to exit; Space + left mouse also pans temporarily in any tool.'
            ))

    def set_mode(self, mode):
        if mode != 'pan':
            self._set_pan_visual(False)
            self._pan_previous_mode = None
        return super().set_mode(mode)

    def _measurement_edit_allowed(self, popup=True):
        # v2.11 removes the old measurement-lock workflow from normal use.
        return True

    def toggle_all_measurement_visibility(self):
        if not self.image_path:
            return
        recs = self._measurement_records()
        kinds = {r.get('kind') for r in recs if r.get('kind') in ('length','width','area')}
        if not kinds:
            messagebox.showinfo(self._t('提示','Info'), self._t('当前图片还没有测量记录。','There are no measurements for the current image.'))
            return
        hidden = self._hidden_kinds()
        if kinds.issubset(hidden):
            hidden.difference_update(kinds)
            self._update_status(self._t('已恢复测量图形；日志始终保留。','Measurement graphics restored; the log was retained throughout.'))
        else:
            hidden.update(kinds)
            self._update_status(self._t('已隐藏全部测量图形；右侧日志和数据不受影响。','All measurement graphics are hidden; log records and data are unchanged.'))
        self.render()

    def undo_last_measurement(self):
        if not self.image_path:
            return
        recs = self._measurement_records()
        if not recs:
            self._update_status(self._t('当前图片没有可撤销的测量。','There is no measurement to undo for this image.'))
            return
        recs.pop()
        counters = {'length':0,'width':0,'area':0}
        for r in recs:
            k = r.get('kind')
            if k in counters:
                counters[k] += 1
                r['id'] = counters[k]
        self._save_measurements_csv()
        self.refresh_measurement_log()
        self.render()
        self._update_status(self._t('已撤销最近一次测量。','The most recent measurement was undone.'))

    def refresh_lock_badges(self):
        super().refresh_lock_badges()
        if hasattr(self, 'measure_cal_status_var'):
            self.measure_cal_status_var.set(
                self._t('🔒 标尺锁定','🔒 Scale locked') if self.calibration
                else self._t('○ 标尺未锁定','○ Scale unlocked')
            )

    # ---------- calibration persistence across ordinary image changes ----------
    def load_image(self, path: Path):
        retained_cal = dict(self.calibration) if self.calibration else None
        before = Path(self.image_path) if self.image_path else None
        super().load_image(path)
        loaded = Path(self.image_path) if self.image_path else None
        if loaded is not None and loaded == Path(path) and loaded != before:
            # Every newly switched image starts from neutral display contrast.
            self.contrast_var.set(1.0)
            self.contrast_label_var.set(self._t('对比度 1.00×','Contrast 1.00×'))
            self._display_cache_key = None
            self._display_cache_image = None
        if retained_cal is not None:
            self.calibration = retained_cal
        self.refresh_lock_badges()
        self.refresh_measurement_log()
        self.render()
        try:
            self.app.refresh_global_state()
        except Exception:
            pass

    # ---------- movable horizontal alignment guide ----------
    def _load_rotation_angles(self):
        try:
            path = self._rotation_path()
        except Exception:
            return
        root = str(path.parent.resolve())
        if self.rotation_loaded_root == root:
            return
        self.rotation_loaded_root = root
        self.rotation_angles_by_image = {}
        self.alignment_guide_fracs_by_image = {}
        if not path.exists():
            return
        try:
            with path.open('r', newline='', encoding='utf-8-sig') as f:
                for r in csv.DictReader(f):
                    name = (r.get('image_name') or '').strip()
                    if not name:
                        continue
                    try:
                        a = clamp(float(r.get('rotation_deg', 0) or 0), -45.0, 45.0)
                    except Exception:
                        a = 0.0
                    try:
                        frac = clamp(float(r.get('guide_y_fraction', 0.5) or 0.5), 0.08, 0.92)
                    except Exception:
                        frac = 0.5
                    self.rotation_angles_by_image[name] = a
                    self.alignment_guide_fracs_by_image[name] = frac
        except Exception:
            self.rotation_angles_by_image = {}
            self.alignment_guide_fracs_by_image = {}

    def _save_rotation_angles(self):
        path = self._rotation_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        names = set(self.rotation_angles_by_image) | set(self.alignment_guide_fracs_by_image)
        with path.open('w', newline='', encoding='utf-8-sig') as f:
            w = csv.writer(f)
            w.writerow(['image_name','rotation_deg','guide_y_fraction','note'])
            for name in sorted(names):
                w.writerow([
                    name,
                    f"{float(self.rotation_angles_by_image.get(name,0.0)):.6f}",
                    f"{float(self.alignment_guide_fracs_by_image.get(name,0.5)):.6f}",
                    'Display/measurement alignment only; source image unchanged.'
                ])

    def _current_guide_frac(self):
        self._load_rotation_angles()
        key = self._measurement_key()
        if not key:
            return 0.5
        return clamp(float(self.alignment_guide_fracs_by_image.get(key,0.5)), 0.08, 0.92)

    def _draw_alignment_guide(self):
        if self.workspace != 'measure' or not self.alignment_active or self.original is None:
            return
        ch = max(1, self.canvas.winfo_height())
        cw = max(1, self.canvas.winfo_width())
        cy = ch * self._current_guide_frac()
        self.canvas.create_line(20, cy, max(21,cw-20), cy, fill='#00e5ff', width=2, dash=(10,5))
        self.canvas.create_text(cw/2, cy-10,
            text=self._t(f'水平参考 · {self._current_rotation_angle():+.2f}°', f'Horizontal guide · {self._current_rotation_angle():+.2f}°'),
            fill='#00e5ff', anchor=tk.S, font=('Segoe UI',10,'bold'))

    def on_left_press(self, event):
        if self.workspace == 'measure' and self.alignment_active and self.original is not None:
            cy = max(1, self.canvas.winfo_height()) * self._current_guide_frac()
            if abs(event.y - cy) <= 14:
                self.alignment_guide_dragging = True
                self.canvas.focus_set()
                return
        if self.mode.get() == 'delete' and self.workspace == 'annotate':
            p = self.screen_to_image(event.x, event.y)
            if p is not None and self.inside_image(*p):
                self._select_layer_object_at(p[0], p[1])
                if self.selected_object:
                    self.delete_selected_object()
            return
        super().on_left_press(event)

    def on_left_drag(self, event):
        if self.alignment_guide_dragging and self.workspace == 'measure':
            ch = max(1, self.canvas.winfo_height())
            frac = clamp(event.y / ch, 0.08, 0.92)
            key = self._measurement_key()
            if key:
                self.alignment_guide_fracs_by_image[key] = frac
            self.render()
            return
        super().on_left_drag(event)

    def on_left_release(self, event):
        if self.alignment_guide_dragging and self.workspace == 'measure':
            self.alignment_guide_dragging = False
            try:
                self._save_rotation_angles()
            except Exception:
                pass
            self.render()
            return
        super().on_left_release(event)

    def on_right_press(self, event):
        if self.workspace == 'measure':
            if self.measure_area_points:
                self.measure_area_points = []
                self.render()
                self._update_status(self._t('已取消当前面积圈选。','Current area drawing cancelled.'))
                return
            if self.measure_start is not None:
                self.measure_start = None
                self.measure_preview = None
                self.render()
                self._update_status(self._t('已取消当前未完成测量。','Current unfinished measurement cancelled.'))
                return
            self.undo_last_measurement()
            return
        super().on_right_press(event)

    def start_alignment_mode(self):
        super().start_alignment_mode()
        if self.alignment_active:
            # Force a redraw after the mode flag is active. This is harmless in
            # the legacy implementation and makes the visual state immediate.
            self.render()
            self._update_status(self._t(
                '水平校正已开启：青色水平线已显示。拖动青线可上下移动；在其他位置左右拖动可旋转图片。',
                'Horizontal alignment is active: the cyan guide is visible. Drag the guide vertically; drag elsewhere horizontally to rotate the image.'
            ))

    # ---------- measurement log: one value system on screen, both retained on disk ----------
    def refresh_measurement_log(self):
        if not hasattr(self, 'measure_tree'):
            return
        self.measure_log_frame.configure(text=(self._t('实时测量日志', 'Live measurement log') + (f' · {self.image_path.name}' if self.image_path else '')))
        for item in self.measure_tree.get_children():
            self.measure_tree.delete(item)
        calibrated = bool(self.calibration)
        self.measure_tree.heading('value', text=self._t('测量值', 'Value') if calibrated else self._t('像素值', 'Pixel value'))
        recs = self._measurement_records() if self.image_path else []
        for r in recs:
            kind = r.get('kind')
            typ = {'length':'Length','width':'Width','area':'Area'}.get(kind, kind)
            if calibrated:
                upp = self.calibration['unit_per_px']; unit = self.calibration['unit']
                if kind == 'area':
                    value = f"{r['value_px']*(upp**2):.3f} {unit}²"
                else:
                    value = f"{r['value_px']*upp:.3f} {unit}"
            else:
                value = f"{r['value_px']:.0f} px²" if kind == 'area' else f"{r['value_px']:.1f} px"
            iid = f"{kind}:{r.get('id',0)}"
            self.measure_tree.insert('', tk.END, iid=iid, values=(typ, r.get('id',''), value))
        self._update_measurement_summary()
        self.refresh_measurement_visibility_badge()

    # ---------- stage 3 delete / clear ----------
    def clear_annotation_layers(self):
        if self.workspace != 'annotate' or self.original is None:
            return
        if not messagebox.askyesno(self._t('一键清空', 'Clear all'), self._t(
            '清空当前图片的全部红色孔隙、蓝色参考线和黄色计算边界？\n\n第二步测量和标尺校准不会被删除。',
            'Clear all red pore regions, blue guides and the yellow calculation boundary for this image?\n\nStep-2 measurements and calibration will not be deleted.'
        )):
            return
        size = (self.img_w, self.img_h)
        self.mask = Image.new('L', size, 0)
        self.guide = Image.new('L', size, 0)
        self.region = Image.new('L', size, 0)
        self.boundary = Image.new('L', size, 0)
        self.selected_object = None
        self.boundary_points = []
        self.boundary_hover = None
        self.undo_stack.clear(); self.redo_stack.clear()
        self.dirty = True
        self.render()
        self._update_status(self._t('当前图层已清空；第二步测量与标尺保留。', 'Annotation layers cleared; Step-2 measurements and calibration remain.'))

    def _delete_at_canvas_pointer(self):
        if self.workspace == 'annotate':
            self.set_mode('delete')

    # ---------- portable project ----------
    def _build_poreproj(self):
        if not self.image_path:
            return None
        root = Path(self._project_root())
        stem = self.image_path.stem
        project_path = root / f'{stem}.poreproj'
        metadata = {
            'format': 'PorosityAnalyzerProject',
            'version': '2.11',
            'image_name': self.image_path.name,
            'stem': stem,
            'rotation_deg': self._current_rotation_angle(),
            'guide_y_fraction': self._current_guide_frac(),
            'calibration': self.calibration,
            'measurement_summary': {},
        }
        recs = self._measurement_records()
        lv=[r['value_px'] for r in recs if r.get('kind')=='length']
        wv=[r['value_px'] for r in recs if r.get('kind')=='width']
        av=[r['value_px'] for r in recs if r.get('kind')=='area']
        metadata['measurement_summary'] = {
            'n_length':len(lv),'mean_length_px':statistics.mean(lv) if lv else None,
            'n_width':len(wv),'mean_width_px':statistics.mean(wv) if wv else None,
            'n_area':len(av),'mean_area_px2':statistics.mean(av) if av else None,
            'ratio_from_means':(statistics.mean(lv)/statistics.mean(wv)) if (lv and wv and statistics.mean(wv)!=0) else None,
        }
        candidates = []
        def add(path, arc):
            p=Path(path)
            if p.exists() and p.is_file(): candidates.append((p,arc))
        add(self.image_path, f'source_images/{self.image_path.name}')
        add(root/f'{stem}_layer.png', f'{stem}_layer.png')
        add(root/f'{stem}_measurements.md', f'{stem}_measurements.md')
        for d, fn in [
            ('manual_masks',f'{stem}_mask.png'),
            ('manual_guides',f'{stem}_guide_mask.png'),
            ('manual_regions',f'{stem}_region_mask.png'),
            ('manual_regions',f'{stem}_boundary_mask.png'),
        ]:
            add(root/d/fn, f'{d}/{fn}')
        for fn in ('reference_measurements.csv','reference_measurements_summary.csv','scale_calibration.csv','view_rotation.csv','measurement_locks.csv','source_images.csv'):
            add(root/'manual_measurements'/fn, f'manual_measurements/{fn}')
        tmp = project_path.with_suffix('.poreproj.tmp')
        if tmp.exists():
            try: tmp.unlink()
            except Exception: pass
        with _zipfile.ZipFile(tmp, 'w', compression=_zipfile.ZIP_DEFLATED) as zf:
            zf.writestr('project.json', _json.dumps(metadata, ensure_ascii=False, indent=2))
            for p, arc in candidates:
                zf.write(p, arcname=arc)
        tmp.replace(project_path)
        return project_path

    def save_layers(self, silent=False):
        if self.image_path is None or self.original is None or self.mask is None:
            if not silent:
                messagebox.showwarning(self._t('没有图片','No image'), self._t('请先打开一张图片。','Open an image first.'))
            return
        # old staged save writes the visible layer + internal masks + measurement files
        super().save_layers(silent=True)
        try:
            project_path = self._build_poreproj()
        except Exception as exc:
            project_path = None
            if not silent:
                messagebox.showerror(self._t('项目文件保存失败','Project save failed'), str(exc))
                return
        if project_path:
            self._update_status(self._t(f'已保存项目：{project_path.name}', f'Project saved: {project_path.name}'))
            if not silent:
                messagebox.showinfo(self._t('保存完成','Saved'), self._t(
                    f'已保存图层结果，并生成可直接用于 ROI 的项目文件：\n{project_path}',
                    f'Layer results were saved and a portable ROI-ready project was created:\n{project_path}'
                ))


_ROICalculatorFrameV28 = StagedROICalculatorFrame


class StagedROICalculatorFrame(_ROICalculatorFrameV28):
    """v2.11 ROI: direct .poreproj open, no measurement-lock gate, optional ratio lock."""

    def __init__(self, parent, app):
        self._i18n_widgets = []
        self._tooltips = []
        self.ratio_locked = tk.BooleanVar(value=True)
        self.ratio_lock_text = tk.StringVar(value='🔒 比例锁定')
        self.pan_mode = False
        self.project_source_path = None
        self._temp_project_dirs = []
        self.space_down = False
        self.space_pan_active = False
        super().__init__(parent, app)
        self.canvas.bind('<KeyPress-m>', lambda e: self.toggle_pan_mode())
        self.canvas.bind('<KeyPress-space>', self._space_press)
        self.canvas.bind('<KeyRelease-space>', self._space_release)
        # Background/original-image toggle moves to O; Space is reserved for panning.
        self.canvas.bind('<KeyPress-o>', lambda e: self.toggle_roi_original())

    def _t(self, zh, en):
        return self.app.tr(zh,en) if hasattr(self.app,'tr') else zh

    def _reg(self, widget, zh, en, tip_zh=None, tip_en=None):
        self._i18n_widgets.append((widget,zh,en))
        try: widget.configure(text=self._t(zh,en))
        except Exception: pass
        if tip_zh or tip_en:
            self._tooltips.append(_HoverTip(widget, lambda z=(tip_zh or zh), e=(tip_en or en): self._t(z,e)))
        return widget

    def _btn(self,parent,zh,en,cmd,tip_zh=None,tip_en=None,**kw):
        b=ttk.Button(parent,command=cmd); self._reg(b,zh,en,tip_zh,tip_en); b.pack(**kw); return b

    def _build_ui(self):
        top=ttk.Frame(self); top.pack(side=tk.TOP,fill=tk.X,padx=6,pady=5)
        self.open_project_btn=self._btn(top,'打开项目文件','Open project',self.open_project_dialog,
            '打开第三步保存的新 .poreproj 项目文件。该单文件已经包含 ROI 所需的孔隙 Mask、原图、长宽测量、标尺和边界信息，因此可以直接从第四步开始。',
            'Open the new .poreproj file saved in Step 3. It already contains the pore mask, source image, measurements, calibration and boundary information required by ROI, so Steps 1–3 can be skipped.',
            side=tk.LEFT,padx=2)
        self.prev_btn=self._btn(top,'上一张','Previous',self.prev_mask,'切换上一张 Mask。','Previous mask.',side=tk.LEFT,padx=(10,2))
        self.next_btn=self._btn(top,'下一张','Next',self.next_mask,'切换下一张 Mask。','Next mask.',side=tk.LEFT,padx=2)
        self.fit_btn=self._btn(top,'适应窗口','Fit window',self.fit_to_window,'适应当前画布。','Fit image to canvas.',side=tk.LEFT,padx=(10,2))
        self.pan_btn=self._btn(top,'平移','Pan',self.toggle_pan_mode,
            '点击或按 M 切换持续平移模式；开启后按钮高亮，再次点击取消。也可以按住 Space + 鼠标左键临时平移。',
            'Click or press M to toggle persistent pan mode; the button stays highlighted while active. Click again to cancel. Hold Space + left mouse for temporary panning.',
            side=tk.LEFT,padx=2)
        self.original_btn=ttk.Button(top,textvariable=self.roi_original_btn_text,command=self.toggle_roi_original); self.original_btn.pack(side=tk.LEFT,padx=(10,2))
        self._tooltips.append(_HoverTip(self.original_btn, lambda:self._t(
            '在白底结果层与原图叠加显示之间切换；计算结果不变。快捷键 O。Space 专用于临时平移。',
            'Toggle white-background result vs. original-image overlay; calculations do not change. Shortcut: O. Space is reserved for temporary panning.'
        )))
        self.export_btn=self._btn(top,'导出 ROI 结果','Export ROI results',self.export_results,
            '单独导出当前 ROI 记录；最终综合报告仍在第五步生成。','Export ROI records separately; the combined final report is generated in Step 5.',side=tk.RIGHT,padx=3)

        roi_ctl=ttk.Frame(self); roi_ctl.pack(side=tk.TOP,fill=tk.X,padx=8,pady=(0,5))
        self.ref_label=ttk.Label(roi_ctl,textvariable=self.ref_summary_var); self.ref_label.pack(side=tk.LEFT,padx=(2,12))
        self.roi_length_label=ttk.Label(roi_ctl); self.roi_length_label.pack(side=tk.LEFT)
        self.roi_length_entry=ttk.Entry(roi_ctl,textvariable=self.roi_w_var,width=8); self.roi_length_entry.pack(side=tk.LEFT,padx=(2,8))
        self.roi_width_label=ttk.Label(roi_ctl); self.roi_width_label.pack(side=tk.LEFT)
        self.roi_width_entry=ttk.Entry(roi_ctl,textvariable=self.roi_h_var,width=8,state='readonly'); self.roi_width_entry.pack(side=tk.LEFT,padx=(2,8))
        self.ratio_btn=ttk.Button(roi_ctl,textvariable=self.ratio_lock_text,command=self.toggle_ratio_lock); self.ratio_btn.pack(side=tk.LEFT,padx=(3,2))
        self._tooltips.append(_HoverTip(self.ratio_btn, lambda:self._t('默认按平均 L/W 自动锁定 ROI 比例；解除后可自由输入长和宽。','By default ROI aspect ratio follows mean L/W; unlock to enter any length and width.')))
        self.generate_btn=self._btn(roi_ctl,'生成 ROI','Generate ROI',self.generate_roi,
            '生成 ROI。长度和宽度至少各有一次测量即可；建议各测五次取平均。','Generate ROI. At least one length and one width measurement are sufficient; five each are recommended.',side=tk.LEFT,padx=3)
        self.region_result_var=tk.StringVar(value='黄色边界内孔隙率: --')
        ttk.Label(roi_ctl,textvariable=self.region_result_var,font=('Segoe UI',10,'bold')).pack(side=tk.RIGHT,padx=8)
        self.roi_w_var.trace_add('write',lambda *_: self._sync_roi_height_from_ratio())

        main=ttk.Frame(self); main.pack(fill=tk.BOTH,expand=True)
        self.canvas=tk.Canvas(main,bg='#202020',highlightthickness=0,cursor='arrow'); self.canvas.pack(side=tk.LEFT,fill=tk.BOTH,expand=True)
        side=ttk.Frame(main,width=340); side.pack(side=tk.RIGHT,fill=tk.Y,padx=(5,7),pady=5); side.pack_propagate(False)
        self.current_box=ttk.LabelFrame(side); self.current_box.pack(fill=tk.X,pady=(0,8))
        self.current_text=tk.StringVar(value='')
        ttk.Label(self.current_box,textvariable=self.current_text,justify=tk.LEFT,anchor=tk.NW,font=('Segoe UI',10)).pack(fill=tk.X,padx=10,pady=10)
        self.porosity_big=tk.StringVar(value='Porosity: --')
        ttk.Label(self.current_box,textvariable=self.porosity_big,font=('Segoe UI',15,'bold')).pack(fill=tk.X,padx=10,pady=(0,10))
        self.record_btn=self._btn(side,'记录当前 ROI','Record current ROI',self.record_current_roi,
            '把当前 ROI 的尺寸和孔隙率加入本图正式记录。','Add the current ROI dimensions and porosity to this image record.',fill=tk.X,pady=(0,8),ipady=4)
        self.rec_box=ttk.LabelFrame(side); self.rec_box.pack(fill=tk.BOTH,expand=True)
        columns=('id','x','y','w','h','porosity')
        self.tree=ttk.Treeview(self.rec_box,columns=columns,show='headings',height=12,selectmode='browse')
        widths={'id':45,'x':45,'y':45,'w':50,'h':50,'porosity':85}
        for c in columns: self.tree.column(c,width=widths[c],anchor=tk.CENTER)
        self.tree.pack(fill=tk.BOTH,expand=True,padx=5,pady=5)
        actions=ttk.Frame(self.rec_box); actions.pack(fill=tk.X,padx=5,pady=(0,5))
        self.delete_rec_btn=self._btn(actions,'删除选中 ROI','Delete selected ROI',self.delete_selected_record,side=tk.LEFT,padx=(0,5))
        self.clear_rec_btn=self._btn(actions,'清空本图记录','Clear image records',self.clear_current_records,side=tk.LEFT)
        self.summary_var=tk.StringVar(value='N = 0    Mean = --    SD = --')
        ttk.Label(self.rec_box,textvariable=self.summary_var,font=('Segoe UI',10,'bold')).pack(fill=tk.X,padx=7,pady=(0,8))
        status=ttk.Frame(self); status.pack(side=tk.BOTTOM,fill=tk.X)
        self.status_var=tk.StringVar(value='')
        ttk.Label(status,textvariable=self.status_var,anchor=tk.W).pack(side=tk.LEFT,fill=tk.X,expand=True,padx=8,pady=3)
        self.zoom_var=tk.StringVar(value='Zoom: 100%'); ttk.Label(status,textvariable=self.zoom_var).pack(side=tk.RIGHT,padx=8)
        self.apply_language(); self.update_live_roi()

    def apply_language(self):
        for w,zh,en in getattr(self,'_i18n_widgets',[]):
            try: w.configure(text=self._t(zh,en))
            except Exception: pass
        if hasattr(self,'roi_length_label'):
            self.roi_length_label.configure(text=self._t('ROI 长度(px):','ROI length (px):'))
            self.roi_width_label.configure(text=self._t('ROI 宽度(px):','ROI width (px):'))
            self.current_box.configure(text=self._t('当前 ROI（实时）','Current ROI (live)'))
            self.rec_box.configure(text=self._t('本图已记录 ROI','Recorded ROI for this image'))
            heads={'id':('ROI','ROI'),'x':('X','X'),'y':('Y','Y'),'w':('W','W'),'h':('H','H'),'porosity':('Porosity %','Porosity %')}
            for c,(zh,en) in heads.items(): self.tree.heading(c,text=self._t(zh,en))
        self._update_ratio_button()
        self.update_live_roi()

    def toggle_pan_mode(self):
        self.pan_mode=not self.pan_mode
        try:
            self.pan_btn.state(['pressed'] if self.pan_mode else ['!pressed'])
        except Exception:
            pass
        self.canvas.configure(cursor='fleur' if self.pan_mode else 'arrow')
        self.status_var.set(self._t(
            '持续平移已开启；按钮高亮。再次点击“平移”或按 M 关闭。Space + 鼠标左键可随时临时平移。' if self.pan_mode else '持续平移已关闭；Space + 鼠标左键仍可临时平移。',
            'Persistent pan is on; the button is highlighted. Click Pan again or press M to turn it off. Space + left mouse always provides temporary pan.' if self.pan_mode else 'Persistent pan is off; Space + left mouse still provides temporary pan.'
        ))

    def _space_press(self,event=None):
        self.space_down=True
        self.canvas.configure(cursor='fleur')

    def _space_release(self,event=None):
        self.space_down=False
        if not self.space_pan_active:
            self.canvas.configure(cursor='fleur' if self.pan_mode else 'arrow')

    def on_left_press(self,event):
        if self.space_down and self.mask is not None:
            self.space_pan_active=True
            self.panning=True
            self.pan_last=(event.x,event.y)
            self.canvas.configure(cursor='fleur')
            return
        if self.pan_mode and self.mask is not None:
            self.panning=True; self.pan_last=(event.x,event.y); self.canvas.configure(cursor='fleur'); return
        super().on_left_press(event)

    def on_left_drag(self,event):
        if (self.pan_mode or self.space_pan_active) and self.panning:
            return ROICalculatorFrame.on_pan_drag(self,event)
        super().on_left_drag(event)

    def on_left_release(self,event):
        if (self.pan_mode or self.space_pan_active) and self.panning:
            ROICalculatorFrame.on_pan_release(self,event)
            self.space_pan_active=False
            self.canvas.configure(cursor='fleur' if (self.pan_mode or self.space_down) else 'arrow')
            return
        super().on_left_release(event)

    def _get_output_root(self):
        # ROI export follows the output address chosen on Step 5 whenever available.
        try:
            report_root = getattr(self.app.report, 'output_root', None)
            if report_root:
                root = Path(report_root) / 'ROI_results'
                root.mkdir(parents=True, exist_ok=True)
                return root
        except Exception:
            pass
        return super()._get_output_root()

    def toggle_ratio_lock(self):
        self.ratio_locked.set(not self.ratio_locked.get())
        self._update_ratio_button()
        if self.ratio_locked.get():
            self.roi_width_entry.configure(state='readonly')
            self._sync_roi_height_from_ratio()
        else:
            self.roi_width_entry.configure(state='normal')
        self.status_var.set(self._t(
            'ROI 比例已锁定为平均 L/W。' if self.ratio_locked.get() else 'ROI 比例已解除；长度和宽度均可自由输入。',
            'ROI aspect ratio is locked to mean L/W.' if self.ratio_locked.get() else 'ROI aspect ratio unlocked; length and width are both editable.'
        ))

    def _update_ratio_button(self):
        if hasattr(self,'ratio_lock_text'):
            self.ratio_lock_text.set(self._t('🔒 比例锁定','🔒 Ratio locked') if self.ratio_locked.get() else self._t('🔓 自由输入','🔓 Free input'))

    def _sync_roi_height_from_ratio(self):
        if not getattr(self,'ratio_locked',tk.BooleanVar(value=True)).get():
            return
        return ROICalculatorFrame._sync_roi_height_from_ratio(self)

    def _load_reference_stats(self):
        # Deliberately bypass the v2.8 staged lock gate: raw Step-2 logs are authoritative for ROI.
        ROICalculatorFrame._load_reference_stats(self)
        if self.ref_ratio is not None and min(self.ref_n_length,self.ref_n_width) < 5:
            self.ref_summary_var.set(self.ref_summary_var.get() + self._t('  [可用；建议各≥5次]','  [usable; ≥5 each recommended]'))
        self._sync_roi_height_from_ratio()

    def generate_roi(self):
        if self.mask is None:
            messagebox.showwarning(self._t('没有数据','No data'), self._t('请先打开 .poreproj 或 binary mask。','Open a .poreproj or binary mask first.'))
            return
        if self.ref_n_length < 1 or self.ref_n_width < 1 or self.ref_ratio in (None,0):
            missing=[]
            if self.ref_n_length<1: missing.append('Length')
            if self.ref_n_width<1: missing.append('Width')
            messagebox.showwarning(self._t('缺少长宽测量','Missing length/width measurements'), self._t(
                f"尚未记录 {' / '.join(missing)}。至少需要 Length 和 Width 各 1 次；建议各测 5 次取平均值。",
                f"No {' / '.join(missing)} measurement has been recorded. At least one Length and one Width are required; five each are recommended for averaging."
            ))
            return
        try:
            w=int(round(float(self.roi_w_var.get())))
            if self.ratio_locked.get():
                h=int(round(w/self.ref_ratio))
                self.roi_h_var.set(str(h))
            else:
                h=int(round(float(self.roi_h_var.get())))
        except Exception:
            messagebox.showerror(self._t('输入错误','Invalid input'), self._t('ROI 长度和宽度必须是数字。','ROI length and width must be numeric.'))
            return
        if w<=0 or h<=0:
            messagebox.showerror(self._t('输入错误','Invalid input'), self._t('ROI 长度和宽度必须大于 0。','ROI length and width must be greater than zero.'))
            return
        if w>self.img_w or h>self.img_h:
            messagebox.showerror(self._t('ROI 太大','ROI too large'), self._t(
                f'当前图片尺寸为 {self.img_w} × {self.img_h} px，ROI 为 {w} × {h} px。',
                f'Image size is {self.img_w} × {self.img_h} px; ROI is {w} × {h} px.'
            )); return
        self.roi=[(self.img_w-w)//2,(self.img_h-h)//2,w,h]
        self.update_live_roi(); self.render()
        self.status_var.set(self._t(
            f'已生成 ROI：{w} × {h} px。拖动方框可实时更新孔隙率。',
            f'ROI generated: {w} × {h} px. Drag it to update porosity live.'
        ))

    def update_live_roi(self):
        result=self.calculate_current_roi()
        if result is None:
            self.current_text.set(self._t(
                '尚未生成 ROI\n\n至少需要 1 次 Length + 1 次 Width；建议各测 5 次取平均。',
                'No ROI yet\n\nAt least 1 Length + 1 Width are required; 5 each are recommended for averaging.'
            ))
            self.porosity_big.set('Porosity: --'); return
        self.current_text.set(
            f"Width = {result['width']} px\n"
            f"Height = {result['height']} px\n\n"
            f"Pore pixels = {result['pore_pixels']:,}\n"
            f"ROI pixels = {result['roi_pixels']:,}"
        )
        self.porosity_big.set(f"Porosity: {result['porosity_percent']:.4f} %")

    def open_project_dialog(self):
        initial = self.project_source_path.parent if self.project_source_path else (self.input_folder or Path.home())
        path=filedialog.askopenfilename(title=self._t('打开 Porosity Analyzer 项目','Open Porosity Analyzer project'),initialdir=str(initial),filetypes=[('Porosity project','*.poreproj'),('All files','*.*')])
        if path: self.load_project_file(Path(path))

    def load_project_file(self,path:Path):
        try:
            td=Path(_tempfile.mkdtemp(prefix='porosity_v29_'))
            with _zipfile.ZipFile(path,'r') as zf:
                zf.extractall(td)
            mask_dir=td/'manual_masks'
            masks=sorted(mask_dir.glob('*_mask.png')) if mask_dir.exists() else []
            if not masks: raise ValueError('manual_masks/*_mask.png not found')
            self._temp_project_dirs.append(td)
            self.project_source_path=Path(path)
            self.project_root=td
            self.input_folder=mask_dir
            self._build_mask_list(mask_dir,selected=masks[0])
            self.load_mask(masks[0])
            self.status_var.set(self._t(f'已打开项目：{path.name}',f'Project opened: {path.name}'))
        except Exception as exc:
            messagebox.showerror(self._t('项目打开失败','Project open failed'),str(exc))

    def _load_source_original(self):
        self.original_rgb=None
        if self.mask is None: return
        base=self._mask_base_stem().lower()
        if self.project_root:
            srcdir=self.project_root/'source_images'
            if srcdir.exists():
                for p in srcdir.iterdir():
                    if p.is_file() and is_image_file(p) and p.stem.lower()==base:
                        try:
                            im=Image.open(p).convert('RGB')
                            if im.size==self.mask.size:
                                self.original_rgb=im; return
                        except Exception: pass
        return _ROICalculatorFrameV28._load_source_original(self)

    def load_mask(self,path:Path):
        # Preserve an explicitly extracted .poreproj root; legacy mask load still infers root normally.
        explicit_root=self.project_root if self.project_source_path else None
        ROICalculatorFrame.load_mask(self,path)
        if explicit_root is not None:
            self.project_root=explicit_root
            self._load_calibration_from_root(); self._load_reference_stats(); self._load_region_for_current_mask()
        # portable layer
        if self.project_root and self.mask is not None:
            stem=self._mask_base_stem(path)
            lp=self.project_root/f'{stem}_layer.png'
            if lp.exists():
                try:
                    im=Image.open(lp).convert('RGB')
                    if im.size==self.mask.size: self.layer_rgb=im; self.display_rgb=im
                except Exception: pass
            self._load_source_original(); self.roi_show_original=False; self.roi_original_btn_text.set(self._t('显示原图','Show original')); self.render()
        self._load_reference_stats(); self.update_live_roi()

    def refresh_stage_state(self):
        # Normal path: take the current saved image from Step 3.
        try:
            ann=self.app.annotator
            if ann.image_path:
                root=Path(ann._project_root())
                p=root/'manual_masks'/f'{ann.image_path.stem}_mask.png'
                if p.exists():
                    self.project_source_path=None
                    self.project_root=root; self.input_folder=p.parent
                    self._build_mask_list(p.parent,selected=p); self.load_mask(p); return
        except Exception: pass
        if self.mask_path:
            if not self.project_source_path:
                self.project_root=self._infer_project_root(self.mask_path)
            self._load_calibration_from_root(); self._load_reference_stats(); self._load_region_for_current_mask(); self.update_live_roi()


_ReportFrameV28 = StagedReportFrame


class StagedReportFrame(_ReportFrameV28):
    """v2.11 report page: only output address, preview, timestamped generation, optional workspace reset."""
    def __init__(self,parent,app):
        self._i18n_widgets=[]; self._tooltips=[]
        super().__init__(parent,app)

    def _t(self,zh,en): return self.app.tr(zh,en) if hasattr(self.app,'tr') else zh
    def _reg(self,w,zh,en,tip_zh=None,tip_en=None):
        self._i18n_widgets.append((w,zh,en));
        try:w.configure(text=self._t(zh,en))
        except Exception:pass
        if tip_zh or tip_en:self._tooltips.append(_HoverTip(w,lambda z=(tip_zh or zh),e=(tip_en or en):self._t(z,e)))
        return w
    def _btn(self,p,zh,en,cmd,tip_zh=None,tip_en=None,**kw):
        b=ttk.Button(p,command=cmd);self._reg(b,zh,en,tip_zh,tip_en);b.pack(**kw);return b

    def _build_ui(self):
        top=ttk.Frame(self); top.pack(fill=tk.X,padx=8,pady=8)
        self.output_btn=self._btn(top,'文件输出地址','Output location',self.choose_output_root,
            '选择最终报告输出位置。每次生成都会使用新的时间戳，不覆盖旧报告。','Choose the final-report output location. Each generation uses a new timestamp and never overwrites an older report.',side=tk.LEFT,padx=2)
        self.refresh_btn=self._btn(top,'刷新预览','Refresh preview',self.refresh_preview,
            '重新汇总当前工作流中的黄色区域、ROI 和测量数据。','Refresh the current yellow-region, ROI and measurement summary.',side=tk.LEFT,padx=(12,2))
        self.generate_btn=self._btn(top,'生成最终报告','Generate final report',self.generate_report,
            '生成带时间戳的 Excel、文本摘要和 QC 图。','Generate timestamped Excel, text summary and QC overlays.',side=tk.RIGHT,padx=2,ipadx=16,ipady=4)
        self.path_var=tk.StringVar(value='')
        ttk.Label(self,textvariable=self.path_var,anchor=tk.W).pack(fill=tk.X,padx=10,pady=(0,6))
        self.info=ttk.LabelFrame(self); self.info.pack(fill=tk.X,padx=8,pady=(0,8))
        self.info_text=tk.StringVar(value='')
        ttk.Label(self.info,textvariable=self.info_text,justify=tk.LEFT,anchor=tk.W).pack(fill=tk.X,padx=10,pady=8)
        frame=ttk.Frame(self); frame.pack(fill=tk.BOTH,expand=True,padx=8,pady=(0,8))
        columns=('image','blue','nroi','roimean','nl','lmean','nw','wmean','ratio')
        self.tree=ttk.Treeview(frame,columns=columns,show='headings',selectmode='browse')
        widths={'image':190,'blue':110,'nroi':70,'roimean':110,'nl':75,'lmean':100,'nw':75,'wmean':100,'ratio':90}
        for c in columns:self.tree.column(c,width=widths[c],anchor=tk.CENTER)
        self.tree.pack(fill=tk.BOTH,expand=True)
        bottom=ttk.Frame(self);bottom.pack(fill=tk.X,padx=8,pady=(0,8))
        self.status_var=tk.StringVar(value='');ttk.Label(bottom,textvariable=self.status_var,anchor=tk.W).pack(side=tk.LEFT,fill=tk.X,expand=True)
        self.apply_language(); self.refresh_preview()

    def apply_language(self):
        for w,zh,en in getattr(self,'_i18n_widgets',[]):
            try:w.configure(text=self._t(zh,en))
            except Exception:pass
        if hasattr(self,'info'):
            self.info.configure(text=self._t('最终报告内容','Final report contents'))
            self.info_text.set(self._t(
                '黄色边界整体孔隙率 + 已记录 ROI 的孔隙率及 Mean/SD + Length/Width/Area 单次与统计 + 标尺换算（如已校准）。\n重置只清空当前软件工作状态，不会删除已经输出到硬盘的报告。',
                'Yellow-region porosity + recorded ROI porosity and Mean/SD + Length/Width/Area measurements and statistics + physical calibration when available.\nReset clears only the current application workspace and never deletes reports already written to disk.'
            ))
            heads={
                'image':('Image','Image'),'blue':('Yellow region %','Yellow region %'),'nroi':('N ROI','N ROI'),'roimean':('ROI Mean %','ROI Mean %'),
                'nl':('N Length','N Length'),'lmean':('Mean L px','Mean L px'),'nw':('N Width','N Width'),'wmean':('Mean W px','Mean W px'),'ratio':('L/W','L/W')}
            for c,(z,e) in heads.items():self.tree.heading(c,text=self._t(z,e))
        self._refresh_path_label()

    def _resolve_current_project(self):
        root=None
        try:
            if getattr(self.app.roi_calc,'project_root',None): root=Path(self.app.roi_calc.project_root)
            elif getattr(self.app.annotator,'image_path',None): root=Path(self.app.annotator._project_root())
        except Exception: pass
        if root: self.project_root=root
        return root

    def _refresh_path_label(self):
        src=self.project_root
        out=self.output_root
        self.path_var.set(self._t(
            f"当前数据源：{src if src else '--'}    文件输出地址：{out if out else '--'}",
            f"Current data source: {src if src else '--'}    Output location: {out if out else '--'}"
        ))

    def choose_output_root(self):
        initial=self.output_root
        if initial is None:
            try:
                if getattr(self.app.roi_calc,'project_source_path',None): initial=Path(self.app.roi_calc.project_source_path).parent
                elif getattr(self.app.annotator,'output_root',None): initial=Path(self.app.annotator.output_root)
                elif getattr(self.app.annotator,'input_folder',None): initial=Path(self.app.annotator.input_folder)
            except Exception: pass
        initial=initial or (DEFAULT_FOLDER if DEFAULT_FOLDER.exists() else Path.home())
        folder=filedialog.askdirectory(title=self._t('选择最终报告输出地址','Choose final report output location'),initialdir=str(initial))
        if folder:
            self.output_root=Path(folder); self._refresh_path_label(); self.status_var.set(self._t(f'输出地址：{self.output_root}',f'Output: {self.output_root}'))

    def _collect_data(self):
        # Use all Step-2 logs; measurement lock is optional and never gates reporting.
        return ReportFrame._collect_data(self)

    def refresh_preview(self):
        self._resolve_current_project(); self._refresh_path_label()
        if self.project_root is None:
            for x in self.tree.get_children():self.tree.delete(x)
            self.status_var.set(self._t('当前还没有可汇总的数据。','No data are currently available for summary.')); return
        ReportFrame.refresh_preview(self)
        self._refresh_path_label()

    def _append_area_sheets(self,xlsx_path,data):
        try:
            from openpyxl import load_workbook
            wb=load_workbook(xlsx_path)
            for s in ('area_measurements','area_summary'):
                if s in wb.sheetnames: del wb[s]
            cal=data.get('calibration'); upp=cal['unit_per_px'] if cal else None; unit=cal['unit'] if cal else ''
            mby=data.get('measurement_by_stem',{})
            ws=wb.create_sheet('area_measurements')
            ws.append(['image_name','area_id','area_px2',f'area_{unit}2' if unit else 'area_calibrated_sq','unit_squared'])
            for d in data.get('images',[]):
                rows=sorted([r for r in mby.get(d['stem'],[]) if r.get('type')=='area'],key=lambda r:r.get('id',0))
                for r in rows:
                    av=r['value_px']*(upp**2) if upp is not None else None
                    ws.append([d['stem'],r['id'],r['value_px'],av,f'{unit}^2' if unit else ''])
            self._style_sheet(ws)
            ws=wb.create_sheet('area_summary');ws.append(['image_name','n_area','mean_area_px2','sd_area_px2',f'mean_area_{unit}2' if unit else 'mean_area_calibrated_sq'])
            for d in data.get('images',[]):
                vals=[r['value_px'] for r in mby.get(d['stem'],[]) if r.get('type')=='area']
                mean=statistics.mean(vals) if vals else None; sd=statistics.stdev(vals) if len(vals)>=2 else None
                ws.append([d['stem'],len(vals),mean,sd,mean*(upp**2) if (mean is not None and upp is not None) else None])
            self._style_sheet(ws);wb.save(xlsx_path)
        except Exception as exc:
            self.status_var.set(self._t(f'报告已生成，但面积附加表写入失败：{exc}',f'Report generated, but area sheets failed: {exc}'))

    def generate_report(self):
        self._resolve_current_project()
        if self.project_root is None:
            messagebox.showwarning(self._t('没有数据','No data'),self._t('当前没有可以生成报告的数据。','There are no data available for a report.'));return
        if Workbook is None:
            messagebox.showerror('openpyxl',self._t('缺少 openpyxl。','openpyxl is not available.'));return
        data=self._collect_data()
        if not data or not data.get('images'):
            messagebox.showwarning(self._t('没有结果','No results'),self._t('没有找到已保存的图层结果。','No saved layer results were found.'));return
        base=self.output_root
        if base is None:
            try:
                if getattr(self.app.roi_calc,'project_source_path',None): base=Path(self.app.roi_calc.project_source_path).parent
                elif getattr(self.app.annotator,'output_root',None): base=Path(self.app.annotator.output_root)
                elif getattr(self.app.annotator,'input_folder',None): base=Path(self.app.annotator.input_folder)
            except Exception: pass
        base=Path(base or (self.project_root/'final_report'));base.mkdir(parents=True,exist_ok=True)
        stamp=_datetime.now().strftime('%Y%m%d_%H%M%S')
        run_dir=base/f'Porosity_Report_{stamp}'
        run_dir.mkdir(parents=True,exist_ok=True)
        previous_output=self.output_root; self.output_root=run_dir
        # Suppress the legacy completion popup; v2.11 shows one reset/continue dialog instead.
        old_info=messagebox.showinfo
        def filtered_info(title,*args,**kwargs):
            if str(title) in ('最终报告完成','保存完成'): return None
            return old_info(title,*args,**kwargs)
        messagebox.showinfo=filtered_info
        try:
            ReportFrame.generate_report(self)
        finally:
            messagebox.showinfo=old_info
        old_xlsx=run_dir/'porosity_final_report.xlsx'; old_txt=run_dir/'porosity_final_summary.txt'
        xlsx=run_dir/f'Porosity_Report_{stamp}.xlsx'; txt=run_dir/f'Porosity_Report_{stamp}.txt'
        if old_xlsx.exists(): old_xlsx.replace(xlsx)
        if old_txt.exists(): old_txt.replace(txt)
        if xlsx.exists(): self._append_area_sheets(xlsx,data)
        self.output_root=previous_output or base
        self._refresh_path_label(); self.status_var.set(self._t(f'最终报告已成功生成：{run_dir}',f'Final report generated successfully: {run_dir}'))
        reset=messagebox.askyesno(self._t('输出成功','Export successful'),self._t(
            f'最终报告已成功生成。\n\n输出位置：\n{run_dir}\n\n是否重置当前工作区？\n（标尺锁定保留；已输出文件不会删除。）',
            f'Final report generated successfully.\n\nOutput:\n{run_dir}\n\nReset the current workspace?\n(Calibration is retained; exported files are never deleted.)'
        ))
        if reset:
            self.app.reset_workspace_keep_calibration()
        else:
            self.refresh_preview()


_PoreToolAppV28 = PoreToolApp


# ============================================================
# v2.11 — Step-3 layout + portable normalized project + Step-4 handoff
# ============================================================

import io as _io_v211

_StagedAnnotatorFrameV210 = StagedAnnotatorFrame


class StagedAnnotatorFrame(_StagedAnnotatorFrameV210):
    """v2.11: Step 3 keeps Preview/Save on row 2 and moves view/edit actions to row 3."""

    def __init__(self, parent, app):
        self.annotation_hidden_all = False
        super().__init__(parent, app)

        # Row-2 annotation quick frame must contain only Preview + Save.
        try:
            self.delete_mode_btn.pack_forget()
            self.clear_annotation_btn.pack_forget()
        except Exception:
            pass

        # Row 3: add requested general actions after the drawing controls.
        self.annotate_action_sep = ttk.Separator(self.annotate_bar, orient=tk.VERTICAL)
        self.annotate_action_sep.pack(side=tk.LEFT, fill=tk.Y, padx=8, pady=3)

        self.fit3_btn = self._button(
            self.annotate_bar, '适应窗口', 'Fit window', self.fit_to_window,
            '自动缩放并居中，使整张图片适合当前画布。',
            'Fit and center the whole image in the canvas.',
            side=tk.LEFT, padx=2, pady=4
        )
        self.pan3_btn = self._button(
            self.annotate_bar, '平移', 'Pan', self.toggle_pan_mode,
            '点击此按钮或按 M 切换持续平移模式；开启时按钮高亮，再次点击取消。任意工具下也可按住 Space + 鼠标左键临时平移。',
            'Click this button or press M to toggle persistent pan mode; the button stays highlighted while active. Hold Space + left mouse for temporary panning.',
            side=tk.LEFT, padx=2, pady=4
        )
        self.delete3_btn = self._button(
            self.annotate_bar, '删除', 'Delete', lambda: self.set_mode('delete'),
            '进入删除模式后，直接点击红色孔隙、蓝色参考线或黄色边界即可删除。',
            'Enter delete mode, then click a red pore, blue guide, or yellow boundary to remove it.',
            side=tk.LEFT, padx=2, pady=4
        )
        self.hide3_text = tk.StringVar(value=self._t('隐藏全部', 'Hide all'))
        self.hide3_btn = ttk.Button(self.annotate_bar, textvariable=self.hide3_text, command=self.toggle_annotation_layers)
        self.hide3_btn.pack(side=tk.LEFT, padx=2, pady=4)
        self._tooltips.append(_HoverTip(self.hide3_btn, lambda: self._t(
            '仅隐藏/恢复当前图上的红色孔隙、蓝色参考线和黄色计算边界；不会删除任何标注或数据。',
            'Hide/restore the red pores, blue guide and yellow formal boundary visually only; no annotation or data is deleted.'
        )))
        self.clear3_btn = self._button(
            self.annotate_bar, '一键清空', 'Clear all', self.clear_annotation_layers,
            '清空当前图的红色孔隙、蓝色参考线和黄色计算边界；不会删除标尺或第二步测量。',
            'Clear current red pores, blue guides and yellow boundary; calibration and Step-2 measurements remain.',
            side=tk.LEFT, padx=2, pady=4
        )

        self.apply_language()

    def apply_language(self):
        super().apply_language()
        if hasattr(self, 'hide3_text'):
            self.hide3_text.set(self._t(
                '显示全部' if self.annotation_hidden_all else '隐藏全部',
                'Show all' if self.annotation_hidden_all else 'Hide all'
            ))

    def _set_pan_visual(self, active):
        super()._set_pan_visual(active)
        if hasattr(self, 'pan3_btn'):
            try:
                self.pan3_btn.state(['pressed'] if active else ['!pressed'])
            except Exception:
                pass

    def _restore_common_fit_pan(self, before_widget=None):
        # Reinsert common Fit/Pan in their original role on Steps 1–2.
        for w in (self.fit_btn, self.pan_btn):
            try:
                w.pack_forget()
            except Exception:
                pass
        kw_fit = dict(side=tk.LEFT, padx=(10, 2))
        kw_pan = dict(side=tk.LEFT, padx=2)
        if before_widget is not None:
            kw_fit['before'] = before_widget
            kw_pan['before'] = before_widget
        self.fit_btn.pack(**kw_fit)
        self.pan_btn.pack(**kw_pan)

    def set_workspace(self, which):
        super().set_workspace(which)

        # Preview + Save stay on row 2 immediately after Next in Step 3.
        if which == 'annotate':
            try:
                self.fit_btn.pack_forget()
                self.pan_btn.pack_forget()
                self.delete_mode_btn.pack_forget()
                self.clear_annotation_btn.pack_forget()
            except Exception:
                pass
        elif which == 'calibrate':
            self._restore_common_fit_pan(self.cal_only_frame)
        elif which == 'measure':
            self._restore_common_fit_pan(self.contrast_frame)

    def toggle_annotation_layers(self):
        if self.workspace != 'annotate':
            return
        self.annotation_hidden_all = not self.annotation_hidden_all
        self.overlay_visible.set(not self.annotation_hidden_all)
        self.hide3_text.set(self._t(
            '显示全部' if self.annotation_hidden_all else '隐藏全部',
            'Show all' if self.annotation_hidden_all else 'Hide all'
        ))
        self.render()
        self._update_status(self._t(
            '已隐藏全部标注层；数据仍完整保留。' if self.annotation_hidden_all else '已恢复显示全部标注层。',
            'All annotation layers are hidden; the data is still retained.' if self.annotation_hidden_all else 'All annotation layers are visible again.'
        ))

    def clear_annotation_layers(self):
        # Clear means data removal; ensure the visual layer is no longer left hidden afterwards.
        self.annotation_hidden_all = False
        self.overlay_visible.set(True)
        if hasattr(self, 'hide3_text'):
            self.hide3_text.set(self._t('隐藏全部', 'Hide all'))
        return super().clear_annotation_layers()

    # ---------- portable project in normalized working coordinates ----------
    @staticmethod
    def _png_bytes_v211(img):
        buf = _io_v211.BytesIO()
        img.save(buf, format='PNG')
        return buf.getvalue()

    def _working_source_v211(self):
        """Return the Step-2 visual working image: contrast + confirmed rotation, without changing source pixels."""
        if self.original is None:
            return None
        try:
            contrast = clamp(float(self.contrast_var.get()), 0.35, 5.0)
        except Exception:
            contrast = 1.0
        angle = float(self._current_rotation_angle())
        img = self.original.copy()
        if abs(contrast - 1.0) > 1e-9:
            img = ImageEnhance.Contrast(img).enhance(contrast)
        if abs(angle) > 1e-9:
            img = img.rotate(
                angle,
                resample=Image.Resampling.BICUBIC,
                expand=False,
                fillcolor=(32, 32, 32)
            )
        return img

    def _rotate_binary_v211(self, layer, angle):
        if layer is None:
            return Image.new('L', (self.img_w, self.img_h), 0)
        binary = layer.convert('L').point(lambda p: 255 if p >= 128 else 0, mode='L')
        if abs(angle) <= 1e-9:
            return binary
        return binary.rotate(
            angle,
            resample=Image.Resampling.NEAREST,
            expand=False,
            fillcolor=0
        ).point(lambda p: 255 if p >= 128 else 0, mode='L')

    def _build_poreproj(self):
        """
        Save a single ROI-ready project.

        The portable project's formal coordinate system is the saved Step-2 working view:
        contrast-adjusted + rotation-corrected image. Annotation masks are rotated by the
        same angle so the image, mask and region remain exactly registered in Step 4.
        The untouched source image is additionally retained under raw_source/ for traceability.
        """
        if not self.image_path or self.original is None:
            return None

        root = Path(self._project_root())
        stem = self.image_path.stem
        project_path = root / f'{stem}.poreproj'
        angle = float(self._current_rotation_angle())
        try:
            contrast = clamp(float(self.contrast_var.get()), 0.35, 5.0)
        except Exception:
            contrast = 1.0

        recs = self._measurement_records()
        lv = [r['value_px'] for r in recs if r.get('kind') == 'length']
        wv = [r['value_px'] for r in recs if r.get('kind') == 'width']
        av = [r['value_px'] for r in recs if r.get('kind') == 'area']
        lm = statistics.mean(lv) if lv else None
        wm = statistics.mean(wv) if wv else None

        metadata = {
            'format': 'PorosityAnalyzerProject',
            'version': '2.11',
            'image_name': self.image_path.name,
            'stem': stem,
            'coordinate_system': 'saved_working_view',
            'display_contrast': contrast,
            'rotation_deg': angle,
            'guide_y_fraction': self._current_guide_frac(),
            'calibration': self.calibration,
            'measurement_summary': {
                'n_length': len(lv),
                'mean_length_px': lm,
                'n_width': len(wv),
                'mean_width_px': wm,
                'n_area': len(av),
                'mean_area_px2': statistics.mean(av) if av else None,
                'ratio_from_means': (lm / wm) if (lm is not None and wm not in (None, 0)) else None,
            },
        }

        working = self._working_source_v211()
        pore = self._rotate_binary_v211(self.mask, angle)
        guide = self._rotate_binary_v211(self.guide, angle)
        region = self._rotate_binary_v211(self.region, angle)
        boundary = self._rotate_binary_v211(self.boundary, angle)

        # Portable white result layer in the same normalized coordinates.
        white = Image.new('RGB', working.size, (255, 255, 255))
        red = Image.new('RGB', working.size, (255, 0, 0))
        blue = Image.new('RGB', working.size, (0, 110, 255))
        yellow = Image.new('RGB', working.size, (255, 215, 0))
        portable_layer = Image.composite(red, white, pore)
        portable_layer = Image.composite(blue, portable_layer, guide)
        portable_layer = Image.composite(yellow, portable_layer, boundary)

        tmp = project_path.with_suffix('.poreproj.tmp')
        if tmp.exists():
            try:
                tmp.unlink()
            except Exception:
                pass

        with _zipfile.ZipFile(tmp, 'w', compression=_zipfile.ZIP_DEFLATED) as zf:
            zf.writestr('project.json', _json.dumps(metadata, ensure_ascii=False, indent=2))

            # Step-4 source image is the saved working view, not a re-read raw image.
            zf.writestr(f'source_images/{stem}.png', self._png_bytes_v211(working))
            zf.writestr(f'manual_masks/{stem}_mask.png', self._png_bytes_v211(pore))
            zf.writestr(f'manual_guides/{stem}_guide_mask.png', self._png_bytes_v211(guide))
            zf.writestr(f'manual_regions/{stem}_region_mask.png', self._png_bytes_v211(region))
            zf.writestr(f'manual_regions/{stem}_boundary_mask.png', self._png_bytes_v211(boundary))
            zf.writestr(f'{stem}_layer.png', self._png_bytes_v211(portable_layer))

            # Keep the untouched source only for traceability; Step 4 never uses it as its working background.
            try:
                zf.write(self.image_path, arcname=f'raw_source/{self.image_path.name}')
            except Exception:
                pass

            md = root / f'{stem}_measurements.md'
            if md.exists():
                zf.write(md, arcname=f'{stem}_measurements.md')

            for fn in (
                'reference_measurements.csv', 'reference_measurements_summary.csv',
                'scale_calibration.csv', 'view_rotation.csv', 'measurement_locks.csv',
                'source_images.csv'
            ):
                p = root / 'manual_measurements' / fn
                if p.exists() and p.is_file():
                    zf.write(p, arcname=f'manual_measurements/{fn}')

        tmp.replace(project_path)
        return project_path


_StagedROICalculatorFrameV210 = StagedROICalculatorFrame


class StagedROICalculatorFrame(_StagedROICalculatorFrameV210):
    """v2.11: Step 4 is driven by saved .poreproj files and can unload the current project."""

    def __init__(self, parent, app):
        super().__init__(parent, app)
        # Insert directly after Show/Hide original in the same top row.
        self.remove_project_btn = self._btn(
            self.original_btn.master,
            '移除当前图片', 'Remove current image', self.remove_current_project,
            '从第四步画布移除当前 .poreproj 工作图；不会删除项目文件或已经记录/输出的数据。之后可立即打开下一个项目文件。',
            'Unload the current .poreproj working image from Step 4; the project file and recorded/exported data are not deleted. You can then open the next project immediately.',
            side=tk.LEFT, padx=2
        )
        self.apply_language()

    def remove_current_project(self):
        # Do not delete the .poreproj or exported files. Keep session ROI records in memory.
        self.mask_path = None
        self.mask_files = []
        self.mask_index = -1
        self.input_folder = None
        self.project_root = None
        self.project_source_path = None
        self.mask = None
        self.display_rgb = None
        self.layer_rgb = None
        self.original_rgb = None
        self.region_mask = None
        self.region_porosity = None
        self.tk_img = None
        self.img_w = 0
        self.img_h = 0
        self.roi = None
        self.ref_mean_length = None
        self.ref_mean_width = None
        self.ref_ratio = None
        self.ref_n_length = 0
        self.ref_n_width = 0
        self.roi_show_original = False
        self.roi_original_btn_text.set(self._t('显示原图', 'Show original'))
        self.ref_summary_var.set(self._t('参考样条: --', 'Reference: --'))
        self.region_result_var.set(self._t('黄色边界内孔隙率: --', 'Yellow-region porosity: --'))
        self.roi_w_var.set('500')
        self.roi_h_var.set('--')
        self.canvas.delete('all')
        self.refresh_record_table()
        self.update_live_roi()
        self.status_var.set(self._t(
            '已移除当前项目；可直接打开下一个 .poreproj。',
            'Current project removed; open the next .poreproj directly.'
        ))

    def refresh_stage_state(self):
        """When arriving from Step 3, load only the saved .poreproj, never the loose legacy mask."""
        try:
            ann = self.app.annotator
            if ann.image_path:
                project = Path(ann._project_root()) / f'{ann.image_path.stem}.poreproj'
                if project.exists() and not ann.dirty:
                    if self.project_source_path is None or Path(self.project_source_path) != project:
                        self.load_project_file(project)
                    return
        except Exception:
            pass
        # Direct Step-4 usage: preserve an already opened .poreproj; otherwise wait for Open project.
        if self.project_source_path and self.mask is not None:
            self._load_calibration_from_root()
            self._load_reference_stats()
            self._load_region_for_current_mask()
            self.update_live_roi()




class PoreToolApp(tk.Tk):
    """v2.11 final staged application with bilingual interface and explicit reset semantics."""
    def __init__(self):
        tk.Tk.__init__(self)
        self.language_code='zh'
        self.language_display_var=tk.StringVar(value='中文')
        self.title('Manual Pore Annotator v2.11')
        self.geometry('1500x930'); self.minsize(1120,720)
        nav=ttk.Frame(self);nav.pack(side=tk.TOP,fill=tk.X,padx=8,pady=(7,4))
        self.stage_buttons={}
        for key in ('calibrate','measure','annotate','roi','report'):
            b=ttk.Button(nav,command=lambda k=key:self.show_module(k));b.pack(side=tk.LEFT,padx=(0,7),ipadx=12,ipady=5);self.stage_buttons[key]=b
        self.global_state_var=tk.StringVar(value='')
        ttk.Label(nav,textvariable=self.global_state_var,anchor=tk.E,font=('Segoe UI',9,'bold')).pack(side=tk.RIGHT,padx=(12,4))
        ttk.Separator(self,orient=tk.HORIZONTAL).pack(fill=tk.X)
        self.body=ttk.Frame(self);self.body.pack(fill=tk.BOTH,expand=True)
        self.annotator=StagedAnnotatorFrame(self.body,app=self)
        self.roi_calc=StagedROICalculatorFrame(self.body,app=self)
        self.report=StagedReportFrame(self.body,app=self)
        self.current_module=None
        self.apply_language(); self.show_module('calibrate')

    def tr(self,zh,en): return en if self.language_code=='en' else zh

    def set_language_from_display(self):
        self.language_code='en' if self.language_display_var.get()=='English' else 'zh'
        self.apply_language()

    def set_language(self, code):
        self.language_code = 'en' if str(code).lower().startswith('en') else 'zh'
        self.language_display_var.set('English' if self.language_code == 'en' else '中文')
        self.apply_language()

    def apply_language(self):
        labels={
            'calibrate':('① 标尺校准','① Scale calibration'),
            'measure':('② 尺寸 / 面积测量','② Dimension / area'),
            'annotate':('③ 图层标注','③ Layer annotation'),
            'roi':('④ ROI 测试','④ ROI analysis'),
            'report':('⑤ 报告整理','⑤ Final report'),
        }
        for k,b in getattr(self,'stage_buttons',{}).items(): b.configure(text=self.tr(*labels[k]))
        for f in (getattr(self,'annotator',None),getattr(self,'roi_calc',None),getattr(self,'report',None)):
            try:f.apply_language()
            except Exception:pass
        self.refresh_global_state()
        if self.current_module: self._refresh_title()

    def _refresh_title(self):
        titles={
            'calibrate':('① 标尺校准','① Scale calibration'),'measure':('② 尺寸 / 面积测量','② Dimension / area measurement'),
            'annotate':('③ 图层标注','③ Layer annotation'),'roi':('④ ROI 测试','④ ROI analysis'),'report':('⑤ 报告整理','⑤ Final report')}
        self.title(f"Manual Pore Annotator v2.11 — {self.tr(*titles.get(self.current_module,('','')))}")

    def refresh_global_state(self):
        try:
            c=self.annotator.calibration
            cal=(self.tr('🔒 标尺锁定: ','🔒 Scale locked: ')+f"1 px = {c['unit_per_px']:.6g} {c['unit']}") if c else self.tr('○ 标尺未锁定','○ Scale unlocked')
            self.global_state_var.set(cal)
            try:
                self.annotator.refresh_lock_badges()
            except Exception:
                pass
        except Exception:
            self.global_state_var.set(self.tr('○ 标尺未锁定','○ Scale unlocked'))

    def show_module(self,which):
        if self.current_module==which:
            if which=='report': self.report.refresh_preview()
            elif which=='roi': self.roi_calc.refresh_stage_state()
            self.refresh_global_state(); return
        self.annotator.pack_forget();self.roi_calc.pack_forget();self.report.pack_forget()
        if which in ('calibrate','measure','annotate'):
            self.annotator.pack(fill=tk.BOTH,expand=True);self.annotator.set_workspace(which);self.annotator.canvas.focus_set()
        elif which=='roi':
            self.roi_calc.pack(fill=tk.BOTH,expand=True);self.roi_calc.refresh_stage_state();self.roi_calc.canvas.focus_set()
        else:
            self.report.pack(fill=tk.BOTH,expand=True);self.report.refresh_preview()
        self.current_module=which;self.refresh_global_state();self._refresh_title()

    def reset_workspace_keep_calibration(self):
        ann=self.annotator
        cal=dict(ann.calibration) if ann.calibration else None
        # Clear only live application state. No source file, project file or exported report is deleted.
        ann.image_path=None;ann.image_files=[];ann.image_index=-1;ann.input_folder=None;ann.output_root=None
        ann.original=None;ann.mask=None;ann.guide=None;ann.region=None;ann.boundary=None;ann.tk_img=None;ann.img_w=ann.img_h=0
        ann.measurements_by_image={};ann.measurements_loaded_root=None
        ann.measurement_locked_by_image={};ann.measurement_lock_snapshots_by_image={};ann.measurement_lock_loaded_root=None
        ann.measurement_hidden_kinds_by_image={};ann.measurement_visibility_phase_by_image={}
        ann.rotation_angles_by_image={};ann.alignment_guide_fracs_by_image={};ann.rotation_loaded_root=None
        ann.alignment_active=False;ann.alignment_dragging=False;ann.alignment_guide_dragging=False
        ann._pan_mode_active=False;ann._pan_previous_mode=None
        ann.contrast_var.set(1.0);ann.contrast_label_var.set(self.tr('对比度 1.00×','Contrast 1.00×'))
        ann.selected_object=None;ann.boundary_points=[];ann.boundary_hover=None;ann.measure_area_points=[];ann.measure_start=None;ann.measure_preview=None
        ann.undo_stack.clear();ann.redo_stack.clear();ann.dirty=False;ann.layer_preview_only=False;ann._display_cache_key=None;ann._display_cache_image=None
        ann.calibration=cal; ann.calibration_loaded_root='__retained_calibration__' if cal else None
        ann.canvas.delete('all');ann.refresh_measurement_log();ann.refresh_lock_badges();ann.refresh_measurement_visibility_badge()

        roi=self.roi_calc
        roi.mask_path=None;roi.mask_files=[];roi.mask_index=-1;roi.input_folder=None;roi.output_root=None;roi.project_root=None;roi.project_source_path=None
        roi.mask=None;roi.display_rgb=None;roi.layer_rgb=None;roi.original_rgb=None;roi.region_mask=None;roi.region_porosity=None;roi.tk_img=None;roi.img_w=roi.img_h=0
        roi.roi=None;roi.records_by_image={};roi.records_loaded_root=None;roi.ref_mean_length=roi.ref_mean_width=roi.ref_ratio=None;roi.ref_n_length=roi.ref_n_width=0
        roi.pan_mode=False;roi.space_down=False;roi.space_pan_active=False
        try: roi.pan_btn.state(['!pressed'])
        except Exception: pass
        roi.roi_w_var.set('500');roi.roi_h_var.set('--');roi.ratio_locked.set(True);roi._update_ratio_button();roi.ref_summary_var.set(self.tr('参考样条: --','Reference: --'))
        roi.region_result_var.set(self.tr('黄色边界内孔隙率: --','Yellow-region porosity: --'));roi.canvas.delete('all')
        for x in roi.tree.get_children():roi.tree.delete(x)
        roi.summary_var.set('N = 0    Mean = --    SD = --');roi.update_live_roi()

        rep=self.report
        rep.project_root=None;rep.output_root=None;rep.preview_rows=[]
        for x in rep.tree.get_children():rep.tree.delete(x)
        rep.status_var.set(self.tr('工作区已重置；标尺校准保留。','Workspace reset; calibration retained.'));rep._refresh_path_label()
        self.show_module('calibrate');ann._update_status(self.tr('已重置：仅保留标尺校准。','Reset complete: only calibration was retained.'));self.refresh_global_state()



_PoreToolAppV210 = PoreToolApp


class PoreToolApp(_PoreToolAppV210):
    """v2.11 application gate: Step 3 must be saved before handing its current image to Step 4."""

    def show_module(self, which):
        if which == 'roi' and getattr(self, 'current_module', None) == 'annotate':
            ann = self.annotator
            if ann.image_path:
                try:
                    project = Path(ann._project_root()) / f'{ann.image_path.stem}.poreproj'
                except Exception:
                    project = None
                if ann.dirty or project is None or not project.exists():
                    messagebox.showwarning(
                        self.tr('请先保存', 'Save first'),
                        self.tr(
                            '当前第三步结果尚未保存。请先点击“保存”生成 .poreproj，再进入第四步。',
                            'The current Step-3 result has not been saved. Click Save to create the .poreproj before entering Step 4.'
                        )
                    )
                    return
        return super().show_module(which)


# ============================================================
# v2.12 — sequential handoff + integer-N ROI + clean folders
#          + dated project files + report-stays-open fix
# ============================================================

_V212_WORK_FOLDER = "PorosityAnalyzer_Project"
_V212_REPORT_FOLDER = "PorosityAnalyzer_Reports"


def _v212_source_root_from_project(project_root=None, project_file=None):
    """Infer the original-image folder without scattering outputs into it."""
    try:
        if project_file:
            p = Path(project_file)
            parent = p.parent
            if parent.name == _V212_WORK_FOLDER:
                return parent.parent
        if project_root:
            p = Path(project_root)
            if p.name == _V212_WORK_FOLDER:
                return p.parent
    except Exception:
        pass
    return None


_StagedAnnotatorFrameV211 = StagedAnnotatorFrame


class StagedAnnotatorFrame(_StagedAnnotatorFrameV211):
    """v2.12: Step-2 visual corrections become the formal Step-3 working image."""

    def __init__(self, parent, app):
        self._v212_source_folder = None
        self._v212_manual_output = False
        self._v212_stage3_baked_key = None
        self._v212_stage3_applied_contrast = 1.0
        self._v212_stage3_applied_rotation = 0.0
        self._v212_pre_stage3_original = None
        self.last_saved_project_path_v212 = None
        super().__init__(parent, app)

    # ---------- clean automatic folder layout ----------
    def _v212_prepare_default_output(self, source_folder):
        source_folder = Path(source_folder)
        changed = self._v212_source_folder is None or Path(self._v212_source_folder) != source_folder
        if changed:
            self._v212_source_folder = source_folder
            self._v212_manual_output = False
            self.output_root = source_folder / _V212_WORK_FOLDER
        elif self.output_root is None:
            self.output_root = source_folder / _V212_WORK_FOLDER

        Path(self.output_root).mkdir(parents=True, exist_ok=True)

    def choose_output_folder(self):
        initial = self.output_root or self.input_folder or DEFAULT_FOLDER
        folder = filedialog.askdirectory(
            title=self._t('选择项目输出文件夹', 'Choose project output folder'),
            initialdir=str(initial)
        )
        if folder:
            self.output_root = Path(folder)
            self.output_root.mkdir(parents=True, exist_ok=True)
            self._v212_manual_output = True
            self._update_status(self._t(
                f'项目输出文件夹：{self.output_root}',
                f'Project output folder: {self.output_root}'
            ))

    def load_image(self, path: Path):
        path = Path(path)
        source_folder = path.parent
        # Opening a new source folder always gets/reuses one clean project subfolder.
        if self._v212_source_folder is None or Path(self._v212_source_folder) != source_folder:
            self._v212_prepare_default_output(source_folder)
        elif not self._v212_manual_output and self.output_root is None:
            self._v212_prepare_default_output(source_folder)

        # Reset per-image forward-handoff marker whenever another source image is loaded.
        before = Path(self.image_path) if self.image_path else None
        super().load_image(path)
        after = Path(self.image_path) if self.image_path else None
        if after is not None and after == path and after != before:
            self._v212_stage3_baked_key = None
            self._v212_pre_stage3_original = None
            self.last_saved_project_path_v212 = None

    # ---------- Step 2 -> Step 3 formal image handoff ----------
    def _v212_working_state_path(self):
        root = Path(self._project_root())
        p = root / "manual_measurements" / "working_view_state.csv"
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    def _v212_read_saved_working_state(self):
        if not self.image_path:
            return None
        path = self._v212_working_state_path()
        if not path.exists():
            return None
        try:
            with path.open("r", newline="", encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    if (r.get("image_name") or "").strip() == self.image_path.name:
                        return {
                            "contrast": float(r.get("contrast", 1.0) or 1.0),
                            "rotation_deg": float(r.get("rotation_deg", 0.0) or 0.0),
                            "working_image": r.get("working_image", ""),
                        }
        except Exception:
            return None
        return None

    def _v212_write_saved_working_state(self):
        if not self.image_path:
            return
        path = self._v212_working_state_path()
        rows = []
        if path.exists():
            try:
                with path.open("r", newline="", encoding="utf-8-sig") as f:
                    rows = list(csv.DictReader(f))
            except Exception:
                rows = []

        image_name = self.image_path.name
        rows = [r for r in rows if (r.get("image_name") or "").strip() != image_name]
        work_rel = f"working_images/{self.image_path.stem}_working.png"
        rows.append({
            "image_name": image_name,
            "contrast": f"{self._v212_stage3_applied_contrast:.6f}",
            "rotation_deg": f"{self._v212_stage3_applied_rotation:.6f}",
            "working_image": work_rel,
        })
        with path.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=["image_name","contrast","rotation_deg","working_image"])
            w.writeheader()
            w.writerows(rows)

    def prepare_stage3_from_step2_v212(self):
        """
        Freeze the currently corrected Step-2 appearance as Step-3 coordinates.
        Contrast and rotation are baked into an in-memory working image only.
        The source file on disk is never modified.
        """
        if self.image_path is None or self.original is None:
            messagebox.showwarning(
                self._t('没有图片', 'No image'),
                self._t('请先在第一步打开图片。', 'Open an image in Step 1 first.')
            )
            return False

        key = str(Path(self.image_path).resolve())
        if self._v212_stage3_baked_key == key:
            return True

        try:
            contrast = clamp(float(self.contrast_var.get()), 0.35, 5.0)
        except Exception:
            contrast = 1.0
        angle = float(self._current_rotation_angle())

        # If a v2.12 working state already exists and matches the current Step-2
        # correction, reuse its working image and already-aligned masks.
        saved = self._v212_read_saved_working_state()
        if saved:
            same = (
                abs(saved.get("contrast", 1.0) - contrast) < 1e-6 and
                abs(saved.get("rotation_deg", 0.0) - angle) < 1e-6
            )
            wp = Path(self._project_root()) / saved.get("working_image", "")
            if same and wp.exists():
                try:
                    work = Image.open(wp).convert("RGB")
                    if work.size == self.original.size:
                        self._v212_pre_stage3_original = self.original.copy()
                        self.original = work
                        self.img_w, self.img_h = work.size
                        self._v212_stage3_applied_contrast = contrast
                        self._v212_stage3_applied_rotation = angle
                        self._v212_stage3_baked_key = key
                        self.contrast_var.set(1.0)
                        self.contrast_label_var.set(self._t('对比度 1.00×','Contrast 1.00×'))
                        self._display_cache_key = None
                        self._display_cache_image = None
                        self.after(10, self.fit_to_window)
                        return True
                except Exception:
                    pass

        raw = self.original.copy()
        work = raw.copy()
        if abs(contrast - 1.0) > 1e-9:
            work = ImageEnhance.Contrast(work).enhance(contrast)
        if abs(angle) > 1e-9:
            work = work.rotate(
                angle,
                resample=Image.Resampling.BICUBIC,
                expand=False,
                fillcolor=(32,32,32)
            )

        # Existing v2.11 layers are defined on the raw image. Move them once into
        # the corrected Step-3 coordinates so drawing and image remain registered.
        def rotate_binary(layer):
            if layer is None:
                return Image.new("L", raw.size, 0)
            b = layer.convert("L").point(lambda p: 255 if p >= 128 else 0, mode="L")
            if abs(angle) <= 1e-9:
                return b
            return b.rotate(
                angle, resample=Image.Resampling.NEAREST,
                expand=False, fillcolor=0
            ).point(lambda p: 255 if p >= 128 else 0, mode="L")

        self._v212_pre_stage3_original = raw
        self.original = work
        self.mask = rotate_binary(self.mask)
        self.guide = rotate_binary(self.guide)
        self.region = rotate_binary(self.region)
        self.boundary = rotate_binary(self.boundary)
        self.img_w, self.img_h = work.size

        self._v212_stage3_applied_contrast = contrast
        self._v212_stage3_applied_rotation = angle
        self._v212_stage3_baked_key = key

        # Step 3 now works in the corrected raster, so display corrections must not
        # be applied a second time.
        self.contrast_var.set(1.0)
        self.contrast_label_var.set(self._t('对比度 1.00×','Contrast 1.00×'))
        self._display_cache_key = None
        self._display_cache_image = None
        self.selected_object = None
        self.undo_stack.clear()
        self.redo_stack.clear()
        self.dirty = True
        self.after(10, self.fit_to_window)
        self.render()
        self._update_status(self._t(
            f'第二步修正已传递到第三步：对比度 {contrast:.2f}×，旋转 {angle:+.2f}°。',
            f'Step-2 corrections handed to Step 3: contrast {contrast:.2f}×, rotation {angle:+.2f}°.'
        ))
        return True

    def set_workspace(self, which):
        # The app calls prepare_stage3_from_step2_v212 before switching into Step 3.
        return super().set_workspace(which)

    # ---------- save one portable dated transfer file ----------
    def _build_poreproj(self):
        if not self.image_path or self.original is None:
            return None

        root = Path(self._project_root())
        root.mkdir(parents=True, exist_ok=True)
        stem = self.image_path.stem
        date_tag = _datetime.now().strftime("%Y%m%d")
        project_path = root / f"{stem}_{date_tag}.poreproj"

        # If Step 3 was reached through the required handoff, self.original and all
        # masks are already in the corrected working coordinates. Do not rotate them again.
        applied_contrast = float(getattr(self, "_v212_stage3_applied_contrast", 1.0))
        applied_angle = float(getattr(self, "_v212_stage3_applied_rotation", 0.0))

        recs = self._measurement_records()
        lv = [r["value_px"] for r in recs if r.get("kind") == "length"]
        wv = [r["value_px"] for r in recs if r.get("kind") == "width"]
        av = [r["value_px"] for r in recs if r.get("kind") == "area"]
        lm = statistics.mean(lv) if lv else None
        wm = statistics.mean(wv) if wv else None

        metadata = {
            "format": "PorosityAnalyzerProject",
            "version": "2.12",
            "image_name": self.image_path.name,
            "stem": stem,
            "created_date": date_tag,
            "coordinate_system": "step2_corrected_working_view",
            "display_contrast_applied": applied_contrast,
            "rotation_deg_applied": applied_angle,
            "guide_y_fraction": self._current_guide_frac(),
            "calibration": self.calibration,
            "measurement_summary": {
                "n_length": len(lv),
                "mean_length_px": lm,
                "n_width": len(wv),
                "mean_width_px": wm,
                "n_area": len(av),
                "mean_area_px2": statistics.mean(av) if av else None,
                "ratio_from_means": (lm / wm) if (lm is not None and wm not in (None, 0)) else None,
            },
        }

        working = self.original.copy()
        pore = self.mask.convert("L").point(lambda p: 255 if p >= 128 else 0, mode="L")
        guide = self.guide.convert("L").point(lambda p: 255 if p >= 128 else 0, mode="L")
        region = self.region.convert("L").point(lambda p: 255 if p >= 128 else 0, mode="L")
        boundary = self.boundary.convert("L").point(lambda p: 255 if p >= 128 else 0, mode="L")

        white = Image.new("RGB", working.size, (255,255,255))
        red = Image.new("RGB", working.size, (255,0,0))
        blue = Image.new("RGB", working.size, (0,110,255))
        yellow = Image.new("RGB", working.size, (255,215,0))
        portable_layer = Image.composite(red, white, pore)
        portable_layer = Image.composite(blue, portable_layer, guide)
        portable_layer = Image.composite(yellow, portable_layer, boundary)

        tmp = project_path.with_suffix(".poreproj.tmp")
        if tmp.exists():
            try: tmp.unlink()
            except Exception: pass

        with _zipfile.ZipFile(tmp, "w", compression=_zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("project.json", _json.dumps(metadata, ensure_ascii=False, indent=2))
            zf.writestr(f"source_images/{stem}.png", self._png_bytes_v211(working))
            zf.writestr(f"manual_masks/{stem}_mask.png", self._png_bytes_v211(pore))
            zf.writestr(f"manual_guides/{stem}_guide_mask.png", self._png_bytes_v211(guide))
            zf.writestr(f"manual_regions/{stem}_region_mask.png", self._png_bytes_v211(region))
            zf.writestr(f"manual_regions/{stem}_boundary_mask.png", self._png_bytes_v211(boundary))
            zf.writestr(f"{stem}_layer.png", self._png_bytes_v211(portable_layer))

            try:
                zf.write(self.image_path, arcname=f"raw_source/{self.image_path.name}")
            except Exception:
                pass

            md = root / f"{stem}_measurements.md"
            if md.exists():
                zf.write(md, arcname=f"{stem}_measurements.md")

            for fn in (
                "reference_measurements.csv", "reference_measurements_summary.csv",
                "scale_calibration.csv", "view_rotation.csv",
                "working_view_state.csv", "source_images.csv"
            ):
                p = root / "manual_measurements" / fn
                if p.exists() and p.is_file():
                    zf.write(p, arcname=f"manual_measurements/{fn}")

        tmp.replace(project_path)
        return project_path

    def save_layers(self, silent=False):
        result = super().save_layers(silent=True)
        # super() already calls this class's _build_poreproj through dynamic dispatch.
        # Persist the corrected working raster next to project data for reopening.
        if self.image_path and self.original is not None:
            try:
                wdir = Path(self._project_root()) / "working_images"
                wdir.mkdir(parents=True, exist_ok=True)
                self.original.save(wdir / f"{self.image_path.stem}_working.png", format="PNG")
                self._v212_write_saved_working_state()
                date_tag = _datetime.now().strftime("%Y%m%d")
                p = Path(self._project_root()) / f"{self.image_path.stem}_{date_tag}.poreproj"
                if p.exists():
                    self.last_saved_project_path_v212 = p
            except Exception:
                pass

        if not silent and self.last_saved_project_path_v212:
            messagebox.showinfo(
                self._t('保存完成', 'Saved'),
                self._t(
                    f'第三步已保存。\n\n中转项目文件：\n{self.last_saved_project_path_v212}',
                    f'Step 3 saved.\n\nTransfer project file:\n{self.last_saved_project_path_v212}'
                )
            )
        return result


_StagedROICalculatorFrameV211 = StagedROICalculatorFrame


class StagedROICalculatorFrame(_StagedROICalculatorFrameV211):
    """v2.12 ROI sizing: N=0 means manual; integer N>=2 means N×mean L and N×mean W."""

    def __init__(self, parent, app):
        self._roi_n_syncing_v212 = False
        self.roi_n_var = tk.StringVar(value="2")
        super().__init__(parent, app)

        # Remove the old aspect-ratio lock button; N now owns automatic dimensions.
        try:
            self.ratio_btn.pack_forget()
        except Exception:
            pass

        # Insert N before ROI length.
        self.roi_n_label = ttk.Label(self.roi_length_label.master)
        self.roi_n_label.pack(side=tk.LEFT, before=self.roi_length_label, padx=(2,2))
        self.roi_n_entry = ttk.Spinbox(
            self.roi_length_label.master,
            textvariable=self.roi_n_var,
            from_=0, to=50, increment=1, width=5
        )
        self.roi_n_entry.pack(side=tk.LEFT, before=self.roi_length_label, padx=(0,10))
        self._tooltips.append(_HoverTip(self.roi_n_entry, lambda: self._t(
            'N=2,3,4… 时，ROI 长和宽分别自动设为 N×平均 Length 与 N×平均 Width；N=0 时才允许手动输入 ROI 长和宽。N=1 不作为正式自动模式。',
            'For N=2,3,4… ROI length and width are set automatically to N×mean Length and N×mean Width. Only N=0 enables manual length/width entry. N=1 is not a formal automatic mode.'
        )))
        self.roi_n_var.trace_add("write", lambda *_: self._v212_sync_roi_from_n())
        self._v212_sync_roi_from_n()
        self.apply_language()

    def apply_language(self):
        super().apply_language()
        if hasattr(self, "roi_n_label"):
            self.roi_n_label.configure(text=self._t("ROI 倍数 N:", "ROI multiplier N:"))
            self.roi_length_label.configure(text=self._t("ROI 长度(px):", "ROI length (px):"))
            self.roi_width_label.configure(text=self._t("ROI 宽度(px):", "ROI width (px):"))

    def _parse_n_v212(self, popup=False):
        s = (self.roi_n_var.get() or "").strip()
        try:
            v = float(s)
        except Exception:
            if popup:
                messagebox.showerror(
                    self._t("N 输入错误", "Invalid N"),
                    self._t("N 必须为 0，或大于等于 2 的整数。", "N must be 0 or an integer greater than or equal to 2.")
                )
            return None
        if abs(v - round(v)) > 1e-9:
            if popup:
                messagebox.showerror(
                    self._t("N 输入错误", "Invalid N"),
                    self._t("N 必须是整数。", "N must be an integer.")
                )
            return None
        n = int(round(v))
        if n != 0 and n < 2:
            if popup:
                messagebox.showerror(
                    self._t("N 输入错误", "Invalid N"),
                    self._t("自动模式下 N 必须大于等于 2；如需自由输入长宽，请设 N=0。", "Automatic mode requires N>=2. Set N=0 for manual length/width entry.")
                )
            return None
        return n

    def _sync_roi_height_from_ratio(self):
        # Old length->ratio trace remains installed by the parent UI.
        # v2.12 dimensions are governed only by N; avoid the old behavior.
        if hasattr(self, "roi_n_var"):
            return
        return super()._sync_roi_height_from_ratio()

    def _v212_sync_roi_from_n(self):
        if self._roi_n_syncing_v212 or not hasattr(self, "roi_length_entry"):
            return
        self._roi_n_syncing_v212 = True
        try:
            n = self._parse_n_v212(popup=False)
            if n == 0:
                self.roi_length_entry.configure(state="normal")
                self.roi_width_entry.configure(state="normal")
                self.status_var.set(self._t(
                    "N=0：已启用手动 ROI 长宽输入。",
                    "N=0: manual ROI length/width entry is enabled."
                ))
                return

            self.roi_length_entry.configure(state="readonly")
            self.roi_width_entry.configure(state="readonly")
            if n is None:
                return

            if self.ref_mean_length is not None and self.ref_mean_width is not None:
                w = max(1, int(round(n * self.ref_mean_length)))
                h = max(1, int(round(n * self.ref_mean_width)))
                self.roi_w_var.set(str(w))
                self.roi_h_var.set(str(h))
        finally:
            self._roi_n_syncing_v212 = False

    def _load_reference_stats(self):
        # Load the same raw Step-2 measurement statistics, then let N define dimensions.
        _StagedROICalculatorFrameV211._load_reference_stats(self)
        self._v212_sync_roi_from_n()

    def generate_roi(self):
        if self.mask is None:
            messagebox.showwarning(
                self._t("没有数据", "No data"),
                self._t("请先打开 .poreproj。", "Open a .poreproj first.")
            )
            return

        if self.ref_n_length < 1 or self.ref_n_width < 1 or self.ref_ratio in (None, 0):
            missing = []
            if self.ref_n_length < 1: missing.append("Length")
            if self.ref_n_width < 1: missing.append("Width")
            messagebox.showwarning(
                self._t("缺少长宽测量", "Missing length/width measurements"),
                self._t(
                    f"尚未记录 {' / '.join(missing)}。至少需要 Length 和 Width 各 1 次。",
                    f"No {' / '.join(missing)} measurement has been recorded. At least one Length and one Width are required."
                )
            )
            return

        n = self._parse_n_v212(popup=True)
        if n is None:
            return

        try:
            if n == 0:
                w = int(round(float(self.roi_w_var.get())))
                h = int(round(float(self.roi_h_var.get())))
            else:
                w = int(round(n * self.ref_mean_length))
                h = int(round(n * self.ref_mean_width))
                self.roi_w_var.set(str(w))
                self.roi_h_var.set(str(h))
        except Exception:
            messagebox.showerror(
                self._t("输入错误", "Invalid input"),
                self._t("ROI 长度和宽度必须是数字。", "ROI length and width must be numeric.")
            )
            return

        if w <= 0 or h <= 0:
            messagebox.showerror(
                self._t("输入错误", "Invalid input"),
                self._t("ROI 长度和宽度必须大于 0。", "ROI length and width must be greater than zero.")
            )
            return
        if w > self.img_w or h > self.img_h:
            messagebox.showerror(
                self._t("ROI 太大", "ROI too large"),
                self._t(
                    f"当前图片尺寸为 {self.img_w} × {self.img_h} px，ROI 为 {w} × {h} px。",
                    f"Image size is {self.img_w} × {self.img_h} px; ROI is {w} × {h} px."
                )
            )
            return

        self.roi = [(self.img_w-w)//2, (self.img_h-h)//2, w, h]
        self.update_live_roi()
        self.render()
        mode_txt = self._t(
            "手动尺寸" if n == 0 else f"N={n}（{n}×平均长宽）",
            "manual dimensions" if n == 0 else f"N={n} ({n}× mean dimensions)"
        )
        self.status_var.set(self._t(
            f"已生成 ROI：{w} × {h} px；{mode_txt}。",
            f"ROI generated: {w} × {h} px; {mode_txt}."
        ))

    def load_project_file(self, path: Path):
        super().load_project_file(path)
        self._v212_sync_roi_from_n()

    def refresh_stage_state(self):
        # Prefer the exact dated project just saved in Step 3.
        try:
            ann = self.app.annotator
            p = getattr(ann, "last_saved_project_path_v212", None)
            if p and Path(p).exists() and not ann.dirty:
                p = Path(p)
                if self.project_source_path is None or Path(self.project_source_path) != p:
                    self.load_project_file(p)
                return
        except Exception:
            pass

        # Reopened source folder: use the newest dated transfer project for this image.
        try:
            ann = self.app.annotator
            if ann.image_path and not ann.dirty:
                root = Path(ann._project_root())
                matches = sorted(
                    root.glob(f"{ann.image_path.stem}_*.poreproj"),
                    key=lambda p: p.stat().st_mtime,
                    reverse=True
                )
                if matches:
                    p = matches[0]
                    if self.project_source_path is None or Path(self.project_source_path) != p:
                        self.load_project_file(p)
                    return
        except Exception:
            pass

        if self.project_source_path and self.mask is not None:
            self._load_calibration_from_root()
            self._load_reference_stats()
            self._load_region_for_current_mask()
            self.update_live_roi()

    def remove_current_project(self):
        super().remove_current_project()
        self.roi_n_var.set("2")
        self._v212_sync_roi_from_n()

    def _get_output_root(self):
        # Keep any optional ROI-only export inside the project/report structure,
        # never loose in the raw-image folder.
        try:
            report_root = getattr(self.app.report, "output_root", None)
            if report_root:
                root = Path(report_root) / "ROI_results"
                root.mkdir(parents=True, exist_ok=True)
                return root
        except Exception:
            pass
        try:
            if self.project_source_path:
                root = Path(self.project_source_path).parent / "ROI_results"
            elif self.project_root:
                root = Path(self.project_root) / "ROI_results"
            else:
                root = Path.home() / "PorosityAnalyzer_ROI_results"
            root.mkdir(parents=True, exist_ok=True)
            return root
        except Exception:
            return super()._get_output_root()


_StagedReportFrameV211 = StagedReportFrame


class StagedReportFrame(_StagedReportFrameV211):
    """v2.12: clean default report folder and never terminate the application after export."""

    def _default_report_root_v212(self):
        try:
            ann = self.app.annotator
            if getattr(ann, "input_folder", None):
                return Path(ann.input_folder) / _V212_REPORT_FOLDER
        except Exception:
            pass
        try:
            p = getattr(self.app.roi_calc, "project_source_path", None)
            root = _v212_source_root_from_project(project_file=p)
            if root:
                return root / _V212_REPORT_FOLDER
        except Exception:
            pass
        try:
            root = _v212_source_root_from_project(project_root=self.project_root)
            if root:
                return root / _V212_REPORT_FOLDER
        except Exception:
            pass
        return None

    def choose_output_root(self):
        initial = self.output_root or self._default_report_root_v212()
        if initial is None:
            initial = DEFAULT_FOLDER if DEFAULT_FOLDER.exists() else Path.home()
        folder = filedialog.askdirectory(
            title=self._t("选择最终报告输出地址", "Choose final report output location"),
            initialdir=str(initial)
        )
        if folder:
            self.output_root = Path(folder)
            self.output_root.mkdir(parents=True, exist_ok=True)
            self._refresh_path_label()
            self.status_var.set(self._t(
                f"输出地址：{self.output_root}",
                f"Output: {self.output_root}"
            ))

    def refresh_preview(self):
        if self.output_root is None:
            d = self._default_report_root_v212()
            if d is not None:
                self.output_root = Path(d)
        return super().refresh_preview()

    def generate_report(self):
        # Default to <raw-image-folder>/PorosityAnalyzer_Reports and reuse it.
        if self.output_root is None:
            d = self._default_report_root_v212()
            if d is not None:
                self.output_root = Path(d)
        if self.output_root is not None:
            Path(self.output_root).mkdir(parents=True, exist_ok=True)

        try:
            result = super().generate_report()
        except Exception as exc:
            # In a --windowed EXE an uncaught callback exception can look like an
            # unexplained disappearance. Keep the root alive and show the error.
            try:
                self.app.deiconify()
                self.app.lift()
            except Exception:
                pass
            messagebox.showerror(
                self._t("报告生成异常", "Report generation error"),
                self._t(
                    f"报告生成过程中出现异常，但软件不会关闭：\n\n{exc}",
                    f"An error occurred during report generation, but the application will remain open:\n\n{exc}"
                )
            )
            return None

        # Explicitly keep the main window alive/visible after every successful export.
        try:
            self.app.deiconify()
            self.app.after(20, self.app.lift)
            self.app.after(40, self.app.focus_force)
        except Exception:
            pass
        return result


_PoreToolAppV211 = PoreToolApp


class PoreToolApp(_PoreToolAppV211):
    """v2.12: enforce forward stage order and pass corrected state downstream."""

    _v212_order = ("calibrate","measure","annotate","roi","report")

    def __init__(self):
        super().__init__()
        self.title("Manual Pore Annotator v2.12")
        self._v212_refresh_stage_buttons()

    def _refresh_title(self):
        titles={
            'calibrate':('① 标尺校准','① Scale calibration'),
            'measure':('② 尺寸 / 面积测量','② Dimension / area measurement'),
            'annotate':('③ 图层标注','③ Layer annotation'),
            'roi':('④ ROI 测试','④ ROI analysis'),
            'report':('⑤ 报告整理','⑤ Final report')
        }
        self.title(f"Manual Pore Annotator v2.12 — {self.tr(*titles.get(self.current_module,('','')))}")

    def _v212_refresh_stage_buttons(self):
        # Keep all stages visible, but enforce a real forward chain.
        # With no raw image loaded, only Step 1 and the independent Step-4
        # ".poreproj direct-open" entrance are available.
        try:
            current = self.current_module or "calibrate"
            ci = self._v212_order.index(current)
            has_raw = bool(getattr(self.annotator, "image_path", None))
            roi_ready = bool(getattr(self.roi_calc, "mask", None))

            if not has_raw:
                for k in self._v212_order:
                    self.stage_buttons[k].configure(state="disabled")
                self.stage_buttons["calibrate"].configure(state="normal")
                self.stage_buttons["roi"].configure(state="normal")
                if current == "roi" and roi_ready:
                    self.stage_buttons["report"].configure(state="normal")
                return

            for i, k in enumerate(self._v212_order):
                state = "normal" if i in (ci, ci + 1) else "disabled"
                self.stage_buttons[k].configure(state=state)
        except Exception:
            pass

    def show_module(self, which):
        current = getattr(self, "current_module", None)

        # Without a raw image, Step 2/3 cannot be opened blank. Step 4 remains
        # an intentional independent entrance for opening an existing .poreproj.
        ann = getattr(self, "annotator", None)
        has_raw = bool(ann and getattr(ann, "image_path", None))
        if not has_raw and which in ("measure", "annotate"):
            messagebox.showwarning(
                self.tr("请先打开图片", "Open an image first"),
                self.tr(
                    "请从第一步打开原图，然后按 ① → ② → ③ 顺序执行。",
                    "Open the source image in Step 1, then follow ① → ② → ③ in order."
                )
            )
            return
        if not has_raw and which == "report" and getattr(self.roi_calc, "mask", None) is None:
            messagebox.showwarning(
                self.tr("没有可汇总数据", "No data to summarize"),
                self.tr("请先完成前面的步骤，或在第四步打开已有 .poreproj。", "Complete the previous stages or open an existing .poreproj in Step 4 first.")
            )
            return

        # During a raw-image workflow: no skipping and no backward jumping.
        if current in self._v212_order and which in self._v212_order and has_raw:
            ci = self._v212_order.index(current)
            ti = self._v212_order.index(which)

            if ti < ci:
                messagebox.showinfo(
                    self.tr("顺序工作流", "Sequential workflow"),
                    self.tr(
                        "当前任务采用顺序工作流。后续步骤建立在前一步的修正结果上；如需重做前一步，请重新载入当前图片后按顺序执行。",
                        "This task uses a sequential workflow. Each later stage is built on the corrected result from the previous stage. Reload the current image if you need to restart an earlier stage."
                    )
                )
                return

            if ti > ci + 1:
                messagebox.showwarning(
                    self.tr("请按顺序执行", "Follow the stage order"),
                    self.tr(
                        "不能跳过中间步骤。请依次完成 ① → ② → ③ → ④ → ⑤。",
                        "Intermediate stages cannot be skipped. Complete ① → ② → ③ → ④ → ⑤ in order."
                    )
                )
                return

            if current == "calibrate" and which == "measure":
                if ann.image_path is None:
                    messagebox.showwarning(
                        self.tr("没有图片", "No image"),
                        self.tr("请先在第一步打开图片。", "Open an image in Step 1 first.")
                    )
                    return

            if current == "measure" and which == "annotate":
                if not ann.prepare_stage3_from_step2_v212():
                    return

            if current == "annotate" and which == "roi":
                p = getattr(ann, "last_saved_project_path_v212", None)
                if not p or not Path(p).exists() or ann.dirty:
                    messagebox.showwarning(
                        self.tr("请先保存", "Save first"),
                        self.tr(
                            "第三步必须先点击“保存”。保存后生成带日期的 .poreproj，中转文件将作为第四步的唯一输入。",
                            "Click Save in Step 3 first. A dated .poreproj transfer file is required before Step 4."
                        )
                    )
                    return

            if current == "roi" and which == "report":
                if getattr(self.roi_calc, "mask", None) is None:
                    messagebox.showwarning(
                        self.tr("没有 ROI 项目", "No ROI project"),
                        self.tr("第四步尚未加载有效项目。", "Step 4 has not loaded a valid project.")
                    )
                    return

        # Bypass the v2.11 undated-project gate; v2.12 already validated the
        # dated transfer file above and owns the sequential transition rules.
        result = _PoreToolAppV210.show_module(self, which)
        self._v212_refresh_stage_buttons()
        return result

    def reset_workspace_keep_calibration(self):
        super().reset_workspace_keep_calibration()
        try:
            self.roi_calc.roi_n_var.set("2")
            self.roi_calc._v212_sync_roi_from_n()
        except Exception:
            pass
        self._v212_refresh_stage_buttons()

    def refresh_global_state(self):
        super().refresh_global_state()
        self._v212_refresh_stage_buttons()



# ============================================================
# v2.13 — free page navigation + controlled scientific handoff
#          + drag/drop import for Steps 1–4
# ============================================================

# External Windows/macOS drag & drop is provided by tkinterdnd2 when installed.
# The ordinary Open Image/Open Folder controls always remain available.
try:
    from tkinterdnd2 import DND_FILES as _V213_DND_FILES
    from tkinterdnd2 import TkinterDnD as _V213_TkinterDnD
    _V213_HAS_DND = True
except Exception:
    _V213_DND_FILES = "DND_Files"
    _V213_TkinterDnD = None
    _V213_HAS_DND = False


_StagedAnnotatorFrameV212 = StagedAnnotatorFrame


class StagedAnnotatorFrame(_StagedAnnotatorFrameV212):
    """
    v2.13 keeps one scientific data model but separates page visibility from handoff.

    Important:
    - A page may be opened at any time.
    - If that page has not received an image through the normal upstream handoff,
      the canvas can intentionally be blank.
    - A file dropped/opened directly on Step 1/2/3 makes that page immediately usable.
    """

    def __init__(self, parent, app):
        self._v213_blank_view = False
        self._v213_direct_input_stage = None
        super().__init__(parent, app)

    def _v213_set_blank_view(self, blank, render_now=True):
        self._v213_blank_view = bool(blank)
        if render_now:
            self.render()

    def _v213_blank_message(self):
        if self.workspace == "measure":
            return self._t(
                "② 当前页面尚未接收图片\n\n可从①进入本页，或直接把图片拖入/打开。",
                "② No image has been handed to this page yet\n\nEnter from Step 1, or drop/open an image directly."
            )
        if self.workspace == "annotate":
            return self._t(
                "③ 当前页面尚未接收第二步工作图\n\n可从②进入本页，或直接把图片拖入/打开。",
                "③ No Step-2 working image has been handed to this page yet\n\nEnter from Step 2, or drop/open an image directly."
            )
        return self._t(
            "当前页面尚未接收图片。\n可直接拖入图片或点击“打开图片”。",
            "No image has been handed to this page yet.\nDrop an image here or click Open Image."
        )

    def render(self):
        if getattr(self, "_v213_blank_view", False):
            try:
                self.canvas.delete("all")
                cw = max(1, self.canvas.winfo_width())
                ch = max(1, self.canvas.winfo_height())
                self.canvas.create_text(
                    cw / 2, ch / 2,
                    text=self._v213_blank_message(),
                    fill="#b8c1c8",
                    justify=tk.CENTER,
                    font=("Segoe UI", 13, "bold"),
                    width=max(280, int(cw * 0.65))
                )
            except Exception:
                pass
            return
        return super().render()

    # Guard drawing/measurement gestures while a freely opened page is intentionally blank.
    def on_left_press(self, event):
        if getattr(self, "_v213_blank_view", False):
            return
        return super().on_left_press(event)

    def on_left_drag(self, event):
        if getattr(self, "_v213_blank_view", False):
            return
        return super().on_left_drag(event)

    def on_left_release(self, event):
        if getattr(self, "_v213_blank_view", False):
            return
        return super().on_left_release(event)

    def on_double_left(self, event):
        if getattr(self, "_v213_blank_view", False):
            return
        return super().on_double_left(event)

    def on_right_press(self, event):
        if getattr(self, "_v213_blank_view", False):
            return
        return super().on_right_press(event)

    def on_mouse_motion(self, event):
        if getattr(self, "_v213_blank_view", False):
            return
        return super().on_mouse_motion(event)

    def load_image(self, path: Path):
        # A direct image open/drop on Step 1/2/3 makes the current page active.
        self._v213_blank_view = False
        result = super().load_image(Path(path))
        try:
            if self.image_path is not None and Path(self.image_path) == Path(path):
                self._v213_direct_input_stage = self.workspace
                self.app._v213_on_annotator_image_loaded(self.workspace)
        except Exception:
            pass
        return result


_PoreToolAppV212 = PoreToolApp


class PoreToolApp(_PoreToolAppV212):
    """
    v2.13 UI rule:
      navigation state != scientific handoff state.

    All five stage buttons are always clickable. Opening a later stage does not
    manufacture missing scientific state. Normal handoff remains:
      Step 1 image -> Step 2
      Step 2 corrected working image -> Step 3
      Step 3 saved .poreproj -> Step 4
      Step 4 data -> Step 5

    Steps 1–4 also support OS file drag/drop when tkinterdnd2 is installed.
    """

    _v213_image_exts = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}

    def __init__(self):
        # Flags must exist before the v2.12 base constructor calls its refresh methods.
        self._v213_stage1_has_image = False
        self._v213_stage2_ready = False
        self._v213_stage3_ready = False
        self._v213_drop_enabled = False

        super().__init__()
        self.title("Manual Pore Annotator v2.13")
        self._v213_set_all_stage_buttons_normal()
        self._v213_enable_drag_drop()

    # --------------------------------------------------------
    # Navigation: all pages remain clickable
    # --------------------------------------------------------
    def _v213_set_all_stage_buttons_normal(self):
        try:
            for b in self.stage_buttons.values():
                b.configure(state="normal")
        except Exception:
            pass

    def _v212_refresh_stage_buttons(self):
        # v2.13 intentionally overrides v2.12 gating.
        self._v213_set_all_stage_buttons_normal()

    def _refresh_title(self):
        titles = {
            "calibrate": ("① 标尺校准", "① Scale calibration"),
            "measure": ("② 尺寸 / 面积测量", "② Dimension / area measurement"),
            "annotate": ("③ 图层标注", "③ Layer annotation"),
            "roi": ("④ ROI 测试", "④ ROI analysis"),
            "report": ("⑤ 报告整理", "⑤ Final report"),
        }
        self.title(
            f"Manual Pore Annotator v2.13 — "
            f"{self.tr(*titles.get(self.current_module, ('','')))}"
        )

    def _v213_on_annotator_image_loaded(self, stage):
        """
        Called after Open Image/Open Folder/Next/Previous/direct drop has actually
        loaded a source image into the shared annotator.
        """
        if stage == "calibrate":
            self._v213_stage1_has_image = True
            # A newly selected Step-1 source begins a fresh downstream handoff.
            self._v213_stage2_ready = False
            self._v213_stage3_ready = False
        elif stage == "measure":
            self._v213_stage1_has_image = True
            self._v213_stage2_ready = True
            self._v213_stage3_ready = False
        elif stage == "annotate":
            # Direct Step-3 image input is explicitly allowed.
            self._v213_stage3_ready = True

        try:
            self.annotator._v213_set_blank_view(False)
        except Exception:
            pass
        self._v213_set_all_stage_buttons_normal()

    def show_module(self, which):
        current = getattr(self, "current_module", None)
        ann = getattr(self, "annotator", None)

        # Same page: refresh, but never impose a gate.
        if current == which:
            if which == "report":
                self.report.refresh_preview()
            elif which == "roi":
                self.roi_calc.refresh_stage_state()
            self.refresh_global_state()
            self._v213_set_all_stage_buttons_normal()
            return

        # ---------------- Step 1 ----------------
        if which == "calibrate":
            # Step 1 owns any source image already loaded there.
            if ann is not None:
                ann._v213_set_blank_view(not bool(ann.image_path), render_now=False)

        # ---------------- Step 2 ----------------
        elif which == "measure":
            if ann is not None:
                # Entering Step 2 from Step 1 is the formal 1 -> 2 handoff.
                if current == "calibrate" and ann.image_path is not None:
                    self._v213_stage2_ready = True
                    ann._v213_set_blank_view(False, render_now=False)
                elif self._v213_stage2_ready and ann.image_path is not None:
                    ann._v213_set_blank_view(False, render_now=False)
                else:
                    # Page remains accessible, but does not pretend to have received data.
                    ann._v213_set_blank_view(True, render_now=False)

        # ---------------- Step 3 ----------------
        elif which == "annotate":
            if ann is not None:
                # Formal 2 -> 3 handoff: bake contrast + rotation into the working image.
                if current == "measure" and self._v213_stage2_ready and ann.image_path is not None:
                    ann._v213_set_blank_view(False, render_now=False)
                    if ann.prepare_stage3_from_step2_v212():
                        self._v213_stage3_ready = True
                    else:
                        ann._v213_set_blank_view(True, render_now=False)
                elif self._v213_stage3_ready and ann.image_path is not None:
                    ann._v213_set_blank_view(False, render_now=False)
                else:
                    ann._v213_set_blank_view(True, render_now=False)

        # ---------------- Step 4 ----------------
        elif which == "roi":
            # If arriving from a saved Step-3 result, use the exact portable project.
            if current == "annotate" and ann is not None:
                p = getattr(ann, "last_saved_project_path_v212", None)
                if p and Path(p).exists() and not ann.dirty:
                    try:
                        if (
                            self.roi_calc.project_source_path is None
                            or Path(self.roi_calc.project_source_path) != Path(p)
                        ):
                            self.roi_calc.load_project_file(Path(p))
                    except Exception:
                        pass
            # If there is no project, Step 4 still opens blank and can accept a drop.

        # ---------------- Step 5 ----------------
        # Always accessible. If no data exists, its preview is simply empty.

        # Use the ungated v2.10/v2.11 UI switcher. All scientific handoff decisions
        # have already been made above.
        result = _PoreToolAppV210.show_module(self, which)
        self._v213_set_all_stage_buttons_normal()
        return result

    def reset_workspace_keep_calibration(self):
        super().reset_workspace_keep_calibration()
        self._v213_stage1_has_image = False
        self._v213_stage2_ready = False
        self._v213_stage3_ready = False
        try:
            self.annotator._v213_set_blank_view(False, render_now=False)
        except Exception:
            pass
        self._v213_set_all_stage_buttons_normal()

    def refresh_global_state(self):
        # Keep the v2.12 status logic but never let it grey navigation buttons.
        try:
            _PoreToolAppV210.refresh_global_state(self)
        except Exception:
            pass
        self._v213_set_all_stage_buttons_normal()

    # --------------------------------------------------------
    # Drag/drop
    # --------------------------------------------------------
    def _v213_enable_drag_drop(self):
        if not _V213_HAS_DND:
            self._v213_drop_enabled = False
            # Do not interrupt ordinary use. Open Image/Open Folder remain valid.
            try:
                self.annotator._tooltips.append(
                    _HoverTip(
                        self.annotator.canvas,
                        lambda: self.tr(
                            "可将图片直接拖入①②③。若拖拽不可用，请安装 tkinterdnd2；“打开图片/文件夹”始终可用。",
                            "Drop images directly into Steps 1–3. If OS drag/drop is unavailable, install tkinterdnd2; Open Image/Folder always works."
                        )
                    )
                )
            except Exception:
                pass
            return

        try:
            # Existing application root is a normal tk.Tk. tkinterdnd2 can attach
            # the TkDND package to it without rebuilding the scientific UI.
            _V213_TkinterDnD._require(self)

            for widget in (self.annotator.canvas, self.roi_calc.canvas):
                widget.drop_target_register(_V213_DND_FILES)
                widget.dnd_bind("<<Drop>>", self._v213_on_drop)

            self._v213_drop_enabled = True
        except Exception:
            self._v213_drop_enabled = False

    def _v213_split_drop_paths(self, data):
        try:
            items = list(self.tk.splitlist(data))
        except Exception:
            items = [str(data)]
        out = []
        for item in items:
            s = str(item).strip()
            if s.startswith("{") and s.endswith("}"):
                s = s[1:-1]
            if s:
                out.append(Path(s))
        return out

    def _v213_images_from_drop(self, paths):
        images = []
        for p in paths:
            try:
                if p.is_dir():
                    for q in sorted(p.iterdir(), key=lambda x: x.name.lower()):
                        if q.is_file() and q.suffix.lower() in self._v213_image_exts:
                            lower = q.name.lower()
                            if any(tag in lower for tag in (
                                "_mask.", "_overlay.", "_annotation.", "_layer.",
                                "_guide_mask.", "_region_mask.", "_boundary_mask."
                            )):
                                continue
                            images.append(q)
                elif p.is_file() and p.suffix.lower() in self._v213_image_exts:
                    images.append(p)
            except Exception:
                continue

        # Stable de-duplication
        seen = set()
        unique = []
        for p in images:
            try:
                k = str(p.resolve()).lower()
            except Exception:
                k = str(p).lower()
            if k not in seen:
                seen.add(k)
                unique.append(p)
        return unique

    def _v213_load_dropped_images(self, paths):
        ann = self.annotator
        images = self._v213_images_from_drop(paths)
        if not images:
            messagebox.showwarning(
                self.tr("没有可用图片", "No supported image"),
                self.tr(
                    "请拖入 PNG/JPG/JPEG/TIF/TIFF/BMP/WebP 图片，或包含这些图片的文件夹。",
                    "Drop PNG/JPG/JPEG/TIF/TIFF/BMP/WebP images, or a folder containing them."
                )
            )
            return

        # If the user dropped a folder, preserve that folder's whole image sequence.
        first = images[0]
        common_parent = first.parent
        try:
            if all(p.parent == common_parent for p in images):
                ann.input_folder = common_parent
                ann._build_image_list(common_parent, selected=first)
                # When multiple explicit files are dropped, prefer exactly the dropped order/list.
                if len(images) > 1:
                    ann.image_files = images
                    ann.image_index = 0
            else:
                ann.input_folder = first.parent
                ann.image_files = images
                ann.image_index = 0
        except Exception:
            ann.input_folder = first.parent
            ann.image_files = images
            ann.image_index = 0

        ann._v213_set_blank_view(False, render_now=False)
        ann.load_image(first)

    def _v213_load_dropped_project(self, paths):
        projects = []
        for p in paths:
            try:
                if p.is_file() and p.suffix.lower() == ".poreproj":
                    projects.append(p)
                elif p.is_dir():
                    projects.extend(sorted(
                        [q for q in p.iterdir() if q.is_file() and q.suffix.lower() == ".poreproj"],
                        key=lambda q: q.name.lower()
                    ))
            except Exception:
                continue

        if not projects:
            messagebox.showwarning(
                self.tr("第四步需要项目文件", "Step 4 requires a project file"),
                self.tr(
                    "④ ROI 页面请拖入第三步保存的 .poreproj 文件。",
                    "Drop a .poreproj saved by Step 3 onto the ROI page."
                )
            )
            return

        try:
            self.roi_calc.load_project_file(projects[0])
        except Exception as exc:
            messagebox.showerror(
                self.tr("项目打开失败", "Could not open project"),
                f"{projects[0]}\n\n{exc}"
            )

    def _v213_on_drop(self, event):
        paths = self._v213_split_drop_paths(getattr(event, "data", ""))
        if not paths:
            return

        stage = getattr(self, "current_module", "calibrate")
        if stage in ("calibrate", "measure", "annotate"):
            self._v213_load_dropped_images(paths)
        elif stage == "roi":
            self._v213_load_dropped_project(paths)
        else:
            messagebox.showinfo(
                self.tr("拖拽入口", "Drag/drop"),
                self.tr(
                    "⑤报告页不直接接收图片。请在①②③拖入原图，或在④拖入 .poreproj。",
                    "The report page does not accept images directly. Drop source images in Steps 1–3 or a .poreproj in Step 4."
                )
            )



# =============================================================================
# ZHUCHEN UNIFIED v1.0 — six-stage integration layer
# =============================================================================
from PIL import ImageFilter, ImageOps
try:
    import numpy as np
    import cv2
    HAS_CV2 = True
except Exception:
    np = None
    cv2 = None
    HAS_CV2 = False

def otsu_threshold(gray: Image.Image, region_mask: Image.Image) -> int:
    """Return Otsu threshold calculated only from pixels where region_mask > 0."""
    g = gray.convert("L")
    m = region_mask.convert("L")
    hist = [0] * 256
    total = 0
    for gv, mv in zip(g.getdata(), m.getdata()):
        if mv:
            hist[int(gv)] += 1
            total += 1
    if total == 0:
        return 128

    sum_all = sum(i * hist[i] for i in range(256))
    sum_bg = 0.0
    weight_bg = 0
    max_between = -1.0
    best = 128

    for t in range(256):
        weight_bg += hist[t]
        if weight_bg == 0:
            continue
        weight_fg = total - weight_bg
        if weight_fg == 0:
            break
        sum_bg += t * hist[t]
        mean_bg = sum_bg / weight_bg
        mean_fg = (sum_all - sum_bg) / weight_fg
        between = weight_bg * weight_fg * (mean_bg - mean_fg) ** 2
        if between > max_between:
            max_between = between
            best = t
    return int(best)

def local_darkness_map(gray: Image.Image) -> Image.Image:
    """
    Build a local color/brightness-difference map. High values mean a pixel is
    darker than its local neighborhood, which is often a better pore signal
    than absolute gray level on uneven microscopy illumination.
    """
    g = gray.convert("L")
    radius = max(12, min(g.size) // 30)
    background = g.filter(ImageFilter.GaussianBlur(radius=radius))
    corr = ImageChops.subtract(background, g)
    return ImageOps.autocontrast(corr)

def absolute_darkness_map(gray: Image.Image) -> Image.Image:
    """
    Step-3 absolute darkness signal.

    High value means the source pixel itself is dark. This catches broad,
    internally uniform black pores whose centres can be missed by a purely
    local-background subtraction signal.
    """
    g = gray.convert("L")
    return ImageOps.autocontrast(ImageOps.invert(g))


def combined_pore_signal_v20(
    gray: Image.Image,
    local_signal: Image.Image | None = None,
) -> Image.Image:
    """
    Step-3 pore signal = absolute darkness OR local darkness difference.

    The pixel-wise maximum implements the OR relationship:
      - broad uniformly dark pore -> absolute-darkness branch catches it;
      - locally dark pore under uneven illumination -> local branch catches it.

    This is darkness-based, not Lab/RGB colour-distance detection.
    """
    g = gray.convert("L")
    local = local_signal.convert("L") if local_signal is not None else local_darkness_map(g)
    absolute = absolute_darkness_map(g)
    return ImageChops.lighter(local, absolute)


def threshold_pores(signal: Image.Image, roi_mask: Image.Image, threshold: int) -> Image.Image:
    """Return L mask: 255=pore, 0=not pore/outside ROI. High local darkness = pore."""
    sig = signal.convert("L")
    r = roi_mask.convert("L")
    t = int(max(0, min(255, threshold)))
    candidate = sig.point(lambda v: 255 if v >= t else 0)
    return ImageChops.multiply(candidate, r)

def _mask_polygon_v04(size, points, roi_mask):
    m = Image.new('L', size, 0)
    if len(points) >= 3:
        ImageDraw.Draw(m).polygon(points + [points[0]], fill=255)
    return ImageChops.multiply(m, roi_mask.convert('L'))

def _equivalent_circle_diameter_px(area_px: int) -> float:
    """Area-equivalent circle diameter: D_eq = 2*sqrt(A/pi)."""
    area_px = max(0, int(area_px))
    return 2.0 * math.sqrt(area_px / math.pi) if area_px > 0 else 0.0


def _filter_pore_components_v05(
    pore_mask: Image.Image,
    roi_mask: Image.Image,
    signal: Image.Image,
    threshold: int,
    min_diameter_px: float = 20.0,
    max_diameter_px: float = 100.0,
) -> Tuple[Image.Image, int]:
    """
    v1.6 fast hard filter.

    There is NO pore-shape classifier, NO watershed, and NO hidden morphology in the diameter gate.

    For every connected dark candidate:
        A = connected-component area in source-image pixels
        D_eq = 2*sqrt(A/pi)

    Hard rule:
        D_eq < D_min px -> delete
        D_min <= D_eq <= 100 px -> keep
        D_eq > 100 px -> delete

    A retained pore may be triangular, rounded, elongated, jagged or highly
    irregular. The filter uses only connected-component area converted to an
    equivalent-circle diameter.

    This deliberately avoids the expensive "split every merged component"
    workflow. One connected-component pass is used before the explicit user-controlled diameter hard gate.
    """
    src = ImageChops.multiply(pore_mask.convert("L"), roi_mask.convert("L"))
    min_diameter_px = max(0.0, float(min_diameter_px))
    max_diameter_px = max(min_diameter_px, float(max_diameter_px))

    # Convert diameter cutoffs to exact area cutoffs once. Comparing integer
    # component area is faster than calculating sqrt for every component.
    min_area = math.pi * (min_diameter_px * 0.5) ** 2
    max_area = math.pi * (max_diameter_px * 0.5) ** 2

    if not HAS_CV2:
        # Pillow/Python fallback. No morphology, no shape logic.
        w, h = src.size
        data = bytearray(src.tobytes())
        visited = bytearray(w * h)
        out = bytearray(w * h)
        kept = 0

        for idx in range(w * h):
            if data[idx] == 0 or visited[idx]:
                continue

            stack = [idx]
            visited[idx] = 1
            comp = []

            while stack:
                cur = stack.pop()
                comp.append(cur)
                y, x = divmod(cur, w)

                for ny in range(max(0, y - 1), min(h - 1, y + 1) + 1):
                    base_i = ny * w
                    for nx in range(max(0, x - 1), min(w - 1, x + 1) + 1):
                        nidx = base_i + nx
                        if not visited[nidx] and data[nidx]:
                            visited[nidx] = 1
                            stack.append(nidx)

            area = len(comp)
            if area < min_area or area > max_area:
                continue

            kept += 1
            for p in comp:
                out[p] = 255

        return Image.frombytes("L", (w, h), bytes(out)), kept

    arr = (np.asarray(src, dtype=np.uint8) > 0).astype(np.uint8)

    # v2.1: no hidden size-changing morphology here.
    # The user's explicit 1–300 px dual-ended diameter gate is authoritative.
    num, labels, stats, _ = cv2.connectedComponentsWithStats(arr, connectivity=8)

    if num <= 1:
        return Image.new("L", src.size, 0), 0

    component_areas = stats[:, cv2.CC_STAT_AREA].astype(np.float64)
    keep_labels = np.where(
        (component_areas >= min_area) & (component_areas <= max_area)
    )[0]
    keep_labels = keep_labels[keep_labels != 0]

    if keep_labels.size == 0:
        return Image.new("L", src.size, 0), 0

    # Vectorized lookup instead of looping over every pixel/component.
    lut = np.zeros(num, dtype=np.uint8)
    lut[keep_labels] = 255
    out = lut[labels]

    return Image.fromarray(out, mode="L"), int(keep_labels.size)


def _build_auto_mask_v05(
    signal: Image.Image,
    roi_mask: Image.Image,
    threshold: int,
    min_diameter_px: float = 20.0,
    max_diameter_px: float = 100.0,
) -> Tuple[Image.Image, int]:
    raw = threshold_pores(signal, roi_mask, threshold)
    return _filter_pore_components_v05(
        raw,
        roi_mask,
        signal,
        threshold,
        min_diameter_px=min_diameter_px,
        max_diameter_px=max_diameter_px,
    )


def _smart_dark_component_v05(
    source: Image.Image,
    signal: Image.Image,
    roi_mask: Image.Image,
    rough_polygon: List[Tuple[int, int]],
    sensitivity: Optional[float] = None,
):
    """
    Dark-only smart pore refinement.

    HARD SCIENTIFIC RULE:
        a candidate pixel can be a pore only when it is darker than the local
        material reference around the user's lasso.

    Therefore a bright reflection can never become a pore merely because its
    Lab/color difference is large.

    The user first draws a smooth rough lasso. Only after mouse release:
      1) estimate local material brightness from a ring outside the lasso;
      2) compute directional darkness = L_background - L_pixel;
      3) combine it with the precomputed local-darkness map;
      4) auto-search a sensitivity value;
      5) keep the connected dark component associated with the darkest seed.

    Returns:
      full_mask, chosen_sensitivity, base_threshold, background_luma, quality
    """
    empty = Image.new("L", source.size, 0)
    if len(rough_polygon) < 3 or not HAS_CV2:
        return empty, 1.0, 0, 0.0, 0.0

    region = _mask_polygon_v04(source.size, rough_polygon, roi_mask)
    bbox = region.getbbox()
    if bbox is None:
        return empty, 1.0, 0, 0.0, 0.0

    x0, y0, x1, y1 = bbox
    pad = 16
    x0 = max(0, x0-pad); y0 = max(0, y0-pad)
    x1 = min(source.width, x1+pad); y1 = min(source.height, y1+pad)
    box = (x0, y0, x1, y1)

    rgb = np.asarray(source.crop(box).convert("RGB"), dtype=np.uint8)
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY).astype(np.float32)
    sig = np.asarray(signal.crop(box).convert("L"), dtype=np.float32)

    reg = (np.asarray(region.crop(box).convert("L"), dtype=np.uint8) > 0).astype(np.uint8)
    roi = (np.asarray(roi_mask.crop(box).convert("L"), dtype=np.uint8) > 0).astype(np.uint8)
    reg_area = int(reg.sum())
    if reg_area < 12:
        return empty, 1.0, 0, 0.0, 0.0

    # Local material reference: ring just OUTSIDE the user's rough lasso.
    # This makes the method robust even when the whole local area lies in shadow.
    ring_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11))
    dil = cv2.dilate(reg, ring_kernel, iterations=1)
    ring = (dil > 0) & (reg == 0) & (roi > 0)

    if int(ring.sum()) >= 25:
        ring_values = gray[ring]
        # Use the upper-middle material level rather than the brightest outlier.
        bg_luma = float(np.percentile(ring_values, 60))
    else:
        # Fallback: the brighter half of the lasso is assumed to be material.
        inside = gray[reg > 0]
        bg_luma = float(np.percentile(inside, 72)) if inside.size else 128.0

    # Directional darkness. BRIGHTER pixels are clipped to zero forever.
    dark_delta = np.maximum(bg_luma - gray, 0.0)
    hard_dark = (gray < (bg_luma - 1.5)) & (reg > 0)

    positive = dark_delta[hard_dark]
    if positive.size < 5 or float(positive.max()) <= 1.0:
        return empty, 1.0 if sensitivity is None else float(sensitivity), 0, bg_luma, 0.0

    # Robust normalization of directional darkness.
    p95 = max(4.0, float(np.percentile(positive, 95)))
    dark_norm = np.clip(dark_delta / p95 * 255.0, 0, 255)

    # Local darkness suppresses broad smooth illumination/shadow gradients.
    # The hard_dark mask above still owns the final decision direction.
    evidence = (0.78 * dark_norm + 0.22 * sig).clip(0, 255).astype(np.uint8)
    evidence[(reg == 0) | (~hard_dark)] = 0

    vals = evidence[(reg > 0) & hard_dark]
    if vals.size < 5:
        return empty, 1.0 if sensitivity is None else float(sensitivity), 0, bg_luma, 0.0

    # Otsu threshold from the dark-only evidence values.
    hist = np.bincount(vals, minlength=256).astype(np.float64)
    total = hist.sum()
    sum_all = float(np.dot(np.arange(256), hist))
    w0 = 0.0
    s0 = 0.0
    best_between = -1.0
    base_t = 96

    for t in range(1, 255):
        w0 += hist[t]
        s0 += t * hist[t]
        if w0 <= 0 or w0 >= total:
            continue
        w1 = total - w0
        m0 = s0 / w0
        m1 = (sum_all - s0) / w1
        between = w0 * w1 * (m0 - m1) ** 2
        if between > best_between:
            best_between = between
            base_t = t

    smooth = cv2.GaussianBlur(evidence, (3, 3), 0)

    # Seed must be the darkest physical pixel, never the largest color difference.
    seed_score = dark_delta.copy()
    seed_score[reg == 0] = -1.0
    sy, sx = np.unravel_index(int(np.argmax(seed_score)), seed_score.shape)

    # "Sensitivity" is intuitive:
    # larger sensitivity -> slightly lower threshold -> more dark area included.
    factors = (
        [float(sensitivity)]
        if sensitivity is not None
        else [0.35, 0.50, 0.70, 0.85, 1.00, 1.20, 1.45, 1.80, 2.20, 2.70]
    )

    eroded = cv2.erode(reg, np.ones((3, 3), dtype=np.uint8), iterations=1)
    lasso_edge = (reg > 0) & (eroded == 0)
    best = None

    for sens in factors:
        sens = max(0.10, min(3.00, float(sens)))
        t = int(max(2, min(254, round(base_t / sens))))

        cand = ((smooth >= t) & hard_dark & (reg > 0)).astype(np.uint8)
        cand = cv2.morphologyEx(
            cand,
            cv2.MORPH_CLOSE,
            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)),
            iterations=1,
        )

        n, labels, stats, _ = cv2.connectedComponentsWithStats(cand, connectivity=8)
        if n <= 1:
            continue

        lab_id = int(labels[sy, sx])
        if lab_id <= 0:
            # Choose the remaining component with the largest mean directional darkness.
            best_lab = None
            best_dark = -1.0
            for lab in range(1, n):
                comp = labels == lab
                if int(comp.sum()) < 4:
                    continue
                md = float(dark_delta[comp].mean())
                if md > best_dark:
                    best_dark = md
                    best_lab = lab
            if best_lab is None:
                continue
            lab_id = int(best_lab)

        comp = labels == lab_id
        area = int(comp.sum())
        if area < 4:
            continue

        area_frac = area / max(1, reg_area)
        if area_frac > 0.96:
            continue

        # Quality favours strong darkness, connectedness and a boundary that
        # does not simply fill the user's rough lasso.
        mean_dark = float(dark_delta[comp].mean())
        dark_strength = mean_dark / max(1.0, p95)
        edge_touch = float(np.count_nonzero(comp & lasso_edge)) / max(1, area)

        contours, _ = cv2.findContours(
            (comp.astype(np.uint8) * 255),
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE,
        )
        solidity = 0.0
        if contours:
            c = max(contours, key=cv2.contourArea)
            hull = cv2.convexHull(c)
            ha = float(cv2.contourArea(hull))
            ca = float(cv2.contourArea(c))
            solidity = ca / ha if ha > 0 else 0.0

        # Broad preference only; no triangle/shape requirement.
        coverage_reward = 1.0 - abs(area_frac - 0.45)
        quality = (
            1.8 * dark_strength
            + 0.45 * solidity
            + 0.35 * coverage_reward
            - 1.8 * edge_touch
            - 0.04 * abs(sens - 1.0)
        )

        if best is None or quality > best[0]:
            best = (quality, sens, t, comp.copy())

    if best is None:
        return empty, 1.0 if sensitivity is None else float(sensitivity), int(base_t), bg_luma, 0.0

    quality, chosen_sens, chosen_t, comp = best
    crop_out = np.zeros(reg.shape, dtype=np.uint8)
    crop_out[comp] = 255

    full = np.zeros((source.height, source.width), dtype=np.uint8)
    full[y0:y1, x0:x1] = crop_out
    full = (
        full
        * (np.asarray(roi_mask.convert("L"), dtype=np.uint8) > 0)
    ).astype(np.uint8)

    return (
        Image.fromarray(full, mode="L"),
        float(chosen_sens),
        int(base_t),
        float(bg_luma),
        float(quality),
    )


def _zc_count(mask):
    return int(mask.convert('L').histogram()[255]) if mask is not None else 0


def _zc_porosity(mask, region):
    if mask is None or region is None: return 0,0,0.0
    roi=_zc_count(region)
    pore=_zc_count(ImageChops.multiply(mask.convert('L'),region.convert('L')))
    return pore,roi,(100.0*pore/roi if roi else 0.0)



class _ZCDualRangeScale(tk.Canvas):
    """
    Compact integer dual-handle range slider.

    Left handle controls minimum; right handle controls maximum.
    Values cannot cross. Designed specifically for Step 3 pore diameter.
    """
    def __init__(
        self, parent, from_=1, to=100, low=1, high=100,
        command=None, length=165, height=30, **kwargs
    ):
        bg = kwargs.pop("bg", None)
        if bg is None:
            try:
                bg = ttk.Style().lookup("TFrame", "background") or "#f0f0f0"
            except Exception:
                bg = "#f0f0f0"

        super().__init__(
            parent,
            width=length,
            height=height,
            highlightthickness=0,
            bd=0,
            bg=bg,
            **kwargs
        )
        self.from_ = float(from_)
        self.to = float(to)
        self.low = float(low)
        self.high = float(high)
        self.command = command
        self.length_px = int(length)
        self.height_px = int(height)
        self.pad = 10
        self.track_y = self.height_px // 2
        self.handle_r = 6
        self._active = None

        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<B1-Motion>", self._on_drag)
        self.bind("<ButtonRelease-1>", self._on_release)
        self.bind("<Configure>", lambda e: self._draw())
        self._draw()

    def _value_to_x(self, value):
        span = max(1e-9, self.to - self.from_)
        usable = max(1, self.length_px - 2 * self.pad)
        return self.pad + (float(value) - self.from_) / span * usable

    def _x_to_value(self, x):
        usable = max(1, self.length_px - 2 * self.pad)
        ratio = (float(x) - self.pad) / usable
        ratio = max(0.0, min(1.0, ratio))
        value = self.from_ + ratio * (self.to - self.from_)
        return float(round(value))

    def get(self):
        return int(round(self.low)), int(round(self.high))

    def set(self, low=None, high=None, notify=False):
        if low is None:
            low = self.low
        if high is None:
            high = self.high

        low = max(self.from_, min(self.to, float(low)))
        high = max(self.from_, min(self.to, float(high)))
        if low > high:
            low, high = high, low

        self.low = float(round(low))
        self.high = float(round(high))
        self._draw()
        if notify:
            self._notify()

    def _draw(self):
        self.delete("all")
        self.length_px = max(30, int(self.winfo_width() or self.length_px))

        x0 = self.pad
        x1 = max(self.pad + 1, self.length_px - self.pad)
        lx = self._value_to_x(self.low)
        hx = self._value_to_x(self.high)
        y = self.track_y

        self.create_line(x0, y, x1, y, width=3, fill="#b8b8b8")
        self.create_line(lx, y, hx, y, width=4, fill="#4f81bd")

        self.create_oval(
            lx-self.handle_r, y-self.handle_r,
            lx+self.handle_r, y+self.handle_r,
            fill="#ffffff", outline="#2f5f91", width=2,
            tags=("low_handle",)
        )
        self.create_oval(
            hx-self.handle_r, y-self.handle_r,
            hx+self.handle_r, y+self.handle_r,
            fill="#ffffff", outline="#2f5f91", width=2,
            tags=("high_handle",)
        )

    def _pick_handle(self, x):
        lx = self._value_to_x(self.low)
        hx = self._value_to_x(self.high)
        return "low" if abs(x-lx) <= abs(x-hx) else "high"

    def _update_active(self, x):
        value = self._x_to_value(x)
        if self._active == "low":
            self.low = min(value, self.high)
        elif self._active == "high":
            self.high = max(value, self.low)
        self._draw()
        self._notify()

    def _notify(self):
        if callable(self.command):
            try:
                self.command(int(round(self.low)), int(round(self.high)))
            except TypeError:
                self.command()

    def _on_press(self, event):
        self._active = self._pick_handle(event.x)
        self._update_active(event.x)

    def _on_drag(self, event):
        if self._active is not None:
            self._update_active(event.x)

    def _on_release(self, event):
        if self._active is not None:
            self._update_active(event.x)
        self._active = None


_ZCBaseAnnotator = StagedAnnotatorFrame

class ZhuChenUnifiedAnnotator(_ZCBaseAnnotator):
    """①② untouched; ③ auto region/detection; ④ refinement/save."""
    def __init__(self,parent,app):
        # v2.4 Step 3: simple one-click local-darkness first pass.
        # Signal is cached per image; no absolute-black channel / overlay chain.
        self._zc_signal_id=None
        self._zc_signal=None
        self._zc_auto_base=None
        self._zc_auto_job=None
        self._zc_region_locked=False; self._zc_region_kind=None; self._zc_kept=0
        self._zc_draft_tag='zc-draft'; self._zc_pts=[]; self._zc_last_screen=None
        self._zc_smart_lasso=None; self._zc_smart_before=None; self._zc_smart_busy=False; self._zc_smart_job=None
        self._zc_dark_default=1.0; self._zc_dark_default_locked=False; self._zc_smart_history_added=False
        self._zc_preview_mode=0
        super().__init__(parent,app)
        self.auto_bar=ttk.LabelFrame(self.stage_host); self.auto_bar.grid(row=0,column=0,sticky='ew'); self.auto_bar.grid_remove()
        self.refine_bar=ttk.LabelFrame(self.stage_host); self.refine_bar.grid(row=0,column=0,sticky='ew'); self.refine_bar.grid_remove()
        self._build_auto_bar(); self._build_refine_bar()
        self._build_refine_quick_frame()
        try:
            self._tooltips.append(_HoverTip(
                self.zc_sens_scale,
                lambda:self._t(
                    '孔隙识别灵敏度：0.05×–3.00×。基于局部暗度差，即“这个位置比附近材料暗多少”。1.00×为自动基准；越小越严格，越大越宽松。拖动只改参数，不自动计算；点击“一键生成孔隙”才执行。',
                    'Pore sensitivity: 0.05×–3.00×. Based on local darkness difference: how much darker this location is than nearby material. 1.00× is the automatic baseline; lower is stricter, higher is more permissive. Dragging changes only the parameter; One-click pores performs the calculation.'
                )
            ))
            self._tooltips.append(_HoverTip(
                self.zc_diam_range,
                lambda:self._t(
                    '孔径硬控：1–300 px 双端范围。左端控制最小等效孔径，右端控制最大等效孔径。最终候选必须落在该范围内。',
                    'Diameter hard gate: dual-ended 1–300 px range. Left controls minimum equivalent diameter; right controls maximum. Final candidates must fall inside this interval.'
                )
            ))
        except Exception:
            pass
        self.apply_language()

    def load_image(self,path):
        before=str(self.image_path) if self.image_path else None
        r=super().load_image(path)
        after=str(self.image_path) if self.image_path else None
        if after and after!=before:
            self._zc_signal_id=None
            self._zc_signal=None
            self._zc_auto_base=None
            self._zc_kept=0
            self._zc_region_locked=bool(self.region is not None and _zc_count(self.region)>0)
            self._zc_region_kind='fixed' if self._zc_region_locked else None
            self._zc_smart_lasso=None; self._zc_smart_before=None; self._clear_zc_draft(); self._refresh_zc_stats()
        return r

    def _build_auto_bar(self):
        b=self.auto_bar

        r=ttk.Frame(b)
        r.pack(side=tk.TOP,fill=tk.X,padx=4,pady=3)

        self.zc_region_btn=self._button(
            r,'圈定固定区域','Draw fixed region',lambda:self.set_mode('zc_region'),
            '自由画出固定分析区域。区域外原图保持可见，但不参与孔隙率计算。',
            'Draw a fixed analysis region. Outside pixels remain visible but are excluded from porosity.',
            side=tk.LEFT,padx=(4,2),pady=3
        )
        self.zc_lock_btn=self._button(
            r,'锁定固定区域','Lock fixed region',self._lock_zc_region,
            '锁定已画区域。若不画区域，点击“一键生成孔隙”会自动使用整张图。',
            'Lock the drawn region. If no region is drawn, One-click pores automatically uses the whole image.',
            side=tk.LEFT,padx=2,pady=3
        )
        self.zc_clear_btn=self._button(
            r,'清除区域','Clear region',self._clear_zc_region,
            '清除当前固定区域；下一次一键生成将自动使用整张图。',
            'Clear the fixed region; the next one-click run will use the whole image.',
            side=tk.LEFT,padx=2,pady=3
        )

        ttk.Separator(r,orient=tk.VERTICAL).pack(side=tk.LEFT,fill=tk.Y,padx=8,pady=3)

        self.zc_generate_btn=self._button(
            r,'一键生成孔隙','One-click pores',self._auto_generate,
            '快速初筛：局部暗度差 → 阈值 → 孔径范围硬过滤。明显漏检留到第四步智能补孔/手绘补孔。',
            'Fast first pass: local darkness difference → threshold → diameter hard gate. Obvious misses are handled in Step 4 by Smart add / Manual add.',
            side=tk.LEFT,padx=2,pady=3
        )

        ttk.Separator(r,orient=tk.VERTICAL).pack(side=tk.LEFT,fill=tk.Y,padx=8,pady=3)

        self.zc_sens_lab=ttk.Label(r)
        self.zc_sens_lab.pack(side=tk.LEFT,padx=(2,2))
        self.zc_sens=tk.DoubleVar(value=1.0)
        self.zc_sens_scale=ttk.Scale(
            r,from_=0.05,to=3.00,variable=self.zc_sens,
            command=self._auto_slider,length=155
        )
        self.zc_sens_scale.pack(side=tk.LEFT,padx=2)
        self.zc_sens_txt=tk.StringVar(value='1.00×')
        ttk.Label(r,textvariable=self.zc_sens_txt,width=6).pack(side=tk.LEFT)

        ttk.Separator(r,orient=tk.VERTICAL).pack(side=tk.LEFT,fill=tk.Y,padx=8,pady=3)

        self.zc_diam_lab=ttk.Label(r)
        self.zc_diam_lab.pack(side=tk.LEFT,padx=(2,2))
        self.zc_diam_range=_ZCDualRangeScale(
            r,from_=1,to=300,low=1,high=300,
            command=self._diam_range_changed,length=205,height=28
        )
        self.zc_diam_range.pack(side=tk.LEFT,padx=2)
        self.zc_diam_txt=tk.StringVar(value='1–300 px')
        self.zc_diam_value=ttk.Label(
            r,textvariable=self.zc_diam_txt,width=11,font=('Segoe UI',9,'bold')
        )
        self.zc_diam_value.pack(side=tk.LEFT,padx=(1,5))

        self.zc_stats=tk.StringVar(value='')
        ttk.Label(r,textvariable=self.zc_stats,font=('Segoe UI',9,'bold')).pack(
            side=tk.LEFT,padx=(8,2)
        )

    def _build_refine_bar(self):
        b=self.refine_bar
        self._button(b,'删除误检','Delete false positive',lambda:self.set_mode('zc_delete'),'点击错误红区，整块删除。','Click an incorrect red component to delete it.',side=tk.LEFT,padx=(8,2),pady=4)
        self._button(b,'智能补孔','Smart add pore',lambda:self.set_mode('zc_smart'),'顺滑圈住漏检孔；绘制时零计算，松手后 dark-only 自动贴边。','Smooth lasso; no processing while drawing, dark-only refinement after release.',side=tk.LEFT,padx=2,pady=4)
        self._button(b,'手绘补孔','Manual add pore',lambda:self.set_mode('freehand'),'沿真实边界画一圈，松手直接填充。','Trace the true boundary and release to fill.',side=tk.LEFT,padx=2,pady=4)
        self._button(b,'擦除修边','Erase / trim',lambda:self.set_mode('erase'),'放大后擦掉多余孔区。','Zoom in and erase excessive pore pixels.',side=tk.LEFT,padx=2,pady=4)
        self._button(b,'撤销','Undo',self.undo,'撤销最近一次精修。','Undo latest refinement.',side=tk.LEFT,padx=(8,2),pady=4)
        ttk.Separator(b,orient=tk.VERTICAL).pack(side=tk.LEFT,fill=tk.Y,padx=8,pady=3)
        self._button(b,'自动暗区','Auto dark region',self._smart_auto_again,'重新自动计算最近一次智能补孔。','Recalculate the latest smart pore automatically.',side=tk.LEFT,padx=2,pady=4)
        self.zc_dark_lab=ttk.Label(b); self.zc_dark_lab.pack(side=tk.LEFT,padx=(6,2))
        self.zc_dark=tk.DoubleVar(value=1.0)
        self.zc_dark_scale=ttk.Scale(b,from_=0.10,to=3.00,variable=self.zc_dark,command=self._smart_slider,length=170)
        self.zc_dark_scale.pack(side=tk.LEFT,padx=2)
        self.zc_dark_txt=tk.StringVar(value='1.00×'); ttk.Label(b,textvariable=self.zc_dark_txt,width=6).pack(side=tk.LEFT)
        self.zc_lock_dark_btn=self._button(
            b,'锁定当前值','Lock current',self._lock_dark_default,
            '把当前暗区灵敏度设为后续智能补孔的默认起始值。以后每个新孔仍可单独微调，除非再次点击锁定。',
            'Use the current dark sensitivity as the default starting value for future smart-pore selections. Each new pore can still be tuned independently.',
            side=tk.LEFT,padx=2,pady=4
        )
        self.zc_reset_dark_btn=self._button(
            b,'恢复默认','Reset default',self._reset_dark_default,
            '取消已锁定的默认灵敏度并恢复 1.00×。当前智能补孔若存在，也重新按 1.00×计算。',
            'Clear the locked default and restore 1.00×. If a current smart selection exists, it is recalculated at 1.00×.',
            side=tk.LEFT,padx=2,pady=4
        )
        self.zc_dark_default_txt=tk.StringVar(value='默认 1.00×')
        ttk.Label(b,textvariable=self.zc_dark_default_txt,font=('Segoe UI',8,'bold')).pack(side=tk.LEFT,padx=(4,2))
        self.zc_brush_lab=ttk.Label(b)
        self.zc_brush_lab.pack(side=tk.LEFT,padx=(8,2))
        ttk.Spinbox(b,from_=1,to=100,textvariable=self.brush_size,width=5).pack(side=tk.LEFT,padx=2)

        self.zc_folder=tk.StringVar(value='')
        ttk.Label(b,textvariable=self.zc_folder,font=('Segoe UI',8)).pack(side=tk.LEFT,padx=(10,2))

    def _build_refine_quick_frame(self):
        """
        Step-4-only quick actions placed on the common image-control row,
        immediately after Fit/Pan.
        """
        self.refine_quick_frame=ttk.Frame(self.common_bar)

        self.zc_original_btn=self._button(
            self.refine_quick_frame,
            '只看原图','Original only',self.show_original_only,
            '只显示底部原图；再次点击恢复全部显示。',
            'Show only the source image; click again to restore the full view.',
            side=tk.LEFT,padx=(4,2)
        )
        self.zc_pore_preview_btn=self._button(
            self.refine_quick_frame,
            '预览','Preview',self.show_pore_preview,
            '只显示白底 + 红色孔区；再次点击恢复全部显示。',
            'Show white background + red pore mask only; click again to restore the full view.',
            side=tk.LEFT,padx=2
        )
        self.zc_quick_save_btn=self._button(
            self.refine_quick_frame,
            '保存','Save',self.save_layers,
            '保存当前精修结果到固定项目目录并生成 .poreproj。',
            'Save the refined result to the fixed project folder and create .poreproj.',
            side=tk.LEFT,padx=2
        )

    def apply_language(self):
        super().apply_language()
        if not hasattr(self,'auto_bar'): return
        self.auto_bar.configure(text=self._t('③ 分析区域 + 自动孔隙','③ Analysis region + automatic pores'))
        self.refine_bar.configure(text=self._t('④ 人工精修','④ Refinement'))
        self.zc_sens_lab.configure(text=self._t('孔隙识别灵敏度:','Pore sensitivity:'))
        self.zc_diam_lab.configure(text=self._t('孔径范围:','Diameter range:'))
        self.zc_dark_lab.configure(text=self._t('暗区灵敏度:','Dark sensitivity:'))
        self.zc_brush_lab.configure(text=self._t('笔刷:','Brush:'))
        self._refresh_dark_default_label()
        self._refresh_preview_button_text()
        self._refresh_zc_stats()

    def _refresh_stage_hint(self):
        if not hasattr(self,'stage_hint_var'): return
        if self.workspace=='calibrate': self.stage_hint_var.set(self._t('Step 1 / 6 · 原五步版标尺校准完整保留','Step 1 / 6 · Legacy calibration stage fully retained'))
        elif self.workspace=='measure': self.stage_hint_var.set(self._t('Step 2 / 6 · 原五步版完整保留：对比度、水平校正、Length / Width / Area','Step 2 / 6 · Legacy stage fully retained: contrast, alignment, Length / Width / Area'))
        elif self.workspace=='auto': self.stage_hint_var.set(self._t('Step 3 / 6 · 不画区域=自动全图；固定区域只限制计算域，不裁图','Step 3 / 6 · No region = whole image; fixed region limits calculation only'))
        elif self.workspace=='refine': self.stage_hint_var.set(self._t('Step 4 / 6 · 精修、预览、保存到固定项目目录','Step 4 / 6 · Refine, preview, save to fixed project folder'))
        else: return super()._refresh_stage_hint()

    def _zc_restore_legacy_step12_ui(self, which):
        """
        v1.3 regression guard.

        Steps 1 and 2 must remain the mature legacy UI/behavior.
        The new Stage-3/4 bars are explicitly removed, then the exact v2.11
        stage composition is restored. This is intentionally redundant:
        it protects against pack/grid state left behind after visiting the
        new automatic/refinement pages.

        Scientific behavior is NOT reimplemented here.
        Existing calibration, contrast, horizontal alignment, measurement,
        logs, keyboard shortcuts, pan and handoff code remain inherited.
        """
        if which not in ("calibrate", "measure"):
            return

        # New workflow bars must never occupy the old Stage-1/2 toolbar slot.
        try:
            self.auto_bar.grid_remove()
            self.refine_bar.grid_remove()
            self.refine_quick_frame.pack_forget()
        except Exception:
            pass

        self._zc_preview_mode = 0
        self.layer_preview_only = False

        # Use the exact mature legacy stage-switch implementation.
        # _StagedAnnotatorFrameV211 is the stable pre-v2.12 annotator class;
        # v2.12/v2.13 scientific handoff/load behavior is still present on
        # this object and is not replaced.
        _StagedAnnotatorFrameV211.set_workspace(self, which)

        # Defensive, explicit geometry restoration. This is the part that
        # prevents Windows/Tk geometry-manager state from making controls
        # appear to have vanished after a Stage-3/4 visit.
        try:
            self.cal_bar.grid_remove()
            self.measure_bar.grid_remove()
            self.annotate_bar.grid_remove()
            self.auto_bar.grid_remove()
            self.refine_bar.grid_remove()
        except Exception:
            pass

        try:
            self.cal_only_frame.pack_forget()
            self.contrast_frame.pack_forget()
            self.annotate_quick_frame.pack_forget()
            self.measure_log_frame.pack_forget()
        except Exception:
            pass

        if which == "calibrate":
            self.cal_bar.grid()
            self.cal_only_frame.pack(side=tk.LEFT)
            self._restore_common_fit_pan(self.cal_only_frame)
            self.mode.set("calibrate")
        else:
            self.measure_bar.grid()
            self.contrast_frame.pack(side=tk.LEFT)
            self._restore_common_fit_pan(self.contrast_frame)
            self.measure_log_frame.pack(
                side=tk.RIGHT, fill=tk.Y, padx=(5, 7), pady=5
            )
            if self.mode.get() not in (
                "measure_length", "measure_width", "measure_area", "pan"
            ):
                self.mode.set("measure_length")

        self._refresh_stage_hint()
        self._mode_changed()
        self.refresh_measurement_log()
        self.refresh_lock_badges()
        self.refresh_measurement_visibility_badge()
        self.render()

        # One extra idle-cycle repair for Windows DPI / geometry-manager
        # timing. It does not create controls or change scientific state.
        try:
            self.after_idle(
                lambda w=which: self._zc_verify_step12_visibility(w)
            )
        except Exception:
            pass

    def _zc_verify_step12_visibility(self, which):
        """
        UI-only self-check. If a required legacy frame is unexpectedly
        unmapped after the idle layout pass, restore it once.
        """
        if getattr(self, "workspace", None) != which:
            return

        try:
            if which == "calibrate":
                required = (
                    self.cal_bar,
                    self.cal_only_frame,
                    self.fit_btn,
                    self.pan_btn,
                    self.calibrate_btn,
                    self.unlock_cal_btn,
                )
            else:
                required = (
                    self.measure_bar,
                    self.contrast_frame,
                    self.measure_log_frame,
                    self.fit_btn,
                    self.pan_btn,
                    self.measure_length_btn,
                    self.measure_width_btn,
                    self.measure_area_btn,
                    self.align_btn,
                    self.align_confirm_btn,
                    self.align_reset_btn,
                    self.contrast_scale,
                )

            if all(bool(w.winfo_ismapped()) for w in required):
                return
        except Exception:
            return

        # Geometry only; no data/state reset.
        try:
            if which == "calibrate":
                self.cal_bar.grid()
                self.cal_only_frame.pack(side=tk.LEFT)
                self._restore_common_fit_pan(self.cal_only_frame)
            else:
                self.measure_bar.grid()
                self.contrast_frame.pack(side=tk.LEFT)
                self._restore_common_fit_pan(self.contrast_frame)
                self.measure_log_frame.pack(
                    side=tk.RIGHT, fill=tk.Y, padx=(5, 7), pady=5
                )
            self.render()
        except Exception:
            pass

    def set_workspace(self,which):
        if which in ('calibrate','measure'):
            try:self.refine_quick_frame.pack_forget()
            except Exception:pass
            self.workspace=which
            self._zc_restore_legacy_step12_ui(which)
            return

        super().set_workspace('annotate')
        self.workspace=which

        try:
            self.annotate_bar.grid_remove()
            self.annotate_quick_frame.pack_forget()
            self.refine_quick_frame.pack_forget()
        except Exception:
            pass

        if which=='auto':
            self._restore_common_fit_pan()
            self.auto_bar.grid()
            self.refine_bar.grid_remove()
            self.mode.set('zc_region')
        else:
            # Pack the Step-4 quick frame first, then explicitly insert
            # Fit/Pan immediately before it. Visual order:
            # ... Next -> Fit -> Pan -> Original only -> Preview -> Save
            self.refine_quick_frame.pack(side=tk.LEFT,padx=(4,2))
            self._restore_common_fit_pan(self.refine_quick_frame)
            self.refine_bar.grid()
            self.auto_bar.grid_remove()
            self.mode.set('zc_delete')

        self.layer_preview_only=False
        self._zc_preview_mode=0
        self._clear_zc_draft()
        self._refresh_preview_button_text()
        self._refresh_stage_hint()
        self._mode_changed()
        self._refresh_zc_stats()
        self.render()

    def _mode_changed(self):
        super()._mode_changed(); m=self.mode.get()
        if m in ('zc_region','zc_smart'): self.canvas.configure(cursor='crosshair')
        elif m=='zc_delete': self.canvas.configure(cursor='hand2')

    def _signal_now(self):
        # Step 4 smart refinement: local-darkness signal, unchanged.
        if self.original is None:return None
        oid=id(self.original)
        if self._zc_signal_id!=oid or self._zc_signal is None:
            self._zc_signal=local_darkness_map(ImageOps.grayscale(self.original)); self._zc_signal_id=oid
        return self._zc_signal


    def _region_now(self):
        if self.original is None:return None
        if self.region is not None and _zc_count(self.region)>0:return self.region.convert('L')
        return Image.new('L',(self.img_w,self.img_h),255)

    def _clear_zc_draft(self):
        try:self.canvas.delete(self._zc_draft_tag)
        except Exception:pass
        self._zc_pts=[]; self._zc_last_screen=None

    def _start_zc_draft(self,event,p,color):
        self._clear_zc_draft(); self._zc_pts=[p]; self._zc_last_screen=(event.x,event.y)
        self.canvas.create_oval(event.x-3,event.y-3,event.x+3,event.y+3,outline=color,width=1,tags=(self._zc_draft_tag,))

    def _append_zc_draft(self,event,p,color):
        if not self._zc_pts:return
        last=self._zc_pts[-1]
        if math.hypot(p[0]-last[0],p[1]-last[1])<max(.5,1.2/max(self.zoom,1e-6)):return
        self._zc_pts.append(p)
        if self._zc_last_screen is not None:
            x,y=self._zc_last_screen; self.canvas.create_line(x,y,event.x,event.y,fill=color,width=2,smooth=True,capstyle=tk.ROUND,joinstyle=tk.ROUND,tags=(self._zc_draft_tag,))
        self._zc_last_screen=(event.x,event.y)

    def _finish_region(self,pts):
        if self.original is None or len(pts)<3:return
        size=(self.img_w,self.img_h); self.region=Image.new('L',size,0); self.boundary=Image.new('L',size,0)
        ImageDraw.Draw(self.region).polygon(pts+[pts[0]],fill=255); ImageDraw.Draw(self.boundary).line(pts+[pts[0]],fill=255,width=max(1,int(self.line_width.get())))
        self.mask=Image.new('L',size,0); self._zc_region_locked=False; self._zc_region_kind='fixed'; self._zc_auto_base=None; self._zc_kept=0; self.dirty=True
        self.render(); self._refresh_zc_stats(); self._update_status(self._t('固定区域已画出；区域外原图仍保留。','Fixed region drawn; outside image remains visible.'))

    def _lock_zc_region(self):
        if self.region is None or _zc_count(self.region)==0:
            messagebox.showinfo(self._t('没有固定区域','No fixed region'),self._t('未画固定区域时，直接点击“一键生成孔隙”会自动锁定全图。','With no fixed region, One-click pores automatically uses the whole image.')); return
        self._zc_region_locked=True; self._zc_region_kind='fixed'; self._refresh_zc_stats(); self._update_status(self._t('固定区域已锁定；区域外只显示，不参与计算。','Fixed region locked; outside pixels remain visible but excluded from calculation.'))

    def _clear_zc_region(self):
        if self.original is None:return
        size=(self.img_w,self.img_h); self.region=Image.new('L',size,0); self.boundary=Image.new('L',size,0); self.mask=Image.new('L',size,0)
        self._zc_region_locked=False; self._zc_region_kind=None; self._zc_auto_base=None; self._zc_kept=0; self.dirty=True; self.render(); self._refresh_zc_stats()

    def _lock_full(self):
        size=(self.img_w,self.img_h); self.region=Image.new('L',size,255); self.boundary=Image.new('L',size,0)
        ImageDraw.Draw(self.boundary).rectangle((0,0,max(0,self.img_w-1),max(0,self.img_h-1)),outline=255,width=max(1,int(self.line_width.get())))
        self._zc_region_locked=True; self._zc_region_kind='full'

    def _ensure_auto_region(self):
        if self.original is None:
            return False
        if self.region is None or _zc_count(self.region)==0:
            self._lock_full()
        else:
            self._zc_region_locked=True
            self._zc_region_kind=self._zc_region_kind or 'fixed'
        return True

    def _current_diameter_range(self):
        dmin,dmax=self.zc_diam_range.get()
        dmin=max(1,min(300,int(round(dmin))))
        dmax=max(dmin,min(300,int(round(dmax))))
        return dmin,dmax

    def _auto_generate(self):
        """
        v2.4 simple fast first pass:
            cached local-darkness signal
            -> Otsu baseline
            -> user sensitivity
            -> one threshold mask
            -> one connected-component diameter filter

        No absolute-black channel, no multi-channel overlay, no watershed.
        """
        if not self._ensure_auto_region():
            return

        reg=self._region_now()

        # _signal_now() caches local_darkness_map by image id, so the expensive
        # Gaussian-background calculation is performed only once per image.
        sig=self._signal_now()

        if self._zc_auto_base is None:
            self._zc_auto_base=otsu_threshold(sig,reg)

        sens=max(.05,min(3.00,float(self.zc_sens.get())))
        threshold=int(max(2,min(254,round(self._zc_auto_base/sens))))
        raw=threshold_pores(sig,reg,threshold)

        dmin,dmax=self._current_diameter_range()
        self.mask,self._zc_kept=_filter_pore_components_v05(
            raw,reg,sig,threshold,
            min_diameter_px=float(dmin),
            max_diameter_px=float(dmax)
        )

        self.dirty=True
        self.zc_sens_txt.set(f'{sens:.2f}×')
        self.zc_diam_txt.set(f'{dmin}–{dmax} px')
        self.render()
        self._refresh_zc_stats()
        self._update_status(self._t(
            f'一键初筛完成：孔隙识别灵敏度 {sens:.2f}×；孔径硬控 {dmin}–{dmax} px；保留 {self._zc_kept} 个孔区。明显漏检请进入第四步智能补孔或手绘补孔。',
            f'One-click first pass complete: pore sensitivity {sens:.2f}×; diameter hard gate {dmin}–{dmax} px; {self._zc_kept} pore regions retained. Handle obvious misses in Step 4 with Smart add or Manual add.'
        ))

    def _rebuild_auto(self):
        # Compatibility route. Explicit click remains the normal workflow.
        self._auto_generate()

    def _auto_slider(self,_=None):
        sens=max(.05,min(3.00,float(self.zc_sens.get())))
        self.zc_sens_txt.set(f'{sens:.2f}×')
        if self._zc_auto_base is not None and self._zc_region_locked:
            self._update_status(self._t(
                '孔隙识别灵敏度已修改；点击“一键生成孔隙”应用。当前结果不会自动重算。',
                'Pore sensitivity changed; click One-click pores to apply it. The current result is not recalculated automatically.'
            ))

    def _diam_range_changed(self,dmin=None,dmax=None):
        if dmin is None or dmax is None:
            dmin,dmax=self.zc_diam_range.get()
        dmin=max(1,min(300,int(round(dmin))))
        dmax=max(dmin,min(300,int(round(dmax))))
        self.zc_diam_txt.set(f'{dmin}–{dmax} px')
        if self._zc_auto_base is not None and self._zc_region_locked:
            self._update_status(self._t(
                '孔径范围已修改；点击“一键生成孔隙”应用。当前结果不会自动重算。',
                'Diameter range changed; click One-click pores to apply it. The current result is not recalculated automatically.'
            ))

    def _refresh_zc_stats(self):
        if not hasattr(self,'zc_stats'):return
        p,r,pct=_zc_porosity(self.mask,self.region)
        if r:
            kind=self._t(
                '全图' if self._zc_region_kind=='full' else '固定区域',
                'Whole image' if self._zc_region_kind=='full' else 'Fixed region'
            )
            self.zc_stats.set(self._t(
                f'{kind} · {self._zc_kept} 区 · {pct:.3f}%',
                f'{kind} · {self._zc_kept} regions · {pct:.3f}%'
            ))
        else:
            self.zc_stats.set(self._t(
                '未指定区域：一键生成自动全图',
                'No region: one-click automatically uses the whole image'
            ))
        if hasattr(self,'zc_folder'):
            self.zc_folder.set(self._t(
                '固定输出: PorosityAnalyzer_Project',
                'Fixed output: PorosityAnalyzer_Project'
            ))

    def _delete_component(self,p):
        if self.mask is None:return
        x,y=int(round(p[0])),int(round(p[1]))
        if not(0<=x<self.img_w and 0<=y<self.img_h) or self.mask.getpixel((x,y))<128:return
        self.push_undo()
        if HAS_CV2:
            arr=(np.asarray(self.mask,dtype=np.uint8)>0).astype(np.uint8); n,labels,_,_=cv2.connectedComponentsWithStats(arr,8); lab=int(labels[y,x]); arr[labels==lab]=0; self.mask=Image.fromarray((arr*255).astype(np.uint8),'L')
        else:
            m=self.mask.copy(); ImageDraw.floodfill(m,(x,y),0,thresh=0); self.mask=m
        self.dirty=True; self._zc_smart_lasso=None; self._zc_smart_before=None; self.render(); self._refresh_zc_stats()

    def _refresh_dark_default_label(self):
        if not hasattr(self,'zc_dark_default_txt'):
            return
        if self._zc_dark_default_locked:
            self.zc_dark_default_txt.set(self._t(
                f'🔒 默认 {self._zc_dark_default:.2f}×',
                f'🔒 Default {self._zc_dark_default:.2f}×'
            ))
        else:
            self.zc_dark_default_txt.set(self._t(
                '默认 1.00×',
                'Default 1.00×'
            ))

    def _lock_dark_default(self):
        value=max(0.10,min(3.00,float(self.zc_dark.get())))
        self._zc_dark_default=value
        self._zc_dark_default_locked=True
        self._refresh_dark_default_label()
        self._update_status(self._t(
            f'已锁定暗区默认值 {value:.2f}×。以后新圈选从该值开始，但仍可单独微调。',
            f'Dark-sensitivity default locked at {value:.2f}×. Future selections start here but remain independently tunable.'
        ))

    def _reset_dark_default(self):
        self._zc_dark_default=1.0
        self._zc_dark_default_locked=False
        self.zc_dark.set(1.0)
        self.zc_dark_txt.set('1.00×')
        self._refresh_dark_default_label()

        # Reset only the CURRENT smart-lasso result, if one exists.
        # Earlier completed pores are untouched because every recomputation uses
        # _zc_smart_before for the current lasso only.
        if self._zc_smart_lasso is not None and self._zc_smart_before is not None and not self._zc_smart_busy:
            self._zc_smart_busy=True
            self.after(20,lambda:self._execute_smart(False,1.0))
        else:
            self._update_status(self._t(
                '暗区默认值已恢复为 1.00×。',
                'Dark-sensitivity default restored to 1.00×.'
            ))

    def _begin_smart(self,pts):
        if self.mask is None or len(pts)<3:return
        if not HAS_CV2:
            messagebox.showwarning('OpenCV',self._t('智能补孔需要 numpy + opencv-python。','Smart add requires numpy + opencv-python.')); return

        # A new lasso always starts from the default value:
        # 1.00× when unlocked, or the user-locked default otherwise.
        start_value=self._zc_dark_default if self._zc_dark_default_locked else 1.0
        start_value=max(0.40,min(2.00,float(start_value)))
        self.zc_dark.set(start_value)
        self.zc_dark_txt.set(f'{start_value:.2f}×')

        self._zc_smart_lasso=pts[:]
        self._zc_smart_before=self.mask.copy()
        self._zc_smart_history_added=False
        self._zc_smart_busy=True
        self._update_status(self._t(
            f'圈定完成；当前区域从暗区灵敏度 {start_value:.2f}× 开始计算…',
            f'Lasso complete; current region starts at dark sensitivity {start_value:.2f}×…'
        ))
        self.update_idletasks()
        self.after(30,lambda:self._execute_smart(False,start_value))

    def _execute_smart(self,auto=True,sensitivity=None):
        if self._zc_smart_lasso is None or self._zc_smart_before is None:return
        try:
            comp,chosen,bt,bg,q=_smart_dark_component_v05(self.original,self._signal_now(),self._region_now(),self._zc_smart_lasso,None if auto else float(sensitivity))
            if _zc_count(comp)==0:
                self.mask=self._zc_smart_before.copy(); self.render(); self._update_status(self._t('圈内未找到稳定黑区；亮光已被排除。','No stable dark region found; bright reflections were excluded.')); return
            if not self._zc_smart_history_added:
                self.push_undo(); self._zc_smart_history_added=True
            self.mask=ImageChops.lighter(self._zc_smart_before,comp); self.mask=ImageChops.multiply(self.mask,self._region_now()); self.dirty=True; self.zc_dark.set(float(chosen)); self.zc_dark_txt.set(f'{float(chosen):.2f}×'); self.render(); self._refresh_zc_stats(); self._update_status(self._t(f'智能补孔完成：暗区灵敏度 {chosen:.2f}×。',f'Smart pore complete: dark sensitivity {chosen:.2f}×.'))
        finally:self._zc_smart_busy=False

    def _smart_auto_again(self):
        if self._zc_smart_lasso is None:return
        if self._zc_smart_busy:return
        # Auto-search affects only the current lasso. The locked default is
        # unchanged unless the user explicitly presses "锁定当前值".
        self._zc_smart_busy=True
        self.after(20,lambda:self._execute_smart(True,None))

    def _smart_slider(self,_=None):
        r=max(0.10,min(3.00,float(self.zc_dark.get()))); self.zc_dark_txt.set(f'{r:.2f}×')
        if self._zc_smart_lasso is None:return
        if self._zc_smart_job is not None:
            try:self.after_cancel(self._zc_smart_job)
            except Exception:pass
        self._zc_smart_job=self.after(150,lambda rr=r:self._apply_smart(rr))

    def _apply_smart(self,r):
        self._zc_smart_job=None
        if self._zc_smart_busy:return
        self._zc_smart_busy=True; self._execute_smart(False,r)

    def on_left_press(self,event):
        if getattr(self,'_v213_blank_view',False):return
        m=self.mode.get()
        if self.workspace=='auto' and m=='zc_region':
            if self.space_down or self._pan_mode_active:return super().on_left_press(event)
            p=self.screen_to_image(event.x,event.y)
            if p is not None and self.inside_image(*p):self._start_zc_draft(event,p,'#ffd700')
            return
        if self.workspace=='refine' and m=='zc_smart':
            if self.space_down or self._pan_mode_active:return super().on_left_press(event)
            p=self.screen_to_image(event.x,event.y)
            if p is not None and self.inside_image(*p):self._start_zc_draft(event,p,'#00e5ff')
            return
        if self.workspace=='refine' and m=='zc_delete':
            p=self.screen_to_image(event.x,event.y)
            if p is not None:self._delete_component(p)
            return
        return super().on_left_press(event)

    def on_left_drag(self,event):
        m=self.mode.get()
        if self.workspace=='auto' and m=='zc_region' and self._zc_pts:
            p=self.screen_to_image(event.x,event.y)
            if p is not None:self._append_zc_draft(event,(clamp(p[0],0,self.img_w-1),clamp(p[1],0,self.img_h-1)),'#ffd700')
            return
        if self.workspace=='refine' and m=='zc_smart' and self._zc_pts:
            p=self.screen_to_image(event.x,event.y)
            if p is not None:self._append_zc_draft(event,(clamp(p[0],0,self.img_w-1),clamp(p[1],0,self.img_h-1)),'#00e5ff')
            return
        return super().on_left_drag(event)

    def on_left_release(self,event):
        m=self.mode.get()
        if self.workspace=='auto' and m=='zc_region' and self._zc_pts:
            p=self.screen_to_image(event.x,event.y)
            if p is not None:self._append_zc_draft(event,(clamp(p[0],0,self.img_w-1),clamp(p[1],0,self.img_h-1)),'#ffd700')
            pts=self._zc_pts[:]; self._clear_zc_draft(); self._finish_region(pts); return
        if self.workspace=='refine' and m=='zc_smart' and self._zc_pts:
            p=self.screen_to_image(event.x,event.y)
            if p is not None:self._append_zc_draft(event,(clamp(p[0],0,self.img_w-1),clamp(p[1],0,self.img_h-1)),'#00e5ff')
            pts=self._zc_pts[:]; self._clear_zc_draft(); self._begin_smart(pts); return
        return super().on_left_release(event)

    def on_right_press(self,event):
        if self.workspace in ('auto','refine') and self._zc_pts:
            self._clear_zc_draft(); self.render(); return
        return super().on_right_press(event)

    def render(self):
        """
        Unified v1.4 render dispatcher.

        Steps 1–2 and normal Stage-3/4 editing use the mature legacy render,
        including measurement overlays and the movable cyan alignment guide.
        Only the two explicit Stage-4 preview-only states use the custom
        white/red or original-only renderer.
        """
        if getattr(self, "_v213_blank_view", False):
            return super().render()

        if (
            getattr(self, "workspace", None) == "refine"
            and int(getattr(self, "_zc_preview_mode", 0)) in (1, 2)
        ):
            return self._render_refine_preview()

        return super().render()

    def _set_refine_preview_mode(self, requested_mode):
        if self.workspace!='refine':
            return
        requested_mode=int(requested_mode)
        current=int(getattr(self,'_zc_preview_mode',0))
        self._zc_preview_mode=0 if current==requested_mode else requested_mode
        self.layer_preview_only=(self._zc_preview_mode==1)
        self.render()

        msgs={
            0:self._t('已恢复全部显示：原图 + 孔区 + 边界。','Full view restored: image + pore mask + boundary.'),
            1:self._t('当前预览：白底 + 红色孔区。再次点击“预览”恢复全部。','Preview: white background + red pore mask. Click Preview again to restore all.'),
            2:self._t('当前只看原图：所有孔区和边界已隐藏。再次点击“只看原图”恢复全部。','Original only: pore masks and boundaries are hidden. Click Original only again to restore all.')
        }
        self._update_status(msgs[self._zc_preview_mode])

    def show_pore_preview(self):
        self._set_refine_preview_mode(1)

    def show_original_only(self):
        self._set_refine_preview_mode(2)

    def toggle_layer_preview(self):
        # Compatibility with the old command path: Preview is now an
        # independent Step-4 button rather than a three-state cycle.
        if self.workspace=='refine':
            self.show_pore_preview()
            return
        return super().toggle_layer_preview()

    def save_layers(self,silent=False):
        r=super().save_layers(silent=True); self._refresh_zc_stats()
        if not silent:
            p=getattr(self,'last_saved_project_path_v212',None)
            if p:messagebox.showinfo(self._t('保存完成','Saved'),self._t(f'第四步已保存。\n\n固定项目目录：\n{Path(p).parent}\n\n第五步项目：\n{p}',f'Step 4 saved.\n\nFixed project folder:\n{Path(p).parent}\n\nStep-5 project:\n{p}'))
        return r


_ZCBaseROI=StagedROICalculatorFrame
class ZhuChenUnifiedROI(_ZCBaseROI):
    pass

_ZCBaseReport=StagedReportFrame
class ZhuChenUnifiedReport(_ZCBaseReport):
    pass


class ZhuChenUnifiedApp(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        # v1.7: keep the main six-step UI hidden until the 3-second splash ends.
        self.withdraw()
        self._zc_splash = None
        self._zc_splash_photo = None
        self._zc_splash_alpha = 0.0
        self.language_code='zh'; self.language_display_var=tk.StringVar(value='中文')
        self.geometry('1540x940'); self.minsize(1160,740)
        nav=ttk.Frame(self); nav.pack(side=tk.TOP,fill=tk.X,padx=8,pady=(7,4)); self.stage_buttons={}
        self.stage_order=('calibrate','measure','auto','refine','roi','report')
        for key in self.stage_order:
            b=ttk.Button(nav,command=lambda k=key:self.show_module(k)); b.pack(side=tk.LEFT,padx=(0,6),ipadx=10,ipady=5); self.stage_buttons[key]=b
        self.global_state_var=tk.StringVar(value=''); ttk.Label(nav,textvariable=self.global_state_var,anchor=tk.E,font=('Segoe UI',9,'bold')).pack(side=tk.RIGHT,padx=(12,4))
        ttk.Separator(self,orient=tk.HORIZONTAL).pack(fill=tk.X); self.body=ttk.Frame(self); self.body.pack(fill=tk.BOTH,expand=True)
        self.annotator=ZhuChenUnifiedAnnotator(self.body,app=self); self.roi_calc=ZhuChenUnifiedROI(self.body,app=self); self.report=ZhuChenUnifiedReport(self.body,app=self)
        self.current_module=None; self._s1=False; self._s2=False; self._s3=False; self._s4=False
        self._enable_dnd()
        self.apply_language()
        self.show_module('calibrate')
        # Build the full UI first, then show only the splash for ~3 seconds.
        self.after(10, self._start_splash_v17)

    def _splash_candidate_paths_v17(self):
        """
        Search for a replaceable splash image.

        Preferred desktop filename:
            splash.png

        Compatibility fallback:
            1.png

        Search order:
        1) next to the packaged EXE
        2) next to this Python file
        3) PyInstaller _MEIPASS bundle directory
        """
        candidates = []

        try:
            if getattr(sys, "frozen", False):
                exe_dir = Path(sys.executable).resolve().parent
                candidates.extend([exe_dir / "splash.png", exe_dir / "1.png"])
        except Exception:
            pass

        try:
            script_dir = Path(__file__).resolve().parent
            candidates.extend([script_dir / "splash.png", script_dir / "1.png"])
        except Exception:
            pass

        try:
            bundle_dir = Path(getattr(sys, "_MEIPASS"))
            candidates.extend([bundle_dir / "splash.png", bundle_dir / "1.png"])
        except Exception:
            pass

        seen = set()
        out = []
        for p in candidates:
            try:
                key = str(p.resolve()).lower()
            except Exception:
                key = str(p).lower()
            if key not in seen:
                seen.add(key)
                out.append(p)
        return out

    def _find_splash_image_v17(self):
        for path in self._splash_candidate_paths_v17():
            try:
                if path.is_file():
                    return path
            except Exception:
                pass
        return None

    def _start_splash_v17(self):
        """
        Centered 3-second splash.

        Timing:
          0.00–0.30 s  fade in
          0.30–2.60 s  fully visible
          2.60–3.00 s  fade out

        If no splash.png / 1.png exists, the scientific program opens
        immediately instead of failing.
        """
        splash_path = self._find_splash_image_v17()
        if splash_path is None:
            self._finish_splash_v17()
            return

        try:
            img = Image.open(splash_path).convert("RGBA")
        except Exception:
            self._finish_splash_v17()
            return

        # Keep aspect ratio and fit comfortably inside the current screen.
        sw = max(800, int(self.winfo_screenwidth()))
        sh = max(600, int(self.winfo_screenheight()))
        max_w = min(1000, int(sw * 0.72))
        max_h = min(650, int(sh * 0.72))

        scale = min(max_w / img.width, max_h / img.height, 1.0)
        if scale < 1.0:
            size = (
                max(1, int(round(img.width * scale))),
                max(1, int(round(img.height * scale))),
            )
            img = img.resize(size, Image.Resampling.LANCZOS)

        win = tk.Toplevel(self)
        self._zc_splash = win
        win.withdraw()
        win.overrideredirect(True)
        win.configure(bg="#000000")

        # Center the splash window on the physical screen.
        w, h = img.size
        x = max(0, (sw - w) // 2)
        y = max(0, (sh - h) // 2)
        win.geometry(f"{w}x{h}+{x}+{y}")

        self._zc_splash_photo = ImageTk.PhotoImage(img)
        label = tk.Label(
            win,
            image=self._zc_splash_photo,
            bd=0,
            highlightthickness=0,
            bg="#000000",
        )
        label.pack(fill=tk.BOTH, expand=True)

        # Keep the splash above other windows during its short lifetime.
        try:
            win.attributes("-topmost", True)
        except Exception:
            pass

        # Alpha is supported on normal Windows/Tk builds.
        try:
            win.attributes("-alpha", 0.0)
            self._zc_splash_alpha = 0.0
        except Exception:
            self._zc_splash_alpha = 1.0

        win.deiconify()
        win.lift()
        self.update_idletasks()

        # 0–300 ms fade in.
        self._splash_fade_in_v17(step=0, steps=15)

        # Fade out starts at 2.60 s; total life is ~3.00 s.
        self.after(2600, lambda: self._splash_fade_out_v17(step=0, steps=20))

    def _splash_fade_in_v17(self, step=0, steps=15):
        win = self._zc_splash
        if win is None or not win.winfo_exists():
            return

        if step >= steps:
            try:
                win.attributes("-alpha", 1.0)
            except Exception:
                pass
            self._zc_splash_alpha = 1.0
            return

        alpha = (step + 1) / float(steps)
        self._zc_splash_alpha = alpha
        try:
            win.attributes("-alpha", alpha)
        except Exception:
            return

        # 15 × 20 ms = 300 ms.
        self.after(20, lambda: self._splash_fade_in_v17(step + 1, steps))

    def _splash_fade_out_v17(self, step=0, steps=20):
        win = self._zc_splash
        if win is None or not win.winfo_exists():
            self._finish_splash_v17()
            return

        if step >= steps:
            self._finish_splash_v17()
            return

        alpha = 1.0 - ((step + 1) / float(steps))
        alpha = max(0.0, min(1.0, alpha))
        self._zc_splash_alpha = alpha
        try:
            win.attributes("-alpha", alpha)
        except Exception:
            # If alpha is unsupported, still preserve the 3-second timing.
            pass

        # 20 × 20 ms = 400 ms.
        self.after(20, lambda: self._splash_fade_out_v17(step + 1, steps))

    def _finish_splash_v17(self):
        win = self._zc_splash
        self._zc_splash = None

        if win is not None:
            try:
                if win.winfo_exists():
                    win.destroy()
            except Exception:
                pass

        self._zc_splash_photo = None

        # Only now reveal the normal six-step application.
        try:
            self.deiconify()
            self.update_idletasks()
            self.lift()
            self.focus_force()
        except Exception:
            pass

    def tr(self,zh,en):return en if self.language_code=='en' else zh
    def set_language_from_display(self):self.language_code='en' if self.language_display_var.get()=='English' else 'zh'; self.apply_language()
    def set_language(self,code):self.language_code='en' if str(code).lower().startswith('en') else 'zh'; self.language_display_var.set('English' if self.language_code=='en' else '中文'); self.apply_language()

    def apply_language(self):
        labs={'calibrate':('① 标尺校准','① Scale calibration'),'measure':('② 尺寸 / 面积测量','② Dimension / area'),'auto':('③ 区域 / 自动孔隙','③ Region / auto pores'),'refine':('④ 人工精修','④ Refinement'),'roi':('⑤ ROI 测试','⑤ ROI analysis'),'report':('⑥ 报告整理','⑥ Final report')}
        for k,b in self.stage_buttons.items():b.configure(text=self.tr(*labs[k]))
        for f in (self.annotator,self.roi_calc,self.report):
            try:f.apply_language()
            except Exception:pass
        self.refresh_global_state(); self._refresh_title()

    def _refresh_title(self):
        labs={'calibrate':('① 标尺校准','① Scale calibration'),'measure':('② 尺寸 / 面积测量','② Dimension / area measurement'),'auto':('③ 分析区域 + 自动孔隙','③ Analysis region + automatic pores'),'refine':('④ 人工精修 + 保存','④ Refinement + save'),'roi':('⑤ ROI 测试','⑤ ROI analysis'),'report':('⑥ 最终报告','⑥ Final report')}
        self.title(f"逐尘 ZhuChen v2.4 — {self.tr(*labs.get(self.current_module,('','')))}")

    def refresh_global_state(self):
        try:
            c=self.annotator.calibration; self.global_state_var.set((self.tr('🔒 标尺锁定: ','🔒 Scale locked: ')+f"1 px = {c['unit_per_px']:.6g} {c['unit']}") if c else self.tr('○ 标尺未锁定','○ Scale unlocked')); self.annotator.refresh_lock_badges()
        except Exception:self.global_state_var.set(self.tr('○ 标尺未锁定','○ Scale unlocked'))

    def _v213_on_annotator_image_loaded(self,stage):
        if stage=='calibrate':self._s1=True; self._s2=self._s3=self._s4=False
        elif stage=='measure':self._s1=self._s2=True; self._s3=self._s4=False
        elif stage=='auto':self._s3=True; self._s4=False
        elif stage=='refine':self._s4=True
        try:self.annotator._v213_set_blank_view(False,render_now=False)
        except Exception:pass

    def show_module(self,which):
        cur=self.current_module; ann=self.annotator
        if cur==which:
            if which=='roi':self.roi_calc.refresh_stage_state()
            elif which=='report':self.report.refresh_preview()
            self.refresh_global_state(); return
        ann.pack_forget(); self.roi_calc.pack_forget(); self.report.pack_forget()
        if which=='calibrate':
            ann.pack(fill=tk.BOTH,expand=True); ann.set_workspace('calibrate'); ann._v213_set_blank_view(not bool(ann.image_path),render_now=False); ann.canvas.focus_set()
        elif which=='measure':
            ann.pack(fill=tk.BOTH,expand=True); ann.set_workspace('measure')
            if cur=='calibrate' and ann.image_path is not None:self._s2=True
            ann._v213_set_blank_view(not(self._s2 and ann.image_path is not None),render_now=False); ann.canvas.focus_set()
        elif which=='auto':
            ann.pack(fill=tk.BOTH,expand=True)
            if cur=='measure' and self._s2 and ann.image_path is not None:
                ann._v213_set_blank_view(False,render_now=False)
                if ann.prepare_stage3_from_step2_v212():self._s3=True; ann._zc_signal_id=None; ann._zc_signal=None
            ann.set_workspace('auto'); ann._v213_set_blank_view(not(self._s3 and ann.image_path is not None),render_now=False); ann.canvas.focus_set()
        elif which=='refine':
            ann.pack(fill=tk.BOTH,expand=True)
            if cur=='auto' and self._s3 and ann.image_path is not None:self._s4=True
            ann.set_workspace('refine'); ann._v213_set_blank_view(not(self._s4 and ann.image_path is not None),render_now=False); ann.canvas.focus_set()
        elif which=='roi':
            if cur=='refine' and ann.image_path is not None:
                p=getattr(ann,'last_saved_project_path_v212',None)
                if ann.dirty or not p or not Path(p).exists():
                    ann.pack(fill=tk.BOTH,expand=True); ann.set_workspace('refine'); messagebox.showwarning(self.tr('请先保存','Save first'),self.tr('第四步请先点击“保存”，再进入第五步 ROI。','Save Step 4 before entering Step 5 ROI.')); return
                if self.roi_calc.project_source_path is None or Path(self.roi_calc.project_source_path)!=Path(p):self.roi_calc.load_project_file(Path(p))
            self.roi_calc.pack(fill=tk.BOTH,expand=True); self.roi_calc.refresh_stage_state(); self.roi_calc.canvas.focus_set()
        else:self.report.pack(fill=tk.BOTH,expand=True); self.report.refresh_preview()
        self.current_module=which; self.refresh_global_state(); self._refresh_title();
        try:ann.render()
        except Exception:pass

    def reset_workspace_keep_calibration(self):
        _PoreToolAppV210.reset_workspace_keep_calibration(self); self._s1=self._s2=self._s3=self._s4=False
        try:
            self.annotator._zc_signal_id=None; self.annotator._zc_signal=None; self.annotator._zc_auto_base=None
            self.annotator._zc_region_locked=False; self.annotator._zc_region_kind=None
            self.annotator._zc_smart_lasso=None; self.annotator._zc_smart_before=None
            self.annotator._zc_dark_default=1.0; self.annotator._zc_dark_default_locked=False
            self.annotator._zc_smart_history_added=False; self.annotator._zc_preview_mode=0
            if hasattr(self.annotator,'zc_dark'):
                self.annotator.zc_dark.set(1.0); self.annotator.zc_dark_txt.set('1.00×')
            if hasattr(self.annotator,'zc_area'):
                self.annotator.zc_area.set(100); self.annotator.zc_area_txt.set('100')
            self.annotator._refresh_dark_default_label(); self.annotator._refresh_preview_button_text()
        except Exception:
            pass
        except Exception:pass
        self.apply_language()

    def _enable_dnd(self):
        if not globals().get('_V213_HAS_DND',False):return
        try:
            _V213_TkinterDnD._require(self)
            for w in (self.annotator.canvas,self.roi_calc.canvas):w.drop_target_register(_V213_DND_FILES); w.dnd_bind('<<Drop>>',self._on_drop)
        except Exception:pass

    def _split_drop(self,data):
        try:items=list(self.tk.splitlist(data))
        except Exception:items=[str(data)]
        return [Path(str(x).strip().strip('{}')) for x in items if str(x).strip()]

    def _on_drop(self,event):
        paths=self._split_drop(getattr(event,'data','')); stage=self.current_module or 'calibrate'
        if stage=='roi':
            ps=[p for p in paths if p.is_file() and p.suffix.lower()=='.poreproj']
            if ps:self.roi_calc.load_project_file(ps[0])
            else:messagebox.showwarning(self.tr('第五步需要项目文件','Step 5 requires a project'),self.tr('请拖入第四步保存的 .poreproj。','Drop a .poreproj saved in Step 4.'))
            return
        if stage=='report':return
        exts={'.png','.jpg','.jpeg','.tif','.tiff','.bmp','.webp'}; imgs=[]
        for p in paths:
            if p.is_file() and p.suffix.lower() in exts:imgs.append(p)
            elif p.is_dir():imgs.extend(sorted([q for q in p.iterdir() if q.is_file() and q.suffix.lower() in exts],key=lambda q:q.name.lower()))
        if imgs:
            self.annotator.input_folder=imgs[0].parent; self.annotator.image_files=imgs; self.annotator.image_index=0; self.annotator._v213_set_blank_view(False,render_now=False); self.annotator.load_image(imgs[0])


# =============================================================================
# ZHUCHEN DATABASE EDITION v3.0
# Target workflow for the current pore-image database:
#   1) scale calibration        — unchanged
#   2) contrast/alignment/L-W-A — unchanged
#   3) bottom crop + one-click pore detection
#   4) full legacy refinement + live/final overall porosity
#   5) optional ROI inspection/recording
#   6) legacy report + one-row-per-image database export
# =============================================================================

def _db_component_count(mask, region=None):
    """Count 8-connected pore components inside *region* without changing masks."""
    if mask is None:
        return 0
    src = mask.convert("L").point(lambda p: 255 if p >= 128 else 0, mode="L")
    if region is not None:
        reg = region.convert("L").point(lambda p: 255 if p >= 128 else 0, mode="L")
        src = ImageChops.multiply(src, reg)

    if HAS_CV2:
        arr = (np.asarray(src, dtype=np.uint8) > 0).astype(np.uint8)
        n, _, _, _ = cv2.connectedComponentsWithStats(arr, connectivity=8)
        return max(0, int(n) - 1)

    # Pillow/Python fallback.
    w, h = src.size
    data = bytearray(src.tobytes())
    seen = bytearray(w * h)
    count = 0
    for idx in range(w * h):
        if data[idx] == 0 or seen[idx]:
            continue
        count += 1
        stack = [idx]
        seen[idx] = 1
        while stack:
            cur = stack.pop()
            y, x = divmod(cur, w)
            for ny in range(max(0, y - 1), min(h - 1, y + 1) + 1):
                base = ny * w
                for nx in range(max(0, x - 1), min(w - 1, x + 1) + 1):
                    ni = base + nx
                    if not seen[ni] and data[ni]:
                        seen[ni] = 1
                        stack.append(ni)
    return count


_ZhuChenUnifiedAnnotator_PreDatabase = ZhuChenUnifiedAnnotator


class ZhuChenDatabaseAnnotator(_ZhuChenUnifiedAnnotator_PreDatabase):
    """
    Database edition.

    Steps 1, 2, 4 are inherited unchanged scientifically. Step 3 replaces the
    freehand analysis-region controls with a reproducible bottom-crop percentage.
    The source/working raster is never physically cropped: only the binary
    analysis-region mask changes.
    """

    DB_VERSION = "3.0"

    def __init__(self, parent, app):
        super().__init__(parent, app)

        self.db_bottom_crop_var = tk.DoubleVar(value=0.0)
        self._db_applied_crop_percent = None
        self._db_setting_loaded_image = None

        # Replace only the Step-3 region-selection UI. The one-click detector,
        # sensitivity, diameter gate, and result label remain the legacy controls.
        try:
            for w in (self.zc_region_btn, self.zc_lock_btn, self.zc_clear_btn):
                w.pack_forget()

            row = self.zc_generate_btn.master
            self.db_crop_label = ttk.Label(row)
            self.db_crop_label.pack(side=tk.LEFT, before=self.zc_generate_btn, padx=(4, 2), pady=3)

            self.db_crop_spin = ttk.Spinbox(
                row,
                from_=0.0, to=95.0, increment=1.0,
                textvariable=self.db_bottom_crop_var,
                width=7,
            )
            self.db_crop_spin.pack(side=tk.LEFT, before=self.zc_generate_btn, padx=(0, 2), pady=3)

            self.db_crop_unit = ttk.Label(row, text="%")
            self.db_crop_unit.pack(side=tk.LEFT, before=self.zc_generate_btn, padx=(0, 5), pady=3)

            self.db_crop_0_btn = self._button(
                row, "0%", "0%", lambda: self._db_set_crop(0),
                "不裁底，整张图参与孔隙分析。", "Use the whole image.",
                side=tk.LEFT, before=self.zc_generate_btn, padx=1, pady=3
            )
            self.db_crop_20_btn = self._button(
                row, "20%", "20%", lambda: self._db_set_crop(20),
                "裁掉底部 20%，原图不被修改。", "Exclude the bottom 20%; source image remains unchanged.",
                side=tk.LEFT, before=self.zc_generate_btn, padx=1, pady=3
            )
            self.db_crop_30_btn = self._button(
                row, "30%", "30%", lambda: self._db_set_crop(30),
                "裁掉底部 30%，原图不被修改。", "Exclude the bottom 30%; source image remains unchanged.",
                side=tk.LEFT, before=self.zc_generate_btn, padx=(1, 6), pady=3
            )

            self._tooltips.append(_HoverTip(
                self.db_crop_spin,
                lambda: self._t(
                    "底部裁剪比例：只改变第三步及之后的有效分析区域，不裁切或覆盖原图。输入 20 表示底部 20% 不参与计算。",
                    "Bottom crop: changes only the valid analysis mask from Step 3 onward; the image itself is never cropped. 20 means the bottom 20% is excluded."
                )
            ))
        except Exception:
            pass

        # Step 4 keeps every existing control; append one read-only final statistic.
        self.db_final_stats_var = tk.StringVar(value="")
        try:
            self.db_final_stats_label = ttk.Label(
                self.refine_bar,
                textvariable=self.db_final_stats_var,
                font=("Segoe UI", 9, "bold")
            )
            self.db_final_stats_label.pack(side=tk.RIGHT, padx=(10, 8), pady=4)
        except Exception:
            pass

        self.apply_language()
        self._refresh_zc_stats()

    # -----------------------------------------------------------------
    # UI / language
    # -----------------------------------------------------------------
    def apply_language(self):
        super().apply_language()
        if hasattr(self, "db_crop_label"):
            self.db_crop_label.configure(text=self._t("底部裁剪:", "Bottom crop:"))
        if hasattr(self, "db_final_stats_var"):
            self._refresh_zc_stats()

    def _refresh_stage_hint(self):
        if getattr(self, "workspace", None) == "auto" and hasattr(self, "stage_hint_var"):
            self.stage_hint_var.set(self._t(
                "Step 3 / 6 · 设定底部裁剪比例 → 一键生成；原图不裁切，只限制计算域",
                "Step 3 / 6 · Set bottom crop → One-click pores; source image is preserved and only the calculation domain changes"
            ))
            return
        if getattr(self, "workspace", None) == "refine" and hasattr(self, "stage_hint_var"):
            self.stage_hint_var.set(self._t(
                "Step 4 / 6 · 原人工精修完整保留；右侧实时显示最终整体孔隙率",
                "Step 4 / 6 · Full legacy refinement retained; final overall porosity is shown live"
            ))
            return
        return super()._refresh_stage_hint()

    # -----------------------------------------------------------------
    # Per-image database settings
    # -----------------------------------------------------------------
    def _db_settings_path(self):
        root = Path(self._project_root())
        p = root / "manual_measurements" / "analysis_settings.csv"
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    def _db_read_settings_rows(self):
        p = self._db_settings_path()
        if not p.exists():
            return []
        try:
            with p.open("r", newline="", encoding="utf-8-sig") as f:
                return list(csv.DictReader(f))
        except Exception:
            return []

    def _db_load_analysis_setting(self):
        if not self.image_path or not hasattr(self, "db_bottom_crop_var"):
            return
        name = self.image_path.name
        self._db_setting_loaded_image = name
        rows = self._db_read_settings_rows()
        row = next((r for r in reversed(rows) if (r.get("image_name") or "") == name), None)
        if row is None:
            self.db_bottom_crop_var.set(0.0)
            self._db_applied_crop_percent = None
            return
        try:
            self.db_bottom_crop_var.set(float(row.get("bottom_crop_percent", 0) or 0))
        except Exception:
            self.db_bottom_crop_var.set(0.0)
        self._db_applied_crop_percent = None

    def _db_save_analysis_setting(self, final=False):
        if not self.image_path or self.original is None:
            return
        path = self._db_settings_path()
        rows = self._db_read_settings_rows()
        image_name = self.image_path.name
        rows = [r for r in rows if (r.get("image_name") or "") != image_name]

        crop = self._db_crop_value()
        pore_pixels, region_pixels, porosity = _zc_porosity(self.mask, self.region)
        pore_count = _db_component_count(self.mask, self.region)
        dmin, dmax = self._current_diameter_range()
        try:
            sensitivity = float(self.zc_sens.get())
        except Exception:
            sensitivity = 1.0

        effective_h = int(round(self.img_h * (1.0 - crop / 100.0))) if self.img_h else 0
        rows.append({
            "image_name": image_name,
            "bottom_crop_percent": f"{crop:.6f}",
            "image_width_px": str(int(self.img_w)),
            "image_height_px": str(int(self.img_h)),
            "analysis_height_px": str(max(0, min(int(self.img_h), effective_h))),
            "analysis_region_pixels": str(int(region_pixels)),
            "pore_pixels": str(int(pore_pixels)),
            "pore_region_count": str(int(pore_count)),
            "overall_porosity_percent": f"{porosity:.9f}",
            "pore_sensitivity": f"{sensitivity:.6f}",
            "diameter_min_px": str(int(dmin)),
            "diameter_max_px": str(int(dmax)),
            "status": "final_refined" if final else "auto_first_pass",
            "saved_at": _datetime.now().isoformat(timespec="seconds"),
        })

        fields = [
            "image_name", "bottom_crop_percent", "image_width_px", "image_height_px",
            "analysis_height_px", "analysis_region_pixels", "pore_pixels",
            "pore_region_count", "overall_porosity_percent", "pore_sensitivity",
            "diameter_min_px", "diameter_max_px", "status", "saved_at"
        ]
        with path.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            w.writerows(rows)

    # -----------------------------------------------------------------
    # Step 3 — standardized bottom crop
    # -----------------------------------------------------------------
    def _db_crop_value(self):
        try:
            v = float(self.db_bottom_crop_var.get())
        except Exception:
            v = 0.0
        return max(0.0, min(95.0, v))

    def _db_set_crop(self, value):
        self.db_bottom_crop_var.set(float(value))
        if getattr(self, "workspace", None) == "auto":
            self._update_status(self._t(
                f"底部裁剪已设为 {float(value):g}%；点击“一键生成孔隙”应用。",
                f"Bottom crop set to {float(value):g}%; click One-click pores to apply."
            ))

    def _db_apply_bottom_crop_region(self):
        if self.original is None:
            return False
        pct = self._db_crop_value()
        h_keep = int(round(self.img_h * (1.0 - pct / 100.0)))
        h_keep = max(1, min(self.img_h, h_keep))

        # Changing the analysis domain requires a fresh Otsu baseline.
        if self._db_applied_crop_percent is None or abs(self._db_applied_crop_percent - pct) > 1e-9:
            self._zc_auto_base = None
        self._db_applied_crop_percent = pct

        self.region = Image.new("L", (self.img_w, self.img_h), 0)
        ImageDraw.Draw(self.region).rectangle((0, 0, self.img_w - 1, h_keep - 1), fill=255)

        self.boundary = Image.new("L", (self.img_w, self.img_h), 0)
        bdraw = ImageDraw.Draw(self.boundary)
        lw = max(1, int(self.line_width.get()))
        bdraw.rectangle((0, 0, self.img_w - 1, h_keep - 1), outline=255, width=lw)

        self._zc_region_locked = True
        self._zc_region_kind = "full" if pct <= 1e-9 else "bottom_crop"
        return True

    def _ensure_auto_region(self):
        return self._db_apply_bottom_crop_region()

    def _auto_generate(self):
        result = super()._auto_generate()
        try:
            self._db_save_analysis_setting(final=False)
        except Exception:
            pass
        self._refresh_zc_stats()
        return result

    # -----------------------------------------------------------------
    # Live/final result display
    # -----------------------------------------------------------------
    def _refresh_zc_stats(self):
        # During parent construction the database widgets do not yet exist.
        if not hasattr(self, "db_bottom_crop_var"):
            try:
                return super()._refresh_zc_stats()
            except Exception:
                return

        p, r, pct = _zc_porosity(self.mask, self.region)
        ncomp = _db_component_count(self.mask, self.region) if r else 0
        crop = self._db_crop_value()

        if hasattr(self, "zc_stats"):
            if r:
                if crop <= 1e-9:
                    domain_zh, domain_en = "全图", "Whole image"
                else:
                    domain_zh, domain_en = f"裁底 {crop:g}%", f"Bottom crop {crop:g}%"
                self.zc_stats.set(self._t(
                    f"{domain_zh} · {ncomp} 区 · {pct:.3f}%",
                    f"{domain_en} · {ncomp} regions · {pct:.3f}%"
                ))
            else:
                self.zc_stats.set(self._t(
                    "未生成：设定底部裁剪后点击一键生成",
                    "Not generated: set bottom crop and click One-click pores"
                ))

        if hasattr(self, "db_final_stats_var"):
            if r:
                self.db_final_stats_var.set(self._t(
                    f"最终整体: {ncomp} 区 · {pct:.3f}%",
                    f"Final overall: {ncomp} regions · {pct:.3f}%"
                ))
            else:
                self.db_final_stats_var.set(self._t("最终整体: --", "Final overall: --"))

        if hasattr(self, "zc_folder"):
            self.zc_folder.set(self._t(
                "固定输出: PorosityAnalyzer_Project",
                "Fixed output: PorosityAnalyzer_Project"
            ))

    def on_left_release(self, event):
        result = super().on_left_release(event)
        if getattr(self, "workspace", None) == "refine":
            try:
                self._refresh_zc_stats()
            except Exception:
                pass
        return result

    def load_image(self, path):
        result = super().load_image(path)
        try:
            self._db_load_analysis_setting()
            self._refresh_zc_stats()
        except Exception:
            pass
        return result

    def _build_poreproj(self):
        project_path = super()._build_poreproj()
        # Preserve database-specific analysis settings in the portable project.
        try:
            settings = self._db_settings_path()
            if project_path and settings.exists():
                with _zipfile.ZipFile(project_path, "a", compression=_zipfile.ZIP_DEFLATED) as zf:
                    if "manual_measurements/analysis_settings.csv" not in zf.namelist():
                        zf.write(settings, arcname="manual_measurements/analysis_settings.csv")
        except Exception:
            pass
        return project_path

    def save_layers(self, silent=False):
        # Persist final refined metrics before the portable project is built.
        try:
            self._db_save_analysis_setting(final=True)
        except Exception:
            pass
        result = super().save_layers(silent=silent)
        try:
            self._refresh_zc_stats()
        except Exception:
            pass
        return result


_ZhuChenUnifiedReport_PreDatabase = ZhuChenUnifiedReport


class ZhuChenDatabaseReport(_ZhuChenUnifiedReport_PreDatabase):
    """Legacy report plus a compact one-row-per-image database table."""

    def apply_language(self):
        super().apply_language()
        if hasattr(self, "info_text"):
            self.info_text.set(self._t(
                "最终整体孔隙率 + 可选 ROI + Length/Width/Area + 标尺换算。\n"
                "同时额外输出 Database_Summary.xlsx / .csv：每张图一行，可直接并入当前实验数据库。",
                "Final overall porosity + optional ROI + Length/Width/Area + calibration.\n"
                "Also exports Database_Summary.xlsx / .csv with one row per image for direct database use."
            ))

    @staticmethod
    def _db_read_analysis_settings(root):
        p = Path(root) / "manual_measurements" / "analysis_settings.csv"
        out = {}
        if not p.exists():
            return out
        try:
            with p.open("r", newline="", encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    name = (r.get("image_name") or "").strip()
                    if name:
                        out[Path(name).stem] = r
        except Exception:
            pass
        return out

    @staticmethod
    def _db_float(row, key):
        try:
            v = row.get(key, "") if row else ""
            return float(v) if v not in (None, "") else None
        except Exception:
            return None

    def _db_database_rows(self, data):
        root = Path(data["root"])
        settings = self._db_read_analysis_settings(root)
        cal = data.get("calibration")
        upp = cal.get("unit_per_px") if cal else None
        unit = cal.get("unit", "") if cal else ""
        mby = data.get("measurement_by_stem", {})
        rows = []

        for d in data.get("images", []):
            stem = d["stem"]
            s = settings.get(stem, {})

            # Final component count is recomputed from saved scientific masks,
            # never trusted from the Step-3 first-pass counter.
            try:
                mask = Image.open(d["mask_path"]).convert("L").point(lambda x: 255 if x >= 128 else 0, mode="L")
            except Exception:
                mask = None
            region = None
            region_path = root / "manual_regions" / f"{stem}_region_mask.png"
            if region_path.exists():
                try:
                    region = Image.open(region_path).convert("L").point(lambda x: 255 if x >= 128 else 0, mode="L")
                except Exception:
                    region = None

            pore_count = _db_component_count(mask, region)
            image_pixels = (mask.width * mask.height) if mask is not None else None
            region_pixels = d.get("blue", {}).get("region_pixels")
            analysis_area_percent = (
                100.0 * region_pixels / image_pixels
                if image_pixels and region_pixels is not None else None
            )

            crop = self._db_float(s, "bottom_crop_percent")
            if crop is None and analysis_area_percent is not None:
                # Standardized Step-3 region spans full width from the top.
                crop = max(0.0, 100.0 - analysis_area_percent)

            mrows = mby.get(stem, [])
            areas = [r.get("value_px") for r in mrows if r.get("type") == "area" and r.get("value_px") is not None]
            mean_area = statistics.mean(areas) if areas else None
            sd_area = statistics.stdev(areas) if len(areas) >= 2 else None

            roi_n = len(d.get("roi_rows", []))
            rows.append({
                "image_name": stem,
                "bottom_crop_percent": crop,
                "analysis_area_percent": analysis_area_percent,
                "pore_region_count_final": pore_count,
                "overall_porosity_percent": d.get("blue", {}).get("porosity_percent"),
                "pore_sensitivity": self._db_float(s, "pore_sensitivity"),
                "diameter_min_px": self._db_float(s, "diameter_min_px"),
                "diameter_max_px": self._db_float(s, "diameter_max_px"),
                "n_length": len(d.get("length_rows", [])),
                "mean_length_px": d.get("mean_length_px"),
                "sd_length_px": d.get("sd_length_px"),
                "n_width": len(d.get("width_rows", [])),
                "mean_width_px": d.get("mean_width_px"),
                "sd_width_px": d.get("sd_width_px"),
                "length_over_width": d.get("ratio_from_means"),
                "n_area": len(areas),
                "mean_area_px2": mean_area,
                "sd_area_px2": sd_area,
                "mean_length_calibrated": d.get("mean_length_px") * upp if (upp is not None and d.get("mean_length_px") is not None) else None,
                "mean_width_calibrated": d.get("mean_width_px") * upp if (upp is not None and d.get("mean_width_px") is not None) else None,
                "mean_area_calibrated_sq": mean_area * (upp ** 2) if (upp is not None and mean_area is not None) else None,
                "calibration_unit": unit,
                "unit_per_px": upp,
                "roi_saved": 1 if roi_n else 0,
                "n_roi": roi_n,
                "roi_mean_porosity_percent": d.get("roi_mean"),
                "roi_sd_porosity_percent": d.get("roi_sd"),
            })
        return rows

    def _db_write_database_export(self, data, out_dir):
        rows = self._db_database_rows(data)
        if not rows:
            return None, None
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        csv_path = out_dir / "Database_Summary.csv"
        xlsx_path = out_dir / "Database_Summary.xlsx"
        headers = list(rows[0].keys())

        with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=headers)
            w.writeheader()
            w.writerows(rows)

        if Workbook is not None:
            wb = Workbook()
            ws = wb.active
            ws.title = "database_summary"
            ws.append(headers)
            for c in ws[1]:
                c.font = Font(bold=True)
            for row in rows:
                ws.append([row.get(h) for h in headers])
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            for col in ws.columns:
                letter = col[0].column_letter
                max_len = max(len(str(c.value)) if c.value is not None else 0 for c in col[:200])
                ws.column_dimensions[letter].width = min(max(max_len + 2, 11), 32)
            wb.save(xlsx_path)
        return xlsx_path, csv_path

    def generate_report(self):
        self._resolve_current_project()
        if self.project_root is None:
            return super().generate_report()

        # Capture data before the legacy success dialog optionally resets workspace.
        data = self._collect_data()
        base_before = self.output_root or self._default_report_root_v212() or (Path(self.project_root) / "final_report")
        base_before = Path(base_before)
        before_dirs = set(base_before.glob("Porosity_Report_*")) if base_before.exists() else set()

        result = super().generate_report()

        # Find the run folder created by the retained legacy report generator.
        run_dir = None
        try:
            candidates = [p for p in base_before.glob("Porosity_Report_*") if p.is_dir()]
            new_dirs = [p for p in candidates if p not in before_dirs]
            pool = new_dirs or candidates
            if pool:
                run_dir = max(pool, key=lambda p: p.stat().st_mtime)
        except Exception:
            run_dir = None
        if run_dir is None:
            run_dir = base_before

        try:
            xlsx_path, csv_path = self._db_write_database_export(data, run_dir)
            if xlsx_path or csv_path:
                self.status_var.set(self._t(
                    f"最终报告 + 数据库表已输出：{run_dir}",
                    f"Final report + database table exported: {run_dir}"
                ))
        except Exception as exc:
            messagebox.showwarning(
                self._t("数据库表输出失败", "Database export failed"),
                self._t(
                    f"传统最终报告已完成，但 Database_Summary 输出失败：\n\n{exc}",
                    f"The legacy final report completed, but Database_Summary export failed:\n\n{exc}"
                )
            )
        return result


# Rebind the runtime classes used inside ZhuChenUnifiedApp.__init__.
# The app's mature navigation, splash, drag/drop, Step 1/2, ROI and reset logic
# remain unchanged; only the annotator/report implementations are upgraded.
ZhuChenUnifiedAnnotator = ZhuChenDatabaseAnnotator
ZhuChenUnifiedReport = ZhuChenDatabaseReport


class ZhuChenDatabaseApp(ZhuChenUnifiedApp):
    def _refresh_title(self):
        labs = {
            'calibrate': ('① 标尺校准', '① Scale calibration'),
            'measure': ('② 尺寸 / 面积测量', '② Dimension / area measurement'),
            'auto': ('③ 底部裁剪 + 自动孔隙', '③ Bottom crop + automatic pores'),
            'refine': ('④ 人工精修 + 最终孔隙率', '④ Refinement + final porosity'),
            'roi': ('⑤ ROI 测试（可选保存）', '⑤ ROI analysis (optional save)'),
            'report': ('⑥ 数据输出', '⑥ Data export'),
        }
        self.title(f"逐尘 ZhuChen Database v3.0 — {self.tr(*labs.get(self.current_module, ('','')))}")

    def apply_language(self):
        super().apply_language()
        # Keep the same six buttons but make the database-specific Step 3/5/6 intent explicit.
        labs = {
            'calibrate': ('① 标尺校准', '① Scale calibration'),
            'measure': ('② 尺寸 / 面积测量', '② Dimension / area'),
            'auto': ('③ 裁底 / 自动孔隙', '③ Crop / auto pores'),
            'refine': ('④ 人工精修', '④ Refinement'),
            'roi': ('⑤ ROI 测试', '⑤ ROI analysis'),
            'report': ('⑥ 数据输出', '⑥ Data export'),
        }
        for k, b in self.stage_buttons.items():
            if k in labs:
                b.configure(text=self.tr(*labs[k]))
        self._refresh_title()



# =============================================================================
# v3.1 — persistent group ledger + no manual handoff-save gate + master report
# =============================================================================
import json as _v31_json


class ZhuChenPersistentROI(ZhuChenUnifiedROI):
    """
    ROI page for the database workflow.

    The old per-ROI export button is repurposed as a single-group COMMIT button.
    It does not create one Excel file per group. Instead it validates the current
    group and writes/updates one durable record in the session ledger. The final
    report later exports all committed groups together.
    """

    def __init__(self, parent, app):
        super().__init__(parent, app)
        try:
            self.export_btn.configure(command=self.save_current_group)
        except Exception:
            pass
        self.apply_language()

    def apply_language(self):
        try:
            super().apply_language()
        except Exception:
            pass
        try:
            self.export_btn.configure(
                text=self._t("保存本组（写入总表）", "Save current group (commit)"),
                command=self.save_current_group,
            )
        except Exception:
            pass

    def save_current_group(self):
        ok, info = self.app._v31_commit_current_group(
            require_complete=True,
            silent=False,
            source="manual_group_save",
        )
        if ok:
            try:
                self.status_var.set(self._t(
                    f"本组已强制留存到总表：{info}",
                    f"Current group committed to master ledger: {info}",
                ))
            except Exception:
                pass

    def remove_current_project(self):
        # Before unloading, preserve whatever currently exists. A complete group
        # becomes a normal committed record; an incomplete one is retained as a
        # draft so that removing the image cannot erase the work already done.
        try:
            if self.mask_path is not None:
                self.app._v31_commit_current_group(
                    require_complete=False,
                    silent=True,
                    source="auto_before_remove",
                )
        except Exception:
            pass
        return super().remove_current_project()

    def load_project_file(self, path: Path):
        # Switching directly to another project also preserves the previous one.
        try:
            if self.mask_path is not None and self.project_source_path is not None:
                old = Path(self.project_source_path)
                if Path(path) != old:
                    self.app._v31_commit_current_group(
                        require_complete=False,
                        silent=True,
                        source="auto_before_project_switch",
                    )
        except Exception:
            pass
        result = super().load_project_file(path)
        try:
            self.app._v31_load_ledger_if_available()
        except Exception:
            pass
        return result


class ZhuChenPersistentReport(ZhuChenDatabaseReport):
    """Final page driven by the durable multi-group ledger, not by one live image."""

    def apply_language(self):
        try:
            super().apply_language()
        except Exception:
            pass
        try:
            self.generate_btn.configure(
                text=self._t("输出全部报告", "Export all reports")
            )
        except Exception:
            pass
        try:
            self.info_text.set(self._t(
                "强制总表模式：每组在 ROI 完成后点击“保存本组（写入总表）”。\n"
                "总表固定保留 Length、Width、整体裁剪、最终整体孔隙率和全部已记录 ROI 孔隙率。"
                "删除当前图片不会删除已保存组；关闭软件时会自动再输出一份总报告。",
                "Mandatory master-ledger mode: after finishing ROI for a group, click Save current group.\n"
                "The master ledger keeps Length, Width, overall crop, final overall porosity and every recorded ROI porosity. "
                "Removing the current image does not delete committed data; closing the app automatically exports a master report."
            ))
        except Exception:
            pass

    def refresh_preview(self):
        try:
            self.app._v31_load_ledger_if_available()
            records = self.app._v31_sorted_records()
        except Exception:
            records = []

        try:
            if self.output_root is None:
                self.output_root = self.app._v31_report_root()
            self._refresh_path_label()
        except Exception:
            pass

        try:
            for item in self.tree.get_children():
                self.tree.delete(item)
        except Exception:
            return

        for r in records:
            tag = "" if r.get("status") == "complete" else " [草稿]"
            self.tree.insert("", tk.END, values=(
                f"{r.get('group_id','')}{tag}",
                "--" if r.get("overall_porosity_percent") is None else f"{r['overall_porosity_percent']:.4f}",
                int(r.get("n_roi", 0) or 0),
                "--" if r.get("roi_mean_porosity_percent") is None else f"{r['roi_mean_porosity_percent']:.4f}",
                int(r.get("n_length", 0) or 0),
                "--" if r.get("mean_length_px") is None else f"{r['mean_length_px']:.2f}",
                int(r.get("n_width", 0) or 0),
                "--" if r.get("mean_width_px") is None else f"{r['mean_width_px']:.2f}",
                "--" if r.get("length_over_width") is None else f"{r['length_over_width']:.3f}",
            ))

        n_complete = sum(1 for r in records if r.get("status") == "complete")
        n_draft = len(records) - n_complete
        try:
            self.status_var.set(self._t(
                f"总表已留存 {n_complete} 个完整组；草稿 {n_draft} 个。最终输出只把完整组写入主表，草稿单列保存。",
                f"Master ledger contains {n_complete} complete groups and {n_draft} drafts. Complete groups go to the main sheet; drafts are kept separately."
            ))
        except Exception:
            pass

    @staticmethod
    def _v31_style_sheet(ws):
        if ws.max_row >= 1:
            for c in ws[1]:
                c.font = Font(bold=True)
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
        for col in ws.columns:
            letter = col[0].column_letter
            max_len = 0
            for c in col[:250]:
                try:
                    max_len = max(max_len, len(str(c.value)) if c.value is not None else 0)
                except Exception:
                    pass
            ws.column_dimensions[letter].width = min(max(max_len + 2, 11), 34)

    def _v31_export_all(self, auto=False, silent=False):
        self.app._v31_load_ledger_if_available()
        records = self.app._v31_sorted_records()
        if not records:
            if not silent:
                messagebox.showwarning(
                    self._t("没有已留存数据", "No retained data"),
                    self._t("当前总表还没有任何组。", "The master ledger does not contain any groups yet."),
                )
            return None
        if Workbook is None:
            if not silent:
                messagebox.showerror("openpyxl", self._t("缺少 openpyxl。", "openpyxl is not available."))
            return None

        base = Path(self.output_root or self.app._v31_report_root())
        base.mkdir(parents=True, exist_ok=True)
        final_dir = base / "All_Reports"
        final_dir.mkdir(parents=True, exist_ok=True)
        stamp = _datetime.now().strftime("%Y%m%d_%H%M%S")
        prefix = "AUTO_ZhuChen_All" if auto else "ZhuChen_All"
        xlsx_path = final_dir / f"{prefix}_{stamp}.xlsx"
        csv_path = final_dir / f"{prefix}_{stamp}_Summary.csv"

        complete = [r for r in records if r.get("status") == "complete"]
        drafts = [r for r in records if r.get("status") != "complete"]

        summary_headers = [
            "sequence", "group_id", "source_image", "saved_at",
            "bottom_crop_percent", "analysis_region_pixels", "pore_pixels",
            "pore_region_count_final", "overall_porosity_percent",
            "n_length", "mean_length_px", "sd_length_px",
            "n_width", "mean_width_px", "sd_width_px", "length_over_width",
            "n_area", "mean_area_px2", "sd_area_px2",
            "roi_size_multiplier_n", "n_roi", "roi_mean_porosity_percent", "roi_sd_porosity_percent",
            "calibration_unit", "unit_per_px", "mean_length_calibrated", "mean_width_calibrated",
            "status",
        ]

        def summary_row(r):
            return {h: r.get(h) for h in summary_headers}

        with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=summary_headers)
            w.writeheader()
            for r in complete:
                w.writerow(summary_row(r))

        wb = Workbook()
        ws = wb.active
        ws.title = "Group_Summary"
        ws.append(summary_headers)
        for r in complete:
            rr = summary_row(r)
            ws.append([rr[h] for h in summary_headers])
        self._v31_style_sheet(ws)

        ws = wb.create_sheet("ROI_Details")
        roi_headers = [
            "sequence", "group_id", "roi_id", "x", "y", "length_px", "width_px",
            "pore_pixels", "roi_pixels", "porosity_percent",
        ]
        ws.append(roi_headers)
        for r in complete:
            for q in r.get("roi_records", []):
                ws.append([
                    r.get("sequence"), r.get("group_id"), q.get("roi_id"), q.get("x"), q.get("y"),
                    q.get("width"), q.get("height"), q.get("pore_pixels"), q.get("roi_pixels"),
                    q.get("porosity_percent"),
                ])
        self._v31_style_sheet(ws)

        for kind, sheet_name in (("length", "Length_Details"), ("width", "Width_Details"), ("area", "Area_Details")):
            ws = wb.create_sheet(sheet_name)
            headers = ["sequence", "group_id", "measurement_id", "value_px", "calibrated_value", "unit"]
            ws.append(headers)
            for r in complete:
                for m in r.get(f"{kind}_records", []):
                    ws.append([
                        r.get("sequence"), r.get("group_id"), m.get("id"), m.get("value_px"),
                        m.get("calibrated_value"), r.get("calibration_unit", ""),
                    ])
            self._v31_style_sheet(ws)

        ws = wb.create_sheet("Incomplete_Drafts")
        draft_headers = [
            "sequence", "group_id", "source_image", "saved_at", "missing_fields",
            "bottom_crop_percent", "overall_porosity_percent", "n_length", "n_width", "n_roi",
        ]
        ws.append(draft_headers)
        for r in drafts:
            ws.append([
                r.get("sequence"), r.get("group_id"), r.get("source_image"), r.get("saved_at"),
                ", ".join(r.get("missing_fields", [])), r.get("bottom_crop_percent"),
                r.get("overall_porosity_percent"), r.get("n_length"), r.get("n_width"), r.get("n_roi"),
            ])
        self._v31_style_sheet(ws)

        ws = wb.create_sheet("Session_Info")
        ws.append(["item", "value"])
        ws.append(["exported_at", _datetime.now().isoformat(timespec="seconds")])
        ws.append(["automatic_on_close", int(bool(auto))])
        ws.append(["complete_groups", len(complete)])
        ws.append(["draft_groups", len(drafts)])
        try:
            ws.append(["ledger_file", str(self.app._v31_ledger_path or "")])
        except Exception:
            pass
        self._v31_style_sheet(ws)

        wb.save(xlsx_path)
        self.app._v31_last_export_at = _datetime.now().isoformat(timespec="seconds")
        self.app._v31_last_export_path = str(xlsx_path)

        if not silent:
            self.status_var.set(self._t(
                f"全部报告已输出：{xlsx_path}",
                f"All reports exported: {xlsx_path}",
            ))
            messagebox.showinfo(
                self._t("输出完成", "Export complete"),
                self._t(
                    f"已一次性输出全部已留存组。\n\nExcel:\n{xlsx_path}\n\nSummary CSV:\n{csv_path}",
                    f"All retained groups were exported in one batch.\n\nExcel:\n{xlsx_path}\n\nSummary CSV:\n{csv_path}",
                ),
            )
        return xlsx_path

    def generate_report(self):
        return self._v31_export_all(auto=False, silent=False)


# Rebind before the application constructor creates its child frames.
ZhuChenUnifiedROI = ZhuChenPersistentROI
ZhuChenUnifiedReport = ZhuChenPersistentReport


class ZhuChenPersistentApp(ZhuChenDatabaseApp):
    """v3.1: durable per-group commits and one combined final report."""

    def __init__(self):
        self._v31_records = {}
        self._v31_ledger_path = None
        self._v31_source_root_cache = None
        self._v31_last_export_at = None
        self._v31_last_export_path = None
        super().__init__()
        self.title("逐尘 ZhuChen Database v3.1")
        self.protocol("WM_DELETE_WINDOW", self._v31_on_close)

    # ------------------------------------------------------------
    # Persistent ledger location / IO
    # ------------------------------------------------------------
    def _v31_detect_source_root(self):
        if self._v31_source_root_cache is not None:
            return Path(self._v31_source_root_cache)

        candidates = []
        try:
            if getattr(self.annotator, "_v212_source_folder", None):
                candidates.append(Path(self.annotator._v212_source_folder))
            if getattr(self.annotator, "input_folder", None):
                candidates.append(Path(self.annotator.input_folder))
        except Exception:
            pass
        try:
            p = getattr(self.roi_calc, "project_source_path", None)
            root = _v212_source_root_from_project(project_file=p)
            if root:
                candidates.append(Path(root))
        except Exception:
            pass
        try:
            root = _v212_source_root_from_project(project_root=getattr(self.roi_calc, "project_root", None))
            if root:
                candidates.append(Path(root))
        except Exception:
            pass

        for p in candidates:
            try:
                if p.name == _V212_WORK_FOLDER:
                    p = p.parent
                if p.exists():
                    self._v31_source_root_cache = p
                    return p
            except Exception:
                continue
        return None

    def _v31_report_root(self):
        source = self._v31_detect_source_root()
        if source is not None:
            root = Path(source) / _V212_REPORT_FOLDER
        else:
            try:
                out = getattr(self.report, "output_root", None)
                root = Path(out) if out else (Path.home() / _V212_REPORT_FOLDER)
            except Exception:
                root = Path.home() / _V212_REPORT_FOLDER
        root.mkdir(parents=True, exist_ok=True)
        return root

    def _v31_load_ledger_if_available(self):
        root = self._v31_report_root()
        path = root / "_session_data" / "ZhuChen_session_ledger.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        if self._v31_ledger_path is not None and Path(self._v31_ledger_path) == path:
            return

        self._v31_ledger_path = path
        loaded = {}
        if path.exists():
            try:
                obj = _v31_json.loads(path.read_text(encoding="utf-8"))
                for r in obj.get("records", []):
                    gid = str(r.get("group_id", "")).strip()
                    if gid:
                        loaded[gid] = r
            except Exception:
                loaded = {}

        # If this is the first known root, merge any current in-memory work.
        for gid, r in self._v31_records.items():
            old = loaded.get(gid)
            if old is None or int(r.get("sequence", 10**9)) <= int(old.get("sequence", 10**9)):
                loaded[gid] = r
        self._v31_records = loaded

    def _v31_save_ledger(self):
        self._v31_load_ledger_if_available()
        path = Path(self._v31_ledger_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": "3.1",
            "updated_at": _datetime.now().isoformat(timespec="seconds"),
            "records": self._v31_sorted_records(),
        }
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(_v31_json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)

    def _v31_sorted_records(self):
        return sorted(
            self._v31_records.values(),
            key=lambda r: (int(r.get("sequence", 10**9)), str(r.get("group_id", ""))),
        )

    # ------------------------------------------------------------
    # Snapshot one current group
    # ------------------------------------------------------------
    @staticmethod
    def _v31_stats(vals):
        vals = [float(v) for v in vals if v is not None]
        if not vals:
            return None, None
        mean = statistics.mean(vals)
        sd = statistics.stdev(vals) if len(vals) >= 2 else None
        return mean, sd

    def _v31_snapshot_current_group(self):
        roi = self.roi_calc
        if getattr(roi, "mask_path", None) is None or getattr(roi, "mask", None) is None:
            return None

        stem = roi._mask_base_stem()
        if not stem:
            return None
        project_root = Path(roi.project_root) if getattr(roi, "project_root", None) else None
        if project_root is None:
            return None

        # Measurements: raw values are preserved, not only averages.
        measurement_rows = []
        mpath = project_root / "manual_measurements" / "reference_measurements.csv"
        if mpath.exists():
            try:
                with mpath.open("r", newline="", encoding="utf-8-sig") as f:
                    for row in csv.DictReader(f):
                        image_name = row.get("image_name", "")
                        if Path(image_name).stem.lower() != stem.lower():
                            continue
                        try:
                            measurement_rows.append({
                                "type": row.get("type", ""),
                                "id": int(float(row.get("id", 0) or 0)),
                                "value_px": float(row.get("value_px", "nan")),
                            })
                        except Exception:
                            continue
            except Exception:
                measurement_rows = []

        cal = getattr(roi, "calibration", None) or {}
        upp = cal.get("unit_per_px")
        unit = cal.get("unit", "")
        try:
            upp = float(upp) if upp is not None else None
        except Exception:
            upp = None

        def pack_measure(kind):
            out = []
            for r in measurement_rows:
                if r.get("type") != kind:
                    continue
                v = r.get("value_px")
                out.append({
                    "id": r.get("id"),
                    "value_px": v,
                    "calibrated_value": (float(v) * upp) if (v is not None and upp is not None) else None,
                })
            return out

        length_records = pack_measure("length")
        width_records = pack_measure("width")
        area_records = pack_measure("area")
        lv = [r["value_px"] for r in length_records]
        wv = [r["value_px"] for r in width_records]
        av = [r["value_px"] for r in area_records]
        lm, lsd = self._v31_stats(lv)
        wm, wsd = self._v31_stats(wv)
        am, asd = self._v31_stats(av)
        ratio = (lm / wm) if (lm is not None and wm not in (None, 0)) else None

        # Final crop settings saved into the portable project by Step 4 silent handoff.
        settings = {}
        spath = project_root / "manual_measurements" / "analysis_settings.csv"
        if spath.exists():
            try:
                with spath.open("r", newline="", encoding="utf-8-sig") as f:
                    for row in csv.DictReader(f):
                        if Path(row.get("image_name", "")).stem.lower() == stem.lower():
                            settings = row
            except Exception:
                settings = {}

        def fnum(key):
            try:
                v = settings.get(key, "")
                return float(v) if v not in (None, "") else None
            except Exception:
                return None

        try:
            roi._load_region_for_current_mask()
        except Exception:
            pass
        rp = getattr(roi, "region_porosity", None) or {}
        overall = rp.get("porosity_percent")
        region_pixels = rp.get("region_pixels")
        pore_pixels = rp.get("pore_pixels")
        try:
            pore_count = _db_component_count(roi.mask, getattr(roi, "region_mask", None))
        except Exception:
            pore_count = None

        key = roi._current_image_key()
        roi_records = []
        if key:
            for q in roi.records_by_image.get(key, []):
                roi_records.append({
                    "roi_id": int(q.get("roi_id", len(roi_records) + 1)),
                    "x": int(q.get("x", 0)), "y": int(q.get("y", 0)),
                    "width": int(q.get("width", 0)), "height": int(q.get("height", 0)),
                    "pore_pixels": int(q.get("pore_pixels", 0)),
                    "roi_pixels": int(q.get("roi_pixels", 0)),
                    "porosity_percent": float(q.get("porosity_percent", 0.0)),
                })
        rv = [q["porosity_percent"] for q in roi_records]
        roi_mean, roi_sd = self._v31_stats(rv)

        try:
            roi_multiplier = int(round(float(roi.roi_n_var.get())))
        except Exception:
            roi_multiplier = None

        bottom_crop = fnum("bottom_crop_percent")
        # 0% is a valid formal crop setting. If the settings file is missing but
        # a valid full-width region exists, derive it from the region fraction.
        if bottom_crop is None and roi.mask is not None and region_pixels is not None:
            total = roi.mask.width * roi.mask.height
            if total > 0:
                bottom_crop = max(0.0, min(100.0, 100.0 - 100.0 * float(region_pixels) / float(total)))

        record = {
            "group_id": stem,
            "source_image": stem,
            "project_file": str(getattr(roi, "project_source_path", "") or ""),
            "saved_at": _datetime.now().isoformat(timespec="seconds"),
            "bottom_crop_percent": bottom_crop,
            "analysis_region_pixels": region_pixels,
            "pore_pixels": pore_pixels,
            "pore_region_count_final": pore_count,
            "overall_porosity_percent": overall,
            "n_length": len(length_records), "mean_length_px": lm, "sd_length_px": lsd,
            "n_width": len(width_records), "mean_width_px": wm, "sd_width_px": wsd,
            "length_over_width": ratio,
            "n_area": len(area_records), "mean_area_px2": am, "sd_area_px2": asd,
            "roi_size_multiplier_n": roi_multiplier,
            "n_roi": len(roi_records),
            "roi_mean_porosity_percent": roi_mean,
            "roi_sd_porosity_percent": roi_sd,
            "calibration_unit": unit,
            "unit_per_px": upp,
            "mean_length_calibrated": lm * upp if (lm is not None and upp is not None) else None,
            "mean_width_calibrated": wm * upp if (wm is not None and upp is not None) else None,
            "length_records": length_records,
            "width_records": width_records,
            "area_records": area_records,
            "roi_records": roi_records,
        }

        missing = []
        if len(length_records) < 1:
            missing.append("Length")
        if len(width_records) < 1:
            missing.append("Width")
        if bottom_crop is None:
            missing.append("Bottom crop")
        if overall is None:
            missing.append("Overall porosity")
        if len(roi_records) < 1:
            missing.append("ROI porosity records")
        record["missing_fields"] = missing
        record["status"] = "complete" if not missing else "draft_incomplete"
        return record

    def _v31_commit_current_group(self, require_complete=True, silent=False, source="manual"):
        rec = self._v31_snapshot_current_group()
        if rec is None:
            if not silent:
                messagebox.showwarning(
                    self.tr("没有当前 ROI 组", "No current ROI group"),
                    self.tr("请先进入 ROI 页面并完成当前组。", "Open the ROI page and finish the current group first."),
                )
            return False, ""

        missing = rec.get("missing_fields", [])
        if require_complete and missing:
            if not silent:
                messagebox.showwarning(
                    self.tr("本组数据未完成", "Current group is incomplete"),
                    self.tr(
                        "保存本组为强制完整记录，以下数据还缺失：\n\n- " + "\n- ".join(missing),
                        "Saving a group requires a complete record. Missing:\n\n- " + "\n- ".join(missing),
                    ),
                )
            return False, rec.get("group_id", "")

        self._v31_load_ledger_if_available()
        gid = rec["group_id"]
        old = self._v31_records.get(gid)
        if old is not None:
            rec["sequence"] = int(old.get("sequence", 1))
            # Never downgrade a previously complete record merely because an
            # incomplete view of the same group was auto-preserved later.
            if old.get("status") == "complete" and rec.get("status") != "complete":
                return True, gid
        else:
            seqs = [int(r.get("sequence", 0) or 0) for r in self._v31_records.values()]
            rec["sequence"] = (max(seqs) + 1) if seqs else 1

        rec["commit_source"] = source
        self._v31_records[gid] = rec
        self._v31_save_ledger()
        try:
            self.report.refresh_preview()
        except Exception:
            pass

        if not silent:
            messagebox.showinfo(
                self.tr("本组已保存", "Group saved"),
                self.tr(
                    f"{gid} 已写入持久总表。\n\n不会为这一组单独生成 Excel；最终在“输出全部报告”时一次性导出。",
                    f"{gid} was committed to the persistent master ledger.\n\nNo separate Excel is created for this group; use Export all reports for one combined output.",
                ),
            )
        return True, gid

    # ------------------------------------------------------------
    # Navigation: no visible Save gate between Step 3/4 and ROI
    # ------------------------------------------------------------
    def show_module(self, which):
        cur = getattr(self, "current_module", None)
        ann = getattr(self, "annotator", None)

        if which == "roi" and ann is not None and ann.image_path is not None and cur in ("auto", "refine"):
            # Silent internal handoff. The user no longer has to press Step-4 Save.
            try:
                ann.save_layers(silent=True)
                p = getattr(ann, "last_saved_project_path_v212", None)
                if p and Path(p).exists():
                    if (
                        self.roi_calc.project_source_path is None
                        or Path(self.roi_calc.project_source_path) != Path(p)
                    ):
                        self.roi_calc.load_project_file(Path(p))
                    self._s4 = True
                else:
                    messagebox.showwarning(
                        self.tr("无法进入 ROI", "Cannot enter ROI"),
                        self.tr("当前孔隙结果无法建立内部中转项目。请检查当前图像/孔隙结果。",
                                "The internal transfer project could not be created. Check the current image/pore result."),
                    )
                    return
            except Exception as exc:
                messagebox.showerror(
                    self.tr("内部保存失败", "Internal handoff failed"),
                    str(exc),
                )
                return

        result = super().show_module(which)
        try:
            self._v31_load_ledger_if_available()
        except Exception:
            pass
        return result

    # ------------------------------------------------------------
    # Close: retain current work and automatically export one master report
    # ------------------------------------------------------------
    def _v31_on_close(self):
        try:
            # If ROI currently has a group, retain it. Complete records become
            # normal groups; incomplete work is preserved as a draft.
            if getattr(self.roi_calc, "mask_path", None) is not None:
                self._v31_commit_current_group(
                    require_complete=False,
                    silent=True,
                    source="auto_on_close",
                )
        except Exception:
            pass

        try:
            if self._v31_records:
                self.report._v31_export_all(auto=True, silent=True)
        except Exception:
            # Closing must never be blocked by an export failure; the JSON ledger
            # has already been written on each group commit.
            pass

        try:
            self.destroy()
        except Exception:
            raise SystemExit



# =============================================================================
# ZHUCHEN CURRENT-DATA EDITION v3.2
# Purpose: keep the mature six-step database workflow, but make Step-2 geometry
# measurements optional for ROI sizing. Step 5 uses one of three fixed physical
# ROI templates derived only from the Step-1 scale calibration.
#
# Fixed ROI templates:
#   P=0.43 mm -> 0.86 mm x 0.40 mm -> 0.344 mm^2
#   P=0.45 mm -> 0.90 mm x 0.40 mm -> 0.360 mm^2
#   P=0.47 mm -> 0.94 mm x 0.40 mm -> 0.376 mm^2
#
# Step 2 Length/Width/Area remain available as optional measurements and are still
# exported when present, but they are no longer required to generate or commit ROI.
# =============================================================================

_ZC_CURRENT_BASE_ANNOTATOR = ZhuChenUnifiedAnnotator


class ZhuChenCurrentDataAnnotator(_ZC_CURRENT_BASE_ANNOTATOR):
    """Database annotator with the mature Step-2 contrast control also visible in Step 3."""

    def set_workspace(self, which):
        result = super().set_workspace(which)
        try:
            # Step 2 keeps its original contrast bar. Step 3 now exposes the same
            # display-only contrast control for easier pore inspection. It does not
            # alter the scientific masks or raw source pixels.
            if which == 'auto':
                self.contrast_frame.pack_forget()
                self.contrast_frame.pack(side=tk.LEFT, padx=(4, 2))
            elif which not in ('measure',):
                self.contrast_frame.pack_forget()
        except Exception:
            pass
        try:
            self._refresh_stage_hint()
        except Exception:
            pass
        return result

    def _refresh_stage_hint(self):
        if getattr(self, 'workspace', None) == 'auto' and hasattr(self, 'stage_hint_var'):
            self.stage_hint_var.set(self._t(
                'Step 3 / 6 · 可调显示对比度 → 设定底部裁剪 → 一键生成；对比度只辅助观察，不直接改写原图/Mask',
                'Step 3 / 6 · Adjust display contrast → set bottom crop → One-click pores; contrast is display-only and does not rewrite source pixels/masks'
            ))
            return
        return super()._refresh_stage_hint()


_ZC_CURRENT_BASE_ROI = ZhuChenPersistentROI


class ZhuChenTemplateROI(_ZC_CURRENT_BASE_ROI):
    """Step-5 ROI driven by three fixed physical templates and Step-1 calibration only."""

    ROI_TEMPLATES = {
        '0.43': {'p_mm': 0.43, 'height_mm': 0.40, 'length_mm': 0.86, 'area_mm2': 0.344},
        '0.45': {'p_mm': 0.45, 'height_mm': 0.40, 'length_mm': 0.90, 'area_mm2': 0.360},
        '0.47': {'p_mm': 0.47, 'height_mm': 0.40, 'length_mm': 0.94, 'area_mm2': 0.376},
    }

    def __init__(self, parent, app):
        self.roi_template_var = tk.StringVar(value='0.43')
        self.roi_template_info_var = tk.StringVar(value='')
        super().__init__(parent, app)

        # Hide the v2.12 N-multiplier / measurement-derived ROI sizing controls.
        for name in (
            'ref_label', 'roi_n_label', 'roi_n_entry',
            'roi_length_label', 'roi_length_entry',
            'roi_width_label', 'roi_width_entry', 'ratio_btn'
        ):
            try:
                getattr(self, name).pack_forget()
            except Exception:
                pass

        # Keep compatibility variables alive for old report/project paths, but they
        # no longer govern the ROI dimensions.
        try:
            self.roi_n_var.set('0')
        except Exception:
            pass

        host = self.generate_btn.master
        self.roi_template_label = ttk.Label(host)
        self.roi_template_label.pack(side=tk.LEFT, before=self.generate_btn, padx=(2, 3))

        self.roi_template_combo = ttk.Combobox(
            host,
            textvariable=self.roi_template_var,
            values=('0.43', '0.45', '0.47'),
            state='readonly',
            width=7,
        )
        self.roi_template_combo.pack(side=tk.LEFT, before=self.generate_btn, padx=(0, 5))
        self.roi_template_combo.bind('<<ComboboxSelected>>', self._on_template_changed)

        self.roi_template_info = ttk.Label(
            host,
            textvariable=self.roi_template_info_var,
            font=('Segoe UI', 9, 'bold')
        )
        self.roi_template_info.pack(side=tk.LEFT, before=self.generate_btn, padx=(0, 8))

        try:
            self._tooltips.append(_HoverTip(
                self.roi_template_combo,
                lambda: self._t(
                    '固定 ROI 模板。尺寸只由第一页标尺校准换算为像素，不再依赖第二页 Length/Width。',
                    'Fixed ROI template. Pixel dimensions are derived only from Step-1 scale calibration and no longer depend on Step-2 Length/Width.'
                )
            ))
        except Exception:
            pass

        self._load_reference_stats()
        self._refresh_template_info()
        self.apply_language()

    # -----------------------------------------------------------------
    # Legacy N/ratio routes are intentionally disabled for this edition.
    # -----------------------------------------------------------------
    def _v212_sync_roi_from_n(self):
        return

    def _sync_roi_height_from_ratio(self):
        return

    def _load_reference_stats(self):
        # Step-2 measurements remain available and exported, but they are optional
        # and never drive the ROI geometry in this edition.
        self.ref_mean_length = None
        self.ref_mean_width = None
        self.ref_ratio = None
        self.ref_n_length = 0
        self.ref_n_width = 0
        try:
            self.ref_summary_var.set(self._t(
                '第二步长宽/面积：可选，不参与 ROI 尺寸',
                'Step-2 length/width/area: optional; not used for ROI sizing'
            ))
        except Exception:
            pass

    # -----------------------------------------------------------------
    # Physical template -> calibrated pixel dimensions
    # -----------------------------------------------------------------
    def _selected_template(self):
        key = (self.roi_template_var.get() or '0.43').strip()
        return self.ROI_TEMPLATES.get(key, self.ROI_TEMPLATES['0.43'])

    @staticmethod
    def _unit_to_mm_factor(unit):
        u = str(unit or '').strip().lower().replace('μ', 'µ')
        factors = {
            'mm': 1.0,
            'cm': 10.0,
            'µm': 1e-3,
            'um': 1e-3,
            'nm': 1e-6,
        }
        return factors.get(u)

    def _mm_per_px(self):
        if not getattr(self, 'calibration', None):
            try:
                self._load_calibration_from_root()
            except Exception:
                pass
        c = getattr(self, 'calibration', None)
        if not c:
            return None
        try:
            upp = float(c.get('unit_per_px'))
        except Exception:
            return None
        factor = self._unit_to_mm_factor(c.get('unit'))
        if factor is None or upp <= 0:
            return None
        return upp * factor

    def _template_pixel_size(self):
        t = self._selected_template()
        mm_per_px = self._mm_per_px()
        if mm_per_px is None or mm_per_px <= 0:
            return None
        w = max(1, int(round(float(t['length_mm']) / mm_per_px)))
        h = max(1, int(round(float(t['height_mm']) / mm_per_px)))
        return w, h, mm_per_px

    def _refresh_template_info(self):
        t = self._selected_template()
        px = self._template_pixel_size()
        if px is None:
            self.roi_template_info_var.set(self._t(
                f"{t['length_mm']:.2f} × {t['height_mm']:.2f} mm · {t['area_mm2']:.3f} mm² · 等待标尺",
                f"{t['length_mm']:.2f} × {t['height_mm']:.2f} mm · {t['area_mm2']:.3f} mm² · scale required"
            ))
            return
        w, h, _ = px
        self.roi_w_var.set(str(w))
        self.roi_h_var.set(str(h))
        self.roi_template_info_var.set(self._t(
            f"{t['length_mm']:.2f} × {t['height_mm']:.2f} mm · {t['area_mm2']:.3f} mm² · {w} × {h} px",
            f"{t['length_mm']:.2f} × {t['height_mm']:.2f} mm · {t['area_mm2']:.3f} mm² · {w} × {h} px"
        ))

    def _on_template_changed(self, event=None):
        self._refresh_template_info()
        t = self._selected_template()
        try:
            self.status_var.set(self._t(
                f"已选择固定模板：P={t['p_mm']:.2f} mm；点击“生成 ROI”应用。",
                f"Fixed template selected: P={t['p_mm']:.2f} mm; click Generate ROI to apply."
            ))
        except Exception:
            pass

    def apply_language(self):
        super().apply_language()
        if hasattr(self, 'roi_template_label'):
            self.roi_template_label.configure(text=self._t('中心距 P / mm:', 'Center distance P / mm:'))
            try:
                self.generate_btn.configure(text=self._t('生成固定 ROI', 'Generate fixed ROI'))
            except Exception:
                pass
            self._refresh_template_info()

    def generate_roi(self):
        if self.mask is None:
            messagebox.showwarning(
                self._t('没有数据', 'No data'),
                self._t('请先打开 .poreproj。', 'Open a .poreproj first.')
            )
            return

        px = self._template_pixel_size()
        if px is None:
            messagebox.showwarning(
                self._t('需要标尺校准', 'Scale calibration required'),
                self._t(
                    '固定 ROI 使用真实物理尺寸，必须先完成第一页标尺校准。\n\n第二页 Length / Width 不需要测量。',
                    'The fixed ROI uses physical dimensions, so Step-1 scale calibration is required.\n\nStep-2 Length / Width measurements are not required.'
                )
            )
            return

        w, h, mm_per_px = px
        if w > self.img_w or h > self.img_h:
            t = self._selected_template()
            messagebox.showerror(
                self._t('ROI 太大', 'ROI too large'),
                self._t(
                    f"模板 P={t['p_mm']:.2f} mm 换算后为 {w} × {h} px，超过当前图片 {self.img_w} × {self.img_h} px。",
                    f"Template P={t['p_mm']:.2f} mm converts to {w} × {h} px, larger than the current image {self.img_w} × {self.img_h} px."
                )
            )
            return

        self.roi_w_var.set(str(w))
        self.roi_h_var.set(str(h))
        self.roi = [(self.img_w - w)//2, (self.img_h - h)//2, w, h]
        self.update_live_roi()
        self.render()
        t = self._selected_template()
        self.status_var.set(self._t(
            f"已生成固定 ROI：P={t['p_mm']:.2f} mm；{t['length_mm']:.2f} × {t['height_mm']:.2f} mm = {w} × {h} px。",
            f"Fixed ROI generated: P={t['p_mm']:.2f} mm; {t['length_mm']:.2f} × {t['height_mm']:.2f} mm = {w} × {h} px."
        ))

    def load_project_file(self, path: Path):
        result = super().load_project_file(path)
        try:
            self.roi_n_var.set('0')
        except Exception:
            pass
        self._load_reference_stats()
        self._refresh_template_info()
        return result

    def refresh_stage_state(self):
        result = super().refresh_stage_state()
        self._load_reference_stats()
        self._refresh_template_info()
        return result

    def remove_current_project(self):
        result = super().remove_current_project()
        try:
            self.roi_n_var.set('0')
        except Exception:
            pass
        self.roi_template_var.set('0.43')
        self._load_reference_stats()
        self._refresh_template_info()
        return result

    def selected_template_metadata(self):
        t = dict(self._selected_template())
        px = self._template_pixel_size()
        if px is not None:
            t['length_px'] = int(px[0])
            t['height_px'] = int(px[1])
            t['mm_per_px'] = float(px[2])
        else:
            t['length_px'] = None
            t['height_px'] = None
            t['mm_per_px'] = None
        return t


_ZC_CURRENT_BASE_REPORT = ZhuChenPersistentReport


class ZhuChenCurrentDataReport(_ZC_CURRENT_BASE_REPORT):
    """Keep the v3.1 master report and append the selected fixed-ROI template metadata."""

    def _v31_export_all(self, auto=False, silent=False):
        xlsx_path = super()._v31_export_all(auto=auto, silent=silent)
        if not xlsx_path:
            return xlsx_path

        # The parent export is intentionally preserved. We only append four
        # traceability columns so the physical ROI template is never lost.
        try:
            from openpyxl import load_workbook
            path = Path(xlsx_path)
            records = [r for r in self.app._v31_sorted_records() if r.get('status') == 'complete']
            by_gid = {str(r.get('group_id', '')): r for r in records}
            extra = [
                'roi_template_p_mm', 'roi_template_height_mm',
                'roi_template_length_mm', 'roi_template_area_mm2'
            ]

            wb = load_workbook(path)
            if 'Group_Summary' in wb.sheetnames:
                ws = wb['Group_Summary']
                headers = [c.value for c in ws[1]]
                for h in extra:
                    if h not in headers:
                        ws.cell(row=1, column=ws.max_column + 1, value=h)
                        headers.append(h)
                idx = {h: headers.index(h) + 1 for h in extra}
                gid_col = headers.index('group_id') + 1 if 'group_id' in headers else 2
                for row in range(2, ws.max_row + 1):
                    gid = str(ws.cell(row=row, column=gid_col).value or '')
                    rec = by_gid.get(gid, {})
                    for h in extra:
                        ws.cell(row=row, column=idx[h], value=rec.get(h))
                self._v31_style_sheet(ws)

            if 'ROI_Details' in wb.sheetnames:
                ws = wb['ROI_Details']
                headers = [c.value for c in ws[1]]
                for h in extra:
                    if h not in headers:
                        ws.cell(row=1, column=ws.max_column + 1, value=h)
                        headers.append(h)
                idx = {h: headers.index(h) + 1 for h in extra}
                gid_col = headers.index('group_id') + 1 if 'group_id' in headers else 2
                for row in range(2, ws.max_row + 1):
                    gid = str(ws.cell(row=row, column=gid_col).value or '')
                    rec = by_gid.get(gid, {})
                    for h in extra:
                        ws.cell(row=row, column=idx[h], value=rec.get(h))
                self._v31_style_sheet(ws)

            wb.save(path)

            csv_path = path.with_name(path.stem + '_Summary.csv')
            if csv_path.exists():
                with csv_path.open('r', newline='', encoding='utf-8-sig') as f:
                    rows = list(csv.DictReader(f))
                    headers = list(rows[0].keys()) if rows else []
                for h in extra:
                    if h not in headers:
                        headers.append(h)
                for r in rows:
                    rec = by_gid.get(str(r.get('group_id', '')), {})
                    for h in extra:
                        r[h] = rec.get(h)
                with csv_path.open('w', newline='', encoding='utf-8-sig') as f:
                    w = csv.DictWriter(f, fieldnames=headers)
                    w.writeheader()
                    w.writerows(rows)
        except Exception:
            # Template metadata enrichment must never invalidate the retained
            # v3.1 report that has already been produced successfully.
            pass

        return xlsx_path


# Rebind runtime classes before the final application is instantiated.
ZhuChenUnifiedAnnotator = ZhuChenCurrentDataAnnotator
ZhuChenUnifiedROI = ZhuChenTemplateROI
ZhuChenUnifiedReport = ZhuChenCurrentDataReport


class ZhuChenCurrentDataApp(ZhuChenPersistentApp):
    """v3.2 current experiment edition: optional Step-2 measurements + calibrated fixed ROI templates."""

    def __init__(self):
        super().__init__()
        self.title('逐尘 ZhuChen Current Data v3.2')

    def _refresh_title(self):
        labs = {
            'calibrate': ('① 标尺校准', '① Scale calibration'),
            'measure': ('② 尺寸 / 面积测量（可选）', '② Dimension / area (optional)'),
            'auto': ('③ 对比度 + 裁底 / 自动孔隙', '③ Contrast + crop / auto pores'),
            'refine': ('④ 人工精修', '④ Refinement'),
            'roi': ('⑤ 固定模板 ROI', '⑤ Fixed-template ROI'),
            'report': ('⑥ 数据输出', '⑥ Data export'),
        }
        self.title(f"逐尘 ZhuChen Current Data v3.2 — {self.tr(*labs.get(self.current_module, ('','')))}")

    def apply_language(self):
        super().apply_language()
        labs = {
            'calibrate': ('① 标尺校准', '① Scale calibration'),
            'measure': ('② 尺寸 / 面积测量（可选）', '② Dimension / area (optional)'),
            'auto': ('③ 对比度 + 裁底 / 自动孔隙', '③ Contrast + crop / auto pores'),
            'refine': ('④ 人工精修', '④ Refinement'),
            'roi': ('⑤ 固定模板 ROI', '⑤ Fixed-template ROI'),
            'report': ('⑥ 数据输出', '⑥ Data export'),
        }
        for k, b in getattr(self, 'stage_buttons', {}).items():
            if k in labs:
                try:
                    b.configure(text=self.tr(*labs[k]))
                except Exception:
                    pass
        if self.current_module:
            self._refresh_title()

    def _v31_snapshot_current_group(self):
        rec = super()._v31_snapshot_current_group()
        if rec is None:
            return None

        # Step-2 length/width/area are optional in this edition. They remain in
        # the record whenever measured, but their absence never blocks a group.
        missing = [m for m in rec.get('missing_fields', []) if m not in ('Length', 'Width')]
        rec['missing_fields'] = missing
        rec['status'] = 'complete' if not missing else 'draft_incomplete'
        rec['roi_size_multiplier_n'] = None

        try:
            t = self.roi_calc.selected_template_metadata()
            rec['roi_template_p_mm'] = t.get('p_mm')
            rec['roi_template_height_mm'] = t.get('height_mm')
            rec['roi_template_length_mm'] = t.get('length_mm')
            rec['roi_template_area_mm2'] = t.get('area_mm2')
            rec['roi_template_length_px'] = t.get('length_px')
            rec['roi_template_height_px'] = t.get('height_px')
            rec['roi_template_mm_per_px'] = t.get('mm_per_px')
        except Exception:
            rec['roi_template_p_mm'] = None
            rec['roi_template_height_mm'] = None
            rec['roi_template_length_mm'] = None
            rec['roi_template_area_mm2'] = None
            rec['roi_template_length_px'] = None
            rec['roi_template_height_px'] = None
            rec['roi_template_mm_per_px'] = None

        return rec



# =============================================================================
# ZHUCHEN CURRENT-DATA EDITION v3.3
# Changes from v3.2:
#   1) Step-5 ROI opens on source image + red pore overlay by default when the
#      source image is available, instead of the legacy white result layer.
#   2) Legacy Length/Width requirement text is removed from the empty-ROI hint.
#   3) ROI physical height is selectable: 0.40 mm or 0.50 mm.
#      P still selects the fixed physical ROI length: 0.86 / 0.90 / 0.94 mm.
#      Pixel W/H are always derived from Step-1 scale calibration only.
# Everything else remains inherited from v3.2 / v3.1.
# =============================================================================

_ZC_V33_BASE_ROI = ZhuChenTemplateROI


class ZhuChenTemplateROIV33(_ZC_V33_BASE_ROI):
    """Fixed-P ROI with selectable physical height (0.40 / 0.50 mm)."""

    ROI_HEIGHTS_MM = (0.40, 0.50)

    def __init__(self, parent, app):
        # During the parent constructor, _selected_template() may already be
        # called. Keep a plain fallback value until the Tk variable is created.
        self._v33_height_mm = 0.40
        super().__init__(parent, app)

        self.roi_height_mm_var = tk.StringVar(master=self, value='0.40')
        host = self.generate_btn.master

        self.roi_height_label = ttk.Label(host)
        self.roi_height_label.pack(
            side=tk.LEFT, before=self.roi_template_info, padx=(2, 3)
        )

        self.roi_height_combo = ttk.Combobox(
            host,
            textvariable=self.roi_height_mm_var,
            values=('0.40', '0.50'),
            state='readonly',
            width=6,
        )
        self.roi_height_combo.pack(
            side=tk.LEFT, before=self.roi_template_info, padx=(0, 6)
        )
        self.roi_height_combo.bind('<<ComboboxSelected>>', self._on_height_changed)

        try:
            self._tooltips.append(_HoverTip(
                self.roi_height_combo,
                lambda: self._t(
                    'ROI 物理高度：0.40 mm 或 0.50 mm。像素高度只由第一页标尺校准换算，不依赖第二页 Length/Width。',
                    'Physical ROI height: 0.40 mm or 0.50 mm. Pixel height is derived only from Step-1 scale calibration and does not depend on Step-2 Length/Width.'
                )
            ))
        except Exception:
            pass

        self._refresh_template_info()
        self.apply_language()

    # -----------------------------------------------------------------
    # P determines physical length; height is an independent 0.40/0.50 choice.
    # -----------------------------------------------------------------
    def _selected_height_mm(self):
        try:
            value = float(self.roi_height_mm_var.get())
        except Exception:
            value = float(getattr(self, '_v33_height_mm', 0.40))
        return 0.50 if abs(value - 0.50) < abs(value - 0.40) else 0.40

    def _selected_template(self):
        key = (self.roi_template_var.get() or '0.43').strip()
        base = self.ROI_TEMPLATES.get(key, self.ROI_TEMPLATES['0.43'])
        height = self._selected_height_mm()
        length = float(base['length_mm'])
        return {
            'p_mm': float(base['p_mm']),
            'height_mm': float(height),
            'length_mm': length,
            'area_mm2': length * float(height),
        }

    def _on_height_changed(self, event=None):
        self._v33_height_mm = self._selected_height_mm()
        self._refresh_template_info()
        t = self._selected_template()
        try:
            self.status_var.set(self._t(
                f"已选择 ROI 高度 {t['height_mm']:.2f} mm；P={t['p_mm']:.2f} mm；点击“生成固定 ROI”应用。",
                f"ROI height {t['height_mm']:.2f} mm selected; P={t['p_mm']:.2f} mm; click Generate fixed ROI to apply."
            ))
        except Exception:
            pass

    def apply_language(self):
        super().apply_language()
        if hasattr(self, 'roi_height_label'):
            self.roi_height_label.configure(text=self._t('ROI 高 / mm:', 'ROI height / mm:'))
            self._refresh_template_info()

    # -----------------------------------------------------------------
    # ROI page display fix: prefer source image + red mask, not white layer.
    # -----------------------------------------------------------------
    def _v33_show_source_by_default(self):
        if self.mask is None:
            return
        if self.original_rgb is None:
            try:
                self._load_source_original()
            except Exception:
                pass

        if self.original_rgb is not None:
            self.roi_show_original = True
            try:
                self.roi_original_btn_text.set(self._t('只看结果层', 'Result layer only'))
            except Exception:
                pass
            self._refresh_roi_display_from_original()
        else:
            # Source is genuinely unavailable: retain the legacy result layer.
            self.roi_show_original = False
            self.display_rgb = self.layer_rgb
            try:
                self.roi_original_btn_text.set(self._t('显示原图', 'Show original'))
            except Exception:
                pass
            self.render()

    def load_mask(self, path: Path):
        result = super().load_mask(path)
        self._v33_show_source_by_default()
        self.update_live_roi()
        return result

    def toggle_roi_original(self):
        if self.mask is None:
            return

        if self.roi_show_original:
            self.roi_show_original = False
            self.display_rgb = self.layer_rgb
            self.roi_original_btn_text.set(self._t('显示原图', 'Show original'))
            self.render()
            return

        if self.original_rgb is None:
            try:
                self._load_source_original()
            except Exception:
                pass
        if self.original_rgb is None:
            messagebox.showinfo(
                self._t('未找到原图', 'Source image not found'),
                self._t(
                    '没有找到与当前 Mask 对应的原图；当前只能显示结果层。',
                    'No source image matching the current mask was found; only the result layer can be shown.'
                )
            )
            return

        self.roi_show_original = True
        self.roi_original_btn_text.set(self._t('只看结果层', 'Result layer only'))
        self._refresh_roi_display_from_original()

    def update_live_roi(self):
        result = self.calculate_current_roi()
        if result is None:
            self.current_text.set(self._t(
                '尚未生成 ROI\n\n请选择中心距 P 与 ROI 高度，然后点击“生成固定 ROI”。',
                'No ROI yet\n\nChoose center distance P and ROI height, then click Generate fixed ROI.'
            ))
            self.porosity_big.set('Porosity: --')
            return

        self.current_text.set(
            f"Width = {result['width']} px\n"
            f"Height = {result['height']} px\n\n"
            f"Pore pixels = {result['pore_pixels']:,}\n"
            f"ROI pixels = {result['roi_pixels']:,}"
        )
        self.porosity_big.set(f"Porosity: {result['porosity_percent']:.4f} %")

    def remove_current_project(self):
        result = super().remove_current_project()
        self._v33_height_mm = 0.40
        try:
            self.roi_height_mm_var.set('0.40')
        except Exception:
            pass
        self._refresh_template_info()
        return result


# Rebind only the Step-5 ROI implementation. Annotator/report remain v3.2.
ZhuChenUnifiedROI = ZhuChenTemplateROIV33


class ZhuChenCurrentDataAppV33(ZhuChenCurrentDataApp):
    """v3.3: default source-overlay ROI view + selectable 0.40/0.50 mm ROI height."""

    def __init__(self):
        super().__init__()
        self.title('逐尘 ZhuChen Current Data v3.3')

    def _refresh_title(self):
        labs = {
            'calibrate': ('① 标尺校准', '① Scale calibration'),
            'measure': ('② 尺寸 / 面积测量（可选）', '② Dimension / area (optional)'),
            'auto': ('③ 对比度 + 裁底 / 自动孔隙', '③ Contrast + crop / auto pores'),
            'refine': ('④ 人工精修', '④ Refinement'),
            'roi': ('⑤ 固定模板 ROI', '⑤ Fixed-template ROI'),
            'report': ('⑥ 数据输出', '⑥ Data export'),
        }
        self.title(f"逐尘 ZhuChen Current Data v3.3 — {self.tr(*labs.get(self.current_module, ('','')))}")


if __name__=='__main__':
    app=ZhuChenCurrentDataAppV33(); app.mainloop()
