# ELECTRE Tri-nC — CNPW external application evidence package

## Scope

This package supports the claims actually reported for this published decision system in Results 2.3 and Table 1. It is **not** intended to reproduce every possible CNPW Mode-A, Mode-B, Stage-2, QCCA or relaxation branch. The evidential standard is claim-specific: each manuscript claim is linked to the frozen/reconstructed candidate–response evidence and to the supplied calculation or audit that supports it.

## Source system

- **Domain:** Healthcare
- **Candidate–response size:** 20 × 12
- **Source citation:** Alves & Pereira (2025), Enhancing clinical and non-clinical risk management: A case study using ELECTRE Tri-nC, Health Care Management Science 28, 824–841
- **Native decision object:** Outranking-based categorical assignment

## Manuscript-claim verification

| ID | Claim | Verified result | Verification route |
|---|---|---|---|
| ELE-1 | Candidate space size | **20 × 12** | Direct published-matrix reconstruction |
| ELE-2 | Highest native category under CNPW mapping | **9 candidates: 1 GL1, 5 GL2, 3 GL3** | Direct category-to-qualification audit |
| ELE-3 | CNPW result | **C(J)=GL3; 20 → 3 → 1; terminal Q3 2019** | Direct supplied execution record |
| ELE-4 | Single-response recovery | **Removing g8 raises GL3 → GL4** | Leave-one-out subset audit |

The machine-readable version is `CLAIM_LEDGER.csv`.

## Included source/reconstruction evidence

- `217-ELECTRE_Tri-nC_Healthcare_CNPW_CrossDomain_Validation_v1.5.2_217Standard.md`
- `218-ELECTRE_Tri-nC_vs_CNPW_Methodology_Comparison_v1.5.2_218Standard.md`
- `Case02_ELECTRE_CNPW_Temporal_Qualification_Trajectory.csv`

## Derived claim-specific audits

- `ELECTRE_Frozen_20x12.csv`
- `ELECTRE_Headline_Audit.csv`

Derived audits do not introduce a new decision method. They expose the exact arithmetic or frozen-level comparison needed to verify manuscript headline claims from the supplied evidence.

## Claim boundary

CNPW retains the published 20×12 matrix and does not reinterpret ELECTRE category membership as CNPW optimality.

## Interpretation

CNPW is applied as an additional qualification and candidate-space diagnostic layer. A difference between the native decision and the CNPW output is not treated as proof that the native method is incorrect; it shows that the native decision object and joint qualification answer different questions. Where the candidate space is top-compatible, the package retains that positive-control result rather than forcing a limitation diagnosis.

## Status

**CLAIM-SPECIFIC EVIDENCE COMPLETE FOR THE CURRENT MANUSCRIPT/TABLE-1 CLAIMS.**
