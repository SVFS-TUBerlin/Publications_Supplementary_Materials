#!/usr/bin/env python3
"""Reproduce the *final* process–porosity–property models reported in the manuscript.

Inputs are specimen-level experimental measurements exported without rounding:
  raw_measurements_101.csv
Outputs in ./results/: metrics, fold predictions, fitted coefficients, report.

No measured porosity from held-out conditions is supplied to PPP prediction.
Each LOOCV fold refits all upstream and downstream models using 26 condition means.
The four validation conditions V1-V4 are excluded from all coefficient fitting.
"""
import csv
import json
import math
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
INPUT = HERE / 'raw_measurements_101.csv'
OUT = HERE / 'results'
DENSITY = 1.24 # g/cm3
LENGTH = 180.0 # mm
K = 100.0 * (1.0 - math.pi/4.0)
SPEEDS = np.array([20.,70.,120.])
HEIGHTS = np.array([.10,.20,.25])


def read_specimens():
    with INPUT.open('r',encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    assert len(rows)==101, f'Expected 101 specimens, got {len(rows)}'
    raw=[]
    for r in rows:
        d={name:float(r[name]) for name in ('h_mm','P_mm','v_mm_s','mass_g','area_mm2','stiffness_N','max_force_N')}
        d['condition']=r['condition']; d['replicate']=int(r['replicate']);d['set']=r['set']
        d['phi']=100*(1-1000*d['mass_g']/(DENSITY*d['area_mm2']*LENGTH))
        d['E']=d['stiffness_N']/d['area_mm2']
        d['UTS']=d['max_force_N']/d['area_mm2']
        raw.append(d)
    groups={}
    for r in raw: groups.setdefault((r['set'],r['condition']),[]).append(r)
    assert len(groups)==31
    def calc(item):
        (split,condition), arr=item
        n = 3 if split=='Main' else 5
        assert len(arr)==n,(condition,len(arr))
        h,p,v=arr[0]['h_mm'],arr[0]['P_mm'],arr[0]['v_mm_s']
        assert all((r['h_mm'],r['P_mm'],r['v_mm_s'])==(h,p,v) for r in arr)
        return dict(split=split,condition=condition,h=h,P=p,v=v,n=n,
                    phi=float(np.mean([r['phi'] for r in arr])),
                    E=float(np.mean([r['E'] for r in arr])),
                    UTS=float(np.mean([r['UTS'] for r in arr])),
                    mass=float(np.mean([r['mass_g'] for r in arr])),
                    area=float(np.mean([r['area_mm2'] for r in arr])))
    main=sorted([calc(item) for item in groups.items() if item[0][0]=='Main'],key=lambda g:(g['h'],g['P'],g['v']))
    val=sorted([calc(item) for item in groups.items() if item[0][0]=='Validation'],key=lambda g:int(g['condition'][1:]))
    assert len(main)==27 and len(val)==4
    return main,val


def matrix(groups):
    return np.array([[g['h'],g['P'],g['v']] for g in groups])


def metric(actual,pred):
    actual=np.asarray(actual,dtype=float);pred=np.asarray(pred,dtype=float)
    d=pred-actual
    return dict(R2=float(1-(d*d).sum()/((actual-actual.mean())**2).sum()),
                MAE=float(np.mean(np.abs(d))),RMSE=float(np.sqrt(np.mean(d*d))))


def solve(feat, y):
    return np.linalg.lstsq(np.asarray(feat,float),np.asarray(y,float),rcond=None)[0]


def fit_upstream(train):
    ycoeffs={}
    for speed in SPEEDS:
        part=[g for g in train if g['v']==speed]
        assert len(part)>=7
        x=np.array([[1,g['h'],g['P']]+([g['h']**2] if speed==20 else []) for g in part])
        Y=[g['phi']-K*g['h']/g['P'] for g in part]
        ycoeffs[int(speed)]=solve(x,Y)
    return ycoeffs


def Y_at(h,p,v,ycoeffs):
    vals=[]
    for speed in SPEEDS:
        x=np.array([1,h,p]+([h*h] if speed==20 else []))
        vals.append(float(x@ycoeffs[int(speed)]))
    return float(np.interp(v,SPEEDS,vals))


def predict_phi(h,p,v,ycoeffs):
    return Y_at(h,p,v,ycoeffs)+K*h/p


def E_basis(g,phi):
    row=np.zeros(6)
    pos=int(np.where(np.isclose(SPEEDS,g['v']))[0][0]); row[2*pos]=1;row[2*pos+1]=phi-10
    return row


def UTS_basis(g,phi):
    row=np.zeros(7)
    pos=int(np.where(np.isclose(HEIGHTS,g['h']))[0][0]);row[pos]=1
    F=(phi-10)/5;H=(g['h']-.20)/.10;V=(g['v']-70)/50
    row[3:]=[F,V,H*V,F*V]
    return row


def fit_downstream(train):
    bE=solve([E_basis(g,g['phi']) for g in train],[g['E'] for g in train])
    bU=solve([UTS_basis(g,g['phi']) for g in train],[g['UTS'] for g in train])
    return bE,bU


def predict_E(g,phi,bE):
    a=np.interp(g['v'],SPEEDS,bE[[0,2,4]])
    b=np.interp(g['v'],SPEEDS,bE[[1,3,5]])
    return float(a+b*(phi-10))


def predict_UTS(g,phi,bU):
    C=np.interp(g['h'],HEIGHTS,bU[:3])
    F=(phi-10)/5;H=(g['h']-.20)/.10;V=(g['v']-70)/50
    return float(C + bU[3]*F+bU[4]*V+bU[5]*H*V+bU[6]*F*V)


def process_basis(g,quad=False):
    h,p,v=g['h'],g['P'],g['v']
    return [1.,h,p,v]+([h*h,p*p,v*v,h*p,h*v,p*v] if quad else [])


def fit_process_direct(train,target,quad=False):
    X=np.array([process_basis(g,quad) for g in train])
    # Normalize the nine nonconstant polynomial terms, not the intercept.
    mu=X[:,1:].mean(axis=0);std=X[:,1:].std(axis=0)
    z=np.column_stack([np.ones(len(X)),(X[:,1:]-mu)/std])
    beta=solve(z,[g[target] for g in train])
    return beta,mu,std


def pred_direct(g,model,quad=False):
    beta,mu,std=model;x=np.array(process_basis(g,quad))
    return float(np.r_[1.,(x[1:]-mu)/std]@beta)


def write_csv(path,heads,rows):
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f);w.writerow(heads);w.writerows(rows)


def modulus_univariate_audits(train):
    """LOOCV for the global and within-stratum measured-porosity E models."""
    yield 'global', 'all', train
    for key in ('v', 'h', 'P'):
        for level in sorted({g[key] for g in train}):
            yield key, level, [g for g in train if g[key] == level]


def modulus_univariate_metrics(train):
    for axis, level, groups in modulus_univariate_audits(train):
        phi = np.array([g['phi'] for g in groups])
        response = np.array([g['E'] for g in groups])
        design = np.column_stack([np.ones(len(phi)), phi - 10])
        predictions = []
        for i, row in enumerate(design):
            keep = np.arange(len(phi)) != i
            predictions.append(row @ solve(design[keep], response[keep]))
        score = metric(response, predictions)
        intercept, slope = solve(design, response)
        yield [axis, level, len(phi), score['R2'], score['MAE'], score['RMSE'], intercept, slope]


def modulus_hc3_test(train):
    """Joint HC3 F test for equal slopes at the three tested speeds."""
    design = np.array([E_basis(g, g['phi']) for g in train])
    response = np.array([g['E'] for g in train])
    covariance_factor = np.linalg.inv(design.T @ design)
    beta = solve(design, response)
    leverage = np.sum((design @ covariance_factor) * design, axis=1)
    residual = (response - design @ beta) / (1 - leverage)
    scaled_design = design * residual[:, None]
    covariance = covariance_factor @ (scaled_design.T @ scaled_design) @ covariance_factor
    contrasts = np.array([[0, 1, 0, -1, 0, 0], [0, 1, 0, 0, 0, -1]])
    dof_n = len(contrasts)
    dof_d = len(response) - design.shape[1]
    differences = contrasts @ beta
    statistic = float(differences @ np.linalg.solve(contrasts @ covariance @ contrasts.T, differences) / dof_n)
    # Closed-form F-distribution survival function for two numerator degrees of freedom.
    p_value = float((1.0 + 2.0 * statistic / dof_d) ** (-dof_d / 2.0))
    return dict(F=statistic, numerator_df=dof_n, denominator_df=dof_d, p_value=p_value)


def run():
    main,val=read_specimens(); OUT.mkdir(exist_ok=True)
    res=[]
    for test in main:
        tr=[g for g in main if g['condition']!=test['condition']]
        yc=fit_upstream(tr);bE,bU=fit_downstream(tr)
        pp=predict_phi(test['h'],test['P'],test['v'],yc)
        item=dict(test,phi_pred=pp,Y_measured=test['phi']-K*test['h']/test['P'],Y_pred=Y_at(test['h'],test['P'],test['v'],yc),
                  E_cond_pred=predict_E(test,test['phi'],bE),UTS_cond_pred=predict_UTS(test,test['phi'],bU),
                  E_ppp_pred=predict_E(test,pp,bE),UTS_ppp_pred=predict_UTS(test,pp,bU))
        for tgt in ('E','UTS'):
            for name,quad in [('linear',False),('quadratic',True)]:
                item[f'{tgt}_{name}_pred']=pred_direct(test,fit_process_direct(tr,tgt,quad),quad)
        res.append(item)
    yc=fit_upstream(main);bE,bU=fit_downstream(main)
    for test in val:
        pp=predict_phi(test['h'],test['P'],test['v'],yc)
        item=dict(test,phi_pred=pp,Y_measured=test['phi']-K*test['h']/test['P'],Y_pred=Y_at(test['h'],test['P'],test['v'],yc),
                  E_cond_pred=predict_E(test,test['phi'],bE),UTS_cond_pred=predict_UTS(test,test['phi'],bU),
                  E_ppp_pred=predict_E(test,pp,bE),UTS_ppp_pred=predict_UTS(test,pp,bU))
        for tgt in ('E','UTS'):
            for name,quad in [('linear',False),('quadratic',True)]:
                item[f'{tgt}_{name}_pred']=pred_direct(test,fit_process_direct(main,tgt,quad),quad)
        res.append(item)
    cols=['split','condition','h','P','v','n','mass','area','phi','Y_measured','phi_pred','Y_pred','E','E_linear_pred','E_quadratic_pred','E_cond_pred','E_ppp_pred','UTS','UTS_linear_pred','UTS_quadratic_pred','UTS_cond_pred','UTS_ppp_pred']
    write_csv(OUT/'condition_predictions_31.csv',cols,[[r.get(k) for k in cols] for r in res])
    m={}
    for phase in ['Main','Validation']:
        r=[g for g in res if g['split']==phase];m[phase]={}
        for actual,pred,label in [('Y_measured','Y_pred','Y_speed_conditioned'),('phi','phi_pred','Porosity_geometry_referenced')]:
            m[phase][label]=metric([g[actual] for g in r],[g[pred] for g in r])
        for tgt in ['E','UTS']:
            for label,col in [('Direct_linear',f'{tgt}_linear_pred'),('Direct_quadratic',f'{tgt}_quadratic_pred'),('Measured_porosity_conditional',f'{tgt}_cond_pred'),('Integrated_PPP',f'{tgt}_ppp_pred')]:
                m[phase][tgt+'_'+label]=metric([g[tgt] for g in r],[g[col] for g in r])
    coeff=[]
    for v,b in yc.items():
        for j,c in enumerate(b):coeff.append(['Y',v,['Intercept','h','P','h2'][j],float(c)])
    for j,c in enumerate(bE):coeff.append(['E',int(SPEEDS[j//2]),'Intercept' if j%2==0 else 'phi_minus_10',float(c)])
    for j,c in enumerate(bU):coeff.append(['UTS','all',['C_h0.10','C_h0.20','C_h0.25','bF','bV','bHV','bFV'][j],float(c)])
    write_csv(OUT/'fitted_coefficients.csv',['response','speed_mm_s','term','coefficient'],coeff)
    write_csv(OUT/'summary_metrics.csv',['set','model','R2','MAE','RMSE'],[[split,name,vals['R2'],vals['MAE'],vals['RMSE']] for split,models in m.items() for name,vals in models.items()])
    (OUT/'metrics.json').write_text(json.dumps(m,indent=2),encoding='utf-8')
    write_csv(OUT/'modulus_porosity_diagnostics.csv',
              ['conditioning_axis','level','n','R2','MAE_MPa','RMSE_MPa','E_at_phi10_MPa','slope_MPa_per_pp'],
              modulus_univariate_metrics(main))
    (OUT/'modulus_hc3.json').write_text(json.dumps(modulus_hc3_test(main), indent=2)+'\n', encoding='utf-8')
    ver={key:m['Validation'][key]['RMSE'] for key in ['E_Integrated_PPP','UTS_Integrated_PPP']}
    assert round(m['Main']['Y_speed_conditioned']['R2'],3)==.953
    assert round(m['Main']['E_Integrated_PPP']['R2'],3)==.929
    assert round(m['Main']['UTS_Integrated_PPP']['R2'],3)==.926
    assert round(ver['E_Integrated_PPP'],3)==13.132
    assert round(ver['UTS_Integrated_PPP'],3)==.370
    print('FINAL PPP: E LOOCV',m['Main']['E_Integrated_PPP'],'UTS LOOCV',m['Main']['UTS_Integrated_PPP'])
    print('FINAL PPP: E validation',m['Validation']['E_Integrated_PPP'],'UTS validation',m['Validation']['UTS_Integrated_PPP'])
    print('Y LOOCV',m['Main']['Y_speed_conditioned'])
    print('V1-4 UTS errors',[(r['condition'],abs(r['UTS_ppp_pred']-r['UTS'])) for r in res if r['split']=='Validation'])
    print('Wrote results to',OUT)

if __name__=='__main__':run()
