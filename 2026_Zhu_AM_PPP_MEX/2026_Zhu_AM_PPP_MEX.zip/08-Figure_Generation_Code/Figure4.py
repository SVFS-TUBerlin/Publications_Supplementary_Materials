# -*- coding: utf-8 -*-
"""
Figure 4：三个固定 P 条件下的 Y–h 实验响应图。

依赖：
    pip install numpy matplotlib

输入数据已内嵌，无需额外 CSV。
字体使用本机 Roboto Regular。
输出：PDF、SVG、600 dpi PNG，以及绘图数据表。
"""

from pathlib import Path
import os
import csv

import numpy as np
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.patheffects as pe
from matplotlib import font_manager
from matplotlib.font_manager import FontProperties
from matplotlib.lines import Line2D


# ============================================================
# 1. 输出位置及字体
# ============================================================

OUTPUT_DIR = Path(r"D:\soft\3")

# 如果自动寻找失败，在这里填写字体文件的完整路径
FONT_PATH = None
# 例如：
# FONT_PATH = Path(
#     r"C:\Users\ylong\AppData\Local\Microsoft\Windows\Fonts"
#     r"\Roboto-Regular.ttf"
# )

PNG_DPI = 600


# ============================================================
# 2. 绘图样式
# ============================================================

H_LEVELS = (0.10, 0.20, 0.25)
P_LEVELS = (0.43, 0.45, 0.47)
V_LEVELS = (20, 70, 120)

# 分别对应 v = 20、70、120 mm/s
COLORS = ("#1f77b4", "#fe7f0f", "#2ca02c")
MARKERS = ("o", "s", "^")
ALPHA = 0.6

# 与最新版理论示意中的 A1 / A2 色系一致
A1_TINT = "#EEE6E9"
A2_TINT = "#FFF0D9"

ZERO_COLOR = "#858C91"
GRID_COLOR = "#DDE1E3"
HEADING_COLOR = "#263642"

Y_LIMITS = (-7.0, 12.0)
Y_TICKS = (-6, -3, 0, 3, 6, 9, 12)
X_LIMITS = (0.085, 0.265)

# 保持最新版 Figure 4 底部三图的比例
PAPER_WIDTH_MM = 190.0
DESIGN_WIDTH_PX = 1800.0
DESIGN_HEIGHT_PX = 675.0

PAPER_SCALE = (
    PAPER_WIDTH_MM / 25.4 * 72.0
) / (DESIGN_WIDTH_PX * 0.75)

FONT_TICK = 18.75 * PAPER_SCALE
FONT_AXIS = 24.0 * PAPER_SCALE
FONT_PANEL_TITLE = 22.0 * PAPER_SCALE
FONT_SECTION_TITLE = 24.0 * PAPER_SCALE
FONT_LEGEND = 22.0 * PAPER_SCALE

# 只给总标题轻微模拟加粗，单位为 pt。
# 设置为 0 可取消加粗。
TITLE_BOLD_STROKE_PT = 0.28


# ============================================================
# 3. 原始主实验数据
#
# 每行：
# (组号, h/mm, P/mm, v/(mm/s), 三件试样的 phi_vol/%)
#
# 来源：原 figure3_specimens.csv 中的 81 件主实验试样。
# 每个三元组按 R1、R2、R3 排列。
# ============================================================

RAW_DATA = [
    (
        "G8", 0.10, 0.43, 20,
        (8.06313248895193,
         8.38754456468096,
         7.905141680960803),
    ),
    (
        "G20", 0.10, 0.43, 70,
        (7.515419725577832,
         7.835424635544685,
         7.409945592250677),
    ),
    (
        "G23", 0.10, 0.43, 120,
        (7.188613619320849,
         7.179626200247702,
         7.269639369654513),
    ),
    (
        "G21", 0.10, 0.45, 20,
        (12.045292171730823,
         13.044888546729094,
         13.107178514469698),
    ),
    (
        "G4", 0.10, 0.45, 70,
        (8.635243331929399,
         8.438897684096913,
         8.428516507001815),
    ),
    (
        "G24", 0.10, 0.45, 120,
        (9.062300242708275,
         9.94549260451506,
         9.704650185416808),
    ),
    (
        "G22", 0.10, 0.47, 20,
        (15.561045812056594,
         14.282627987279762,
         14.49151570952628),
    ),
    (
        "G13", 0.10, 0.47, 70,
        (12.866332660239166,
         13.019568408117976,
         13.266586289153482),
    ),
    (
        "G9", 0.10, 0.47, 120,
        (13.283810874734936,
         13.392999232799152,
         13.71739182036128),
    ),
    (
        "G18", 0.20, 0.43, 20,
        (6.369175755641465,
         6.77811934768039,
         6.116440431779468),
    ),
    (
        "G6", 0.20, 0.43, 70,
        (6.914419393338111,
         6.774578650269881,
         7.138913594079388),
    ),
    (
        "G12", 0.20, 0.43, 120,
        (10.406019116987109,
         8.878897590266298,
         8.882241857974327),
    ),
    (
        "G2", 0.20, 0.45, 20,
        (8.048934957163588,
         8.219005948577717,
         8.264210838112152),
    ),
    (
        "G1", 0.20, 0.45, 70,
        (11.135202286298265,
         10.86597518298036,
         11.06149030653386),
    ),
    (
        "G3", 0.20, 0.45, 120,
        (12.139843108319038,
         11.902628434886507,
         11.609095154981633),
    ),
    (
        "G16", 0.20, 0.47, 20,
        (11.889969357058527,
         11.63130774891059,
         11.055008040038617),
    ),
    (
        "G7", 0.20, 0.47, 70,
        (13.503659540859523,
         13.565754349853664,
         14.8905836206354),
    ),
    (
        "G17", 0.20, 0.47, 120,
        (14.653528790902191,
         14.959756184060948,
         15.387094092683762),
    ),
    (
        "G25", 0.25, 0.43, 20,
        (6.546076427663417,
         6.505282849368877,
         6.621700029010736),
    ),
    (
        "G14", 0.25, 0.43, 70,
        (7.335983509437794,
         7.21456968403823,
         7.310511907769001),
    ),
    (
        "G27", 0.25, 0.43, 120,
        (8.616584946615157,
         8.278039497056222,
         8.72940409485803),
    ),
    (
        "G26", 0.25, 0.45, 20,
        (9.102103853094237,
         8.625730994152047,
         9.079152096439946),
    ),
    (
        "G5", 0.25, 0.45, 70,
        (9.48115885055969,
         10.167084221749668,
         10.511538418515164),
    ),
    (
        "G15", 0.25, 0.45, 120,
        (13.31434499564118,
         12.751756962809724,
         12.5863717011504),
    ),
    (
        "G10", 0.25, 0.47, 20,
        (10.761250767426224,
         10.75065752259654,
         11.059326603995622),
    ),
    (
        "G19", 0.25, 0.47, 70,
        (12.381220333269226,
         12.647393449070254,
         12.346175506543478),
    ),
    (
        "G11", 0.25, 0.47, 120,
        (15.50827723154634,
         15.26630289824864,
         15.29917627366083),
    ),
]


# ============================================================
# 4. 字体查找与设置
# ============================================================

def locate_roboto_regular():
    if FONT_PATH is not None:
        path = Path(FONT_PATH).expanduser()
        if not path.is_file():
            raise FileNotFoundError(f"字体文件不存在：{path}")
        return path

    candidates = [
        Path.home()
        / "AppData/Local/Microsoft/Windows/Fonts/Roboto-Regular.ttf",

        Path(os.environ.get("WINDIR", r"C:\Windows"))
        / "Fonts/Roboto-Regular.ttf",

        Path(__file__).resolve().parent / "Roboto-Regular.ttf",
    ]

    for path in candidates:
        if path.is_file():
            return path

    # 已安装字体也可能采用不同文件名
    for entry in font_manager.fontManager.ttflist:
        if (
            entry.name.lower() == "roboto"
            and str(entry.style).lower() == "normal"
            and str(entry.weight).lower()
            in {"normal", "regular", "400"}
        ):
            path = Path(entry.fname)
            if path.is_file():
                return path

    raise FileNotFoundError(
        "未找到 Roboto Regular。\n"
        "请在脚本顶部 FONT_PATH 中填写字体完整路径。"
    )


def configure_fonts(font_path):
    font_manager.fontManager.addfont(str(font_path))

    family = FontProperties(
        fname=str(font_path)
    ).get_name()

    mpl.rcParams.update({
        "font.family": family,
        "font.sans-serif": [family],
        "font.weight": "normal",
        "font.size": FONT_TICK,

        "axes.labelsize": FONT_AXIS,
        "axes.labelweight": "normal",
        "axes.linewidth": 1.5 * PAPER_SCALE,
        "axes.edgecolor": "black",
        "axes.labelcolor": "black",

        "xtick.labelsize": FONT_TICK,
        "ytick.labelsize": FONT_TICK,
        "xtick.color": "black",
        "ytick.color": "black",
        "text.color": "black",
        "axes.unicode_minus": True,

        # 只依赖 Regular，不要求独立 Bold / Italic 文件。
        "mathtext.fontset": "custom",
        "mathtext.rm": f"{family}:style=normal:weight=normal",
        "mathtext.it": f"{family}:style=normal:weight=normal",
        "mathtext.bf": f"{family}:style=normal:weight=normal",
        "mathtext.bfit": f"{family}:style=normal:weight=normal",
        "mathtext.sf": f"{family}:style=normal:weight=normal",
        "mathtext.tt": f"{family}:style=normal:weight=normal",
        "mathtext.cal": f"{family}:style=normal:weight=normal",
        "mathtext.fallback": "stix",

        # PDF 保持矢量，嵌入字体，不压缩内容流。
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "pdf.compression": 0,

        "svg.fonttype": "none",

        "figure.facecolor": "white",
        "savefig.facecolor": "white",
    })

    return FontProperties(fname=str(font_path))


# ============================================================
# 5. 逐件计算 Y，再计算均值与 min–max
# ============================================================

def calculate_groups():
    groups = {}

    for group_id, h, P, v, measurements in RAW_DATA:
        key = (h, P, v)

        if key in groups:
            raise ValueError(f"重复工况：{key}")

        phi_vol = np.asarray(measurements, dtype=float)

        if (
            phi_vol.shape != (3,)
            or not np.all(np.isfinite(phi_vol))
            or np.any(phi_vol < 0)
            or np.any(phi_vol > 100)
        ):
            raise ValueError(f"{group_id} 的原始数据无效。")

        phi2 = 100.0 * (1.0 - np.pi / 4.0) * h / P
        Y = phi_vol - phi2

        groups[key] = {
            "group_id": group_id,
            "h_mm": h,
            "P_mm": P,
            "v_mm_s": v,
            "n": 3,
            "phi2_pct": float(phi2),
            "phi_vol_R1_pct": float(phi_vol[0]),
            "phi_vol_R2_pct": float(phi_vol[1]),
            "phi_vol_R3_pct": float(phi_vol[2]),
            "Y_R1_pp": float(Y[0]),
            "Y_R2_pp": float(Y[1]),
            "Y_R3_pp": float(Y[2]),
            "Y_mean_pp": float(Y.mean()),
            "Y_min_pp": float(Y.min()),
            "Y_max_pp": float(Y.max()),
        }

    expected = {
        (h, P, v)
        for h in H_LEVELS
        for P in P_LEVELS
        for v in V_LEVELS
    }

    if set(groups) != expected:
        raise ValueError("主实验数据必须包含完整的 27 个工况。")

    return groups


# ============================================================
# 6. 绘制三张横向排列的趋势图
# ============================================================

def make_figure(groups, regular_font):
    fig = plt.figure(figsize=(
        PAPER_WIDTH_MM / 25.4,
        PAPER_WIDTH_MM / 25.4
        * DESIGN_HEIGHT_PX / DESIGN_WIDTH_PX,
    ))

    axes = []

    for col, P in enumerate(P_LEVELS):
        left = 145 + 580 * col

        ax = fig.add_axes([
            left / 1800,
            180 / 675,
            450 / 1800,
            320 / 675,
        ])

        axes.append(ax)

        ax.set_xlim(*X_LIMITS)
        ax.set_ylim(*Y_LIMITS)

        ax.set_xticks(
            H_LEVELS,
            [f"{h:.2f}" for h in H_LEVELS],
        )
        ax.set_yticks(Y_TICKS)

        # 背景仅对应 Y 相对参考值的数值位置。
        ax.axhspan(
            0, Y_LIMITS[1],
            facecolor=A1_TINT,
            edgecolor="none",
            zorder=-3,
        )

        ax.axhspan(
            Y_LIMITS[0], 0,
            facecolor=A2_TINT,
            edgecolor="none",
            zorder=-3,
        )

        for y in Y_TICKS:
            if y != 0:
                ax.axhline(
                    y,
                    color=GRID_COLOR,
                    linewidth=0.75 * PAPER_SCALE,
                    linestyle=(0, (2.2, 2.2)),
                    zorder=0,
                )

        ax.axhline(
            0,
            color=ZERO_COLOR,
            linewidth=1.5 * PAPER_SCALE,
            zorder=1,
        )

        for spine in ax.spines.values():
            spine.set_visible(True)
            spine.set_linewidth(1.5 * PAPER_SCALE)

        ax.tick_params(
            axis="both",
            direction="in",
            length=5 * PAPER_SCALE,
            width=1.5 * PAPER_SCALE,
            pad=7.5 * PAPER_SCALE,
        )

        for index, v in enumerate(V_LEVELS):
            selected = [
                groups[(h, P, v)]
                for h in H_LEVELS
            ]

            mean = np.array([
                row["Y_mean_pp"] for row in selected
            ])

            minimum = np.array([
                row["Y_min_pp"] for row in selected
            ])

            maximum = np.array([
                row["Y_max_pp"] for row in selected
            ])

            ax.errorbar(
                H_LEVELS,
                mean,
                yerr=[
                    mean - minimum,
                    maximum - mean,
                ],
                fmt="none",
                ecolor=COLORS[index],
                elinewidth=1.25 * PAPER_SCALE,
                capsize=3.75 * PAPER_SCALE,
                capthick=1.25 * PAPER_SCALE,
                alpha=ALPHA,
                zorder=2,
            )

            ax.plot(
                H_LEVELS,
                mean,
                color=COLORS[index],
                marker=MARKERS[index],
                linewidth=2.25 * PAPER_SCALE,
                markersize=7.5 * PAPER_SCALE,
                markeredgewidth=0.9375 * PAPER_SCALE,
                alpha=ALPHA,
                zorder=3,
            )

        fig.text(
            (left + 225) / 1800,
            538 / 675,
            rf"$P = {P:.2f}$ mm",
            ha="center",
            va="center",
            fontsize=FONT_PANEL_TITLE,
        )

        ax.set_xlabel(
            r"Layer height, $h$ (mm)",
            fontsize=FONT_AXIS,
        )

        ax.xaxis.set_label_coords(
            0.5,
            -58 / 320,
        )

    axes[0].set_ylabel(
    "Geometry-referenced response,\n$Y$ (pp)",
    fontsize=FONT_AXIS,
    )

    axes[0].yaxis.set_label_coords(
        -50 / 450,
        0.5,
    )

    handles = [
        Line2D(
            [0], [0],
            color=color,
            marker=marker,
            linewidth=2.25 * PAPER_SCALE,
            markersize=7.5 * PAPER_SCALE,
            markeredgewidth=0.9375 * PAPER_SCALE,
            alpha=ALPHA,
        )
        for color, marker in zip(COLORS, MARKERS)
    ]

    fig.text(
        617.5 / 1800,
        40 / 675,
        r"$v$ (mm s$^{-1}$)",
        ha="center",
        va="center",
        fontsize=FONT_LEGEND,
    )

    fig.legend(
        handles,
        ["20", "70", "120"],
        loc="center",
        bbox_to_anchor=(0.574, 40 / 675),
        ncol=3,
        frameon=False,
        fontsize=FONT_LEGEND,
        handlelength=2,
        handletextpad=0.55,
        columnspacing=2,
        borderaxespad=0,
    )

    # 明确指定普通文字使用同一份 Regular 字体文件。
    fig.canvas.draw()

    for text in fig.findobj(match=mpl.text.Text):
        size = text.get_fontsize()
        properties = regular_font.copy()
        properties.set_size(size)
        text.set_fontproperties(properties)

    fig.canvas.draw()

    return fig


# ============================================================
# 7. 保存图片和绘图数据
# ============================================================

def save_outputs(fig, groups):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    for extension in ("pdf", "svg", "png"):
        path = OUTPUT_DIR / f"Figure4_Y_h_panels.{extension}"

        fig.savefig(
            path,
            dpi=PNG_DPI,
            bbox_inches=None,
            transparent=False,
        )

        print(f"Saved: {path}")

    table_path = OUTPUT_DIR / "Figure4_Y_h_points.csv"

    ordered_rows = [
        groups[(h, P, v)]
        for P in P_LEVELS
        for v in V_LEVELS
        for h in H_LEVELS
    ]

    with table_path.open(
        "w",
        encoding="utf-8-sig",
        newline="",
    ) as file:
        writer = csv.DictWriter(
            file,
            fieldnames=list(ordered_rows[0]),
        )
        writer.writeheader()
        writer.writerows(ordered_rows)

    print(f"Saved: {table_path}")


def main():
    font_path = locate_roboto_regular()
    regular_font = configure_fonts(font_path)

    print(f"Font: {font_path}")
    print("Font weight: Roboto Regular; title uses simulated bold")

    groups = calculate_groups()
    fig = make_figure(groups, regular_font)

    save_outputs(fig, groups)
    plt.close(fig)

    print("完成：27 个主工况、81 件试样、9 条折线路径。")


if __name__ == "__main__":
    main()