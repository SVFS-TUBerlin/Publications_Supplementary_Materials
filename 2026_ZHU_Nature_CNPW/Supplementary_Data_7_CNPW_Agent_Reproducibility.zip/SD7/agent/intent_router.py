from __future__ import annotations

from dataclasses import dataclass

from .contracts import CanonicalTask, ExecutionMode
from .errors import AgentError
from .input_guard import GuardOutcome, InputGuard
from .intent_models import INTENT_CONTRACT_VERSION, IntentLabel, IntentProposal, proposal_from_mapping


@dataclass(frozen=True)
class IntentValidationOutcome:
    proposal: IntentProposal | None
    mode: ExecutionMode | None
    error: AgentError | None

    @property
    def accepted(self) -> bool:
        return self.proposal is not None and self.mode is not None


def validate_intent_proposal(value: object) -> IntentValidationOutcome:
    try:
        proposal = proposal_from_mapping(value)
    except ValueError as exc:
        return IntentValidationOutcome(None, None, AgentError("AI_INTENT_INVALID", "AI intent proposal is malformed or contains forbidden scientific fields.", (("reason", str(exc)),)))
    if proposal.intent_contract_version != INTENT_CONTRACT_VERSION:
        return IntentValidationOutcome(None, None, AgentError("AI_INTENT_INVALID", "AI intent proposal uses an unsupported contract version."))
    if proposal.intent is IntentLabel.UNSUPPORTED:
        return IntentValidationOutcome(proposal, None, AgentError("AI_INTENT_UNSUPPORTED", "The request cannot be represented by the frozen Agent v0.1 intent boundary."))
    mode = ExecutionMode.MODE_A if proposal.intent is IntentLabel.MODE_A else ExecutionMode.MODE_B_SIMPLIFIED_RESULT_A_GL7
    return IntentValidationOutcome(proposal, mode, None)


def build_task_from_validated_intent(input_guard: InputGuard, filename: str,
                                    outcome: IntentValidationOutcome,
                                    requested_language: str = "en") -> GuardOutcome:
    if not outcome.accepted:
        return GuardOutcome(None, outcome.error or AgentError("AI_INTENT_INVALID", "AI intent proposal was not accepted."))
    return input_guard.validate(filename, outcome.mode, requested_language)
