# Supporting Data and Code — PLA Material Extrusion Study

**Associated manuscript:** *Mechanistic Analysis and Process–Porosity–Property Modeling for Forward Prediction and Inverse Design in Material Extrusion Additive Manufacturing*  
**Dataset scope:** 27 main processing conditions (G1–G27; 3 specimens per condition) and four additional validation conditions (V1–V4; 5 specimens per condition), totaling **31 processing conditions and 101 tensile specimens**.  
**Main archive:** `2026_Zhu_AM_PPP_MEX.zip`  
**Archive version:** 24 November 2026

## 1. Purpose and organization

The supporting files are distributed as three downloads:

| Download | Contents |
|---|---|
| `2026_Zhu_AM_PPP_MEX.zip` | Measurement workbooks, ROI results, processing programs, model and figure code, and both software tools |
| `2026_Zhu_AM_PPP_MEX_Tensile_Curves.zip` | 101 original tensile instrument exports under `02_Tensile_Curves/` |
| `2026_Zhu_AM_PPP_MEX_ROI_Images.zip` | Microscopy images and associated XML files under `03_Microscopy/ROI_Images/` |

To reconstruct the directory tree below, extract all three ZIP files into the **same project folder**. The model-reproduction scripts can also run with only the main archive extracted.

The scientific manuscript and the **three-page Supplementary Information PDF** are separate documents. In particular, Supplementary Figures S1–S3 and Supplementary Tables S1–S2 appear in `SI.pdf`; this archive provides additional files underlying the experimental and computational analyses. The data are organized so that experimental measurements can be traced to specimen and processing-condition identifiers and, for the principal predictive models, reprocessed with the supplied code.

```text
SI/
├── 01_Raw_Measurements/
│   └── Raw_Measurements_101.xlsx
├── 02_Tensile_Curves/
│   └── 101 individual .xlsx tensile-test exports
├── 03_Microscopy/
│   ├── Table S1. ROI-level sectional porosity measurements
│   │   for the 27 printing conditions..xlsx
│   ├── ROI_Images/
│   └── Pore_Image_Analysis/
│       ├── ZhuChen_v3_3.py
│       └── README.md
├── 04_Processing_Conditions/
│   ├── 1.gcode ... 27.gcode
│   ├── v1.gcode ... v4.gcode
│   └── Printing_Times_31_Conditions.xlsx
├── 05_Processed_Data/
│   └── Processed_Data_101_and_31.xlsx
├── 06_Models_and_Validation/
│   ├── README.md
│   ├── raw_measurements_101.csv
│   ├── reproduce_models.py
│   ├── reproduce_E_random_forest.py
│   ├── requirements.txt
│   └── results/
├── 07_Inverse_Design_and_GUI/
│   └── PPP_Design_Tool.zip
└── 08-Figure_Generation_Code/
    └── Figure2.py ... Figure11.py and selected image inputs
```

## 2. Directory descriptions

### `01_Raw_Measurements/` — Specimen measurement records

**File:** `Raw_Measurements_101.xlsx`

This workbook consolidates the recorded numerical inputs for all **101 specimens**. It has three worksheets:

- **`Raw_101`** — one row per specimen, including its condition identifier, replicate identifier, layer height (`h`), line pitch (`P`), printing speed (`v`), specimen mass, measured initial cross-sectional area, tensile regression slope, maximum tensile force, and original-workbook provenance.
- **`Conditions_31`** — the explicit mapping between the **G1–G27 / V1–V4** identifiers and their processing parameters and replicate counts.
- **`Data_Notes`** — definitions and source notes for the recorded fields.

The workbook is a consolidated measurement table. For full force–displacement records, see `02_Tensile_Curves/`; for calculated properties and condition averages, see `05_Processed_Data/`. The consolidated table reports cross-sectional area rather than all individual caliper readings.

### `02_Tensile_Curves/` — Individual tensile-test exports

The separate tensile archive supplies **101 original `.xlsx` instrument-export files** in this directory: three for each of the 27 main conditions and five for each of the four additional conditions. Main-condition files follow names such as `1-21.xlsx`, `1-22.xlsx`, and `1-23.xlsx`; additional-condition files include names such as `v1-21.xlsx` through `v4-25.xlsx`.

The workbooks include raw testing-series information, including force and crosshead-displacement measurements, as well as instrument-generated result sheets. The specimen-to-condition interpretation is supported by the measurement and condition tables in `01_Raw_Measurements/`. The test method described in the manuscript uses a **120 mm reference length** for engineering strain, the **0.001–0.003 engineering-strain interval** for the Young's-modulus regression, and maximum engineering stress for UTS.

### `03_Microscopy/` — Optical cross-sections and ROI measurements

This directory contains the Excel workbook of sectional-porosity measurements:

`Table S1. ROI-level sectional porosity measurements for the 27 printing conditions..xlsx`

The workbook contains entries for the **27 main processing conditions**, identified by sequence number, individual ROI porosity values (`ROI1`, `ROI2`, etc.), and the recorded mean sectional porosity. This is the underlying numerical supplement for the condition-level sectional-porosity comparisons in **manuscript Table 3** (70 mm/s) and **Supplementary Tables S1–S2** (20 and 120 mm/s).

Extract the separate microscopy ZIP into the project folder to populate `03_Microscopy/ROI_Images/`. Representative montages are shown in manuscript Figure 5 and Supplementary Figures S2–S3.

`Pore_Image_Analysis/` contains the Python source of the custom image-analysis tool described in Section 2.2 and Supplementary Figure S1. See its README for installation, scale calibration, mask refinement, ROI settings, and data export.

### `04_Processing_Conditions/` — Printing programs and durations

- **`1.gcode`–`27.gcode`** — printing programs for the 27 main experimental conditions.
- **`v1.gcode`–`v4.gcode`** — printing programs for the four additional validation conditions.
- **`Printing_Times_31_Conditions.xlsx`** — a condition-indexed table of printing times, reported in **minutes**.

The processing parameters for each numbered condition are listed in the `Conditions_31` worksheet of `01_Raw_Measurements/Raw_Measurements_101.xlsx`. The G-code files preserve the actual programmed tool paths and extrusion commands; the printing-time values are **manually timed, condition-level values selected from the minimum recorded duration**, not per-specimen automated machine logs or replicated timing statistics.

### `05_Processed_Data/` — Derived responses and model comparison tables

**File:** `Processed_Data_101_and_31.xlsx`

This workbook links specimen measurements to the properties and condition means used in the analysis. Its six sheets are:

| Worksheet | Contents |
|---|---|
| `Definitions` | Constants, measurement definitions, and units |
| `Specimens_101` | Derived specimen-level volumetric porosity, Young's modulus, and UTS, calculated from recorded inputs |
| `Condition_Means_31` | Means of the 27 main conditions and four additional conditions, with 3 or 5 specimens per condition |
| `Final_PPP_31` | Condition-level measured responses, final process–porosity–property predictions, and direct-model reference predictions |
| `Model_Metrics` | R², MAE, and RMSE for the modeled responses |
| `Readme` | Sheet descriptions and interpretation notes |

**Interpretation of predictions:** for the 27 main processing conditions, the reported final-PPP model comparisons use leave-one-condition-out predictions; for V1–V4, the final model is fitted with the 27 main conditions and evaluated at the additional conditions. The additional-condition measurements are not used to fit the final model coefficients.

### `06_Models_and_Validation/` — Core PPP model reproduction

This directory provides a **standalone Python reproduction of the final principal model chain**, comprising:

1. Geometry-referenced porosity modeling, using the process-dependent response `Y` and the geometric reference contribution;
2. The speed-conditioned Young's-modulus model;
3. The seven-coefficient UTS model with porosity, layer-height, and speed effects;
4. Integrated process-only PPP predictions for porosity, modulus, and UTS;
5. Synchronized **27-fold leave-one-condition-out cross-validation** and evaluation at V1–V4.

**Quick start** (Python 3.11+; run from `06_Models_and_Validation/`):

```bash
python -m pip install -r requirements.txt
python reproduce_models.py
python reproduce_E_random_forest.py --output results/E_random_forest_LOOCV.csv
```

The script reads `raw_measurements_101.csv`. The `results/` directory contains reproducible outputs:

- `condition_predictions_31.csv` — 27 held-out predictions and V1–V4 predictions;
- `fitted_coefficients.csv` — fitted model coefficients;
- `summary_metrics.csv` and `metrics.json` — predictive-performance summaries;
- `modulus_hc3.json` and `modulus_porosity_diagnostics.csv` — robust slope test and porosity–modulus diagnostics;
- `E_random_forest_LOOCV.csv` — held-out modulus predictions for the Table 5A random forest (scikit-learn 1.8.0, 100 trees, seed 42).

Selected manuscript-level checks are **Y LOOCV R² = 0.953**, **integrated E LOOCV R² = 0.929 and RMSE = 16.255 MPa**, and **integrated UTS LOOCV R² = 0.926 and RMSE = 0.521 MPa**. The corresponding V1–V4 integrated-model RMSE values are **13.132 MPa** for E and **0.370 MPa** for UTS.

For detailed implementation and model definitions, consult the **directory-specific `06_Models_and_Validation/README.md`**. This script reproduces the final core prediction and validation chain; it is **not a single script for every microscopy, model-selection, statistical-test, inverse-design, or figure-generation analysis in the study**.

### `07_Inverse_Design_and_GUI/` — Interactive forward/inverse design software

**File:** `PPP_Design_Tool.zip`

Extract this nested ZIP separately. It contains the **Python/Tkinter source-based Process–Porosity–Property Design Tool**, including the active frozen prediction models, forward prediction, analytical inverse design, three-dimensional joint-feasibility visualization, export functions, internal tests, and its own usage instructions.

For Windows, consult `Lianyu_PPP_Design_Tool/README_运行说明.md` inside the nested archive. The supplied startup files include `Install_Dependencies.bat` and `Start_Design_Tool.bat`. Alternatively, from the extracted tool directory:

```bash
python -m pip install -r requirements.txt
python run_design_tool.py
```

The model and inverse-design routines can also be checked using the included QA/test scripts. The default illustrative inverse-design targets are **E = 2400 ± 20 MPa** and **UTS = 50 ± 0.5 MPa**, consistent with manuscript Figure 11.

**Version note:** the active model is defined by the current files under `data/` and the software modules. The inverse-design volume fractions are fractions of the investigated process-parameter domain, not empirical pass rates or probability estimates.

### `08-Figure_Generation_Code/` — Figure scripts and image inputs

This directory contains Python source files for **manuscript Figures 2–11** (`Figure2.py` through `Figure11.py`) plus selected image inputs, including Figure 2 photographs and Figure 11 interface screenshots.

These files preserve figure-generation methods and supporting assets. **Not every script is guaranteed to run unchanged from an arbitrary extracted directory:** some scripts refer to additional local source images, output locations, or dataset paths. Refer to each source file for its input requirements. Manuscript Figure 1 is not represented among these figure scripts.

## 3. Variables, units, and data provenance

| Variable or field | Meaning | Unit |
|---|---|---|
| `h` | Layer height | mm |
| `P` | Line pitch (center-to-center spacing) | mm |
| `v` | Prescribed printing speed | mm/s |
| `m` | Specimen mass | g |
| `A` | Measured initial specimen cross-sectional area | mm² |
| `Fmax` | Maximum recorded tensile force | N |
| `E` | Young's modulus | MPa |
| `UTS` | Ultimate tensile strength | MPa |
| `phi_vol` | Specimen-scale volumetric porosity | % |
| `phi_sec` | Local sectional porosity determined from optical ROIs | % |
| `phi_2` | Geometric reference contribution | % |
| `Y` | `phi_vol − phi_2`, geometry-referenced response | percentage points (pp) |
| `Delta_phi_v-s` | `phi_vol − phi_sec` | percentage points (pp) |
| Printing time | Manually recorded fabrication duration | min |

The porosity calculation uses a **reference PLA density of 1.24 g/cm³** and a **nominal specimen length of 180 mm**. The numerical formula for volumetric porosity when mass is in g and area and length are in mm² and mm is:

```text
phi_vol (%) = 100 * [1 − (1000 * mass_g)/(1.24 * area_mm2 * 180)]
```

The reference geometric contribution is:

```text
phi_2 (%) = 100 * (1 − pi/4) * h/P
Y (pp) = phi_vol (%) − phi_2 (%)
```

These are numerical percentage-scale conventions: internally, computation should retain full precision, with rounding applied only to displayed values. The dimensional and procedural definitions are given in the manuscript Methods and in the individual code packages.

## 4. Suggested route for reproducing the results

1. **Identify the condition.** Use `01_Raw_Measurements/Raw_Measurements_101.xlsx` → `Conditions_31` to map G1–G27 or V1–V4 to `h`, `P`, and `v`.
2. **Inspect raw measurements.** Look up the specimen rows in `Raw_101`, and the corresponding instrument records in `02_Tensile_Curves/`.
3. **Inspect processed mechanical data.** Use `05_Processed_Data/` → `Specimens_101` and `Condition_Means_31` for computed responses and the modeled condition means.
4. **Reproduce the main prediction results.** Follow `06_Models_and_Validation/README.md`, run `reproduce_models.py`, and compare `results/` with manuscript Tables 4–7 and the final PPP performance statistics as appropriate.
5. **Inspect pore morphology and sectional porosity.** Use the microscopy images and ROI workbook in `03_Microscopy/` alongside manuscript Figure 5, Table 3, and Supplementary Figures S1–S3 and Tables S1–S2. Follow `03_Microscopy/Pore_Image_Analysis/README.md` to run the image-analysis tool.
6. **Inspect inverse-design calculations.** Extract and run the package in `07_Inverse_Design_and_GUI/`; consult its documentation for analytical parameter inversion, joint feasibility, and export formats.
7. **Inspect figure generation.** See the files in `08-Figure_Generation_Code/` for the figure-specific scripts and supplied image assets.

## 5. Scope and interpretation

- The fitted relationships apply to the investigated PLA material, printing system, and parameter ranges: **h = 0.10–0.25 mm, P = 0.43–0.47 mm, and v = 20–120 mm/s**. Applying them to different materials or process ranges requires independent assessment and potentially model recalibration.
- The main model fitting uses **27 condition means**, not all 101 specimens as independent regression conditions. V1–V4 are **additional experimental checks excluded from the final coefficient fitting**.
- The measured-porosity conditional E/UTS models and the fully integrated process-only PPP models have different input requirements. Only the latter produce predictions from `h`, `P`, and `v` without experimentally measured porosity.
- Sectional porosity describes the sampled optical regions; it is **not interchangeable with** specimen-scale volumetric porosity and is **not used as an input** in the final PPP prediction chain.
- The visible-gap classifications described in the manuscript and SI are associated with the investigated processing conditions and optical observations; they should not be interpreted as measurements of molecular interdiffusion or inter-road bond strength.
- Numerical comparisons and tolerance windows in the software describe predictions within the studied process domain, **not statistical prediction intervals** unless explicitly stated otherwise.

## 6. Publication and citation

When using these data or programs, cite the associated manuscript and, once the public repository is released, its repository record or persistent identifier. The repository URL, DOI, and any formal software/data licensing terms should be supplied through the release record; they are **not specified in the present archive**.

For questions about an individual data field or script, first consult its workbook notes or directory-specific README and retain the original condition and specimen identifiers when reporting derived results.
