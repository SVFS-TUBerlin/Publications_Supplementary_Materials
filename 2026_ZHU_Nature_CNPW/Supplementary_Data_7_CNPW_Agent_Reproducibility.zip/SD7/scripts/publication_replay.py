"""Portable V8_RESIDUAL_MODEB reference reproduction; calls frozen Agent only."""
from __future__ import annotations
import argparse
import dataclasses
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.dont_write_bytecode = True
from agent.dual_coordinator import DualAnalysisCoordinator
from agent.integrated_report import render_integrated_json, render_presentation_markdown
from agent.qcca_analyzer import recovery_for_target

CONTRACT = 'V8_RESIDUAL_MODEB'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def normalize(value):
    """Only transport metadata is normalized; scientific values are unchanged."""
    if isinstance(value, dict):
        return {k: ('inputs/' + Path(v).name if k == 'source_path' else normalize(v))
                for k,v in value.items() if k not in {'execution_timestamp','canonical_task_sha256','canonical_task_hash_sha256'}}
    if isinstance(value,list):
        return [normalize(v) for v in value]
    return value

def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))

def scientific_projection(run):
    """Return only frozen scientific state for cross-release comparison."""
    def branch(value):
        result = dict(value['verified_result'])
        for key in ('provenance','integrity','status','result_contract_version','task_id'):
            result.pop(key,None)
        result['stage_1'] = dict(result['stage_1'])
        result['stage_1'].pop('k_g_eff',None)
        return {
            'verified_result': result,
            'global_qcca': value['global_qcca']['result'],
            'local_qcca': value['local_qcca']['result'],
            'targeted_actions': value.get('targeted_actions',[]),
        }
    return {'mode_a':branch(run['mode_a']),'mode_b_contracts':[branch(item) for item in run['mode_b_contracts']]}

def export(dual):
    result = normalize(json.loads(render_integrated_json(dual)))
    result['publication_contract'] = CONTRACT
    result['publication_normalization'] = 'source_path uses logical inputs/name; execution_timestamp and path-dependent canonical task SHA-256 omitted; scientific state unchanged'
    # Existing Core/Agent Global recovery routine, all higher targets; diagnostic only.
    result['global_target_diagnostics'] = []
    for b in [dual['mode_a'],*dual['mode_b_contracts']]:
        q = b['global_qcca'].result
        result['global_target_diagnostics'].append({'contract_id':b['contract_id'],
            'response_names':list(q.criterion_names),
            'targets':[dataclasses.asdict(recovery_for_target(q,t)) for t in range(q.full_system_ceiling+1,q.global_level_count+1)]})
    return json.loads(canonical(result))

def verify(run):
    assert run['overall_integrity_status']=='completed'
    names = [c['name'] for c in run['mode_a']['verified_result']['input_summary']['active_criteria']]
    assert len(run['mode_b_contracts'])==2**len(names)-2
    for b in [run['mode_a'],*run['mode_b_contracts']]:
        assert b['verification']['status']=='completed'
        r=b['verified_result']; w1=set(r['stage_1']['retained_candidate_ids'])
        assert set(r['terminal']['terminal_candidate_ids']) <= set(r['stage_2']['retained_candidate_ids']) <= w1
        assert set(r['stage_2']['per_criterion_local_trace']['local'])==set(names)
        g=b['global_qcca']; assert g['status']=='COMPLETED'
        q=g['result']; condition=r['mode_b_conditioning']
        expected=names if condition is None else [x for x in names if x not in condition['protected_block']]
        assert q['criterion_names']==expected
        assert len(q['subset_capabilities'])==2**len(expected)-1
        domain=set(q['domain_candidate_ids'])
        if condition:
            assert domain==set(condition['omega_candidate_ids']) and w1<=domain
            assert r['stage_1']['qualification_response_indices']==[i for i,x in enumerate(names) if x in expected]
        for subset in q['subset_capabilities']:
            assert set(subset['responses'])<=set(expected)
            assert set(subset['supporting_candidate_ids'])<=domain
        local=b['local_qcca']
        if local['status']=='COMPLETED':
            ql=local['result']; assert ql['criterion_names']==names and set(ql['domain_candidate_ids'])==w1
            assert [t['target'] for t in ql['target_recoveries']]==list(range(ql['full_system_ceiling']+1,ql['global_level_count']+1))
        for action in b['targeted_actions']:
            assert action['verified']
            for candidate in action['result']['alternatives']:
                assert candidate['candidate_id'] in w1
                for name in action['recovery']['retained_responses']:
                    assert candidate['local_profile'][names.index(name)]>=action['target']
    for diagnostic,b in zip(run['global_target_diagnostics'],[run['mode_a'],*run['mode_b_contracts']]):
        universe=set(diagnostic['response_names']); domain=set(b['global_qcca']['result']['domain_candidate_ids'])
        for target in diagnostic['targets']:
            for recovery in target['recovery_sets']:
                assert recovery['retained_responses']
                assert set(recovery['removed_responses']) <= universe
                assert set(recovery['supporting_candidate_ids']) <= domain

def execute(case,input_path):
    assert sha(input_path)==case['sha256'], 'INPUT HASH MISMATCH: '+case['id']
    outcome=DualAnalysisCoordinator(ROOT).execute(input_path)
    assert outcome.error is None, str(outcome.error)
    result=export(outcome.result)
    verify(result)
    return result, render_presentation_markdown(outcome.result)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--inputs',type=Path,required=True,help='Directory with the six SD5 input files')
    parser.add_argument('--controlled',type=Path,required=True)
    parser.add_argument('--reference',type=Path,required=True,help='Extracted new SD6 root')
    parser.add_argument('--output',type=Path,required=True,help='New output directory')
    args=parser.parse_args()
    manifest=json.loads((args.reference/'INPUT_MANIFEST.json').read_text(encoding='utf-8'))
    args.output.mkdir(parents=True,exist_ok=False)
    records=[]
    for case in manifest:
        source=args.controlled if case['id']=='CONTROLLED_PLA_MEX' else args.inputs/case['filename']
        actual,_=execute(case,source)
        reference=json.loads((args.reference/case['id']/'V8_Integrated_Report.json').read_text(encoding='utf-8'))
        assert scientific_projection(actual)==scientific_projection(reference), 'SCIENTIFIC REFERENCE MISMATCH: '+case['id']
        records.append({'case':case['id'],'reference_sha256':sha(args.reference/case['id']/'V8_Integrated_Report.json'),'status':'PASS'})
        print(case['id']+': PASS',flush=True)
    (args.output/'REPLAY_VERIFICATION.json').write_text(json.dumps(records,indent=2),encoding='utf-8')

if __name__=='__main__': main()
