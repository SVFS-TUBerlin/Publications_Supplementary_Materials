# 212 — External FFF CNPW Validation Protocol (v1.5.2)

## 1. Role of the external case

This file defines the formal protocol used to test whether CNPW v1.5.2 can be transferred from the internal PLA-MEX case to an independent fused-filament-fabrication (FFF) multi-response decision problem.

The external case is not used to modify the CNPW algorithm.

Its purpose is:

\[
\boxed{
\text{published external response models}
\rightarrow
\text{frozen executable candidate library}
\rightarrow
\text{CNPW v1.5.2 transfer test}
}
\]

The external validation asks whether the same qualification architecture can operate on:

- a different published study;
- a different parameter space;
- six instead of four active responses;
- different response meanings and units;
- a multi-component qualified region;
- absolute engineering requirements supplied by the source study.

No PLA-MEX threshold, PG identifier, fitted model, response scale, or process-window boundary is transferred into this case.

---

## 2. Published external source

The external case is reconstructed from:

**Matheus C. Almeida, Francisco T. A. Barbosa, Lucas G. Oliveira, Luiz M. Coelho Junior & Rogério S. Peruchi**,  
*Multi-objective optimization of sustainable performance in fused filament fabrication*,  
**Computers & Industrial Engineering**, Volume 216 (2026), Article 112001.  
DOI: **10.1016/j.cie.2026.112001**

The source study provides response-surface equations for four FFF process variables and multiple performance responses.

The original source model is reproduced before CNPW is applied.

---

## 3. Frozen external parameter space

The four source-study process variables are:

\[
LW,\quad LH,\quad ID,\quad S.
\]

The executable external grid is frozen as:

- \(LW=0.40\)–\(0.60\) mm, step \(0.02\) mm: 11 values;
- \(LH=0.12\)–\(0.28\) mm, step \(0.02\) mm: 9 values;
- \(ID=10\)–\(90\%\), step \(10\%\): 9 values;
- \(S=20\)–\(50\) mm/s, step \(3\) mm/s: 11 values.

Therefore:

\[
\boxed{
11\times 9\times 9\times 11
=
9,801
}
\]

candidate combinations are frozen.

Candidate identifiers are:

\[
EPG0001\text{--}EPG9801.
\]

No candidate outside this library is used in the formal external CNPW analysis.

---

## 4. Frozen response construction

Six independent responses are active in CNPW:

\[
\boxed{
Energy,\ Cost,\ Cgk_w,\ Cgk_t,\ Ca_w,\ Ca_t
}
\]

with preferred directions:

\[
Energy,\ Cost:\ \min
\]

and:

\[
Cgk_w,\ Cgk_t,\ Ca_w,\ Ca_t:\ \max.
\]

The published RSM equations are used for:

- Energy;
- Cost;
- \(Cgk_w\);
- \(Cgk_t\);
- \(Y_w\);
- \(Y_t\).

The two conformity responses are deterministically reconstructed as:

\[
Ca_w
=
1-\frac{|Y_w-10|}{0.20}
\]

and:

\[
Ca_t
=
1-\frac{|Y_t-4|}{0.20}.
\]

The source-study carbon response satisfies:

\[
CO_2=0.0398\times Energy
\]

and is retained only as an audit quantity because it is functionally dependent on Energy and therefore not treated as an additional independent CNPW objective.

---

## 5. Source-model reproduction audit

Before CNPW execution, the published balanced NGC solution is numerically reproduced.

The reported point:

\[
LW=0.59,\quad LH=0.12,\quad ID=10,\quad S=50
\]

is reproduced as a local optimum close to:

\[
LW=0.586701,\quad LH=0.12,\quad ID=10,\quad S=50.
\]

The reproduced response values remain close to the published values.

The reproduction status is:

\[
\boxed{\text{PASS WITH SOLVER-START CAVEAT}}
\]

because the source paper reports GRG optimization but does not report its starting values, and the normalized global criterion exhibits local-start dependence.

This caveat is preserved rather than hidden.

---

# 6. Stage 1 — external Global Levels

The external case uses the same formal Stage-1 definition as CNPW v1.5.2.

For each response, candidates are oriented so that larger is preferable, ranked from worst to best, and assigned nominal Global Levels:

\[
GL1,\ldots,GL7.
\]

The nominal positional level is:

\[
\widetilde{\ell}(r)
=
\min
\left\{
7,
\left\lceil\frac{7r}{9801}\right\rceil
\right\}.
\]

Because \(9801\) is not divisible by 7, the no-tie nominal sizes are:

- GL1–GL6: 1,400 candidates each;
- GL7: 1,401 candidates.

The frozen tie-upward rule is retained:

> if identical response values cross a nominal level boundary, all members of the tie group are assigned to the better touched level.

The formal external audit found:

\[
\boxed{0}
\]

cross-boundary tie groups for all six responses.

Thus the nominal 1,400/1,401 sizes remain unchanged.

---

# 7. Mode A — full six-response Equal Priority

For the full active set:

\[
A=
\{Energy,Cost,Cgk_w,Cgk_t,Ca_w,Ca_t\},
\]

Stage 1 gives:

\[
\boxed{
Q^{(1)*}=GL6
}
\]

with:

\[
\boxed{
|W^{(1)}|=22
}
\]

or:

\[
0.2245\%
\]

of the frozen external library.

Unlike the internal PLA-MEX case, the strict external region is not one connected window.

Under four-dimensional face adjacency:

\[
\boxed{
W^{(1)}=
4\text{ components}
}
\]

with component sizes:

\[
\boxed{
10,\ 9,\ 2,\ 1.
}
\]

This is a useful transferability result because CNPW is not forced to return one continuous manufacturing window.

---

# 8. Stage 2 — full six-response local qualification

Stage 2 is executed only inside the 22 Stage-1-qualified candidates.

For each of the six responses, the actual numerical range inside \(W^{(1)}\) is divided into:

\[
K_l=7
\]

equal-width Local Levels:

\[
LL1,\ldots,LL7.
\]

The highest non-empty cumulative local intersection is:

\[
\boxed{
Q^{(2)*}=LL2
}
\]

with four candidates:

\[
EPG0110,\ EPG1001,\ EPG7238,\ EPG8129.
\]

Their sorted worst-first local profiles are:

\[
EPG0110:
(LL2,LL2,LL4,LL7,LL7,LL7)
\]

\[
EPG1001:
(LL2,LL2,LL5,LL7,LL7,LL7)
\]

\[
EPG7238:
(LL2,LL3,LL5,LL5,LL6,LL7)
\]

\[
EPG8129:
(LL2,LL3,LL5,LL5,LL7,LL7).
\]

Worst-first lexicographic pruning therefore retains:

\[
\boxed{
W^{(2a)}=\{EPG8129\}
}
\]

and raw-response dominance leaves the same singleton:

\[
\boxed{
W^{(2T)}=\{EPG8129\}.
}
\]

EPG8129 uses:

\[
LW=0.58\text{ mm},\quad
LH=0.14\text{ mm},\quad
ID=10\%,\quad
S=50\text{ mm/s}.
\]

This result supersedes the old external-file representative EPG0110, which had been selected by the now-retired local \(B/M\) rule.

No weighted average, normalized mean, local \(B/M\), or compensatory score is used in the v1.5.2 terminal step.

---

# 9. Mode-A objective-subset transfer test

With six responses, all non-empty active-objective subsets are evaluated:

\[
2^6-1
=
\boxed{63}
\]

Mode-A configurations.

The Stage-1 compatibility structure is:

| Active-objective count | Number of subsets | \(Q^{(1)*}=GL7\) | \(Q^{(1)*}=GL6\) |
|---:|---:|---:|---:|
| 1 | 6 | 6 | 0 |
| 2 | 15 | 15 | 0 |
| 3 | 20 | 19 | 1 |
| 4 | 15 | 12 | 3 |
| 5 | 6 | 3 | 3 |
| 6 | 1 | 0 | 1 |

Thus pairwise compatibility is very high in this external case, but full six-response qualification still falls to GL6.

The full subset analysis uses the complete v1.5.2 sequence:

\[
GL
\rightarrow
W^{(1)}
\rightarrow
LL
\rightarrow
W^{(2)}
\rightarrow
\text{worst-first}
\rightarrow
\text{raw dominance}.
\]

Set-valued terminal sets are retained when the active subset does not justify further discrimination.

---

# 10. Mode B — two-tier priority transfer test

All non-empty proper priority blocks are evaluated:

\[
2^6-2
=
\boxed{62}
\]

Mode-B configurations.

For each priority block \(P\):

1. identify its default highest common Global Level \(Q_P^{(1)*}\);
2. construct the Tier-1 admissible set;
3. evaluate the residual block \(R\) jointly;
4. require an acceptable residual qualification of:

\[
\boxed{
q_{\min}^{acc}=GL6
}
\]

anchored to the full external Mode-A baseline;
5. if the residual block falls below GL6, relax the priority protection along the predefined global-level path;
6. execute residual Stage 2 using LL qualification;
7. apply worst-first residual LL pruning;
8. apply raw residual-response dominance.

Tier-1 responses remain hard admissibility requirements and are not reused as terminal bonuses.

The 62-block audit gives:

\[
\boxed{
32/62
}
\]

configurations requiring structured recovery.

All required recovery is achieved by weakening an over-restrictive GL7 priority protection to GL6.

Final residual Stage-1 qualification is:

- GL6 in 39 configurations;
- GL7 in 23 configurations.

Five Mode-B configurations retain a genuinely set-valued terminal after all non-compensatory pruning.

This demonstrates that the external case supports the same two-tier priority architecture without forcing every configuration into one scalar winner.

---

# 11. Single-priority examples

The six single-response priority cases illustrate the priority cost.

| Priority response | Default priority | Accepted priority | Recovery | Residual \(Q^{(1)*}\) | Formal terminal |
|---|---|---|---|---|---|
| Energy | GL7 | GL7 | No | GL6 | EPG9570 |
| Cost | GL7 | GL7 | No | GL6 | EPG9031 |
| Cgk_w | GL7 | GL7 | No | GL6 | EPG8129 |
| Cgk_t | GL7 | **GL6** | **Yes** | GL6 | EPG1001 |
| Ca_w | GL7 | GL7 | No | GL6 | EPG7238 |
| Ca_t | GL7 | GL7 | No | GL6 | EPG7238 |

The \(Cgk_t\) priority is therefore the only single-response GL7 priority that must be relaxed to preserve the external-case minimum residual qualification GL6.

---

# 12. Explicit absolute engineering requirement

The source study provides an absolute capability interpretation:

\[
Cgk_w\ge1.33
\]

and:

\[
Cgk_t\ge1.33.
\]

These are treated as explicit hard Tier-1 requirements rather than relative GL preferences.

The hard requirement retains:

\[
\boxed{
90
}
\]

candidates.

It has:

\[
\boxed{
0
}
\]

overlap with the full six-response relative \(W^{(1)}=W_6\) region.

The residual block:

\[
R=
\{Energy,Cost,Ca_w,Ca_t\}
\]

reaches:

\[
\boxed{
Q_R^{(1)*}=GL5
}
\]

with:

\[
|W_{P\rightarrow R}^{(1)}|=11.
\]

Residual Stage 2 gives:

\[
Q_R^{(2)*}=LL3
\]

and uniquely retains:

\[
\boxed{
EPG0011.
}
\]

EPG0011 uses:

\[
LW=0.40,\quad
LH=0.12,\quad
ID=10,\quad
S=50.
\]

This establishes a useful external distinction:

\[
\boxed{
\text{relative joint qualification}
\neq
\text{absolute engineering acceptability}.
}
\]

CNPW can support either query, but the requirement must be declared explicitly.

---

# 13. Pareto audit

The six-response external library contains:

\[
\boxed{
434
}
\]

Pareto-efficient candidates.

Of the 22 candidates in the full strict \(W^{(1)}\):

\[
\boxed{
13
}
\]

are Pareto-efficient.

The formal v1.5.2 terminal EPG8129 is Pareto-efficient.

Pareto status remains an external audit only and is not used in qualification or terminal selection.

---

# 14. Published NGC comparator

Four published NGC scenarios are projected onto the frozen external GL system:

- Spec-Conformity;
- Env-Conscious;
- Balanced;
- Neutral.

Their minimum Global Levels are:

- Spec-Conformity: GL4;
- Env-Conscious: GL4;
- Balanced: GL5;
- Neutral: GL4.

Thus:

\[
\boxed{
0/4
}
\]

published scalarized scenarios satisfy the full six-response GL6 qualification requirement.

This is not interpreted as a general failure of NGC.

It demonstrates only that scalarized optimization and non-compensatory joint qualification answer different decision questions in this published FFF case.

---

# 15. What this external case validates

The external FFF case provides evidence for transfer of the CNPW **decision architecture**, not transfer of numerical thresholds or universal optimality.

The following features survive the domain change:

1. finite executable candidate-library qualification;
2. population-balanced Stage-1 GLs;
3. tie-preserving level assignment;
4. highest common non-compensatory intersection;
5. bounded actual-magnitude Stage-2 LLs;
6. worst-first terminal pruning;
7. raw-response dominance;
8. Mode-A active-objective subsets;
9. Mode-B priority conditioning;
10. structured priority recovery;
11. explicit absolute engineering requirements;
12. connectivity / multi-component process-window reporting;
13. Pareto audit without using Pareto as the qualification rule;
14. comparison with the source study's scalarized decision outputs.

The external case also produces qualitatively different geometry from the PLA-MEX case:

\[
\boxed{
\text{four disconnected strict components rather than one dominant connected strict window}
}
\]

which strengthens the interpretation that CNPW is not tuned merely to reproduce one internal process-space pattern.

---

# 16. Boundaries of the claim

This external validation does not establish that:

- CNPW is universally optimal;
- the published RSM equations are exact outside their source domain;
- the 9,801 candidates are 9,801 independent physical experiments;
- all multi-objective engineering problems must produce GL6;
- EPG8129 is a universal FFF optimum;
- Pareto, NGC, or other multi-objective methods are invalid.

The correct claim is narrower:

> The same frozen CNPW v1.5.2 qualification architecture can be executed without algorithmic modification on an independent published six-response FFF model space, where it returns a multi-component qualified region, configuration-dependent priority solutions, explicit-requirement results, and non-compensatory terminal sets.

---

# 17. File structure after consolidation

The old three-file external branch is consolidated into two active files:

## 212 — this method file

`212_External_FFF_CNPW_Validation_Protocol_v1.5.2.md`

Role:

\[
\boxed{
\text{source provenance + reconstruction + frozen external CNPW protocol}
}
\]

## 213 — consolidated data/result workbook

`213_External_FFF_CNPW_9801_Validation_v1.5.2.xlsx`

Role:

\[
\boxed{
\text{frozen 9801 library + Mode A + Mode B + absolute requirement + external benchmarks + audits}
}
\]

The former 214 configurable-intersection workbook is fully absorbed into the new 213 workbook.

The old B/M representative logic in the previous 213/214 files is superseded and should be treated only as legacy provenance.
