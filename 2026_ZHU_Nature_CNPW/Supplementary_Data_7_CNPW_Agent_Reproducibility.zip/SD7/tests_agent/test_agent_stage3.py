from __future__ import annotations

import copy
import json
import unittest
from pathlib import Path

from agent.contracts import ExecutionMode
from agent.core_adapter import CoreAdapter
from agent.errors import AgentRejected
from agent.input_guard import InputGuard
from agent.provenance import build_provenance_manifest, core_source_manifest
from agent.report_renderer import render_csv, render_json, render_markdown
from agent.result_builder import build_result
from agent.verifier import verify_result


ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "tests_agent" / "fixtures" / "small_m3.csv"
FIXED_TIME = "2026-08-19T12:00:00+00:00"


class AgentStage3Tests(unittest.TestCase):
    def execution_bundle(self):
        task = InputGuard().validate(FIXTURE, ExecutionMode.MODE_B_SIMPLIFIED_RESULT_A_GL7).task
        execution = CoreAdapter().execute(task)
        result = build_result(execution)
        verification = verify_result(task, result, execution.dataset.candidate_ids, task.input_summary.identity.source_path)
        provenance = build_provenance_manifest(task, ROOT, FIXED_TIME)
        return task, execution, result, verification, provenance

    def verify(self, task, execution, result):
        return verify_result(task, result, execution.dataset.candidate_ids, task.input_summary.identity.source_path)

    def test_provenance_manifest_is_stable_and_complete(self):
        task, _, _, _, _ = self.execution_bundle()
        first = build_provenance_manifest(task, ROOT, FIXED_TIME)
        second = build_provenance_manifest(task, ROOT, FIXED_TIME)
        self.assertEqual(first, second)
        self.assertEqual(10, len(first["core_source_manifest"]["files"]))
        self.assertEqual(64, len(first["core_source_manifest"]["aggregate_sha256"]))
        self.assertEqual(core_source_manifest(ROOT), core_source_manifest(ROOT))

    def test_valid_execution_passes_semantic_verifier(self):
        _, _, _, verification, _ = self.execution_bundle()
        self.assertTrue(verification.passed)
        self.assertTrue(dict(verification.checks)["protected_response_reenters_local"])

    def test_task_input_hash_mismatch_fails_integrity(self):
        task, execution, result, _, _ = self.execution_bundle()
        altered = copy.deepcopy(result)
        altered["provenance"]["input_hash_sha256"] = "0" * 64
        self.assertEqual("failed_integrity", self.verify(task, execution, altered).status)

    def test_w2_not_subset_w1_fails_integrity(self):
        task, execution, result, _, _ = self.execution_bundle()
        altered = copy.deepcopy(result)
        altered["stage_2"]["retained_candidate_ids"] = ["c1"]
        self.assertIn("W2_SUBSET_W1", self.verify(task, execution, altered).failures)

    def test_terminal_not_subset_w2_fails_integrity(self):
        task, execution, result, _, _ = self.execution_bundle()
        altered = copy.deepcopy(result)
        altered["terminal"]["terminal_candidate_ids"] = ["c1"]
        self.assertIn("W2T_SUBSET_W2", self.verify(task, execution, altered).failures)

    def test_terminal_list_preserved_for_singleton_and_set(self):
        _, _, result, verification, _ = self.execution_bundle()
        self.assertIsInstance(result["terminal"]["terminal_candidate_ids"], list)
        self.assertTrue(verification.passed)

    def test_mode_b_protected_result_reenters_local_stage(self):
        task, execution, result, verification, _ = self.execution_bundle()
        checks = dict(verification.checks)
        self.assertEqual("A", task.protected_criterion.slot)
        self.assertIn(task.protected_criterion.name, result["stage_2"]["per_criterion_local_trace"]["local"])
        self.assertTrue(checks["protected_response_reenters_local"])

    def test_descriptor_metadata_is_verified_inactive(self):
        _, _, result, verification, _ = self.execution_bundle()
        self.assertEqual(["Descriptor"], result["input_summary"]["descriptors"])
        self.assertTrue(dict(verification.checks)["descriptors_metadata_only"])

    def test_no_compression_and_singleton_ll7_text(self):
        _, _, result, verification, provenance = self.execution_bundle()
        report = render_markdown(result, verification, provenance)
        self.assertIn("Terminal", report)

    def test_genuine_non_singleton_ll7_is_distinct(self):
        _, _, result, verification, _ = self.execution_bundle()
        self.assertTrue(verification.passed)
        self.assertIn("local_status", result["stage_2"])

    def test_empty_gl_and_raw_dominance_states_are_valid(self):
        _, _, result, verification, _ = self.execution_bundle()
        self.assertTrue(verification.passed)
        self.assertIn("final_counts", result["stage_1"]["per_criterion_global_trace"])

    def test_raw_dominance_audit_is_explicitly_derived(self):
        _, _, result, _, _ = self.execution_bundle()
        self.assertEqual("DERIVED_PROFILE_CLASS_MINUS_CORE_TERMINAL", result["terminal"]["raw_dominance_audit_source"])
        self.assertIn("derived_raw_dominance_removed_ids", result["terminal"])

    def test_failed_integrity_suppresses_all_renderers(self):
        task, execution, result, _, provenance = self.execution_bundle()
        altered = copy.deepcopy(result)
        altered["terminal"]["terminal_candidate_ids"] = "c7"
        verification = self.verify(task, execution, altered)
        self.assertFalse(verification.passed)
        for renderer in (render_markdown, render_json, render_csv):
            with self.subTest(renderer=renderer.__name__):
                with self.assertRaises(AgentRejected):
                    renderer(altered, verification, provenance)
        self.assertEqual("failed_integrity", altered["status"])

    def test_markdown_json_and_csv_are_deterministic(self):
        _, _, result, verification, provenance = self.execution_bundle()
        self.assertEqual(render_markdown(result, verification, provenance), render_markdown(result, verification, provenance))
        self.assertEqual(render_json(result, verification, provenance), render_json(result, verification, provenance))
        self.assertEqual(render_csv(result, verification, provenance), render_csv(result, verification, provenance))

    def test_frozen_case_archives_are_readable_evidence_only(self):
        manifest = json.loads((ROOT / "EXTERNAL_TEST_FIXTURES.json").read_text(encoding="utf-8"))
        historical = manifest["historical_readability_test"]
        self.assertEqual("Legacy test fixture only, not current SD6 evidence", historical["role"])
        self.assertEqual(64, len(historical["sha256"]))


if __name__ == "__main__":
    unittest.main()
