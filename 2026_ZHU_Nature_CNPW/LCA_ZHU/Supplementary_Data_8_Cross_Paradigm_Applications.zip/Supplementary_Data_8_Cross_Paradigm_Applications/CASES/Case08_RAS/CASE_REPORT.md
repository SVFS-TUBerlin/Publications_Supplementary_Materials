# RAS — CNPW external application evidence package

## Scope

This package supports the claims actually reported for this published decision system in Results 2.3 and Table 1. It is **not** intended to reproduce every possible CNPW Mode-A, Mode-B, Stage-2, QCCA or relaxation branch. The evidential standard is claim-specific: each manuscript claim is linked to the frozen/reconstructed candidate–response evidence and to the supplied calculation or audit that supports it.

## Source system

- **Domain:** Video streaming
- **Candidate–response size:** 5 × 16
- **Source citation:** Thomas A. Weber (2025), Relatively Robust QoS and QoE Score Aggregation, ACIIS 2025, DOI: 10.1109/ACIIS66255.2025.11402948
- **Native decision object:** Ideal-relative worst-case robust aggregation

## Manuscript-claim verification

| ID | Claim | Verified result | Verification route |
|---|---|---|---|
| RAS-1 | Candidate space and native result | **5 × 16; RAS selects E; E maps to GL1** | Exact source matrix + native RAS reproduction |
| RAS-2 | Mode-A result | **C(J)=GL2; Mode A selects A** | Direct frozen CNPW execution |
| RAS-3 | Illustrative Mode-B convergence | **Under a CNPW-declared 50% ideal-relative retention contract, protecting Startup Delay, Packet Loss or Jitter returns E** | Source-aligned illustrative CNPW cardinal-retention contract; not a native RAS acceptance threshold |
| RAS-4 | Recovery order | **First GL3 recovery requires removing VMAF, SSIM and ER** | Exhaustive frozen-level subset reasoning; unique 13-response GL3 subset |

The machine-readable version is `CLAIM_LEDGER.csv`.

## Included source/reconstruction evidence

- `Weber_ACIIS2025_CNPW_Formal_HeadToHead.xlsx`
- `Weber_ACIIS2025_CNPW_Formal_Report.md`

## Derived claim-specific audits

- `RAS_Illustrative_ModeB_Record.md`
- `RAS_Recovery_and_ModeB_Audit.csv`

Derived audits do not introduce a new decision method. They expose the exact arithmetic or frozen-level comparison needed to verify manuscript headline claims from the supplied evidence.

## Claim boundary

The five-provider data are synthetic illustrative values. The 50% retention contract is CNPW-declared and is not a native RAS acceptance threshold.

## Interpretation

CNPW is applied as an additional qualification and candidate-space diagnostic layer. A difference between the native decision and the CNPW output is not treated as proof that the native method is incorrect; it shows that the native decision object and joint qualification answer different questions. Where the candidate space is top-compatible, the package retains that positive-control result rather than forcing a limitation diagnosis.

## Status

**CLAIM-SPECIFIC EVIDENCE COMPLETE FOR THE CURRENT MANUSCRIPT/TABLE-1 CLAIMS.**
