# Deterministic replay

Generated from the current hardened release: 140/140 six-domain Mode-B branches and 6/6 Mode-A branches passed (146/146 total). The controlled case adds 14 Mode-B branches and one Mode-A branch. Scientific projections for all seven cases matched the frozen SD6 references after excluding transport-only paths, timestamps and path-derived task hashes. Independent invariant reconstruction and mutation rejection are reported in the release-level verification report.
