# Source-paper handling

The nine published source papers are cited in the reconstruction ledger and case reports but are not redistributed inside Supplementary Data 8.

Supplementary Data 8 instead supplies the source-aligned reconstruction/execution objects required to audit the manuscript claims. Where a source candidate library, repository dataset or trajectory has a redistribution boundary, the corresponding case report records that boundary and distinguishes exact candidate-level reuse from digitized or reconstructed objects.

The native methods retain their original semantics. CNPW does not replace the source methods or reinterpret their published objectives; it adds a joint-qualification and candidate-space diagnostic layer to the reconstructed candidate populations used for the manuscript comparison.
