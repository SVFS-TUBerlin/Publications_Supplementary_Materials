# WIBA — CNPW external application evidence package

## Scope

This package supports the claims actually reported for this published decision system in Results 2.3 and Table 1. It is **not** intended to reproduce every possible CNPW Mode-A, Mode-B, Stage-2, QCCA or relaxation branch. The evidential standard is claim-specific: each manuscript claim is linked to the frozen/reconstructed candidate–response evidence and to the supplied calculation or audit that supports it.

## Source system

- **Domain:** University ranking
- **Candidate–response size:** 897 × 4
- **Source citation:** Novoa-Hernández, Pelta & Cruz Corona (2025), Helping to Choose a Robust Alternative: A Sensitivity Analysis and a Software Tool for Multi-Criteria Decision-Making, Expert Systems 42:e70031
- **Native decision object:** Preference-order robust interval ranking

## Manuscript-claim verification

| ID | Claim | Verified result | Verification route |
|---|---|---|---|
| WIBA-1 | Candidate space | **897 × 4** | Direct repository-derived frozen input |
| WIBA-2 | Native top profiles | **Oxford rank 1 → (7,7,7,5); Caltech rank 2 → (7,7,7,6); MIT rank 3/reference → (7,7,7,7)** | Direct native/CNPW mapping |
| WIBA-3 | CNPW result | **Seven universities attain (7,7,7,7)** | Direct Stage-1 record |
| WIBA-4 | Positive-control QCCA | **15/15 non-empty response subsets attain GL7** | Complete 4-response subset audit |

The machine-readable version is `CLAIM_LEDGER.csv`.

## Included source/reconstruction evidence

- `WIBA_Universities_CNPW_ModeB_v1.5.3_Execution.xlsx`
- `WIBA_Universities_CNPW_ModeB_v1.5.3_Report.md`
- `WIBA_Universities_CNPW_v1.5.2_Candidate_Audit.csv`
- `WIBA_Universities_CNPW_v1.5.2_Formal_Execution.xlsx`
- `WIBA_Universities_CNPW_v1.5.2_Formal_Report.md`

## Derived claim-specific audits

- `WIBA_Subset_Compatibility_Audit.csv`

Derived audits do not introduce a new decision method. They expose the exact arithmetic or frozen-level comparison needed to verify manuscript headline claims from the supplied evidence.

## Claim boundary

The 897-university repository matrix is used; the known source-versus-repository aggregate-count discrepancy does not alter the reproduced reference/ranking behavior.

## Interpretation

CNPW is applied as an additional qualification and candidate-space diagnostic layer. A difference between the native decision and the CNPW output is not treated as proof that the native method is incorrect; it shows that the native decision object and joint qualification answer different questions. Where the candidate space is top-compatible, the package retains that positive-control result rather than forcing a limitation diagnosis.

## Status

**CLAIM-SPECIFIC EVIDENCE COMPLETE FOR THE CURRENT MANUSCRIPT/TABLE-1 CLAIMS.**
