from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class AgentError:
    code: str
    message: str
    details: tuple[tuple[str, str], ...] = ()
    input_hash_sha256: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {"code": self.code, "message": self.message, "details": dict(self.details), "input_hash_sha256": self.input_hash_sha256}


class AgentRejected(ValueError):
    def __init__(self, error: AgentError):
        super().__init__(error.message)
        self.error = error
