# Case 03 — Electric passenger vehicles source record

- **Local archived source:** `FEV-data-Excel.xlsx`
- **Source locator:** Auta elektryczne sheet
- **Article citation:** Kubiczek, J. & Hadasik, B. *Segmentation of Passenger Electric Cars Market in Poland*. World Electric Vehicle Journal 12(1), 23 (2021). DOI: https://doi.org/10.3390/wevj12010023
- **Source dataset citation:** Hadasik, B. & Kubiczek, J. *Dataset of electric passenger cars with their specifications*. Mendeley Data, V1 (2021). DOI: https://doi.org/10.17632/tb9yrptydn.1
- **Initial source population:** 53 vehicle rows
- **Candidate filter / population rule:** All 53 vehicle models/variants retained
- **Final CNPW population:** 53
- **Active responses:** 5
- **Local source SHA256:** `2adba06cefe4af6ad62cf1c6003c78e19300252e8eace0764e6e5c6f1853345f`
- **Local source size (bytes):** 18420
- **Redistribution status:** `PROVENANCE_ONLY_ORIGINAL_NOT_BUNDLED`
- **Frozen input:** `CNPW_Electric_Vehicles_M5_Input_v0.1.xlsx`

The five selected vehicle variables and their favourable directions are recorded in `Source_to_Input_Mapping.xlsx`. The original third-party workbook is not bundled in SD4.
