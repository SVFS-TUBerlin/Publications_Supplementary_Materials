"""Manifest-driven V8 public-Agent replay; never writes frozen V0.1 evidence."""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from agent.dual_coordinator import DualAnalysisCoordinator
from agent.integrated_report import render_integrated_json, render_presentation_markdown
from src.input_loader import load_dataset

MANIFEST = ROOT / "tests_replay" / "manifest.json"
OUTPUT = ROOT / "Cross_Domain_Validation" / "V8_Replay_Output"


def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def compact(counter): return "; ".join(f"{key}:{value}" for key, value in sorted(counter.items()))


def scrub(value):
    if isinstance(value, dict): return {k: scrub(v) for k, v in value.items() if k != "execution_timestamp"}
    if isinstance(value, list): return [scrub(item) for item in value]
    return value


def action_count(branch): return len(branch.get("targeted_actions", ()))


def branch_row(index, branch):
    result = branch.get("verified_result")
    if result is None:
        return [index, branch["contract_id"], "", "", "", "", "", "", "", "", "", "", "", "FAILED", "", "", "FAILED"]
    c, s1, s2, t = result["mode_b_conditioning"], result["stage_1"], result["stage_2"], result["terminal"]
    local = branch.get("local_qcca")
    return [index, branch["contract_id"], " | ".join(c["protected_block"]), len(c["protected_indices"]), c["k_p"], c["protected_count"], s1["highest_joint_level"], len(s1["retained_candidate_ids"]), s2["k_l"], s2["local_status"], s2["highest_joint_level"] if s2["local_qcca_required"] else "", " | ".join(t["terminal_candidate_ids"]), branch["global_qcca"].status, local.status if local else "NOT_REQUIRED", len(local.result.target_recoveries) if local and local.status == "COMPLETED" else 0, action_count(branch), branch["verification"].status]


def write_case(case, dual, elapsed):
    target = OUTPUT / case["id"]
    target.mkdir(parents=True, exist_ok=True)
    source = ROOT / case["input"]
    technical = json.loads(render_integrated_json(dual))
    (target / "V8_Integrated_Report.json").write_text(json.dumps(technical, ensure_ascii=False, sort_keys=True, indent=2), encoding="utf-8")
    (target / "V8_Integrated_Report.md").write_text(render_presentation_markdown(dual, display_filename=source.name), encoding="utf-8")
    headers = ["contract_index", "contract_id", "protected_block", "protected_block_size", "k_p", "omega_count", "conditional_c_g", "w1_count", "k_l", "local_status", "c_l", "terminal_ids", "global_qcca_status", "local_qcca_status", "higher_q_target_count", "action_route_count", "verification_status"]
    with (target / "Mode_B_Contracts.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle); writer.writerow(headers)
        for index, branch in enumerate(dual["mode_b_contracts"], 1): writer.writerow(branch_row(index, branch))
    with (target / "QCCA_Action_Summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle); writer.writerow(["branch", "global_qcca", "local_qcca", "target", "recovery_set", "action_witnesses", "action_verified"])
        for label, branch in [("MODE_A", dual["mode_a"]), *[(f"MODE_B_{i}", branch) for i, branch in enumerate(dual["mode_b_contracts"], 1)]]:
            global_status = branch.get("global_qcca").status if branch.get("global_qcca") else "UNAVAILABLE"
            local_status = branch.get("local_qcca").status if branch.get("local_qcca") else "NOT_REQUIRED"
            actions = branch.get("targeted_actions", ())
            if not actions: writer.writerow([label, global_status, local_status, "", "", "", ""])
            for action in actions: writer.writerow([label, global_status, local_status, action["target"], " | ".join(action["recovery"].removed_responses), " | ".join(x.candidate_id for x in action["result"].alternatives), action["verified"]])
    a = dual["mode_a"]["verified_result"]
    (target / "Mode_A_Summary.json").write_text(json.dumps({"global_capability": a["stage_1"]["highest_joint_level"], "w1_count": len(a["stage_1"]["retained_candidate_ids"]), "local_status": a["stage_2"]["local_status"], "k_l": a["stage_2"]["k_l"], "local_capability": a["stage_2"]["highest_joint_level"], "terminal_ids": a["terminal"]["terminal_candidate_ids"], "local_qcca_required": a["stage_2"]["local_qcca_required"], "action_routes": action_count(dual["mode_a"])}, indent=2), encoding="utf-8")
    hashes = {path.name: digest(path) for path in sorted(target.iterdir()) if path.is_file()}
    provenance = {"input_path": case["input"], "input_sha256": digest(source), "case_id": case["id"], "runtime_seconds_diagnostic": round(elapsed, 6), "deterministic_output_hashes": hashes, "complete_verification": dual["complete_verification"].to_dict()}
    (target / "Replay_Provenance.json").write_text(json.dumps(provenance, sort_keys=True, indent=2), encoding="utf-8")
    results = [branch["verified_result"] for branch in dual["mode_b_contracts"] if branch.get("verified_result")]
    return {"Case": case["name"], "N": case["n"], "M": case["m"], "Mode-A C_G": a["stage_1"]["highest_joint_level"], "Mode-A W1": len(a["stage_1"]["retained_candidate_ids"]), "Mode-A Local": a["stage_2"]["local_status"], "Mode-A terminal": " | ".join(a["terminal"]["terminal_candidate_ids"]), "Mode-B expected": case["mode_b_contracts"], "Mode-B actual": len(dual["mode_b_contracts"]), "Mode-B verified": sum(branch["verification"].passed for branch in dual["mode_b_contracts"]), "Mode-B C_G distribution": compact(Counter(f"GL{x['stage_1']['highest_joint_level']}" for x in results)), "Mode-B Local distribution": compact(Counter(f"{x['stage_2']['local_status']}:LL{x['stage_2']['highest_joint_level']}" for x in results)), "Mode-B unique/co-terminal": f"{sum(len(x['terminal']['terminal_candidate_ids']) == 1 for x in results)}/{sum(len(x['terminal']['terminal_candidate_ids']) > 1 for x in results)}", "QCCA-required": sum(x["stage_2"]["local_qcca_required"] for x in results), "Action-producing": sum(action_count(b) > 0 for b in dual["mode_b_contracts"]), "Complete verification": dual["complete_verification"].status}


def main():
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    OUTPUT.mkdir(parents=True, exist_ok=True)
    (OUTPUT / "Replay_Manifest.json").write_text(json.dumps(manifest, sort_keys=True, indent=2), encoding="utf-8")
    rows, log = [], []
    coordinator = DualAnalysisCoordinator(ROOT)
    for case in manifest["cases"]:
        source = ROOT / case["input"]
        dataset = load_dataset(source)
        if (len(dataset.candidate_ids), len(dataset.criteria)) != (case["n"], case["m"]): raise RuntimeError(f"Manifest mismatch: {case['id']}")
        started = time.perf_counter(); first = coordinator.execute(source); elapsed = time.perf_counter() - started
        if first.error or first.result is None: raise RuntimeError(f"Public execution failed: {case['id']}: {first.error}")
        second = coordinator.execute(source)
        if second.error or scrub(json.loads(render_integrated_json(first.result))) != scrub(json.loads(render_integrated_json(second.result))): raise RuntimeError(f"Non-deterministic replay: {case['id']}")
        rows.append(write_case(case, first.result, elapsed)); log.append(f"{case['id']}: PASS; N={case['n']}; M={case['m']}; Mode-B={len(first.result['mode_b_contracts'])}; runtime={elapsed:.3f}s")
    fields = list(rows[0])
    with (OUTPUT / "Six_Domain_V8_Master_Ledger.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader(); writer.writerows(rows)
    total_b = sum(row["Mode-B actual"] for row in rows)
    (OUTPUT / "Six_Domain_V8_Replay_Report.md").write_text("# CNPW V8 Six-Domain Replay\n\n- Cases: 6\n- Expected/actual Mode-A branches: 6/6\n- Expected/actual Mode-B contracts: 140/" + str(total_b) + "\n- Expected/actual decision branches: 146/" + str(6 + total_b) + "\n- Every case was executed twice through the public V8 Agent; deterministic scientific exports matched after timestamp removal.\n\nNo contract is ranked; the replay validates the shared CNPW contract across heterogeneous inputs, not universal scientific applicability or causality.\n", encoding="utf-8")
    (OUTPUT / "V8_vs_V0_1_Cross_Domain_Comparison.md").write_text("# V8 versus V0.1 Cross-Domain Comparison\n\nV0.1 evidence is preserved and is not a V8 regression oracle. For all six cases, Mode A is directly comparable where historical outputs exist; retired V0.1 residual-response Mode B is **NOT DIRECTLY COMPARABLE** with the V8 equal-count protected-block family. V8 adds complete contract-family enumeration, frozen-domain QCCA/recovery/action evidence, and non-ranking reports. Any output difference is therefore classified **EXPECTED V8 CHANGE** unless a separate technical verification failure is recorded.\n", encoding="utf-8")
    (OUTPUT / "Replay_Verification.log").write_text("\n".join(log) + "\n", encoding="utf-8")


if __name__ == "__main__": main()
