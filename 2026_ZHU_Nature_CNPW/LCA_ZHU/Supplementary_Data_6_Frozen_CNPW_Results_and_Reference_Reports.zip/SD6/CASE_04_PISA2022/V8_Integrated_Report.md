# CNPW V8 Integrated Analysis Report

## 1. Input and scientific contract

- Filename: CNPW_Case04_PISA2022_81x3_Input_v0.1.xlsx
- N: 81 · M: 3
- Responses, declared order: Mathematics mean score, Reading mean score, Science mean score
- One-click execution: Mode A plus every non-empty proper equal-count protected-response block.
- CNPW selects first; any percentages are reporting-only and never influence qualification, QCCA, recovery, or alternatives.

## 2. Mode A

### Mode A deterministic state

- Full-system Global capability: GL7 · |W¹|=9
- All-response Local state: resolved_unique_all_top_local · K_L=7
- Terminal/co-terminal candidates: Singapore

## 3. Mode-B protected-domain contract landscape

Protection determines admissibility; residual responses determine Stage-1 conditional capability; all active responses re-enter Stage-2 Local refinement.
Rows follow protected-block cardinality and declared response order. They are not ranked. Ω_P is the protected admissible population; W_B¹ is the residual Stage-1 retained population.

| Contract | Protected block | k_P | Ω_P size | Residual Stage-1 capability | W_B¹ size | All-response Local state / C_L | Terminal/co-terminal | QCCA/action |
|---|---|---:|---:|---:|---:|---|---|---|
| 1452b50e53ef | Mathematics mean score | GL7 | 15 | GL7 | 9 | resolved_unique_all_top_local | Singapore | NOT_REQUIRED |
| 686b1b00875c | Reading mean score | GL7 | 12 | GL7 | 9 | resolved_unique_all_top_local | Singapore | NOT_REQUIRED |
| d2cc38ee0a25 | Science mean score | GL7 | 12 | GL7 | 9 | resolved_unique_all_top_local | Singapore | NOT_REQUIRED |
| 3e9ae550e9e7 | Mathematics mean score + Reading mean score | GL7 | 9 | GL7 | 9 | resolved_unique_all_top_local | Singapore | NOT_REQUIRED |
| 18e7f611b3f6 | Mathematics mean score + Science mean score | GL7 | 9 | GL7 | 9 | resolved_unique_all_top_local | Singapore | NOT_REQUIRED |
| 40feecd9c473 | Reading mean score + Science mean score | GL7 | 11 | GL7 | 9 | resolved_unique_all_top_local | Singapore | NOT_REQUIRED |

## 4. QCCA diagnosis and QCCA-guided alternatives

Global QCCA diagnoses (X, J, G) for Mode A and (Ω_P, J_res, G) for Mode B, excluding protected responses only from the residual Global system. Local QCCA uses all active responses J on frozen W¹, only for a Core-declared Local collapse. Recovery sets and targeted alternatives preserve all equal formal routes; none is preferred.

## 5. Verification and provenance

- Complete public-run verification: PASS.
- Expected/actual Mode-B contracts: 6/6.
- Every Mode-B contract has a deterministic content-derived identity and reuses the frozen full-population Global matrix.

## 6. AI-assisted interpretation

AI-assisted interpretation: Unavailable in this execution.

## 7. Limitations

A protected response with a lower Local position remains inside its Stage-1 protected domain; this does not relax or invalidate the protection contract. No weights, scores, preferred contract, preferred recovery set, preferred alternative, SHAP, connectivity, boundary, or process interpretation is provided.