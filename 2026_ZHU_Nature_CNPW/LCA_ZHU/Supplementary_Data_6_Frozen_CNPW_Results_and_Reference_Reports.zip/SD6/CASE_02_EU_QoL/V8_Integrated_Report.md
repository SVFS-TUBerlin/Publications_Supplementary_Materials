# CNPW V8 Integrated Analysis Report

## 1. Input and scientific contract

- Filename: CNPW_H2_EU_Quality_of_Life_Cities_2023_M5_Input_v0.1.xlsx
- N: 83 · M: 5
- Responses, declared order: Overall city satisfaction, Public transport satisfaction, Good job opportunities, Safety walking alone at night, Affordable good housing
- One-click execution: Mode A plus every non-empty proper equal-count protected-response block.
- CNPW selects first; any percentages are reporting-only and never influence qualification, QCCA, recovery, or alternatives.

## 2. Mode A

### Mode A deterministic state

- Full-system Global capability: GL4 · |W¹|=7
- All-response Local state: local_qcca_required · K_L=7 · C_L=LL1
- Terminal/co-terminal candidates: Gdańsk

## 3. Mode-B protected-domain contract landscape

Protection determines admissibility; residual responses determine Stage-1 conditional capability; all active responses re-enter Stage-2 Local refinement.
Rows follow protected-block cardinality and declared response order. They are not ranked. Ω_P is the protected admissible population; W_B¹ is the residual Stage-1 retained population.

| Contract | Protected block | k_P | Ω_P size | Residual Stage-1 capability | W_B¹ size | All-response Local state / C_L | Terminal/co-terminal | QCCA/action |
|---|---|---:|---:|---:|---:|---|---|---|
| b494985968b8 | Overall city satisfaction | GL7 | 12 | GL4 | 4 | local_qcca_required / LL2 | Gdańsk | COMPLETED |
| b56cdf0dcbcc | Public transport satisfaction | GL7 | 12 | GL4 | 2 | local_qcca_required / LL1 | Strasbourg | COMPLETED |
| eff9cbb45783 | Good job opportunities | GL7 | 12 | GL4 | 1 | resolved_unique_highest_global | Cluj-Napoca | NOT_REQUIRED |
| 630067684dc3 | Safety walking alone at night | GL7 | 12 | GL4 | 1 | resolved_unique_highest_global | Aalborg | NOT_REQUIRED |
| 18dd57ebf2c5 | Affordable good housing | GL7 | 12 | GL4 | 1 | resolved_unique_highest_global | Aalborg | NOT_REQUIRED |
| 0b8f26b0eb40 | Overall city satisfaction + Public transport satisfaction | GL7 | 4 | GL2 | 1 | resolved_unique_highest_global | Rostock | NOT_REQUIRED |
| e1a9f8724d05 | Overall city satisfaction + Good job opportunities | GL7 | 2 | GL4 | 1 | resolved_unique_highest_global | Cluj-Napoca | NOT_REQUIRED |
| 59aeb6d41217 | Overall city satisfaction + Safety walking alone at night | GL7 | 5 | GL3 | 1 | resolved_unique_highest_global | Groningen | NOT_REQUIRED |
| 874fb5aa6d6d | Overall city satisfaction + Affordable good housing | GL6 | 6 | GL4 | 3 | local_qcca_required / LL1 | Aalborg | COMPLETED |
| c75ed1b0d241 | Public transport satisfaction + Good job opportunities | GL7 | 4 | GL3 | 1 | resolved_unique_highest_global | Oslo | NOT_REQUIRED |
| 05c8a200bd85 | Public transport satisfaction + Safety walking alone at night | GL7 | 4 | GL3 | 1 | resolved_unique_highest_global | Oslo | NOT_REQUIRED |
| 64617d1e542c | Public transport satisfaction + Affordable good housing | GL6 | 2 | GL4 | 1 | resolved_unique_highest_global | Rennes | NOT_REQUIRED |
| 792fcd13ae4b | Good job opportunities + Safety walking alone at night | GL7 | 2 | GL3 | 1 | resolved_unique_highest_global | Oslo | NOT_REQUIRED |
| 33fb8cfdd069 | Good job opportunities + Affordable good housing | GL6 | 2 | GL2 | 1 | resolved_unique_highest_global | Antalya | NOT_REQUIRED |
| 43a3fa22eba0 | Safety walking alone at night + Affordable good housing | GL7 | 4 | GL4 | 1 | resolved_unique_highest_global | Aalborg | NOT_REQUIRED |
| 702f5509b3b3 | Overall city satisfaction + Public transport satisfaction + Good job opportunities | GL7 | 1 | GL1 | 1 | resolved_unique_highest_global | Stockholm | NOT_REQUIRED |
| e334938e16bf | Overall city satisfaction + Public transport satisfaction + Safety walking alone at night | GL7 | 2 | GL1 | 2 | local_qcca_required / LL1 | Zürich | COMPLETED |
| 099983543a19 | Overall city satisfaction + Public transport satisfaction + Affordable good housing | GL6 | 1 | GL4 | 1 | resolved_unique_highest_global | Rennes | NOT_REQUIRED |
| 159771e1129d | Overall city satisfaction + Good job opportunities + Safety walking alone at night | GL7 | 1 | GL1 | 1 | resolved_unique_highest_global | Stockholm | NOT_REQUIRED |
| a91030cc87a3 | Overall city satisfaction + Good job opportunities + Affordable good housing | GL5 | 4 | GL4 | 2 | local_qcca_required / LL1 | Rennes | COMPLETED |
| db08655c3072 | Overall city satisfaction + Safety walking alone at night + Affordable good housing | GL6 | 2 | GL4 | 1 | resolved_unique_highest_global | Aalborg | NOT_REQUIRED |
| 14870c9239df | Public transport satisfaction + Good job opportunities + Safety walking alone at night | GL7 | 2 | GL3 | 1 | resolved_unique_highest_global | Oslo | NOT_REQUIRED |
| c8bf2d2361f8 | Public transport satisfaction + Good job opportunities + Affordable good housing | GL5 | 2 | GL4 | 1 | resolved_unique_highest_global | Rennes | NOT_REQUIRED |
| 18d95d5314f6 | Public transport satisfaction + Safety walking alone at night + Affordable good housing | GL5 | 3 | GL3 | 1 | resolved_unique_highest_global | Groningen | NOT_REQUIRED |
| 8a851b9bbe35 | Good job opportunities + Safety walking alone at night + Affordable good housing | GL6 | 1 | GL2 | 1 | resolved_unique_highest_global | Antalya | NOT_REQUIRED |
| b748820c5bab | Overall city satisfaction + Public transport satisfaction + Good job opportunities + Safety walking alone at night | GL7 | 1 | GL1 | 1 | resolved_unique_highest_global | Stockholm | NOT_REQUIRED |
| 0ac1309ef48d | Overall city satisfaction + Public transport satisfaction + Good job opportunities + Affordable good housing | GL5 | 2 | GL4 | 1 | resolved_unique_highest_global | Rennes | NOT_REQUIRED |
| be26e1bc1a0c | Overall city satisfaction + Public transport satisfaction + Safety walking alone at night + Affordable good housing | GL5 | 2 | GL3 | 1 | resolved_unique_highest_global | Groningen | NOT_REQUIRED |
| 31685ff540c0 | Overall city satisfaction + Good job opportunities + Safety walking alone at night + Affordable good housing | GL5 | 2 | GL4 | 1 | resolved_unique_highest_global | Aalborg | NOT_REQUIRED |
| aef47623bf9d | Public transport satisfaction + Good job opportunities + Safety walking alone at night + Affordable good housing | GL4 | 7 | GL7 | 4 | local_qcca_required / LL2 | Gdańsk | COMPLETED |

## 4. QCCA diagnosis and QCCA-guided alternatives

Global QCCA diagnoses (X, J, G) for Mode A and (Ω_P, J_res, G) for Mode B, excluding protected responses only from the residual Global system. Local QCCA uses all active responses J on frozen W¹, only for a Core-declared Local collapse. Recovery sets and targeted alternatives preserve all equal formal routes; none is preferred.

### Mode A Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Public transport satisfaction}; witnesses: Aalborg.
- Target LL2; recovery set {Safety walking alone at night}; witnesses: Rennes.
- Target LL2; recovery set {Affordable good housing}; witnesses: Gdańsk, Cluj-Napoca.
- Target LL3; recovery set {Safety walking alone at night}; witnesses: Rennes.
- Target LL3; recovery set {Affordable good housing}; witnesses: Gdańsk, Cluj-Napoca.
- Target LL4; recovery set {Affordable good housing}; witnesses: Gdańsk.
- Target LL5; recovery set {Affordable good housing}; witnesses: Gdańsk.
- Target LL6; recovery set {Overall city satisfaction, Public transport satisfaction, Good job opportunities}; witnesses: Aalborg.
- Target LL6; recovery set {Public transport satisfaction, Safety walking alone at night, Affordable good housing}; witnesses: Cluj-Napoca.
- Target LL6; recovery set {Good job opportunities, Safety walking alone at night, Affordable good housing}; witnesses: Rennes.
- Target LL7; recovery set {Overall city satisfaction, Public transport satisfaction, Good job opportunities}; witnesses: Aalborg.

### Mode B b494985968b8 Local QCCA

- Baseline C_L: LL2; targets: LL3, LL4, LL5, LL6, LL7.
- Target LL3; recovery set {Affordable good housing}; witnesses: Gdańsk.
- Target LL4; recovery set {Affordable good housing}; witnesses: Gdańsk.
- Target LL5; recovery set {Good job opportunities, Affordable good housing}; witnesses: Gdańsk.
- Target LL6; recovery set {Overall city satisfaction, Public transport satisfaction, Affordable good housing}; witnesses: Cluj-Napoca.
- Target LL6; recovery set {Overall city satisfaction, Good job opportunities, Safety walking alone at night}; witnesses: Rennes.
- Target LL6; recovery set {Public transport satisfaction, Good job opportunities, Affordable good housing}; witnesses: Gdańsk.
- Target LL7; recovery set {Overall city satisfaction, Public transport satisfaction, Affordable good housing}; witnesses: Cluj-Napoca.
- Target LL7; recovery set {Overall city satisfaction, Good job opportunities, Safety walking alone at night}; witnesses: Rennes.
- Target LL7; recovery set {Public transport satisfaction, Good job opportunities, Affordable good housing}; witnesses: Gdańsk.

### Mode B b56cdf0dcbcc Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Public transport satisfaction, Affordable good housing}; witnesses: Strasbourg.
- Target LL3; recovery set {Public transport satisfaction, Affordable good housing}; witnesses: Strasbourg.
- Target LL4; recovery set {Public transport satisfaction, Affordable good housing}; witnesses: Strasbourg.
- Target LL5; recovery set {Public transport satisfaction, Affordable good housing}; witnesses: Strasbourg.
- Target LL6; recovery set {Public transport satisfaction, Affordable good housing}; witnesses: Strasbourg.
- Target LL7; recovery set {Public transport satisfaction, Affordable good housing}; witnesses: Strasbourg.

### Mode B 874fb5aa6d6d Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Overall city satisfaction}; witnesses: Aalborg.
- Target LL3; recovery set {Overall city satisfaction, Public transport satisfaction}; witnesses: Aalborg.
- Target LL3; recovery set {Safety walking alone at night, Affordable good housing}; witnesses: Rennes.
- Target LL4; recovery set {Overall city satisfaction, Public transport satisfaction}; witnesses: Aalborg.
- Target LL4; recovery set {Safety walking alone at night, Affordable good housing}; witnesses: Rennes.
- Target LL5; recovery set {Safety walking alone at night, Affordable good housing}; witnesses: Rennes.
- Target LL6; recovery set {Safety walking alone at night, Affordable good housing}; witnesses: Rennes.
- Target LL7; recovery set {Safety walking alone at night, Affordable good housing}; witnesses: Rennes.

### Mode B e334938e16bf Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Good job opportunities}; witnesses: Zürich.
- Target LL3; recovery set {Good job opportunities}; witnesses: Zürich.
- Target LL4; recovery set {Good job opportunities}; witnesses: Zürich.
- Target LL5; recovery set {Good job opportunities}; witnesses: Zürich.
- Target LL6; recovery set {Good job opportunities}; witnesses: Zürich.
- Target LL7; recovery set {Good job opportunities}; witnesses: Zürich.

### Mode B a91030cc87a3 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Safety walking alone at night, Affordable good housing}; witnesses: Rennes.
- Target LL3; recovery set {Safety walking alone at night, Affordable good housing}; witnesses: Rennes.
- Target LL4; recovery set {Safety walking alone at night, Affordable good housing}; witnesses: Rennes.
- Target LL5; recovery set {Safety walking alone at night, Affordable good housing}; witnesses: Rennes.
- Target LL6; recovery set {Safety walking alone at night, Affordable good housing}; witnesses: Rennes.
- Target LL7; recovery set {Safety walking alone at night, Affordable good housing}; witnesses: Rennes.

### Mode B aef47623bf9d Local QCCA

- Baseline C_L: LL2; targets: LL3, LL4, LL5, LL6, LL7.
- Target LL3; recovery set {Affordable good housing}; witnesses: Gdańsk.
- Target LL4; recovery set {Affordable good housing}; witnesses: Gdańsk.
- Target LL5; recovery set {Good job opportunities, Affordable good housing}; witnesses: Gdańsk.
- Target LL6; recovery set {Overall city satisfaction, Public transport satisfaction, Affordable good housing}; witnesses: Cluj-Napoca.
- Target LL6; recovery set {Overall city satisfaction, Good job opportunities, Safety walking alone at night}; witnesses: Rennes.
- Target LL6; recovery set {Public transport satisfaction, Good job opportunities, Affordable good housing}; witnesses: Gdańsk.
- Target LL7; recovery set {Overall city satisfaction, Public transport satisfaction, Affordable good housing}; witnesses: Cluj-Napoca.
- Target LL7; recovery set {Overall city satisfaction, Good job opportunities, Safety walking alone at night}; witnesses: Rennes.
- Target LL7; recovery set {Public transport satisfaction, Good job opportunities, Affordable good housing}; witnesses: Gdańsk.

## 5. Verification and provenance

- Complete public-run verification: PASS.
- Expected/actual Mode-B contracts: 30/30.
- Every Mode-B contract has a deterministic content-derived identity and reuses the frozen full-population Global matrix.

## 6. AI-assisted interpretation

AI-assisted interpretation: Unavailable in this execution.

## 7. Limitations

A protected response with a lower Local position remains inside its Stage-1 protected domain; this does not relax or invalidate the protection contract. No weights, scores, preferred contract, preferred recovery set, preferred alternative, SHAP, connectivity, boundary, or process interpretation is provided.