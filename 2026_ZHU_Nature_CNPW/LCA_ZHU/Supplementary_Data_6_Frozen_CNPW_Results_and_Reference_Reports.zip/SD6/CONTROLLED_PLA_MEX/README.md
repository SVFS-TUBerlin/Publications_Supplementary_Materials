# Controlled PLA-MEX

Contract: V8_RESIDUAL_MODEB. Global Mode B: (Omega_P,J_res,G); Local: (W1,J,L). Full JSON contains all scientific traces, recovery and action results.
