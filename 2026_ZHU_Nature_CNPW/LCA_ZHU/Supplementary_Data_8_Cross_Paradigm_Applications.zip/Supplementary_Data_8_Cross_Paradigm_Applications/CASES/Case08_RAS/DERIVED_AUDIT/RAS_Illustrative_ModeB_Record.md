# RAS — claim-specific illustrative Mode-B record

## Purpose

This record supports the limited manuscript statement that CNPW Mode B can recover the native RAS choice under an explicitly declared cardinal-retention contract.

It is **not** a claim that RAS itself uses this threshold.

## Contract

The source RAS method evaluates worst-case ideal-relative performance. To compare this cardinal semantics with CNPW protection, an illustrative CNPW retention requirement of

\[
\alpha=0.5
\]

was applied separately to source criteria.

## Result

At \(\alpha=0.5\), the conditional CNPW terminal remains A for 13 of the 16 individually protected criteria, but changes to E when the protected criterion is:

- Startup Delay;
- Packet Loss Rate;
- Jitter.

These E outcomes were reported as stable for the tested global resolutions \(K_g=3,4,5\).

Thus the manuscript statement “Mode B recovers E” refers to a **CNPW-declared illustrative cardinal-protection contract** under which the CNPW recommendation converges with the native RAS choice.

## Boundary

The 50% retention level is descriptive and was introduced by CNPW for comparison. It is not a native RAS acceptance threshold and should not be presented as source semantics.
