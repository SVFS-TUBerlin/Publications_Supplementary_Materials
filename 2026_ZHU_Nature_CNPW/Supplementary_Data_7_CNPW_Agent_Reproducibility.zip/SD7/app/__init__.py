"""Local Streamlit presentation layer for the bounded CNPW Scientific Agent."""
