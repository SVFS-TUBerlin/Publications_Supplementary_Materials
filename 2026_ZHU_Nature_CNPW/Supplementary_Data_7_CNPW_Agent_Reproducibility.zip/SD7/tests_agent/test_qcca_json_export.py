import json, unittest
from pathlib import Path
from agent.dual_coordinator import DualAnalysisCoordinator
from agent.integrated_report import render_integrated_json
ROOT=Path(__file__).resolve().parents[1]
class QccaJsonTests(unittest.TestCase):
 def test_tuple_keyed_qcca_exports_as_deterministic_records(self):
  d=DualAnalysisCoordinator(ROOT).execute(ROOT/'examples'/'example_m3.csv').result; a=render_integrated_json(d); b=render_integrated_json(d); x=json.loads(a)
  self.assertEqual(a,b); q=x['qcca']['result'];self.assertIn('full_system_ceiling',q);self.assertIsInstance(q['subset_ceilings'][0]['criteria'],list);self.assertIn('leave_one_out_recoveries',q);self.assertIn('bottleneck_state',q)
