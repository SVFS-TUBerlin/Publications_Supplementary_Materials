from .models import Dataset, RunResult
from .stage1 import assign_stage1
from .stage2 import adaptive_stage2
from .terminal import prune_terminal


def finish_from_stage1(dataset: Dataset, mode: str, stage1, protected=None) -> RunResult:
    """Complete frozen W(1) without permitting any Stage-1 backfill."""
    criteria = list(range(len(dataset.criteria)))
    stage2 = adaptive_stage2(dataset, stage1.retained, criteria)
    if stage2.local_status == "local_qcca_required":
        profile_class, terminal = prune_terminal(dataset, stage2.retained, stage2.ll, criteria)
    elif stage2.local_status == "co_terminal_response_equivalent":
        profile_class = terminal = list(stage2.retained)
    elif stage2.local_status == "resolved_unique_highest_global":
        profile_class = terminal = list(stage1.retained)
    else:
        profile_class = terminal = [i for i in stage1.retained if all(stage2.ll[i][j] == stage2.k_l for j in criteria)]
    return RunResult(mode, stage1, stage2, profile_class, terminal, protected, len(terminal) > 1, stage2.response_equivalent)


def run_mode_a(dataset: Dataset) -> RunResult:
    return finish_from_stage1(dataset, "Mode A — Equal Importance", assign_stage1(dataset))
