# NAUTILI Forestry — Published Process Digitization × CNPW v1.5.2

## Status

**Phase 1 (published-process reconstruction): PASS at plot-digitized resolution.**  
**Phase 2 (stepwise NAUTILI × CNPW comparison): PASS as a digitization-based audit.**  
**Exact numerical reproduction: NOT claimed.**

The 2026 paper reports a 9-step NAUTILI group decision process. Figure 3 is used here to digitize the three DMs' aspiration levels, the colored reachable ranges, and the final red Pareto solution. Because the paper does not provide the full numerical trajectory in tabular form, all Figure-3-derived values in this report are approximate.

A ±2-pixel horizontal tolerance is separately audited when testing joint attainability. The objective-scale equivalents are:

- Rev: ±1.059 million €
- HA: ±50.239
- Carb: ±9.894 thousand Mg C
- DW: ±0.842 thousand m³

## 1. Key direct comparison

The most important empirical result is not a "winner", but a difference in decision semantics.

Across all 9 preference rows:

- the **mean of the three DMs' digitized aspiration vectors is never jointly attained by one of the 9,061 candidates**, even after the ±2-pixel tolerance (`0/9` rows have a non-zero full four-objective intersection);
- the vector formed by taking the **four marginal upper reachable endpoints simultaneously is also never jointly attained**, even after the same tolerance (`0/9` rows have a non-zero full intersection).

Thus, on the same finite forestry Pareto library:

\[
\boxed{\text{objective-wise reachable maxima}\neq\text{one jointly attainable solution}}
\]

This is fully consistent with the NAUTILI interpretation of reachable ranges and is exactly the distinction CNPW's joint-intersection logic can expose.

## 2. Stepwise joint-attainability audit

The last two columns are based on the ±2-pixel digitization tolerance. "Largest feasible subsets" reports the highest-dimensional aspiration subset for which at least one actual candidate exists.

| Figure row | Target | Full count (strict) | Full count (±2 px) | Max feasible subset size | Largest feasible subsets (±2 px) |
|---|---|---:|---:|---:|---|
| Initial | DM1 | 0 | 0 | 3 | Rev+HA+DW (268); HA+Carb+DW (7520) |
| Initial | DM2 | 95 | 262 | 4 | Rev+HA+Carb+DW (262) |
| Initial | DM3 | 0 | 0 | 1 | Rev (19); HA (1412); Carb (641); DW (1030) |
| Initial | MeanPref | 0 | 0 | 3 | Rev+HA+DW (122); HA+Carb+DW (2835) |
| Initial | MarginalUpper | 0 | 0 | 2 | HA+DW (22) |
| Step 1 | DM1 | 0 | 0 | 3 | Rev+HA+DW (302); HA+Carb+DW (7522) |
| Step 1 | DM2 | 110 | 267 | 4 | Rev+HA+Carb+DW (267) |
| Step 1 | DM3 | 0 | 0 | 1 | Rev (80); HA (1398); Carb (516); DW (973) |
| Step 1 | MeanPref | 0 | 0 | 3 | Rev+HA+DW (115); HA+Carb+DW (2775) |
| Step 1 | MarginalUpper | 0 | 0 | 2 | HA+DW (22) |
| Step 2 | DM1 | 0 | 0 | 3 | Rev+HA+DW (316); HA+Carb+DW (7511) |
| Step 2 | DM2 | 0 | 0 | 3 | Rev+HA+DW (22); HA+Carb+DW (2105) |
| Step 2 | DM3 | 0 | 0 | 2 | Carb+DW (18) |
| Step 2 | MeanPref | 0 | 0 | 3 | Rev+HA+DW (56); HA+Carb+DW (3679) |
| Step 2 | MarginalUpper | 0 | 0 | 2 | HA+DW (24); Carb+DW (46) |
| Step 3 | DM1 | 0 | 0 | 3 | Rev+HA+DW (307); HA+Carb+DW (7522) |
| Step 3 | DM2 | 0 | 2 | 4 | Rev+HA+Carb+DW (2) |
| Step 3 | DM3 | 0 | 0 | 2 | HA+Carb (7); Carb+DW (793) |
| Step 3 | MeanPref | 0 | 0 | 3 | Rev+HA+DW (65); HA+Carb+DW (5273) |
| Step 3 | MarginalUpper | 0 | 0 | 3 | HA+Carb+DW (7) |
| Step 4 | DM1 | 0 | 0 | 3 | Rev+HA+DW (274); HA+Carb+DW (7522) |
| Step 4 | DM2 | 0 | 0 | 3 | Rev+HA+DW (4); Rev+Carb+DW (1); HA+Carb+DW (4138) |
| Step 4 | DM3 | 0 | 0 | 3 | HA+Carb+DW (163) |
| Step 4 | MeanPref | 0 | 0 | 3 | Rev+HA+DW (68); HA+Carb+DW (5603) |
| Step 4 | MarginalUpper | 0 | 0 | 3 | HA+Carb+DW (288) |
| Step 5 | DM1 | 0 | 0 | 3 | Rev+HA+DW (304); HA+Carb+DW (7519) |
| Step 5 | DM2 | 0 | 0 | 3 | Rev+Carb+DW (1); HA+Carb+DW (3739) |
| Step 5 | DM3 | 0 | 0 | 3 | HA+Carb+DW (257) |
| Step 5 | MeanPref | 0 | 0 | 3 | Rev+HA+DW (79); HA+Carb+DW (5562) |
| Step 5 | MarginalUpper | 0 | 0 | 3 | HA+Carb+DW (2391) |
| Step 6 | DM1 | 0 | 0 | 3 | Rev+HA+DW (267); HA+Carb+DW (7522) |
| Step 6 | DM2 | 0 | 0 | 3 | HA+Carb+DW (4167) |
| Step 6 | DM3 | 0 | 0 | 3 | HA+Carb+DW (1487) |
| Step 6 | MeanPref | 0 | 0 | 3 | Rev+HA+DW (81); HA+Carb+DW (5965) |
| Step 6 | MarginalUpper | 0 | 0 | 3 | HA+Carb+DW (4134) |
| Step 7 | DM1 | 0 | 0 | 3 | HA+Carb+DW (4028) |
| Step 7 | DM2 | 0 | 0 | 3 | HA+Carb+DW (4168) |
| Step 7 | DM3 | 0 | 0 | 3 | HA+Carb+DW (1585) |
| Step 7 | MeanPref | 0 | 0 | 3 | HA+Carb+DW (4049) |
| Step 7 | MarginalUpper | 0 | 0 | 3 | HA+Carb+DW (4247) |
| Step 8 | DM1 | 0 | 0 | 3 | Rev+HA+DW (254); HA+Carb+DW (6673) |
| Step 8 | DM2 | 0 | 0 | 3 | Rev+HA+DW (6); HA+Carb+DW (5257) |
| Step 8 | DM3 | 0 | 0 | 3 | Rev+HA+DW (129); HA+Carb+DW (6277) |
| Step 8 | MeanPref | 0 | 0 | 3 | Rev+HA+DW (121); HA+Carb+DW (6248) |
| Step 8 | MarginalUpper | 0 | 0 | 3 | Rev+HA+DW (8); Rev+Carb+DW (1); HA+Carb+DW (5216) |

Important interpretation: an aspiration vector is **not** a hard requirement in NAUTILI. Therefore, a zero intersection does not mean NAUTILI failed. It means that if the displayed aspirations are interrogated as simultaneous candidate-space requirements, no actual candidate in the frozen 9,061-point library satisfies all of them at once.

A recurring pattern is that `HA+Carb+DW` remains jointly feasible while adding `Rev` frequently destroys full feasibility. This agrees with the independent CNPW Phase-0 result, where `Rev+Carb` was the only pair whose highest common Stage-1 qualification was GL5 while all other pairs reached GL6.

## 3. Published final Pareto point: digitized mapping

Digitized red final point from Figure 3:

\[
(218.732, 16783.910, 3771.243, 183.823)
\]

interpreted as `(Rev, HA, Carb, DW)`.

The nearest candidate in the normalized 4-objective 9,061-point library is:

\[
\boxed{F4708}
\]

with exact library values:

\[
(218.000, 16785.328, 3773.100, 183.466)
\]

and normalized 4D distance to the plot-digitized red point:

\[
0.005095.
\]

The next-nearest alternatives are much farther:

| Candidate | normalized distance | Rev | HA | Carb | DW | GL profile | Q1 |
|---|---:|---:|---:|---:|---:|---|---:|
| F4708 | 0.005095 | 218.000 | 16785.328 | 3773.100 | 183.466 | 6/2/2/2 | 2 |
| F5506 | 0.020355 | 216.686 | 16865.548 | 3789.199 | 184.827 | 6/2/2/2 | 2 |
| F3739 | 0.025815 | 219.510 | 16685.190 | 3753.908 | 181.107 | 6/2/2/2 | 2 |
| F4039 | 0.029935 | 219.827 | 16664.832 | 3749.537 | 180.842 | 6/2/2/2 | 2 |
| F1140 | 0.035831 | 215.519 | 16941.549 | 3802.779 | 185.736 | 6/2/2/2 | 2 |

Therefore **F4708 is a strong nearest plot-digitized mapping**, but it is not claimed to be the exact source-row identity until exact numerical final-solution data are obtained.

## 4. CNPW status of the mapped NAUTILI final solution

For F4708:

- Stage-1 GL profile = **6/2/2/2**
- Equal-priority common qualification = **GL2**
- Member of baseline `W1` (highest common GL4 set): **False**
- Member of baseline `W2`: **False**

Its empirical objective percentiles are approximately:

- Rev: 81.6%
- HA: 19.5%
- Carb: 23.3%
- DW: 16.3%

This makes the methodological difference unusually clear. The plot-mapped NAUTILI group solution is high in revenue but relatively low in the other three objectives under equal-population qualification, whereas the CNPW Equal-Priority baseline terminal candidates have profiles `4/6/5/6`.

For comparison:

- F1030: (160.543, 19457.959, 4036.726, 213.699), percentiles (55.1%, 72.3%, 58.3%, 81.9%)
- F3057: (160.666, 19455.780, 4035.328, 213.659), percentiles (55.3%, 72.2%, 58.2%, 81.7%)

This should **not** be written as "CNPW found a better solution." The defensible interpretation is:

\[
\boxed{\text{group-preferred Pareto solution}\neq\text{highest equal-priority jointly qualified region}}
\]

under the frozen 9,061-point decision universe.

## 5. What is now empirically supported

1. NAUTILI's published interactive process can be reconstructed from Figure 3 at plot-digitized resolution.
2. Individual/marginal reachable information does not imply simultaneous attainability in the same candidate library.
3. CNPW can add a joint-compatibility diagnostic to the same displayed aspiration/reachability information without redefining NAUTILI's preference semantics.
4. The mapped group-preferred final Pareto point is not in the CNPW Equal-Priority highest-qualified region.
5. The main structural conflict identified independently by CNPW — involving revenue, especially revenue versus carbon — also appears repeatedly in the stepwise aspiration-compatibility audit.

## 6. Boundaries / claim discipline

- Figure-derived trajectory values are approximate, not source-exact.
- ±2-pixel sensitivity is provided to reduce false conclusions from plot extraction.
- Aspirations are navigation preferences, not qualification thresholds; joint-attainability counts are a CNPW-style interrogation of those values, not a critique that NAUTILI "fails" when aspirations are infeasible.
- The final mapping to F4708 is nearest-neighbor evidence, not exact provenance.
- The 9,061 candidates are a frozen Pareto-representative library; conclusions do not cover every combinatorial forest management plan.
- CNPW evaluates predefined relaxation paths and does not decide which objective should be sacrificed first.

## Verdict

\[
\boxed{\textbf{METHOD LOCKED / CROSS-DOMAIN PROCESS COMPARISON: PASS WITH DIGITIZATION CAVEAT}}
\]

The remaining upgrade, if exact original numeric trajectory data can be obtained, is to replace plot-digitized values with source-exact reference points and reachable bounds. The current result is already sufficient to show a real, same-universe methodological contrast, but the exact-numeric version would be stronger.
