import unittest
from itertools import combinations
from pathlib import Path

from agent.dual_coordinator import DualAnalysisCoordinator, _protected_blocks


ROOT = Path(__file__).resolve().parents[1]


class V8PublicOrchestrationTests(unittest.TestCase):
    def run_fixture(self, filename):
        outcome = DualAnalysisCoordinator(ROOT).execute(ROOT / filename)
        self.assertIsNone(outcome.error)
        self.assertEqual("completed", outcome.result["overall_integrity_status"])
        return outcome.result

    def test_exact_contract_family_counts_order_and_id_stability(self):
        for filename, m in (("tests_agent/fixtures/small_m3.csv", 3), (None, 4), (None, 5)):
            with self.subTest(m=m):
                expected = [subset for size in range(1, m) for subset in combinations(range(m), size)]
                self.assertEqual(expected, _protected_blocks(m))
                self.assertEqual(2 ** m - 2, len(_protected_blocks(m)))
                if filename:
                    first, second = self.run_fixture(filename), self.run_fixture(filename)
                    branches = first["mode_b_contracts"]
                    self.assertEqual(expected, [branch["canonical_task"].protected_indices for branch in branches])
                    self.assertEqual([branch["contract_id"] for branch in branches], [branch["contract_id"] for branch in second["mode_b_contracts"]])
                    self.assertTrue(first["complete_verification"].passed)
                    self.assertTrue(all(branch["canonical_task"].protection_semantics == "equal_count_global_qualification" for branch in branches))

    def test_pla_mex_fourteen_contract_landscape(self):
        dual = self.run_fixture("CNPW_PLA_MEX_7056_Core_Input_v0.2.csv")
        a = dual["mode_a"]["verified_result"]
        self.assertEqual((6, 65, 7, 4, ["PG6628"]), (a["stage_1"]["highest_joint_level"], len(a["stage_1"]["retained_candidate_ids"]), a["stage_2"]["k_l"], a["stage_2"]["highest_joint_level"], a["terminal"]["terminal_candidate_ids"]))
        branches = dual["mode_b_contracts"]
        self.assertEqual(14, len(branches))
        results = [branch["verified_result"] for branch in branches]
        self.assertEqual(8, sum(item["stage_1"]["highest_joint_level"] == 6 for item in results))
        self.assertEqual(2, sum(item["stage_1"]["highest_joint_level"] == 7 for item in results))
        for block, count in (((0, 1, 3), 11), ((0, 2, 3), 8)):
            selected = next(b["verified_result"] for b in branches if b["canonical_task"].protected_indices == block)
            self.assertEqual(6, selected["mode_b_conditioning"]["k_p"])
            self.assertEqual((7, count), (selected["stage_1"]["highest_joint_level"], len(selected["stage_1"]["retained_candidate_ids"])))
        self.assertEqual(4, sum(item["stage_1"]["highest_joint_level"] == 5 for item in results))
        self.assertEqual(13, sum(item["stage_2"]["highest_joint_level"] == 4 for item in results))
        self.assertEqual(1, sum(item["stage_2"]["highest_joint_level"] == 5 for item in results))
        terminals = {identifier for item in results for identifier in item["terminal"]["terminal_candidate_ids"]}
        self.assertEqual({"PG4422", "PG4862", "PG5303", "PG6627", "PG6628", "PG6630", "PG6634"}, terminals)
        uts = branches[0]
        self.assertEqual((7, 1008, 5, 117, 4, ["PG4422", "PG4862"]), (uts["verified_result"]["mode_b_conditioning"]["k_p"], uts["verified_result"]["mode_b_conditioning"]["protected_count"], uts["verified_result"]["stage_1"]["highest_joint_level"], len(uts["verified_result"]["stage_1"]["retained_candidate_ids"]), uts["verified_result"]["stage_2"]["highest_joint_level"], uts["verified_result"]["terminal"]["terminal_candidate_ids"]))
        self.assertEqual("COMPLETED", uts["local_qcca"].status)
