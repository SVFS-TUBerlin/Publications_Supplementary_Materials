# Case 04 — International educational assessment source record

- **Local archived source:** `PISA2022_CNPW_81x3.xlsx`
- **Source locator:** Author-derived extract; Metadata identifies Annex B1 Tables I.B1.2.1, I.B1.2.2 and I.B1.2.3
- **Source citation:** OECD. *PISA 2022 Results (Volume I): The State of Learning and Equity in Education*. OECD Publishing (2023). DOI: https://doi.org/10.1787/53f23881-en
- **Initial source population:** 81 participating countries/economies/education systems in the frozen extract
- **Candidate filter / population rule:** OECD average excluded; asterisks/caution markers not included in candidate names
- **Final CNPW population:** 81
- **Active responses:** 3
- **Local source SHA256:** `8516c3848d7862570e441bd24739f3646b906abad0828663e6aa9a3008fe14bc`
- **Local source size (bytes):** 8212
- **Redistribution status:** `AUTHOR_DERIVED_EXTRACT_INCLUDED`
- **Frozen input:** `CNPW_Case04_PISA2022_81x3_Input_v0.1.xlsx`

The bundled workbook is an author-derived frozen provenance extract, not the original OECD workbook. The response-level mapping to the SD5 execution input is recorded in `Source_to_Input_Mapping.xlsx`.
