from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

from src.input_loader import InputError, load_dataset
from src.models import Dataset

from .contracts import (ActiveCriterion, CanonicalTask, ExecutionMode,
                        FrozenCoreConfiguration, InputIdentity, InputSummary,
                        PresentationPreferences, ProvenanceRecord, stable_json)
from .errors import AgentError


@dataclass(frozen=True)
class GuardOutcome:
    task: CanonicalTask | None
    error: AgentError | None

    @property
    def accepted(self) -> bool:
        return self.task is not None


class InputGuard:
    """Agent-level boundary that delegates file parsing to the frozen Core."""

    _SLOT_NAMES = tuple("ABCDEFGHIJ")

    def validate(self, filename: str | Path, requested_mode: ExecutionMode | str,
                 requested_language: str = "en") -> GuardOutcome:
        path = Path(filename)
        input_hash = self._hash_if_file(path)
        suffix = path.suffix.lower()
        if suffix not in {".csv", ".xlsx"}:
            return self._reject("UNSUPPORTED_INPUT_FORMAT", "Input file must be .csv or .xlsx.", input_hash, suffix=suffix or "<none>")
        mode = self._mode_or_none(requested_mode)
        if mode is None:
            return self._reject("UNSUPPORTED_MODE", "Requested mode is not supported by Agent v0.1.", input_hash)
        try:
            dataset = load_dataset(path)
        except (InputError, OSError, ValueError) as exc:
            return self._reject_from_core_input_error(str(exc), input_hash)
        criterion_count = len(dataset.criteria)
        if criterion_count < 3 or criterion_count > 5:
            return self._reject("UNSUPPORTED_DIRECT_CRITERION_COUNT", "Direct Agent input requires 3 to 5 active Result criteria.", input_hash, active_criteria=str(criterion_count))
        return GuardOutcome(self._build_task(path, input_hash, dataset, mode, requested_language), None)

    def _build_task(self, path: Path, source_hash: str, dataset: Dataset,
                    mode: ExecutionMode, language: str) -> CanonicalTask:
        criteria = tuple(ActiveCriterion(item.name, self._SLOT_NAMES[index], item.column, item.direction)
                         for index, item in enumerate(dataset.criteria))
        identity = InputIdentity(path.name, str(path.resolve()), source_hash, dataset.file_format.lower())
        summary = InputSummary(identity, len(dataset.candidate_ids), "A", criteria, tuple(dataset.descriptor_names))
        protected = criteria[0] if mode is ExecutionMode.MODE_B_SIMPLIFIED_RESULT_A_GL7 else None
        residual = criteria[1:] if protected is not None else ()
        provenance = ProvenanceRecord(source_hash, ("parsed_by_current_core_input_loader", "agent_direct_criterion_count_3_to_5"))
        task_seed = {"input_hash_sha256": source_hash, "requested_mode": mode.value, "source_name": path.name}
        task_id = hashlib.sha256(stable_json(task_seed).encode("utf-8")).hexdigest()[:32]
        return CanonicalTask(task_id, "0.1", mode, summary, FrozenCoreConfiguration(), provenance,
                             PresentationPreferences(language), protected, residual)

    @staticmethod
    def _hash_if_file(path: Path) -> str | None:
        if not path.is_file():
            return None
        return hashlib.sha256(path.read_bytes()).hexdigest()

    @staticmethod
    def _mode_or_none(value: ExecutionMode | str) -> ExecutionMode | None:
        try:
            return value if isinstance(value, ExecutionMode) else ExecutionMode(value)
        except ValueError:
            return None

    @staticmethod
    def _reject(code: str, message: str, input_hash: str | None, **details: str) -> GuardOutcome:
        return GuardOutcome(None, AgentError(code, message, tuple(sorted(details.items())), input_hash))

    def _reject_from_core_input_error(self, message: str, input_hash: str | None) -> GuardOutcome:
        lower = message.lower()
        if "duplicate candidate id" in lower:
            code = "DUPLICATE_CANDIDATE_ID"
        elif "candidate id is blank" in lower:
            code = "INVALID_CANDIDATE_ID"
        elif "direction rule" in lower:
            code = "INVALID_DIRECTION"
        elif "blank result slot" in lower:
            code = "HIDDEN_DATA_IN_INACTIVE_RESULT_SLOT"
        elif "must be finite" in lower:
            code = "NONFINITE_RESULT"
        elif "input file must be" in lower:
            code = "UNSUPPORTED_INPUT_FORMAT"
        else:
            code = "INVALID_CANDIDATE_ID" if "candidate id" in lower else "NONFINITE_RESULT" if "not numeric" in lower else "UNSUPPORTED_INPUT_FORMAT"
        return self._reject(code, message, input_hash)
