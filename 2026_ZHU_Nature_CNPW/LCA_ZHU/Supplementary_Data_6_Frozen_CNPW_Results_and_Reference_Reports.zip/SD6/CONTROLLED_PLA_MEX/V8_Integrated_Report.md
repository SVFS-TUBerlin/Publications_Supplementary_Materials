# CNPW V8 Integrated Analysis Report

## 1. Input and scientific contract

- Filename: CNPW_PLA_MEX_7056_Core_Input_v0.2.csv
- N: 7056 · M: 4
- Responses, declared order: UTS_MPa, E_MPa, GWP_kgCO2eq, FRS_kgoileq
- One-click execution: Mode A plus every non-empty proper equal-count protected-response block.
- CNPW selects first; any percentages are reporting-only and never influence qualification, QCCA, recovery, or alternatives.

## 2. Mode A

### Mode A deterministic state

- Full-system Global capability: GL6 · |W¹|=65
- All-response Local state: local_qcca_required · K_L=7 · C_L=LL4
- Terminal/co-terminal candidates: PG6628

## 3. Mode-B protected-domain contract landscape

Protection determines admissibility; residual responses determine Stage-1 conditional capability; all active responses re-enter Stage-2 Local refinement.
Rows follow protected-block cardinality and declared response order. They are not ranked. Ω_P is the protected admissible population; W_B¹ is the residual Stage-1 retained population.

| Contract | Protected block | k_P | Ω_P size | Residual Stage-1 capability | W_B¹ size | All-response Local state / C_L | Terminal/co-terminal | QCCA/action |
|---|---|---:|---:|---:|---:|---|---|---|
| 0f71b279c44b | UTS_MPa | GL7 | 1008 | GL5 | 117 | local_qcca_required / LL4 | PG4422, PG4862 | COMPLETED |
| 6bdd4f167519 | E_MPa | GL7 | 1008 | GL6 | 8 | local_qcca_required / LL4 | PG6627 | COMPLETED |
| aa05f50d044c | GWP_kgCO2eq | GL7 | 1008 | GL6 | 11 | local_qcca_required / LL4 | PG6630 | COMPLETED |
| 6209bf4f7102 | FRS_kgoileq | GL7 | 1008 | GL5 | 20 | local_qcca_required / LL4 | PG6634 | COMPLETED |
| c4bfeeabc09c | UTS_MPa + E_MPa | GL7 | 621 | GL5 | 24 | local_qcca_required / LL5 | PG5303 | COMPLETED |
| 54e87a8084ac | UTS_MPa + GWP_kgCO2eq | GL6 | 194 | GL6 | 65 | local_qcca_required / LL4 | PG6628 | COMPLETED |
| f127afef4b10 | UTS_MPa + FRS_kgoileq | GL6 | 98 | GL6 | 65 | local_qcca_required / LL4 | PG6628 | COMPLETED |
| 90039b81f93d | E_MPa + GWP_kgCO2eq | GL6 | 162 | GL6 | 65 | local_qcca_required / LL4 | PG6628 | COMPLETED |
| 1615c153821c | E_MPa + FRS_kgoileq | GL6 | 93 | GL6 | 65 | local_qcca_required / LL4 | PG6628 | COMPLETED |
| 710d8bbf2c92 | GWP_kgCO2eq + FRS_kgoileq | GL7 | 875 | GL5 | 20 | local_qcca_required / LL4 | PG6634 | COMPLETED |
| 1582bd5a4283 | UTS_MPa + E_MPa + GWP_kgCO2eq | GL6 | 134 | GL6 | 65 | local_qcca_required / LL4 | PG6628 | COMPLETED |
| 88e1d338dec4 | UTS_MPa + E_MPa + FRS_kgoileq | GL6 | 65 | GL7 | 11 | local_qcca_required / LL4 | PG6630 | COMPLETED |
| b975e52ffecc | UTS_MPa + GWP_kgCO2eq + FRS_kgoileq | GL6 | 98 | GL7 | 8 | local_qcca_required / LL4 | PG6627 | COMPLETED |
| f03033261029 | E_MPa + GWP_kgCO2eq + FRS_kgoileq | GL6 | 93 | GL6 | 65 | local_qcca_required / LL4 | PG6628 | COMPLETED |

## 4. QCCA diagnosis and QCCA-guided alternatives

Global QCCA diagnoses (X, J, G) for Mode A and (Ω_P, J_res, G) for Mode B, excluding protected responses only from the residual Global system. Local QCCA uses all active responses J on frozen W¹, only for a Core-declared Local collapse. Recovery sets and targeted alternatives preserve all equal formal routes; none is preferred.

### Mode A Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa}; witnesses: PG6629.
- Target LL5; recovery set {FRS_kgoileq}; witnesses: PG6628.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6627.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6626.

### Mode B 0f71b279c44b Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa}; witnesses: PG4423, PG4863, PG5303.
- Target LL6; recovery set {UTS_MPa}; witnesses: PG4864, PG5304, PG5744.
- Target LL7; recovery set {UTS_MPa}; witnesses: PG5745, PG6185.

### Mode B 6bdd4f167519 Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa, E_MPa}; witnesses: PG6628.
- Target LL5; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6627.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG6628.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6626.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG6628.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6626.

### Mode B aa05f50d044c Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa}; witnesses: PG6630.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG5750.
- Target LL6; recovery set {UTS_MPa, FRS_kgoileq}; witnesses: PG6630.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6189, PG6629.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG5310.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6629.

### Mode B 6209bf4f7102 Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa}; witnesses: PG6194.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG5754, PG6635.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6193.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG6635.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6633.

### Mode B c4bfeeabc09c Local QCCA

- Baseline C_L: LL5; targets: LL6, LL7.
- Target LL6; recovery set {UTS_MPa}; witnesses: PG5744.
- Target LL7; recovery set {UTS_MPa}; witnesses: PG6185.

### Mode B 54e87a8084ac Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa}; witnesses: PG6629.
- Target LL5; recovery set {FRS_kgoileq}; witnesses: PG6628.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6627.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6626.

### Mode B f127afef4b10 Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa}; witnesses: PG6629.
- Target LL5; recovery set {FRS_kgoileq}; witnesses: PG6628.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6627.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6626.

### Mode B 90039b81f93d Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa}; witnesses: PG6629.
- Target LL5; recovery set {FRS_kgoileq}; witnesses: PG6628.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6627.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6626.

### Mode B 1615c153821c Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa}; witnesses: PG6629.
- Target LL5; recovery set {FRS_kgoileq}; witnesses: PG6628.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6627.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6626.

### Mode B 710d8bbf2c92 Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa}; witnesses: PG6194.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG5754, PG6635.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6193.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG6635.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6633.

### Mode B 1582bd5a4283 Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa}; witnesses: PG6629.
- Target LL5; recovery set {FRS_kgoileq}; witnesses: PG6628.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6627.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6626.

### Mode B 88e1d338dec4 Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa}; witnesses: PG6630.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG5750.
- Target LL6; recovery set {UTS_MPa, FRS_kgoileq}; witnesses: PG6630.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6189, PG6629.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG5310.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6629.

### Mode B b975e52ffecc Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa, E_MPa}; witnesses: PG6628.
- Target LL5; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6627.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG6628.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6626.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG6628.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6626.

### Mode B f03033261029 Local QCCA

- Baseline C_L: LL4; targets: LL5, LL6, LL7.
- Target LL5; recovery set {UTS_MPa}; witnesses: PG6629.
- Target LL5; recovery set {FRS_kgoileq}; witnesses: PG6628.
- Target LL6; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL6; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6627.
- Target LL7; recovery set {UTS_MPa, E_MPa}; witnesses: PG6630.
- Target LL7; recovery set {GWP_kgCO2eq, FRS_kgoileq}; witnesses: PG6626.

## 5. Verification and provenance

- Complete public-run verification: PASS.
- Expected/actual Mode-B contracts: 14/14.
- Every Mode-B contract has a deterministic content-derived identity and reuses the frozen full-population Global matrix.

## 6. AI-assisted interpretation

AI-assisted interpretation: Unavailable in this execution.

## 7. Limitations

A protected response with a lower Local position remains inside its Stage-1 protected domain; this does not relax or invalidate the protection contract. No weights, scores, preferred contract, preferred recovery set, preferred alternative, SHAP, connectivity, boundary, or process interpretation is provided.