from __future__ import annotations

from dataclasses import dataclass

from src.input_loader import load_dataset
from src.mode_a import run_mode_a
from src.mode_b import run_mode_b
from src.models import Dataset, ProtectionContract, RunResult

from .contracts import CanonicalTask, ExecutionMode
from .errors import AgentError, AgentRejected


@dataclass(frozen=True)
class CoreExecution:
    task: CanonicalTask
    dataset: Dataset
    core_result: RunResult


class CoreAdapter:
    """Narrow call-through adapter: it selects a Core mode and copies no science."""

    def execute(self, task: CanonicalTask) -> CoreExecution:
        try:
            dataset = load_dataset(task.input_summary.identity.source_path)
            if task.requested_mode is ExecutionMode.MODE_A:
                result = run_mode_a(dataset)
            elif task.requested_mode is ExecutionMode.MODE_B_PROTECTED_DOMAIN:
                result = run_mode_b(dataset, ProtectionContract(task.protection_semantics or "", task.protected_indices))
            elif task.requested_mode is ExecutionMode.MODE_B_SIMPLIFIED_RESULT_A_GL7:
                # Compatibility task labels still invoke an explicit V8 contract;
                # there is no retired no-argument Core Mode-B call.
                result = run_mode_b(dataset, ProtectionContract("equal_count_global_qualification", (0,)))
            else:
                raise ValueError("Unsupported canonical task mode.")
            return CoreExecution(task, dataset, result)
        except (OSError, ValueError) as exc:
            raise AgentRejected(AgentError("CORE_INVOCATION_FAILED", "Frozen Core invocation failed.", (("reason", str(exc)),), task.input_summary.identity.source_hash_sha256)) from None
