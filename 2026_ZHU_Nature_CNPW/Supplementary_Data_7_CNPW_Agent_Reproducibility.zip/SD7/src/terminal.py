from .models import Dataset


def prune_terminal(dataset: Dataset, candidates: list[int], ll: list[list[int]], criterion_indices: list[int]) -> tuple[list[int], list[int]]:
    profiles = {candidate: tuple(sorted(ll[candidate][criterion] for criterion in criterion_indices)) for candidate in candidates}
    best_profile = max(profiles.values())
    profile_class = [candidate for candidate in candidates if profiles[candidate] == best_profile]
    survivors = []
    for candidate in profile_class:
        dominated = False
        for other in profile_class:
            if other == candidate:
                continue
            no_worse = all((dataset.values[other][criterion] >= dataset.values[candidate][criterion] if dataset.criteria[criterion].direction == "maximize" else dataset.values[other][criterion] <= dataset.values[candidate][criterion]) for criterion in criterion_indices)
            strictly_better = any((dataset.values[other][criterion] > dataset.values[candidate][criterion] if dataset.criteria[criterion].direction == "maximize" else dataset.values[other][criterion] < dataset.values[candidate][criterion]) for criterion in criterion_indices)
            if no_worse and strictly_better:
                dominated = True
                break
        if not dominated:
            survivors.append(candidate)
    return profile_class, survivors
