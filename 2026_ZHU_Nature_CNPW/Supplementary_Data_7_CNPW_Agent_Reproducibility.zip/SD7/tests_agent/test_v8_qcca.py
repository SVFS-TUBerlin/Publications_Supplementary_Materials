import unittest

from agent.qcca_pipeline import run_core_qcca
from agent.targeted_relaxation import targeted_relaxation
from agent.targeted_relaxation_verifier import verify_targeted_relaxation
from src.input_loader import load_dataset
from src.mode_a import run_mode_a
from src.mode_b import run_mode_b
from src.models import ProtectionContract


class V8QccaPlaMexTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = load_dataset("CNPW_PLA_MEX_7056_Core_Input_v0.2.csv")
        cls.mode_a = run_mode_a(cls.data)
        cls.mode_b = run_mode_b(cls.data, ProtectionContract("equal_count_global_qualification", (0,)))

    def test_mode_a_global_subset_capabilities_and_gl7_recovery(self):
        outcome = run_core_qcca(self.data, self.mode_a, "GLOBAL")
        self.assertEqual("COMPLETED", outcome.status)
        q = outcome.result
        self.assertEqual("GLOBAL", q.representation)
        self.assertEqual(tuple(self.data.candidate_ids), q.domain_candidate_ids)
        self.assertEqual(6, q.full_system_ceiling)
        self.assertEqual(7, q.singleton_ceilings[("UTS_MPa",)])
        self.assertEqual(7, q.subset_ceilings[("UTS_MPa", "E_MPa")])
        self.assertEqual(6, q.subset_ceilings[("UTS_MPa", "GWP_kgCO2eq")])
        recovery = __import__("agent.qcca_analyzer", fromlist=["recovery_for_target"]).recovery_for_target(q, 7)
        self.assertEqual(2, recovery.minimum_recovery_order)
        self.assertEqual({("UTS_MPa", "E_MPa"), ("GWP_kgCO2eq", "FRS_kgoileq")}, {x.removed_responses for x in recovery.recovery_sets})

    def test_mode_a_local_auto_targets_and_actions_stay_in_w1(self):
        outcome = run_core_qcca(self.data, self.mode_a, "LOCAL")
        self.assertEqual("COMPLETED", outcome.status)
        q = outcome.result
        self.assertEqual("LOCAL", q.representation)
        self.assertEqual(4, q.full_system_ceiling)
        self.assertEqual({
            ("UTS_MPa", "E_MPa"): 7, ("UTS_MPa", "GWP_kgCO2eq"): 5,
            ("UTS_MPa", "FRS_kgoileq"): 4, ("E_MPa", "GWP_kgCO2eq"): 5,
            ("E_MPa", "FRS_kgoileq"): 5, ("GWP_kgCO2eq", "FRS_kgoileq"): 7,
            ("UTS_MPa", "E_MPa", "GWP_kgCO2eq"): 5,
            ("UTS_MPa", "E_MPa", "FRS_kgoileq"): 4,
            ("UTS_MPa", "GWP_kgCO2eq", "FRS_kgoileq"): 4,
            ("E_MPa", "GWP_kgCO2eq", "FRS_kgoileq"): 5,
            ("UTS_MPa", "E_MPa", "GWP_kgCO2eq", "FRS_kgoileq"): 4,
        }, q.subset_ceilings)
        self.assertEqual([5, 6, 7], [x.target for x in q.target_recoveries])
        by_target = {x.target: x for x in q.target_recoveries}
        self.assertEqual({("UTS_MPa",), ("FRS_kgoileq",)}, {x.removed_responses for x in by_target[5].recovery_sets})
        self.assertEqual({("UTS_MPa", "E_MPa"), ("GWP_kgCO2eq", "FRS_kgoileq")}, {x.removed_responses for x in by_target[6].recovery_sets})
        raw = [self.data.values[i] for i in self.mode_a.stage1.retained]
        route = targeted_relaxation(q, by_target[5].recovery_sets[0], raw_values=raw)
        self.assertTrue(verify_targeted_relaxation(route, q, by_target[5].recovery_sets[0]))
        self.assertIn("PG6629", [x.candidate_id for x in route.alternatives])
        self.assertTrue(all(x.candidate_id in q.domain_candidate_ids for x in route.alternatives))
        for target, expected in ((6, {"PG6630", "PG6627"}), (7, {"PG6630", "PG6626"})):
            witnesses = set()
            for recovery in by_target[target].recovery_sets:
                witnesses.update(x.candidate_id for x in targeted_relaxation(q, recovery).alternatives)
            self.assertTrue(expected.issubset(witnesses))

    def test_higher_order_frontier_has_no_scalar_ranking(self):
        q = run_core_qcca(self.data, self.mode_a, "LOCAL").result
        recovery = next(x for x in next(item for item in q.target_recoveries if item.target == 6).recovery_sets if len(x.removed_responses) == 2)
        route = targeted_relaxation(q, recovery)
        self.assertEqual("HIGHER_ORDER_NONDOMINATED_DEFICIT_FRONTIER", route.kind)
        self.assertTrue(verify_targeted_relaxation(route, q, recovery))
        self.assertTrue(route.alternatives)

    def test_mode_b_global_and_local_domains_remain_protection_bound(self):
        global_q = run_core_qcca(self.data, self.mode_b, "GLOBAL").result
        local_q = run_core_qcca(self.data, self.mode_b, "LOCAL").result
        self.assertEqual(1008, len(global_q.domain_candidate_ids))
        self.assertEqual(5, global_q.full_system_ceiling)
        self.assertEqual(117, len(local_q.domain_candidate_ids))
        self.assertEqual(4, local_q.full_system_ceiling)
        self.assertEqual({
            ("UTS_MPa", "E_MPa"): 5, ("UTS_MPa", "GWP_kgCO2eq"): 4,
            ("UTS_MPa", "FRS_kgoileq"): 4, ("E_MPa", "GWP_kgCO2eq"): 7,
            ("E_MPa", "FRS_kgoileq"): 7, ("GWP_kgCO2eq", "FRS_kgoileq"): 7,
            ("UTS_MPa", "E_MPa", "GWP_kgCO2eq"): 4,
            ("UTS_MPa", "E_MPa", "FRS_kgoileq"): 4,
            ("UTS_MPa", "GWP_kgCO2eq", "FRS_kgoileq"): 4,
            ("E_MPa", "GWP_kgCO2eq", "FRS_kgoileq"): 7,
            ("UTS_MPa", "E_MPa", "GWP_kgCO2eq", "FRS_kgoileq"): 4,
        }, local_q.subset_ceilings)
        self.assertIn("UTS_MPa", local_q.criterion_names)
        recovery = next(item for item in local_q.target_recoveries if item.target == 5)
        self.assertEqual({("UTS_MPa",)}, {x.removed_responses for x in recovery.recovery_sets})
        route = targeted_relaxation(local_q, recovery.recovery_sets[0], raw_values=[self.data.values[i] for i in self.mode_b.stage1.retained], mode_b_omega_candidate_ids=self.mode_b.protected["omega_candidate_ids"])
        self.assertTrue(verify_targeted_relaxation(route, local_q, recovery.recovery_sets[0]))
        self.assertTrue(all(item.in_mode_b_omega for item in route.alternatives))
        self.assertTrue({"PG4863", "PG5303"}.issubset({item.candidate_id for item in route.alternatives}))
        for target, expected in ((6, "PG5744"), (7, "PG6185")):
            recovery = next(item for item in local_q.target_recoveries if item.target == target)
            candidates = {item.candidate_id for item in targeted_relaxation(local_q, recovery.recovery_sets[0]).alternatives}
            self.assertIn(expected, candidates)
