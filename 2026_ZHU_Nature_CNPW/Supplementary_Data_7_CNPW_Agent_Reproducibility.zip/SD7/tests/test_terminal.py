import unittest

from src.terminal import prune_terminal
from tests.helpers import make_dataset


class TerminalTests(unittest.TestCase):
    def test_worst_first_profile(self):
        data = make_dataset(["A", "B", "C"], ["x", "y"], ["maximize", "maximize"], [[2, 2], [3, 3], [5, 1]])
        ll = [[6, 6], [6, 6], [7, 5]]
        profile, terminal = prune_terminal(data, [0, 1, 2], ll, [0, 1])
        self.assertEqual([0, 1], profile)

    def test_raw_dominance(self):
        data = make_dataset(["A", "B", "C"], ["x", "y"], ["maximize", "maximize"], [[2, 2], [3, 3], [5, 1]])
        ll = [[6, 6], [6, 6], [7, 5]]
        _, terminal = prune_terminal(data, [0, 1, 2], ll, [0, 1])
        self.assertEqual([1], terminal)

    def test_set_valued_terminal(self):
        data = make_dataset(["A", "B"], ["x", "y"], ["maximize", "maximize"], [[3, 2], [2, 3]])
        ll = [[7, 6], [6, 7]]
        _, terminal = prune_terminal(data, [0, 1], ll, [0, 1])
        self.assertEqual([0, 1], terminal)
