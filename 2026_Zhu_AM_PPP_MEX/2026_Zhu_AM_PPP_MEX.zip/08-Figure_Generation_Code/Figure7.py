# -*- coding: utf-8 -*-
"""Figure 7: final ten-coefficient porosity design maps and additional-condition assessment.

Run on Windows: python Figure7.py
Install once: python -m pip install numpy pandas matplotlib
Outputs: D:\\soft\\3
All 101 source specimen records and configuration are embedded below.
No external CSV/Excel/JSON/model/font-directory inputs, downloads or network calls.
Roboto Regular must be installed in Windows; panel bold is simulated if necessary.
The source 20261021 figure's layout/contours/markers/windows/color scale are retained.
20 mm/s uses h+h^2+P; 70/120 mm/s use h+P; all are final full-training OLS fits.
"""
from __future__ import annotations
from pathlib import Path
import hashlib
import io
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import font_manager, ticker, patheffects
from matplotlib.font_manager import FontProperties
from matplotlib.colors import Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle, Patch

OUTPUT_DIR = Path(r"D:\soft\3")
SPEEDS = (20, 70, 120)
H_LEVELS, P_LEVELS = (.10, .20, .25), (.43, .45, .47)
H_LIMITS, P_LIMITS = (.10, .25), (.43, .47)
H_CENTER, H_SCALE, P_CENTER, P_SCALE = .175, .075, .45, .02
GEOMETRIC_FACTOR = 100 * (1 - np.pi / 4)
TARGET, DESIGN_TOLERANCE, ACCEPTANCE_TOLERANCE = 11.5, .5, .5
MEASURED, PREDICTED, EXAMPLE_STAR = "#287AA1", "#343E47", "#C73535"
PITCH_LABEL = r"Line pitch, $P$ (mm)"

# Physical-unit coefficient references are checks only; predictions use refitted OLS.
COEFFICIENT_REFERENCE = {
    20: [-49.52717185, -145.82446652, 153.32880474, 221.29194436],
    70: [-65.43452238, -45.15643692, 166.79383666],
    120: [-70.13926777, -32.43515569, 175.13206900],
}
# The 70/120 models are unchanged; full-precision original archive coefficients.
OLD_LINEAR_REFERENCE = {
    70: [-65.434522377505, -45.1564369158112, 166.793836664214],
    120: [-70.1392677658162, -32.4351556920785, 175.132068999162],
}
# (field minimum, field maximum, nodes within 11.5 +/-0.5 pp).
FIELD_REFERENCE = {
    20: (6.010628, 14.733836, 4924),
    70: (6.7619240826317, 13.0844629343691, 6753),
    120: (6.91474672072146, 15.4790070494167, 6421),
}
# Historical assessment: mean/min/max/predicted porosity; never used for fitting.
VALIDATION_REFERENCE = {
    'V1': (8.95637721960102, 8.70419472590953, 9.24011508248985, 10.002633137438),
    'V2': (11.5561887691257, 11.3427877313357, 11.7174694381179, 11.5898697397647),
    'V3': (14.7006138762239, 14.2558224653374, 15.3394947461047, 14.0422805803881),
    'V4': (6.50230023917114, 6.31051642258871, 6.90343841028076, 6.82305313786759),
}
EXPECTED_ADDITIONAL = {'V1': (.15,.45,70), 'V2': (.20,.46,70), 'V3': (.25,.47,90), 'V4': (.10,.43,90)}
FROZEN_CSV_SHA256 = 'eaa509b573e89945f2c283d4d8733f4a6fff1804a91727e226796b7d4922647c'
SPECIMEN_CSV = """﻿record_id,role,group_id,replicate,h_mm,P_mm,v_mm_s,area_mm2,mass_g,phi_vol_pct,Y_pp
G8-R1,main,G8,1,0.10000000000000001,0.42999999999999999,20,29.789999999999999,6.1130000000000004,8.0631324889519291,3.0723921028460754
G8-R2,main,G8,2,0.10000000000000001,0.42999999999999999,20,30.096,6.1539999999999999,8.3875445646809599,3.3968041785751062
G8-R3,main,G8,3,0.10000000000000001,0.42999999999999999,20,29.724299999999999,6.1100000000000003,7.9051416809608028,2.9144012948549491
G20-R1,main,G20,1,0.10000000000000001,0.42999999999999999,70,30.8828,6.375,7.5154197255778321,2.5246793394719784
G20-R2,main,G20,2,0.10000000000000001,0.42999999999999999,70,30.956,6.3680000000000003,7.835424635544685,2.8446842494388318
G20-R3,main,G20,3,0.10000000000000001,0.42999999999999999,70,30.596,6.3230000000000004,7.4099455922506774,2.4192052061448241
G23-R1,main,G23,1,0.10000000000000001,0.42999999999999999,120,30.552,6.3289999999999997,7.188613619320849,2.1978732332149957
G23-R2,main,G23,2,0.10000000000000001,0.42999999999999999,120,30.307700000000001,6.2789999999999999,7.1796262002477018,2.1888858141418481
G23-R3,main,G23,3,0.10000000000000001,0.42999999999999999,120,30.655999999999999,6.3449999999999998,7.269639369654513,2.2788989835486597
G21-R1,main,G21,1,0.10000000000000001,0.45000000000000001,20,29.850000000000001,5.8600000000000003,12.045292171730823,7.2763624694518976
G21-R2,main,G21,2,0.10000000000000001,0.45000000000000001,20,29.569700000000001,5.7389999999999999,13.044888546729094,8.2759588444501659
G21-R3,main,G21,3,0.10000000000000001,0.45000000000000001,20,29.719799999999999,5.7640000000000002,13.107178514469698,8.3382488121907699
G4-R1,main,G4,1,0.10000000000000001,0.45000000000000001,70,29.5303,6.0220000000000002,8.6352433319293986,3.8663136296504712
G4-R2,main,G4,2,0.10000000000000001,0.45000000000000001,70,29.520800000000001,6.0330000000000004,8.4388976840969132,3.6699679818179858
G4-R3,main,G4,3,0.10000000000000001,0.45000000000000001,70,29.419599999999999,6.0129999999999999,8.4285165070018149,3.6595868047228879
G24-R1,main,G24,1,0.10000000000000001,0.45000000000000001,120,29.902999999999999,6.0694999999999997,9.0623002427082753,4.2933705404293496
G24-R2,main,G24,2,0.10000000000000001,0.45000000000000001,120,29.8704,6.0039999999999996,9.94549260451506,5.1765629022361326
G24-R3,main,G24,3,0.10000000000000001,0.45000000000000001,120,29.9892,6.0439999999999996,9.7046501854168081,4.9357204831378807
G22-R1,main,G22,1,0.10000000000000001,0.46999999999999997,20,29.617799999999999,5.5819999999999999,15.561045812056594,10.995049288598048
G22-R2,main,G22,2,0.10000000000000001,0.46999999999999997,20,29.7667,5.6950000000000003,14.282627987279762,9.7166314638212139
G22-R3,main,G22,3,0.10000000000000001,0.46999999999999997,20,30.048999999999999,5.7350000000000003,14.491515709526279,9.9255191860677314
G13-R1,main,G13,1,0.10000000000000001,0.46999999999999997,70,30.048999999999999,5.8440000000000003,12.866332660239166,8.3003361367806185
G13-R2,main,G13,2,0.10000000000000001,0.46999999999999997,70,30.168900000000001,5.8570000000000002,13.019568408117976,8.4535718846594285
G13-R3,main,G13,3,0.10000000000000001,0.46999999999999997,70,30.198,5.8460000000000001,13.266586289153482,8.700589765694934
G9-R1,main,G9,1,0.10000000000000001,0.46999999999999997,120,30.048999999999999,5.8159999999999998,13.283810874734936,8.7178143512763882
G9-R2,main,G9,2,0.10000000000000001,0.46999999999999997,120,30.18,5.8339999999999996,13.392999232799152,8.8270027093406043
G9-R3,main,G9,3,0.10000000000000001,0.46999999999999997,120,30.199999999999999,5.8159999999999998,13.71739182036128,9.1513952969027326
G18-R1,main,G18,1,0.20000000000000001,0.42999999999999999,20,30.7057,6.4169999999999998,6.3691757556414652,-3.6123050165702422
G18-R2,main,G18,2,0.20000000000000001,0.42999999999999999,20,30.523199999999999,6.351,6.7781193476803896,-3.2033614245313178
G18-R3,main,G18,3,0.20000000000000001,0.42999999999999999,20,30.184000000000001,6.3250000000000002,6.1164404317794681,-3.8650403404322393
G6-R1,main,G6,1,0.20000000000000001,0.42999999999999999,70,30.312799999999999,6.298,6.9144193933381111,-3.0670613788735963
G6-R2,main,G6,2,0.20000000000000001,0.42999999999999999,70,30.406700000000001,6.327,6.7745786502698806,-3.2069021219418268
G6-R3,main,G6,3,0.20000000000000001,0.42999999999999999,70,30.506699999999999,6.3230000000000004,7.138913594079388,-2.8425671781323194
G12-R1,main,G12,1,0.20000000000000001,0.42999999999999999,120,30.494,6.0979999999999999,10.406019116987109,0.4245383447754012
G12-R2,main,G12,2,0.20000000000000001,0.42999999999999999,120,30.612300000000001,6.226,8.8788975902662983,-1.1025831819454091
G12-R3,main,G12,3,0.20000000000000001,0.42999999999999999,120,30.52,6.2069999999999999,8.8822418579743267,-1.0992389142373806
G2-R1,main,G2,1,0.20000000000000001,0.45000000000000001,20,29.449200000000001,6.0439999999999996,8.0489349571635884,-1.4889244473942664
G2-R2,main,G2,2,0.20000000000000001,0.45000000000000001,20,29.7332,6.0910000000000002,8.2190059485777169,-1.3188534559801379
G2-R3,main,G2,3,0.20000000000000001,0.45000000000000001,20,29.7332,6.0880000000000001,8.2642108381121524,-1.2736485664457025
G1-R1,main,G1,1,0.20000000000000001,0.45000000000000001,70,30.088799999999999,5.968,11.135202286298265,1.5973428817404081
G1-R2,main,G1,2,0.20000000000000001,0.45000000000000001,70,29.9376,5.9560000000000004,10.86597518298036,1.3281157784225035
G1-R3,main,G1,3,0.20000000000000001,0.45000000000000001,70,30.068899999999999,5.9690000000000003,11.061490306533861,1.5236309019760057
G3-R1,main,G3,1,0.20000000000000001,0.45000000000000001,120,30.060600000000001,5.8949999999999996,12.139843108319038,2.6019837037611837
G3-R2,main,G3,2,0.20000000000000001,0.45000000000000001,120,30,5.899,11.902628434886507,2.3647690303286542
G3-R3,main,G3,3,0.20000000000000001,0.45000000000000001,120,29.798999999999999,5.8789999999999996,11.609095154981633,2.0712357504237762
G16-R1,main,G16,1,0.20000000000000001,0.46999999999999997,20,30.193999999999999,5.9379999999999997,11.889969357058527,2.7579763101414319
G16-R2,main,G16,2,0.20000000000000001,0.46999999999999997,20,30.075199999999999,5.9320000000000004,11.63130774891059,2.4993147019934945
G16-R3,main,G16,3,0.20000000000000001,0.46999999999999997,20,29.835000000000001,5.923,11.055008040038617,1.9230149931215208
G7-R1,main,G7,1,0.20000000000000001,0.46999999999999997,70,30.0425,5.7999999999999998,13.503659540859523,4.3716664939424295
G7-R2,main,G7,2,0.20000000000000001,0.46999999999999997,70,30.09,5.8049999999999997,13.565754349853664,4.4337613029365688
G7-R3,main,G7,3,0.20000000000000001,0.46999999999999997,70,30.0425,5.7069999999999999,14.8905836206354,5.7585905737183047
G17-R1,main,G17,1,0.20000000000000001,0.46999999999999997,120,30.0168,5.718,14.653528790902191,5.5215357439850976
G17-R2,main,G17,2,0.20000000000000001,0.46999999999999997,120,30.0564,5.7050000000000001,14.959756184060948,5.827763137143851
G17-R3,main,G17,3,0.20000000000000001,0.46999999999999997,120,30.208200000000001,5.7050000000000001,15.387094092683762,6.2551010457666667
G25-R1,main,G25,1,0.25,0.42999999999999999,20,30.620000000000001,6.3869999999999996,6.5460764276634169,-5.9307745376012182
G25-R2,main,G25,2,0.25,0.42999999999999999,20,30.630600000000001,6.3920000000000003,6.5052828493688768,-5.9715681158957583
G25-R3,main,G25,3,0.25,0.42999999999999999,20,30.640000000000001,6.3860000000000001,6.6217000290107357,-5.8551509362538994
G14-R1,main,G14,1,0.25,0.42999999999999999,70,30.339500000000001,6.2750000000000004,7.3359835094377939,-5.1408674558268412
G14-R2,main,G14,2,0.25,0.42999999999999999,70,30.333600000000001,6.282,7.2145696840382296,-5.2622812812264055
G14-R3,main,G14,3,0.25,0.42999999999999999,70,30.393999999999998,6.2880000000000003,7.3105119077690013,-5.1663390574956338
G27-R1,main,G27,1,0.25,0.42999999999999999,120,30.294,6.1790000000000003,8.6165849466151574,-3.8602660186494777
G27-R2,main,G27,2,0.25,0.42999999999999999,120,30.113800000000001,6.165,8.2780394970562217,-4.1988114682084126
G27-R3,main,G27,3,0.25,0.42999999999999999,120,30.193999999999999,6.1509999999999998,8.7294040948580296,-3.7474468704066055
G26-R1,main,G26,1,0.25,0.45000000000000001,20,30.096,6.1059999999999999,9.1021038530942366,-2.8202204026030824
G26-R2,main,G26,2,0.25,0.45000000000000001,20,29.792000000000002,6.0759999999999996,8.6257309941520468,-3.2965932615452704
G26-R3,main,G26,3,0.25,0.45000000000000001,20,29.945499999999999,6.077,9.0791520964399464,-2.8431721592573709
G5-R1,main,G5,1,0.25,0.45000000000000001,70,29.9894,6.0590000000000002,9.4811588505596909,-2.4411654051376264
G5-R2,main,G5,2,0.25,0.45000000000000001,70,29.739599999999999,5.9630000000000001,10.167084221749668,-1.7552400339476506
G5-R3,main,G5,3,0.25,0.45000000000000001,70,29.798999999999999,5.952,10.511538418515164,-1.4107858371821518
G15-R1,main,G15,1,0.25,0.45000000000000001,120,29.909700000000001,5.7869999999999999,13.31434499564118,1.3920207399438631
G15-R2,main,G15,2,0.25,0.45000000000000001,120,29.798999999999999,5.8029999999999999,12.751756962809724,0.82943270711240658
G15-R3,main,G15,3,0.25,0.45000000000000001,120,29.798999999999999,5.8140000000000001,12.5863717011504,0.66404744545308425
G10-R1,main,G10,1,0.25,0.46999999999999997,20,29.837199999999999,5.9429999999999996,10.761250767426224,-0.65374054122014691
G10-R2,main,G10,2,0.25,0.46999999999999997,20,29.617799999999999,5.9000000000000004,10.750657522596541,-0.66433378604982884
G10-R3,main,G10,3,0.25,0.46999999999999997,20,29.776,5.9109999999999996,11.059326603995622,-0.35566470465074751
G19-R1,main,G19,1,0.25,0.46999999999999997,70,29.5656,5.782,12.381220333269226,0.96622902462285676
G19-R2,main,G19,2,0.25,0.46999999999999997,70,29.604399999999998,5.7720000000000002,12.647393449070254,1.2324021404238843
G19-R3,main,G19,3,0.25,0.46999999999999997,70,29.518000000000001,5.7750000000000004,12.346175506543478,0.93118419789710838
G11-R1,main,G11,1,0.25,0.46999999999999997,120,29.997,5.657,15.508277231546341,4.0932859228999714
G11-R2,main,G11,2,0.25,0.46999999999999997,120,29.884899999999998,5.6520000000000001,15.26630289824864,3.85131158960227
G11-R3,main,G11,3,0.25,0.46999999999999997,120,29.997,5.6710000000000003,15.29917627366083,3.8841849650144606
V1-R1,validation,V1,1,0.14999999999999999,0.45000000000000001,70,30.842400000000001,6.274,8.8614407555320902,1.7080462021136995
V1-R2,validation,V1,2,0.14999999999999999,0.45000000000000001,70,30.803999999999998,6.2770000000000001,8.7041947259095309,1.5508001724911402
V1-R3,validation,V1,3,0.14999999999999999,0.45000000000000001,70,30.803999999999998,6.2460000000000004,9.1550741210818742,2.0016795676634835
V1-R4,validation,V1,4,0.14999999999999999,0.45000000000000001,70,30.892099999999999,6.258,9.2401150824898526,2.0867205290714619
V1-R5,validation,V1,5,0.14999999999999999,0.45000000000000001,70,30.814,6.2709999999999999,8.8210614129917602,1.6676668595733697
V2-R1,validation,V2,1,0.20000000000000001,0.46000000000000002,70,30.223199999999999,5.9699999999999998,11.50072848686774,2.170213851974188
V2-R2,validation,V2,2,0.20000000000000001,0.46000000000000002,70,30.338000000000001,5.9809999999999999,11.67316572589211,2.3426510909985581
V2-R3,validation,V2,3,0.20000000000000001,0.46000000000000002,70,30.2592,5.9740000000000002,11.546792463414778,2.2162778285212266
V2-R4,validation,V2,4,0.20000000000000001,0.46000000000000002,70,30.23,5.9820000000000002,11.342787731335749,2.0122730964421951
V2-R5,validation,V2,5,0.20000000000000001,0.46000000000000002,70,30.338000000000001,5.9779999999999998,11.717469438117876,2.3869548032243251
V3-R1,validation,V3,1,0.25,0.46999999999999997,90,29.884899999999998,5.6929999999999996,14.651638782683918,3.2366474740375484
V3-R2,validation,V3,2,0.25,0.46999999999999997,90,29.868400000000001,5.6440000000000001,15.339494746104654,3.9245034374582839
V3-R3,validation,V3,3,0.25,0.46999999999999997,90,29.943999999999999,5.7030000000000003,14.670467309587201,3.255476000940829
V3-R4,validation,V3,4,0.25,0.46999999999999997,90,29.93,5.7060000000000004,14.585646077406423,3.1706547687600537
V3-R5,validation,V3,5,0.25,0.46999999999999997,90,29.924600000000002,5.7270000000000003,14.255822465337433,2.8408311566910616
V4-R1,validation,V4,1,0.10000000000000001,0.42999999999999999,90,30.300000000000001,6.3220000000000001,6.5202219146645923,1.5294815285587386
V4-R2,validation,V4,2,0.10000000000000001,0.42999999999999999,90,30.453600000000002,6.3280000000000003,6.90343841028076,1.9126980241749063
V4-R3,validation,V4,3,0.10000000000000001,0.42999999999999999,90,30.454999999999998,6.3630000000000004,6.3928270690230331,1.4020866829171794
V4-R4,validation,V4,4,0.10000000000000001,0.42999999999999999,90,30.280000000000001,6.3319999999999999,6.3105164225887078,1.3197760364828539
V4-R5,validation,V4,5,0.10000000000000001,0.42999999999999999,90,30.280000000000001,6.327,6.3844973792986037,1.39375699319275
"""

# Original plotting configuration, embedded; output names updated below.
CFG = {'target_porosity_pct': None, 'tolerance_pp': None, 'design_targets': [{'porosity_pct': 11.5, 'tolerance_pp': 0.5, 'color': '#E5B340', 'fill_color': '#FFE6A3'}], 'target_status': 'illustrative 11.5% target with a fixed 0.5 pp engineering tolerance; not tuned against validation', 'show_interpolation_inset': False, 'grid_size': 201, 'colormap': 'viridis_r', 'color_limits_pct': [5.5, 15.5], 'colorbar_ticks_pct': [6, 8, 10, 12, 14, 15.5], 'contour_levels_pct': [6, 8, 10, 12, 14], 'figure_size_inches': [12.4, 12.0], 'png_dpi': 600, 'preview_dpi': 120, 'show_projection_stars': False, 'target_fill_alpha': 0.14, 'shared_color_scale_scope': 'predicted background and measured main-condition mean porosity', 'validation_star_color': '#C73535', 'validation_star_position_role': 'V2 actual experimental h, P, v in panel b only', 'validation_tolerance_pp': 0.5, 'validation_window_interpretation': 'engineering acceptance window; not a statistical prediction interval'}




def geometric_porosity(h, p):
    """Analytical reference phi_2, in percent."""
    return GEOMETRIC_FACTOR * np.asarray(h, float) / np.asarray(p, float)


def load_groups():
    """Check frozen paired specimen data, derive responses, then aggregate."""
    if hashlib.sha256(SPECIMEN_CSV.encode("utf-8")).hexdigest() != FROZEN_CSV_SHA256:
        raise ValueError("Embedded specimen data differ from the frozen source.")
    s = pd.read_csv(io.StringIO(SPECIMEN_CSV), float_precision="round_trip")
    required = ["record_id", "role", "group_id", "replicate", "h_mm", "P_mm",
                "v_mm_s", "area_mm2", "mass_g", "phi_vol_pct", "Y_pp"]
    missing = set(required) - set(s.columns)
    if missing:
        raise ValueError(f"Missing source columns: {sorted(missing)}")
    if len(s) != 101 or s.record_id.duplicated().any():
        raise ValueError("Expected 101 uniquely identified specimens.")
    if s.duplicated(["role", "group_id", "replicate"]).any():
        raise ValueError("Nonunique specimen pairing keys.")
    numeric = [c for c in required if c not in ("record_id", "role", "group_id")]
    if not np.isfinite(s[numeric].to_numpy(float)).all():
        raise ValueError("Missing/nonfinite numerical source measurements.")
    if set(s.role) != {"main", "validation"}:
        raise ValueError("Expected explicit main/validation roles.")
    if (s[["mass_g", "area_mm2"]] <= 0).any().any():
        raise ValueError("Mass and area must be positive.")
    phi = 100 * (1 - s.mass_g / (1.24 * s.area_mm2 * 180 / 1000))
    y = phi - geometric_porosity(s.h_mm, s.P_mm)
    if not np.allclose(phi, s.phi_vol_pct, rtol=0, atol=1e-10):
        raise ValueError("Frozen porosity differs from specimen-level derivation.")
    if not np.allclose(y, s.Y_pp, rtol=0, atol=1e-10):
        raise ValueError("Frozen Y differs from phi_vol - phi_2.")
    # Do not replace frozen columns or alter raw measurements.
    for (role, gid), frame in s.groupby(["role", "group_id"]):
        expected = 3 if role == "main" else 5
        if set(frame.replicate) != set(range(1, expected+1)):
            raise ValueError(f"{gid}: missing/duplicate replicate numbers.")
        if set(frame.record_id) != {f"{gid}-R{i}" for i in range(1, expected+1)}:
            raise ValueError(f"{gid}: specimen identifiers do not match replicates.")
        if len(frame) != expected:
            raise ValueError(f"{gid}: expected {expected} specimens.")
        if not frame[["h_mm", "P_mm", "v_mm_s"]].nunique().eq(1).all():
            raise ValueError(f"{gid}: parameters vary within a condition.")
    g = s.groupby(["role", "group_id", "h_mm", "P_mm", "v_mm_s"],
                  as_index=False).agg(
        phi_vol_mean_pct=("phi_vol_pct", "mean"),
        phi_vol_min_pct=("phi_vol_pct", "min"),
        phi_vol_max_pct=("phi_vol_pct", "max"),
        phi_vol_SD_pct=("phi_vol_pct", "std"),
        Y_mean_pp=("Y_pp", "mean"), n=("record_id", "size"))
    main = g[g.role == "main"].copy()
    validation = g[g.role == "validation"].sort_values("group_id").copy()
    if len(main) != 27 or len(validation) != 4:
        raise ValueError("Expected 27 training and four validation conditions.")
    if not set(main.group_id).isdisjoint(validation.group_id):
        raise ValueError("Training and validation identities overlap.")
    expected_design = {(h, p, v) for h in H_LEVELS for p in P_LEVELS for v in SPEEDS}
    actual_design = {(round(r.h_mm, 8), round(r.P_mm, 8), int(r.v_mm_s))
                     for r in main.itertuples()}
    if actual_design != expected_design:
        raise ValueError("Training conditions do not match the complete 3x3x3 design.")
    if set(validation.group_id) != {"V1", "V2", "V3", "V4"}:
        raise ValueError("Expected V1-V4 validation labels.")
    if set(main.group_id) != {f"G{i}" for i in range(1,28)}:
        raise ValueError("Expected all main-condition IDs G1-G27.")
    if len(s[s.role == "main"]) != 81 or len(s[s.role == "validation"]) != 20:
        raise ValueError("Expected 81 main and 20 additional specimens.")
    for r in validation.itertuples():
        if not np.allclose([r.h_mm,r.P_mm,r.v_mm_s], EXPECTED_ADDITIONAL[r.group_id],
                           rtol=0, atol=1e-12):
            raise ValueError("An additional condition's actual coordinates changed.")
    if not ((g.phi_vol_min_pct <= g.phi_vol_mean_pct)
            & (g.phi_vol_mean_pct <= g.phi_vol_max_pct)).all():
        raise ValueError("Invalid experimental min-mean-max ordering.")
    return s, g, main, validation


def fit_models(main):
    """Final full-training OLS: 4 + 3 + 3 coefficients, no LOOCV submodels."""
    models, records = {}, []
    for speed in SPEEDS:
        f = main.loc[main.v_mm_s == speed]
        if len(f) != 9 or set(f.role) != {"main"}:
            raise ValueError("Only nine main-condition means may enter each fit.")
        zh = (f.h_mm.to_numpy() - H_CENTER) / H_SCALE
        zp = (f.P_mm.to_numpy() - P_CENTER) / P_SCALE
        columns = [np.ones(9), zh, zp]
        if speed == 20:
            columns.append(zh**2)
        x = np.column_stack(columns)
        expected_ncoef = 4 if speed == 20 else 3
        if np.linalg.matrix_rank(x) != expected_ncoef:
            raise ValueError(f"Rank-deficient design at {speed} mm/s.")
        coded = np.linalg.lstsq(x, f.Y_mean_pp.to_numpy(), rcond=None)[0]
        q = coded[3] / H_SCALE**2 if speed == 20 else 0.0
        b = coded[1] / H_SCALE - 2*q*H_CENTER
        c = coded[2] / P_SCALE
        a = (coded[0] - coded[1]*H_CENTER/H_SCALE
             - coded[2]*P_CENTER/P_SCALE + q*H_CENTER**2)
        beta = np.array([a, b, c, q] if speed == 20 else [a, b, c])
        raw_columns = [np.ones(9), f.h_mm.to_numpy(), f.P_mm.to_numpy()]
        if speed == 20:
            raw_columns.append(f.h_mm.to_numpy()**2)
        raw_x = np.column_stack(raw_columns)
        independent = np.linalg.lstsq(raw_x, f.Y_mean_pp.to_numpy(), rcond=None)[0]
        if not np.allclose(raw_x@independent, x@coded, rtol=0, atol=1e-10):
            raise RuntimeError("Independent raw/coded OLS fits disagree.")
        if not np.allclose(raw_x@beta, x@coded, rtol=0, atol=1e-10):
            raise RuntimeError("Conversion to physical coefficients failed.")
        if not np.allclose(beta, COEFFICIENT_REFERENCE[speed], rtol=0, atol=5e-7):
            raise RuntimeError(f"Historical coefficient mismatch at {speed} mm/s.")
        models[speed] = beta
        for term, value in zip(("a", "b", "c", "q"), beta):
            records.append({
                "v_mm_s": speed, "term": term, "coefficient": float(value),
                "units": "pp" if term == "a" else "pp/mm^2" if term == "q" else "pp/mm",
                "n_training_conditions": 9, "n_training_specimens": 27,
                "training_group_ids": ";".join(f.group_id.tolist()),
            })
    if [len(models[s]) for s in SPEEDS] != [4, 3, 3] or len(records) != 10:
        raise RuntimeError("The final model must have exactly 4+3+3 coefficients.")
    return models, pd.DataFrame(records)


def predict_y(h, p, v, models):
    """Evaluate full-training models; interpolate outputs, not unequal arrays."""
    h, p = np.broadcast_arrays(np.asarray(h, float), np.asarray(p, float))
    eps = 1e-12
    if (not np.isfinite(h).all() or not np.isfinite(p).all()
            or np.any(h < H_LIMITS[0]-eps) or np.any(h > H_LIMITS[1]+eps)
            or np.any(p < P_LIMITS[0]-eps) or np.any(p > P_LIMITS[1]+eps)):
        raise ValueError("Prediction is outside the h-P study domain.")
    if np.ndim(v) != 0 or not np.isfinite(v) or not 20 <= v <= 120:
        raise ValueError("Speed must be a scalar between 20 and 120 mm/s.")

    def evaluate(speed):
        beta = models[speed]
        result = beta[0] + beta[1]*h + beta[2]*p
        return result + beta[3]*h**2 if speed == 20 else result

    if v in models:
        result = evaluate(v)
    elif v < 70:
        result = (70-v)/50*evaluate(20) + (v-20)/50*evaluate(70)
    else:
        result = (120-v)/50*evaluate(70) + (v-70)/50*evaluate(120)
    if not np.isfinite(result).all():
        raise ValueError("Non-finite Y prediction.")
    return result


def predict_porosity(h, p, v, models):
    """Reconstruct physical volumetric porosity; no clipping or smoothing."""
    return predict_y(h, p, v, models) + geometric_porosity(h, p)


def validation_results(validation, models):
    v = validation.copy()
    predictions, methods = [], []
    for r in v.itertuples():
        predictions.append(float(predict_porosity(r.h_mm, r.P_mm, r.v_mm_s, models)))
        methods.append("direct 70 mm/s final model" if r.v_mm_s == 70
                       else "0.6 Y_70 + 0.4 Y_120; then add phi_2")
    v["predicted_phi_vol_pct"] = predictions
    v["prediction_method"] = methods
    v["error_pp"] = v.predicted_phi_vol_pct - v.phi_vol_mean_pct
    v["absolute_percentage_error_pct"] = abs(v.error_pp)/v.phi_vol_mean_pct*100
    v["prediction_inside_experimental_minmax"] = (
        (v.predicted_phi_vol_pct >= v.phi_vol_min_pct)
        & (v.predicted_phi_vol_pct <= v.phi_vol_max_pct))
    stat = {"MAE_pp": float(abs(v.error_pp).mean()),
            "RMSE_pp": float(np.sqrt(np.mean(v.error_pp**2))),
            "MAPE_pct": float(v.absolute_percentage_error_pct.mean())}
    # Check the only intermediate-speed conditions use the specified interpolation.
    for r in v[v.v_mm_s == 90].itertuples():
        direct = (.6*predict_y(r.h_mm, r.P_mm, 70, models)
                  + .4*predict_y(r.h_mm, r.P_mm, 120, models)
                  + geometric_porosity(r.h_mm, r.P_mm))
        if abs(direct-r.predicted_phi_vol_pct) > 1e-12:
            raise RuntimeError("90 mm/s speed interpolation check failed.")
    return v, stat


def configure_style():
    """Use installed Roboto; never read a font from the script directory."""
    font_path = None
    try:
        candidate = font_manager.findfont(
            FontProperties(family="Roboto", style="normal", weight="normal"),
            fallback_to_default=False)
        if Path(candidate).is_file():
            font_path = Path(candidate)
    except ValueError:
        pass
    if font_path is None:
        candidates = [
            Path.home()/"AppData/Local/Microsoft/Windows/Fonts/Roboto-Regular.ttf",
            Path(os.environ.get("WINDIR", r"C:\Windows"))/"Fonts/Roboto-Regular.ttf",
        ]
        font_path = next((p for p in candidates if p.is_file()), None)
    if font_path is None:
        raise FileNotFoundError("Install Roboto Regular in Windows and restart Python.")
    font_manager.fontManager.addfont(str(font_path))
    regular = FontProperties(fname=str(font_path))
    plt.rcParams.update({
        "font.family": regular.get_name(), "font.weight": "normal",
        "font.size": 14, "axes.labelsize": 19, "xtick.labelsize": 15,
        "ytick.labelsize": 15, "axes.linewidth": 1.1,
        "xtick.direction": "in", "ytick.direction": "in",
        "xtick.major.width": 1.1, "ytick.major.width": 1.1,
        "mathtext.fontset": "stix", "text.usetex": False,
        "pdf.fonttype": 42, "ps.fonttype": 42, "pdf.compression": 0,
        "svg.fonttype": "none", "svg.hashsalt": "Figure7-final-10coef",
        "figure.facecolor": "white", "savefig.facecolor": "white",
    })
    regular.set_math_fontfamily("stix")
    print(f"Font: {font_path}")
    return regular


def contrast_ink(value, cmap, norm):
    luminance = np.dot(cmap(norm(value))[:3], [.2126, .7152, .0722])
    return "#343A40" if luminance > .40 else "#ECEEF0"


def interior_labels(ax, contours, cmap, norm):
    candidates = []
    for level, segments in zip(contours.levels, contours.allsegs):
        nonempty = [s for s in segments if len(s)]
        if not nonempty:
            continue
        points = np.concatenate(nonempty)
        coded = (points-[.43, .10])/[.04, .15]
        inside = np.all((coded > .14) & (coded < .86), axis=1)
        if inside.any():
            choice = np.argmin(np.sum((coded[inside]-.5)**2, axis=1))
            candidates.append(tuple(points[inside][choice]))
    if not candidates:
        return
    indices = np.unique(np.linspace(0, len(candidates)-1, min(2, len(candidates))).astype(int))
    labels = ax.clabel(contours, manual=[candidates[i] for i in indices],
                       inline=True, fontsize=10.5, fmt=lambda x: f"{x:g}")
    for label in labels:
        label.set_color(contrast_ink(float(label.get_text()), cmap, norm))


def target_band(ax, p, h, field, target, *, alpha=.14):
    value, tol = target["porosity_pct"], target["tolerance_pp"]
    lower, upper = value-tol, value+tol
    zmin, zmax = float(field.min()), float(field.max())
    if upper < zmin or lower > zmax:
        return False
    color = target["color"]
    ax.contourf(p,h,field,levels=[lower,upper],colors=[target.get("fill_color",color)],
                alpha=alpha,antialiased=False,zorder=2)
    boundaries = [x for x in (lower, upper) if zmin < x < zmax]
    if boundaries:
        ax.contour(p, h, field, levels=boundaries, colors=color, alpha=.90,
                   linestyles="--", linewidths=.85, zorder=3)
    if zmin < value < zmax:
        ax.contour(p, h, field, levels=[value], colors="white",
                   linewidths=2.1,alpha=.65,zorder=3)
        line = ax.contour(p, h, field, levels=[value], colors=color,
                          linewidths=1.8,zorder=3)
        # Full level list is required for robust manual placement in Matplotlib.
        segments = [s for s in line.allsegs[0] if len(s)]
        if segments:
            points = np.concatenate(segments)
            coded = (points-[.43, .10])/[.04, .15]
            inside = np.all((coded > .14) & (coded < .86), axis=1)
            if inside.any():
                choice = np.argmin(np.sum((coded[inside]-.5)**2, axis=1))
                labels = ax.clabel(line, manual=[tuple(points[inside][choice])],
                                   fmt={value: f"{value:g}%"}, fontsize=10.5,
                                   inline=True, colors=color)
                for label in labels:
                    label.set_bbox({"facecolor": "white", "alpha": .88,
                                    "edgecolor": "none", "pad": 1.3})
    return True


def axes_map(ax):
    ax.set(xlim=P_LIMITS, ylim=H_LIMITS)
    ax.xaxis.set_major_locator(ticker.FixedLocator([.43,.44,.45,.46,.47]))
    ax.yaxis.set_major_locator(ticker.FixedLocator([.10,.15,.20,.25]))
    ax.xaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))
    ax.yaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))
    ax.tick_params(pad=10)
    ax.set_xlabel(PITCH_LABEL, labelpad=7)
    ax.set_ylabel(r"Layer height, $h$ (mm)", labelpad=8)


def make_figure(main, validation, stats, p, h, fields, cfg, out, regular):
    fig, axes = plt.subplots(2, 2, figsize=cfg["figure_size_inches"])
    fig.subplots_adjust(left=.105, right=.97, bottom=.255, top=.95,
                        wspace=.32, hspace=.35)
    norm = Normalize(*cfg["color_limits_pct"])
    cmap = plt.get_cmap(cfg["colormap"])
    levels = np.linspace(*cfg["color_limits_pct"], 161)
    artists, map_points, stars, panel_tags = [], [], [], []
    special_levels = [t["porosity_pct"]+offset*t["tolerance_pp"]
                      for t in cfg["design_targets"] for offset in (-1,0,1)]
    for ax, letter, speed in zip([axes[0,0],axes[0,1],axes[1,0]], "abc", SPEEDS):
        field = fields[speed]
        # Retain all original contour bands; do not modify prediction values.
        # Same-face-color strokes cover vector polygon rendering seams.
        filled = ax.contourf(p,h,field,levels=levels,cmap=cmap,norm=norm,
                             antialiased=False,zorder=0)
        filled_artists = [filled] if hasattr(filled,"set_edgecolor") else filled.collections
        for artist in filled_artists:
            artist.set_edgecolor("face")
            artist.set_linewidth(1.0)
            artist.set_antialiased(False)
            artist.set_rasterized(False)
        artists.append(filled)
        ordinary = [x for x in cfg["contour_levels_pct"]
                    if field.min()<x<field.max() and not any(np.isclose(x,y) for y in special_levels)]
        if ordinary:
            lines = ax.contour(p,h,field,levels=ordinary,
                colors=[contrast_ink(x,cmap,norm) for x in ordinary],
                linewidths=.60,alpha=.68,zorder=1)
            interior_labels(ax,lines,cmap,norm)
        visible = [target_band(ax,p,h,field,t,alpha=cfg.get("target_fill_alpha",.14))
                   for t in cfg["design_targets"]]
        if visible and not any(visible):
            ax.text(.03,.05,"No target-feasible region",transform=ax.transAxes,fontsize=11,
                    bbox={"facecolor":"white","alpha":.85,"edgecolor":"none"})
        frame=main[np.isclose(main.v_mm_s,speed)]
        # Fill encodes measured porosity; background encodes predicted porosity.
        points=ax.scatter(frame.P_mm,frame.h_mm,c=frame.phi_vol_mean_pct,
            cmap=cmap,norm=norm,s=49,edgecolors="#242B31",linewidths=1.05,
            zorder=5,clip_on=False)
        map_points.append(points)
        points.set_path_effects([patheffects.Stroke(linewidth=2.7,foreground="white"),
                                patheffects.Normal()])
        axes_map(ax)
        panel_tags.append(ax.text(0,1.045,f"({letter})",transform=ax.transAxes,fontsize=19,
                fontweight="bold",va="bottom"))
        ax.text(.97,.965,f"Predicted range: {field.min():.2f}–{field.max():.2f}%",
                transform=ax.transAxes,ha="right",va="top",fontsize=11.2,zorder=6,
                bbox={"facecolor":"white","alpha":.91,"edgecolor":"none","pad":3})
        if speed==70:
            # One illustrative condition, at its unchanged real process coordinates.
            row=validation.loc[validation.group_id=="V2"].iloc[0]
            if not np.isclose(row.v_mm_s,speed):
                raise ValueError("V2 does not belong to the 70 mm/s map.")
            star=ax.scatter([row.P_mm],[row.h_mm],marker="*",s=180,
                facecolors=EXAMPLE_STAR,edgecolors="white",linewidths=.85,
                zorder=8,clip_on=False)
            stars.append((ax, star))
            star.set_path_effects([patheffects.Stroke(linewidth=1.6,foreground="#603C3C"),
                                   patheffects.Normal()])
            ax.annotate(f"V2  {row.phi_vol_mean_pct:.3f}%",
                (row.P_mm,row.h_mm),xytext=(-9,10),
                textcoords="offset points",fontsize=10.2,zorder=9,
                ha="right",va="bottom",
                bbox={"facecolor":"white","alpha":.90,"edgecolor":"none","pad":1.4})

    ax=axes[1,1]
    x=np.arange(len(validation));obs=validation.phi_vol_mean_pct.to_numpy()
    pred=validation.predicted_phi_vol_pct.to_numpy()
    lo=validation.phi_vol_min_pct.to_numpy();hi=validation.phi_vol_max_pct.to_numpy()
    lower=validation.predicted_tolerance_lower_pct.to_numpy()
    upper=validation.predicted_tolerance_upper_pct.to_numpy()
    target=cfg["design_targets"][0]
    obs_x,pred_x=x-.07,x+.07
    for xp,yl,yh in zip(pred_x,lower,upper):
        ax.add_patch(Rectangle((xp-.23,yl),.46,yh-yl,
            facecolor=target.get("fill_color",target["color"]),edgecolor=target["color"],
            linewidth=1.05,linestyle="--",alpha=.55,zorder=1.5))
    for xo,xp,yo,yp in zip(obs_x,pred_x,obs,pred):
        ax.plot([xo,xp],[yo,yp],color="#929CA4",linewidth=1,zorder=1)
    if not np.all((lo <= obs) & (obs <= hi)):
        raise RuntimeError("Panel d: invalid measured min-mean-max ordering.")
    measured_errors = ax.errorbar(obs_x,obs,yerr=np.vstack([obs-lo,hi-obs]),fmt="o",markersize=7,
                color=MEASURED,ecolor=MEASURED,elinewidth=1,capsize=3,capthick=1,zorder=3)
    ax.scatter(pred_x,pred,marker="D",s=59,facecolors="white",
               edgecolors=PREDICTED,linewidths=1.25,zorder=4)
    ax.set(xlim=(-.5,3.5),ylim=(np.floor(min(lo.min(),lower.min())-.4),
                                np.ceil(max(hi.max(),upper.max())+.6)))
    ax.set_xticks(x,validation.group_id.tolist())
    ax.yaxis.set_major_locator(ticker.MultipleLocator(2))
    ax.set_xlabel("Additional condition",labelpad=7)
    ax.set_ylabel(r"Volumetric porosity, $\varphi_{\mathrm{vol}}$ (%)",labelpad=8)
    ax.grid(axis="y",color="#E3E6E8",linewidth=.6,linestyle=(0,(3,3)),zorder=0)
    ax.set_axisbelow(True)
    panel_tags.append(ax.text(0,1.045,"(d)",transform=ax.transAxes,fontsize=19,fontweight="bold",va="bottom"))
    count=int(validation.mean_within_prediction_tolerance.sum())
    tolerance=cfg["validation_tolerance_pp"]
    ax.text(.045,.965,f"MAE = {stats['MAE_pp']:.3f} pp\nRMSE = {stats['RMSE_pp']:.3f} pp\n"
            f"Within ±{tolerance:g} pp: {count}/{len(validation)}",
            transform=ax.transAxes,va="top",fontsize=12.0,linespacing=1.5)
    symbols=[Line2D([],[],marker="o",linestyle="none",color=MEASURED,markersize=7,
                    label="Measured"),
             Line2D([],[],marker="D",linestyle="none",markeredgecolor=PREDICTED,
                    markerfacecolor="white",markersize=7,label="Predicted"),
             Line2D([],[],marker="*",linestyle="none",markeredgecolor="white",
                    markerfacecolor=EXAMPLE_STAR,markersize=13,label="V2 example"),
             Line2D([],[],color=target["color"],linewidth=2.0,
                    label=f"{target['porosity_pct']:g}% map target"),
             Patch(facecolor=target.get("fill_color",target["color"]),
                   edgecolor=target["color"],linestyle="--",alpha=.55,
                   label=f"±{tolerance:g} pp band / window")]
    fig.legend(handles=symbols,loc="lower center",bbox_to_anchor=(.54,.145),
                ncol=len(symbols),frameon=False,fontsize=11.5,
                columnspacing=1.7,handlelength=1.5,handletextpad=.6)
    color_ax=fig.add_axes([.21,.090,.65,.020])
    colorbar=fig.colorbar(artists[0],cax=color_ax,orientation="horizontal",
                          ticks=cfg["colorbar_ticks_pct"])
    colorbar.ax.tick_params(labelsize=13,length=4,direction="out")
    colorbar.set_label(r"Volumetric porosity, $\varphi_{\mathrm{vol}}$ (%)",
                       fontsize=17,labelpad=6)

    if colorbar.solids is not None:
        colorbar.solids.set_rasterized(False)
        colorbar.solids.set_edgecolor("face")
    fig.canvas.draw()
    for text in fig.findobj(match=mpl.text.Text):
        fp=regular.copy()
        fp.set_size(text.get_fontsize())
        text.set_fontproperties(fp)
    for text in panel_tags:
        text.set_path_effects([patheffects.withStroke(linewidth=.4, foreground="black"),
                               patheffects.Normal()])
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    for text in fig.findobj(match=mpl.text.Text):
        if text.get_visible() and text.get_text():
            box=text.get_window_extent(renderer)
            if (box.x0 < -1 or box.y0 < -1 or
                    box.x1 > fig.bbox.width+1 or box.y1 > fig.bbox.height+1):
                raise RuntimeError(f"Text outside figure canvas: {text.get_text()}")
    if len(map_points)!=3 or any(len(c.get_offsets())!=9 for c in map_points):
        raise RuntimeError("Each map must show nine actual main conditions.")
    for collection,speed in zip(map_points,SPEEDS):
        frame=main.loc[main.v_mm_s==speed]
        if not np.allclose(collection.get_offsets(),frame[["P_mm","h_mm"]].to_numpy(),
                           rtol=0,atol=1e-12):
            raise RuntimeError("Main-condition map coordinates changed.")
        if not np.allclose(collection.get_array(),frame.phi_vol_mean_pct,
                           rtol=0,atol=1e-12):
            raise RuntimeError("Main marker colors must encode measured group means.")
    if len(stars)!=1 or stars[0][0] is not axes[0,1]:
        raise RuntimeError("Only panel b may contain the V2 red star.")
    if not np.allclose(stars[0][1].get_offsets(),[[.46,.20]],rtol=0,atol=1e-12):
        raise RuntimeError("V2 must remain at its actual experimental coordinates.")
    if measured_errors.has_xerr or not measured_errors.has_yerr:
        raise RuntimeError("Panel d must have vertical experimental min-max bars.")
    segments=measured_errors.lines[2][0].get_segments()
    if len(segments)!=4:
        raise RuntimeError("Panel d must contain all four experimental ranges.")
    for i,segment in enumerate(segments):
        if not np.allclose(segment,[[obs_x[i],lo[i]],[obs_x[i],hi[i]]],
                           rtol=0,atol=1e-12):
            raise RuntimeError("Panel d error-bar endpoints differ from real min/max.")
    for map_ax in (axes[0,0],axes[0,1],axes[1,0]):
        if map_ax.get_xlabel()!=PITCH_LABEL:
            raise RuntimeError("Inconsistent line-pitch terminology.")
    if len(axes[1,1].patches)!=4:
        raise RuntimeError("Expected four prediction-centered acceptance windows.")
    for suffix in ("pdf","svg","png"):
        fig.savefig(out/f"Figure7.{suffix}",dpi=cfg["png_dpi"],transparent=False)
    plt.close(fig)



def caption(cfg, validation):
    return (
        "**Figure 7. Speed-conditioned porosity design maps and "
        "additional-condition prediction assessment.** "
        "(a-c) Predicted volumetric porosity at printing speeds of 20, 70, "
        "and 120 mm/s, respectively. Line pitch ($P$) denotes the prescribed "
        "center-to-center distance between adjacent deposited roads. "
        "The fields are reconstructed from the rounded-profile geometric term "
        "and final speed-conditioned $Y$ models: $a_{20}+b_{20}h+c_{20}P+q_{20}h^2$ "
        "at 20 mm/s and $a_v+b_vh+c_vP$ at 70 and 120 mm/s. "
        "The ten coefficients are fitted by equally weighted OLS to the "
        "27 main-condition means (three specimens per condition); these "
        "are full-training fits rather than LOOCV fold models. "
        "Ordinary contours indicate constant predicted porosity. The yellow "
        "11.5% contour and pale-yellow band bounded by dashed lines represent "
        "the 11.5% design target and its +/-0.5 percentage-point (pp) tolerance. "
        "Filled circles mark the actual main-condition coordinates; their "
        "colors encode measured three-specimen means on the same 5.5-15.5% "
        "scale as the predicted backgrounds. The red star in (b) marks V2 "
        "at its actual parameters and is labelled with its measured mean. "
        "The shaded design regions are model-based nominal feasible regions, "
        "not regions experimentally verified at every point; V2 is a "
        "retrospective example, not a prospectively selected design validation. "
        "(d) Measured five-specimen means (blue circles), min-max ranges "
        "(vertical error bars), and model predictions (open diamonds) for "
        "V1-V4, all excluded from coefficient fitting. Here the pale-yellow "
        "engineering acceptance windows are centered on the individual "
        "predictions (+/-0.5 pp), whereas the map band is centered on the "
        "common 11.5% target. Neither is a statistical confidence or prediction "
        "interval. V2 and V4 satisfy the mean-response acceptance criterion "
        "(2/4 conditions). In $(h,P,v)$ order, the additional conditions are "
        "V1=(0.15 mm, 0.45 mm, 70 mm/s), "
        "V2=(0.20 mm, 0.46 mm, 70 mm/s), "
        "V3=(0.25 mm, 0.47 mm, 90 mm/s), and "
        "V4=(0.10 mm, 0.43 mm, 90 mm/s). "
        "V1/V2 use the 70 mm/s model; V3/V4 use "
        "$0.6\\widehat{Y}_{70}+0.4\\widehat{Y}_{120}$, followed by "
        "addition of $100(1-\\pi/4)h/P$.\n"
    )


def calculate_and_check(main, val, stats, models, cfg):
    """Numerical checks run before any official figure is exported."""
    pa = np.linspace(*P_LIMITS, cfg["grid_size"])
    ha = np.linspace(*H_LIMITS, cfg["grid_size"])
    p, h = np.meshgrid(pa, ha)
    fields = {speed: predict_porosity(h, p, speed, models) for speed in SPEEDS}
    checks = ["101 frozen specimen rows retained; CSV SHA256 matched.",
              "27 main x 3 + 4 additional x 5; no exclusions.",
              "Condition means receive equal OLS weights; additional groups excluded.",
              "Coefficient structure and historical coefficient checks: 4+3+3 PASS."]
    summary = []
    for speed, field in fields.items():
        if field.shape != (201, 201) or not np.isfinite(field).all():
            raise RuntimeError("Invalid prediction field.")
        lo, hi = float(field.min()), float(field.max())
        if lo < cfg["color_limits_pct"][0] or hi > cfg["color_limits_pct"][1]:
            raise RuntimeError("The shared color scale does not contain the field.")
        mask = abs(field - TARGET) <= DESIGN_TOLERANCE
        expected = FIELD_REFERENCE[speed]
        atol = 1e-6 if speed == 20 else 1e-9
        if not np.allclose([lo, hi], expected[:2], rtol=0, atol=atol):
            raise RuntimeError(f"Unexpected prediction range at {speed} mm/s.")
        if int(mask.sum()) != expected[2]:
            raise RuntimeError(f"Unexpected feasible-node count at {speed} mm/s.")
        if speed in (70, 120):
            a, b, c = OLD_LINEAR_REFERENCE[speed]
            unchanged = a + b*h + c*p + geometric_porosity(h, p)
            if not np.allclose(field, unchanged, rtol=0, atol=1e-9):
                raise RuntimeError("A 70/120 mm/s field changed unexpectedly.")
        summary.append({
            "v_mm_s": speed, "predicted_min_pct": lo, "predicted_max_pct": hi,
            "target_pct": TARGET, "design_tolerance_pp": DESIGN_TOLERANCE,
            "target_lower_pct": TARGET-DESIGN_TOLERANCE,
            "target_upper_pct": TARGET+DESIGN_TOLERANCE,
            "feasible_grid_nodes": int(mask.sum()), "grid_nodes_total": int(mask.size),
            "h_min_mm": H_LIMITS[0], "h_max_mm": H_LIMITS[1],
            "P_min_mm": P_LIMITS[0], "P_max_mm": P_LIMITS[1],
            "feasible_region_role": "model-based nominal region",
        })
        checks.append(f"{speed} mm/s: range {lo:.9f}-{hi:.9f}%; "
                      f"feasible nodes {int(mask.sum())}/{mask.size}: PASS.")
    interp90 = predict_y(h, p, 90, models)
    if not np.allclose(interp90, .6*predict_y(h, p, 70, models)
                       + .4*predict_y(h, p, 120, models), rtol=0, atol=1e-12):
        raise RuntimeError("90 mm/s interpolation must be 0.6 Y70 + 0.4 Y120.")
    for r in val.itertuples():
        ref = VALIDATION_REFERENCE[r.group_id]
        calculated = [r.phi_vol_mean_pct, r.phi_vol_min_pct,
                      r.phi_vol_max_pct, r.predicted_phi_vol_pct]
        if not np.allclose(calculated, ref, rtol=0, atol=1e-9):
            raise RuntimeError(f"Additional-condition result changed: {r.group_id}")
        if not r.phi_vol_min_pct <= r.phi_vol_mean_pct <= r.phi_vol_max_pct:
            raise RuntimeError("Invalid measured min-mean-max ordering.")
    if not np.isclose(stats["MAE_pp"], .5147557707520622, rtol=0, atol=1e-9):
        raise RuntimeError("Additional-condition MAE changed.")
    if not np.isclose(stats["RMSE_pp"], .6387626718547781, rtol=0, atol=1e-9):
        raise RuntimeError("Additional-condition RMSE changed.")
    if set(val.loc[val.mean_within_prediction_tolerance, "group_id"]) != {"V2", "V4"}:
        raise RuntimeError("Expected V2 and V4 within prediction-centered tolerance.")
    checks += ["Whole-grid 90 mm/s output interpolation: PASS.",
               "V1-V4 means, min/max, predictions, MAE/RMSE and 2/4 acceptance: PASS.",
               "Design band: 11.5 +/-0.5 pp; acceptance windows: prediction +/-0.5 pp.",
               "No clipping, numerical smoothing or model selection.",
               "V2 is shown once, at its real experimental coordinates in panel (b)."]
    return p, h, fields, pd.DataFrame(summary), checks


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    specimens, groups, main_groups, additional = load_groups()
    models, coefficients = fit_models(main_groups)
    val, stats = validation_results(additional, models)
    val["engineering_tolerance_pp"] = ACCEPTANCE_TOLERANCE
    val["predicted_tolerance_lower_pct"] = val.predicted_phi_vol_pct-ACCEPTANCE_TOLERANCE
    val["predicted_tolerance_upper_pct"] = val.predicted_phi_vol_pct+ACCEPTANCE_TOLERANCE
    val["mean_within_prediction_tolerance"] = abs(val.error_pp) <= ACCEPTANCE_TOLERANCE
    val["predicted_Y_pp"] = [
        float(predict_y(r.h_mm, r.P_mm, r.v_mm_s, models)) for r in val.itertuples()]
    p, h, fields, summary, checks = calculate_and_check(
        main_groups, val, stats, models, CFG)
    for name, frame in (
            ("Figure7_validation_results.csv", val),
            ("Figure7_model_coefficients.csv", coefficients),
            ("Figure7_design_summary.csv", summary)):
        frame.to_csv(OUTPUT_DIR/name, index=False, encoding="utf-8-sig", float_format="%.17g")
    cap = caption(CFG, val)
    if "Line pitch" not in cap or "center-to-center" not in cap:
        raise RuntimeError("Missing line-pitch definition in caption.")
    (OUTPUT_DIR/"Figure7_caption.md").write_text(cap, encoding="utf-8")
    regular = configure_style()
    make_figure(main_groups, val, stats, p, h, fields, CFG, OUTPUT_DIR, regular)
    checks.append("Plot: three maps, one V2 star, four measured ranges/windows; "
                  "shared color scale and text boundaries checked.")
    checks.append(f"Roboto Regular: {regular.get_file()}; mathematics: STIX.")
    text = "\n".join(checks) + "\n\n" + coefficients.to_string(index=False)
    text += "\n\n" + summary.to_string(index=False) + "\n"
    text += f"\nMAE={stats['MAE_pp']:.12f} pp; RMSE={stats['RMSE_pp']:.12f} pp\n"
    text += "EXPORT_STATUS: SUCCESS\n"
    (OUTPUT_DIR/"Figure7_checks.txt").write_text(text, encoding="utf-8-sig")
    print(text)
    print(f"Saved Figure7 outputs to: {OUTPUT_DIR}")

if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        with (OUTPUT_DIR/"Figure7_checks.txt").open("a", encoding="utf-8") as handle:
            handle.write(f"\nEXPORT_STATUS: FAILED - {type(error).__name__}: {error}\n")
            handle.write("Existing output files may belong to an earlier run.\n")
        raise
