from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from datetime import datetime, timezone
from hashlib import sha256
from typing import Any

from .intent_models import (INTENT_CONTRACT_VERSION, INTENT_SYSTEM_INSTRUCTION,
                            IntentContext, IntentModelClient, proposal_from_mapping)


class IntentProviderError(RuntimeError):
    pass


class OpenAIIntentClient(IntentModelClient):
    """Optional reference provider using Responses structured output and stdlib HTTP."""

    provider_identity = "openai-responses-api"

    def __init__(self, api_key: str | None = None, model: str | None = None,
                 timeout_seconds: float = 20.0):
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self._model = model or os.environ.get("CNPW_OPENAI_INTENT_MODEL", "gpt-5")
        self._timeout_seconds = timeout_seconds

    def propose_intent(self, user_text: str, context: IntentContext) -> object:
        if not self._api_key:
            raise IntentProviderError("AI provider credentials are unavailable.")
        payload = {"model": self._model, "store": False, "instructions": INTENT_SYSTEM_INSTRUCTION, "input": [{"role": "user", "content": [{"type": "input_text", "text": self._user_message(user_text, context)}]}], "text": {"format": {"type": "json_schema", "name": "cnpw_intent_proposal", "strict": True, "schema": self._schema()}}}
        request = urllib.request.Request("https://api.openai.com/v1/responses", data=json.dumps(payload).encode("utf-8"), headers={"Authorization": f"Bearer {self._api_key}", "Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=self._timeout_seconds) as response:
                body = json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError, json.JSONDecodeError) as exc:
            raise IntentProviderError("AI provider request failed.") from exc
        try:
            structured = json.loads(self._output_text(body))
        except (KeyError, TypeError, json.JSONDecodeError) as exc:
            raise IntentProviderError("AI provider returned no valid structured intent.") from exc
        raw_hash = sha256(json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
        structured.update({"intent_contract_version": INTENT_CONTRACT_VERSION, "request_id": structured.get("request_id", raw_hash[:16]), "provider_identity": self.provider_identity, "model_identity": self._model, "raw_response_hash": raw_hash, "created_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat()})
        return proposal_from_mapping(structured)

    @staticmethod
    def _user_message(user_text: str, context: IntentContext) -> str:
        return "User request:\n" + user_text + "\n\nActive Result names (directions are already defined by the input file and must not be inferred):\n" + ", ".join(context.active_result_names)

    @staticmethod
    def _output_text(body: dict[str, Any]) -> str:
        if isinstance(body.get("output_text"), str):
            return body["output_text"]
        for item in body.get("output", []):
            for content in item.get("content", []):
                if content.get("type") == "output_text" and isinstance(content.get("text"), str):
                    return content["text"]
        raise KeyError("output_text")

    @staticmethod
    def _schema() -> dict[str, Any]:
        return {"type": "object", "additionalProperties": False, "properties": {"intent": {"type": "string", "enum": ["MODE_A", "MODE_B_SIMPLIFIED_RESULT_A_GL7", "UNSUPPORTED"]}, "short_reason": {"type": "string"}, "confidence_label": {"type": ["string", "null"], "enum": ["HIGH", "MEDIUM", "LOW", None]}}, "required": ["intent", "short_reason", "confidence_label"]}
