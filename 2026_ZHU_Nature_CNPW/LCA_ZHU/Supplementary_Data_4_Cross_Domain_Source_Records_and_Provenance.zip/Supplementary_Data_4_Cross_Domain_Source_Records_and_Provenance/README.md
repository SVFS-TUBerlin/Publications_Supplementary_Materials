# Supplementary Data 4 — Cross-domain source records and provenance

This package preserves the provenance and source-to-input construction of the six external cross-domain datasets while keeping third-party source files separate from the publication supplement unless an author-derived provenance object is explicitly included.

The package contains:
- `Source_Provenance_Ledger.xlsx`: case-level source identity, citations, source locators, archived-source SHA256 values, candidate-population rules and publication actions;
- `Source_to_Input_Mapping.xlsx`: response-level mappings from source variables/tables to the exact frozen CNPW responses supplied in Supplementary Data 5, including favourable directions, units/scales, transformations and exclusions;
- `source_records/`: one human-readable provenance record per case;
- `source_records/PISA2022/PISA2022_Source_Extract_81x3.xlsx`: an author-derived frozen provenance extract from the published OECD PISA 2022 tables, not the original OECD workbook;
- `LOCAL_SOURCE_ARCHIVE_SHA256.csv`: identities of the locally archived source files used during construction;
- `LICENSE_AND_REDISTRIBUTION_STATUS.csv`: the publication decision for source redistribution;
- `MANIFEST.csv` and `SHA256SUMS.txt`: package-integrity records.

Publication boundary:
- original third-party files are not bundled in SD4 by default;
- source identity, bibliographic provenance, official source location, archived-source hash and the documented source-to-input transformation are retained;
- the exact standardized CNPW execution inputs are supplied separately in Supplementary Data 5;
- deterministic outputs and reports are supplied separately in Supplementary Data 6.

This separation implements the frozen chain:

`source record → frozen CNPW input → frozen CNPW output`.
