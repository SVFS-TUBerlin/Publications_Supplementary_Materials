import copy
import unittest
from unittest.mock import patch

from agent.qcca_analyzer import analyze_qcca, recovery_for_target
from agent.qcca_pipeline import run_core_qcca
from agent.qcca_verifier import verify_qcca
from src.mode_b import run_mode_b
from src.models import ProtectionContract
from src.terminal import prune_terminal
from tests.helpers import make_dataset


class ResidualQccaTests(unittest.TestCase):
    def test_multi_protected_global_scope_columns_and_recovery_sets(self):
        d = make_dataset([str(i) for i in range(7)], ['p1','p2','r1','r2'],
                         ['maximize']*4, [[i,6-i,i,6-i] for i in range(7)])
        b = run_mode_b(d, ProtectionContract('equal_count_global_qualification', (0,1)))
        outcome = run_core_qcca(d, b, 'GLOBAL')
        self.assertEqual('COMPLETED', outcome.status)
        q = outcome.result
        self.assertEqual(('r1','r2'), q.criterion_names)
        self.assertEqual(tuple(b.protected['omega_candidate_ids']), q.domain_candidate_ids)
        self.assertEqual(3, len(q.subset_capabilities))
        self.assertEqual(((4,4),), q.level_matrix)
        for target in range(1,8):
            recovery = recovery_for_target(q, target)
            for route in recovery.recovery_sets:
                self.assertLessEqual(set(route.removed_responses + route.retained_responses), {'r1','r2'})
        bad = copy.deepcopy(b)
        bad.stage1.active_criteria = [0,1,2,3]
        self.assertEqual('UNAVAILABLE', run_core_qcca(d, bad, 'GLOBAL').status)

    def test_singleton_global_system_has_no_empty_recovery(self):
        d = make_dataset([str(i) for i in range(7)], ['p1','p2','r'],
                         ['maximize']*3, [[i,6-i,i] for i in range(7)])
        b = run_mode_b(d, ProtectionContract('equal_count_global_qualification', (0,1)))
        q = run_core_qcca(d, b, 'GLOBAL').result
        self.assertEqual(('r',), q.criterion_names)
        self.assertEqual(1, len(q.subset_capabilities))
        self.assertEqual((), q.leave_one_out_recoveries)
        self.assertTrue(verify_qcca(q,4).passed)
        self.assertEqual(0, recovery_for_target(q,4).minimum_recovery_order)
        self.assertEqual('UNRECOVERABLE_WITH_NONEMPTY_RETAINED_BLOCK', recovery_for_target(q,5).state)

    def test_global_recovery_can_remove_only_residual_response(self):
        # Fixed projected residual matrix: target 7 requires one of two removals.
        q = analyze_qcca(('r1','r2'), [[7,4],[4,7]], 4, mode='MODE_B')
        r = recovery_for_target(q,7)
        self.assertEqual(1, r.minimum_recovery_order)
        self.assertEqual({('r1',),('r2',)}, {x.removed_responses for x in r.recovery_sets})

    def test_protected_responses_participate_in_local_and_terminal(self):
        d = make_dataset([str(i) for i in range(7)], ['p1','p2','r'],
                         ['maximize']*3, [[i,6-i,1] for i in range(7)])
        # Raw contract admits the tradeoff endpoints, while residual r is tied.
        from decimal import Decimal
        contract = ProtectionContract('explicit_raw_thresholds', (0,1), raw_thresholds={0:Decimal(0),1:Decimal(0)})
        with patch('src.mode_a.prune_terminal', wraps=prune_terminal) as terminal:
            b = run_mode_b(d, contract)
        self.assertEqual([0,1,2], terminal.call_args.args[3])
        self.assertTrue(b.stage2.local_qcca_required)
        self.assertEqual({'p1','p2','r'}, set(b.stage2.local))
        q = run_core_qcca(d,b,'LOCAL').result
        self.assertEqual(('p1','p2','r'), q.criterion_names)
        self.assertEqual(tuple(d.candidate_ids[i] for i in b.stage1.retained), q.domain_candidate_ids)
        self.assertEqual(7,len(q.subset_capabilities))
        self.assertEqual(4,q.full_system_ceiling)
        self.assertEqual([3],b.terminal)
        self.assertEqual([5,6,7], [x.target for x in q.target_recoveries])
