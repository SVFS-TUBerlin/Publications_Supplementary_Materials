# Supplementary Data 1 — Controlled-system source and validation data

## Scientific role

This package contains the author-generated source and validation evidence required to reproduce the upstream response-generation layer used by the controlled PLA–MEX CNPW system.

The chain is:

`27 frozen process-state anchors -> trilinear state reconstruction -> frozen response equations -> independent V1–V4 audit`.

The canonical 7,056-candidate response table is supplied separately as Supplementary Data 2.

## Contents

- `G1_G27_Frozen_ProcessState_Anchors.csv` — frozen 3×3×3 process-state anchors.
- `V1_V4_Independent_EndToEnd_Audit.csv` — four reserved end-to-end validation conditions.
- `MODEL_AND_SCOPE.md` — domain, equations, units, validation summary and scope.
- `generate_7056_response_space.py` — independent reconstruction script.
- `REPRODUCTION_CHECK.json` — row-by-row replay audit against the frozen 7,056 response space.
- `MANIFEST.csv` — file-level provenance and SHA256 hashes.

## Boundary

This package reproduces the decision-layer input used by CNPW. It does not redevelop the upstream EM4/UM5 model-selection study.
