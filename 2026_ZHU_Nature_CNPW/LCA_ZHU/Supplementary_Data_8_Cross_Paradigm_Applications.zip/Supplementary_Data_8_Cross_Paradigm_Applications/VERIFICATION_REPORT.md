# SD8 claim-verification report — final formalism v1.6.0

## Verification standard

This report records claim-specific checks on the nine published-system applications in Results 2.3 and Table 1. The checks verify the supplied frozen/reconstructed CNPW evidence; they are not presented as independent replication of the source studies.

## Cases unchanged from the prior verified package

The previously verified headline checks remain unchanged for:
- Case01 NGC;
- Case02 ELECTRE;
- Case03 NAUTILI;
- Case04 SMAA/MVSK;
- Case07 WIBA;
- Case08 RAS.

Their evidence objects are byte-preserved in this rebuild.

## Case05 — Pesticide

The complete 200,625-scenario universe was replayed blockwise under the final Stage-1 positional/tie-upward rule and adaptive Stage-2 Local formalism.

Final manuscript-claim checks:
- native rank-1 in Stage-1 W1 = **30/47**;
- native terminal/co-terminal agreement = **24/47**;
- disagreements = **17 below C(J) + 6 same-ceiling refinement differences**;
- top-compatible blocks = **21/47**;
- collapsed blocks = **26/47**;
- **25/26** collapsed blocks recover after a single-impact removal;
- **Tomato-H** requires a minimum two-impact removal.

Adaptive Stage-2 correction:
- Chili-I resolves at K_L*=9 to scenario 40415;
- Tomato-I resolves at K_L*=8 to scenario 13416;
- Okra-I freezes at K_L*=182 with Local capability LL181; final co-terminals are **6584 and 6585**, superseding the legacy fixed-K_L=7 four-member terminal set.

The headline manuscript counts remain unchanged.

## Case06 — MGCA

The source study generated one least-cost solution plus 100 MGA iterates at each nominal 2%, 4%, 6%, 8% and 10% total-system-cost slack. After exact duplicate removal, cumulative source-native budget populations are 1, 87, 166, 252, 340 and 418.

Realized cost ratios exhibit solver-level boundary overshoot, with a maximum excess of approximately **0.000318995 percentage points** above the generating nominal budget. The final replay therefore uses source-native MGA budget-batch membership as the protected-domain definition and retains realized slack only as a numerical audit.

For every 2–10% protected state:
- residual seven-response capability = **GL5**;
- residual W1 = **MGCA-008 / MGCA-052**;
- all eight active responses re-enter Stage 2;
- final terminal = **MGCA-008**.

Conditional residual QCCA:
- 2%: minimum recovery order r*=2; remove Zone-1 Cost + Zone-3 Cost -> **GL6**;
- 4%, 6%, 8%, 10%: remove Zone-1 Cost -> **GL7**.

The manuscript MGCA claims are reproduced unchanged.

## Case09 — ALEM

Stored Global labels were checked against the final positional/tie-upward K_G=7 rule and matched exactly.

Representative Instance 0:
- native lexicographic rank-1 profile = **(7,7,2,1)**;
- final Mode-A terminal profile = **(7,4,6,4)**;
- dual-GL7 protection on Saved Species and Cost retains 30 candidates;
- residual Stage-1 capability over Compactness/Population = **GL3** with W1 ranks **26 and 29**.

Under final all-active-response Stage 2 at K_L=7:
- rank 26 Local profile = **(7,7,7,1)**;
- rank 29 Local profile = **(7,1,7,7)**;
- both sorted profiles = **(1,7,7,7)**;
- neither raw-response dominates the other.

Final result: **co-terminal ranks 26 and 29**, both with frozen Global profile **(7,7,4,3)**.

The Table-1 / main-text Global-profile comparison is unchanged. Cost removal raises C(J) in **10/10** instances, as previously reported.

## Conclusion

The final v1.6.0 SD8 rebuild removes the three identified legacy inconsistencies without changing the manuscript headline conclusions for Pesticide, MGCA or ALEM. Case-specific final evidence workbooks and machine-readable audits are included in the corresponding folders.
