# MVSK-SME vs CNPW cross-domain validation — v1

## Source case
Angilella et al. (2026), *An enhanced simulation-based approach for multicriteria evaluation of SMEs’ performance*, Annals of Operations Research 360:767–813.

## Frozen candidate-response universe
Primary analysis uses the published 2022 performance matrix: 46 listed European SMEs × 10 criteria. Criteria directions follow the paper: E_score↑, S_score↑, G_score↑, RD_Intensity↑, Fut_Growth↑, Leverage↓, Liquidity↑, Coverage↑, Profitability↑, Activity↑.

CNPW configuration: Mode A, Kg=7, Kl=7, tie-preserving nominal equal-count Stage 1; Stage 2 equal-width supplied-scale qualification; terminal worst-first lexicographic local-level profile then raw-response dominance.

## Primary 2022 result
- N = 46, m = 10
- Q1* = 4
- |W1| = 1
- W1 = a21 Eleco
- Q2* = 7
- W2T = a21 Eleco

The unique Stage-1 survivor is **a21 Eleco**. Its global level profile is:

E_score L4, S_score L4, G_score L6, RD_Intensity L4, Fut_Growth L5, Leverage L6, Liquidity L4, Coverage L6, Profitability L7, Activity L7

Because W1 is a singleton, Stage 2 is degenerate by construction: every local response is L7 and Q2*=7. The substantive selection occurs entirely in Stage 1.

## Native MVSK comparison
For 2022, Eleco has published MVSK rank 12 under lambda=3, 18, and 36. Under lambda=36, the native top-10 candidates and their CNPW common qualification are:

|   MVSK_rank | ID   | Company                     |   Q1 |
|------------:|:-----|:----------------------------|-----:|
|           1 | a6   | AC Immune                   |    2 |
|           2 | a17  | Dbv Technologies            |    1 |
|           3 | a4   | Relief Therapeutics Holding |    1 |
|           4 | a44  | BioArctic                   |    3 |
|           5 | a45  | MAG Interactive             |    2 |
|           6 | a1   | Kuros Biosciences           |    3 |
|           7 | a41  | Bactiguard Holding          |    3 |
|           8 | a15  | Genift                      |    2 |
|           9 | a20  | OSE Immunotherapeutics      |    2 |
|          10 | a9   | Zealand Pharma              |    1 |

The native MVSK rank-1 candidate, **a6 AC Immune**, has CNPW Q1=2. Its weakest global levels are Coverage=L2 and Profitability=L2. Hence the preference-uncertainty ranking and equal-priority joint-qualification result disagree strongly on the top candidate.

## Kg sensitivity, 2022

|   Kg |   Q1_star |   W1_n | W1_IDs                             |
|-----:|----------:|-------:|:-----------------------------------|
|    4 |         2 |      9 | a1,a11,a21,a24,a27,a38,a41,a44,a45 |
|    5 |         3 |      1 | a21                                |
|    6 |         3 |      2 | a1,a21                             |
|    7 |         4 |      1 | a21                                |
|    8 |         4 |      1 | a21                                |
|    9 |         5 |      1 | a21                                |
|   10 |         5 |      1 | a21                                |

Eleco is retained in the highest common-qualification set for every tested Kg from 4 to 10; it is the unique survivor for Kg=5,7,8,9,10 and co-survives with a1 at Kg=6.

## Leave-one-criterion-out, 2022

| Removed criterion   |   Q1_star |   W1_n | W1_IDs   |
|:--------------------|----------:|-------:|:---------|
| E_score             |         4 |      2 | a1,a21   |
| S_score             |         4 |      2 | a21,a45  |
| G_score             |         4 |      2 | a21,a30  |
| RD_Intensity        |         4 |      1 | a21      |
| Fut_Growth          |         4 |      2 | a21,a44  |
| Leverage            |         4 |      1 | a21      |
| Liquidity           |         4 |      2 | a21,a25  |
| Coverage            |         4 |      1 | a21      |
| Profitability       |         4 |      2 | a21,a38  |
| Activity            |         4 |      1 | a21      |

Removing any single criterion does **not** raise Q1* above L4. Thus the L4 ceiling is not attributable to one unique criterion; it is a genuinely multivariate compatibility limit at full 10-criterion scope.

## All-subset compatibility, 2022

|   subset_size |   4 |   5 |   6 |   7 |
|--------------:|----:|----:|----:|----:|
|             1 |   0 |   0 |   0 |  10 |
|             2 |   0 |   1 |  14 |  30 |
|             3 |   7 |  34 |  57 |  22 |
|             4 |  58 | 101 |  44 |   7 |
|             5 | 133 | 104 |  14 |   1 |
|             6 | 153 |  55 |   2 |   0 |
|             7 | 104 |  16 |   0 |   0 |
|             8 |  43 |   2 |   0 |   0 |
|             9 |  10 |   0 |   0 |   0 |
|            10 |   1 |   0 |   0 |   0 |

Across all 2^10-1 = 1023 non-empty criterion subsets, 70 subsets attain L7 and 201 attain at least L6, but all 10 leave-one-out 9-criterion subsets remain capped at L4. This shows a steep collapse in common qualification as the requirement block approaches the full 10-criterion problem.

## Temporal repeat (same protocol)

|   Year |   Q1_star |   W1_n | W1_IDs                 |   Q2_star | W2T_IDs   | W2T_native_MVSK_lam36   |
|-------:|----------:|-------:|:-----------------------|----------:|:----------|:------------------------|
|   2018 |         4 |      2 | a14,a25                |         1 | a14       | a14:3                   |
|   2019 |         4 |      2 | a14,a25                |         1 | a14,a25   | a14:1;a25:28            |
|   2020 |         4 |      2 | a24,a25                |         1 | a25       | a25:26                  |
|   2021 |         3 |      6 | a1,a21,a24,a28,a38,a45 |         1 | a24       | a24:10                  |
|   2022 |         4 |      1 | a21                    |         7 | a21       | a21:12                  |

The temporal analysis is heterogeneous rather than cherry-picked: 2019 shows direct agreement for Innate Pharma (native MVSK rank 1, lambda=36, and CNPW terminal co-winner), whereas 2020–2022 show substantial divergence. This is useful evidence that CNPW is not mechanically reproducing or opposing the native method.

## Interpretation
The cleanest claim supported by this case is not that CNPW is universally superior to MVSK. It is that **preference-robust high ranking and equal-priority joint qualification are distinct decision objects**. In 2022, the MVSK winner is only L2 jointly qualified, while the unique L4 jointly qualified SME is ranked 12th under all three published lambda scenarios.

## Audit notes
- Table 16 was parsed directly from the published appendix; no external reconstruction of candidate identities or criteria was required.
- Native rankings were parsed from published Table 9.
- Stage-1 conclusions are invariant to strictly increasing/order-preserving re-scaling of each preference-oriented criterion, so the comparison is not dependent on the units shown in Table 16.
- Exact numerical reproduction of the authors’ 10,000-weight MVSK simulations was not required for this first CNPW execution because the published native rankings are available; Supplementary material is only needed if exact stochastic reimplementation is desired.
