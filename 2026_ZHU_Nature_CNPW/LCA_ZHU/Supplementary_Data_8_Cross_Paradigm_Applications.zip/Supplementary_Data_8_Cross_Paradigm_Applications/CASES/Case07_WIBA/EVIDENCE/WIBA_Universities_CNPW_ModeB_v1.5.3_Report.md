# WIBA Universities × CNPW Mode B v1.5.3 — Execution Report

## 1. Input verification

The uploaded repository ZIP contains `WIBApp-main/www/datasets/universities.xlsx`.
The raw repository dataset contains 897 alternatives and four maximization criteria: Teaching, Research, Diversity, and Financial Sustainability.
A direct row-by-row comparison with the uploaded CNPW execution workbook found **0 mismatches across the 897×4 evaluation matrix**.

The source priority order is:

\[
\text{Teaching} > \text{Research} > \text{Diversity} > \text{Financial Sustainability}.
\]

## 2. Formal Mode B configuration

Primary configuration follows the frozen v1.5.3 two-tier Mode-B definition:

- Tier-1 priority block: \(P=\{\text{Teaching}\}\)
- Tier-2 residual block: \(R=\{\text{Research, Diversity, Financial Sustainability}\}\)
- No external engineering threshold is supplied, so the singleton priority block uses its own highest global qualification as the default hard requirement.
- Therefore the primary protection condition is **Teaching ≥ GL7**.
- Global levels remain those from the frozen 897-candidate Stage-1 reference system.
- Baseline \(K_g=K_l=7\).

## 3. Primary Mode B result: Teaching ≥ GL7

Priority conditioning:

\[
897 \rightarrow 129
\]

universities satisfy Teaching ≥ GL7.

Within these 129 candidates, the residual highest common qualification is:

\[
Q_R^{(1)*}=\mathrm{GL7}.
\]

The conditional Stage-1 set contains 7 universities:

\[
129 \rightarrow 7.
\]

Every member has global profile:

\[
(\mathrm{GL7},\mathrm{GL7},\mathrm{GL7},\mathrm{GL7})
\]

across Teaching, Research, Diversity and Financial Sustainability.

Stage 2 is performed only on the residual block Research/Diversity/Financial Sustainability within these seven candidates. The highest residual local qualification is:

\[
Q_R^{(2)*}=\mathrm{LL2},
\]

and the conditional Stage-2 set is a singleton:

\[
7 \rightarrow 1.
\]

The terminal is **Ecole Polytechnique Federale de Lausanne (EPFL/LAUS)**.
Its residual local profile is:

\[
(\mathrm{LL2},\mathrm{LL7},\mathrm{LL2}),
\]

with sorted worst-first profile:

\[
(2,2,7).
\]

## 4. Direct comparison with WIBA POC1

The key WIBA candidates map into the frozen CNPW qualification system as follows:

| University | WIBA neutral rank | Teaching GL | Residual GL profile (R/D/F) | Residual Q |
|---|---:|---:|---|---:|
| Oxford | 1 | 7 | 7/7/5 | 5 |
| Caltech | 2 | 7 | 7/7/6 | 6 |
| MIT | 3 | 7 | 7/7/7 | 7 |
| EPFL | 14 | 7 | 7/7/7 | 7 |

Oxford therefore satisfies the protected highest-priority requirement (Teaching GL7), but its residual joint qualification is only GL5 although GL7 is attainable under the same Teaching protection condition.

Hence the relevant qualification statement is:

\[
\boxed{\text{Oxford: Teaching GL7 + residual GL5; attainable: Teaching GL7 + residual GL7.}}
\]

The two-level residual qualification deficit is therefore **avoidable without lowering the protected Teaching qualification level**.

This is a qualification-level statement, not a raw-value dominance claim. Oxford has the highest raw Teaching value in the dataset, so CNPW does not claim that another candidate dominates Oxford in all raw response magnitudes.

MIT is an important positive control: it is the WIBA max-lower-bound reference and also satisfies full CNPW GL7/GL7/GL7/GL7 qualification.

## 5. Priority relaxation sensitivity: Teaching ≥ GL6

A one-level relaxation was evaluated as a sensitivity/recovery-style query.

\[
897 \rightarrow 257
\]

candidates satisfy Teaching ≥ GL6.

The residual highest common global qualification remains:

\[
Q_R^{(1)*}=\mathrm{GL7},
\]

so relaxing Teaching from GL7 to GL6 produces **no residual global-qualification gain**.

The conditional Stage-1 set expands from 7 to 11 candidates. Residual Stage 2 gives:

\[
Q_R^{(2)*}=\mathrm{LL5}
\]

with a singleton terminal:

**Australian National University (ANU)**,

whose global profile is:

\[
(\mathrm{GL6},\mathrm{GL7},\mathrm{GL7},\mathrm{GL7}).
\]

Thus the relaxation changes the terminal candidate by admitting stronger residual actual-magnitude combinations, but it does not increase the residual Stage-1 qualification ceiling beyond GL7.

## 6. Interpretation

The Mode-B result is stronger than the earlier Mode-A-only comparison because it respects the source study's highest declared priority as a protected block.

The principal finding is:

> WIBA's neutral Rank-1 university (Oxford) satisfies the highest Teaching qualification but retains an avoidable GL5 residual weak link, whereas seven universities attain GL7 simultaneously in Teaching and all three residual criteria.

This supports the distinction:

\[
\boxed{\text{robustness over an ordered-weight region} \neq \text{priority-conditioned joint qualification}.}
\]

The appropriate claim is not that CNPW universally outperforms WIBA, but that CNPW identifies objective-level qualification deficits that remain invisible to a ranking defined by robustness over admissible preference weights.

## 7. Status

**MODE-B EXECUTION PASS.**

Recommended primary WIBA analysis:

- Main comparison: **Mode B, Teaching protected at GL7**.
- Auxiliary diagnostic: Mode A Equal Priority.
- Sensitivity/supporting analysis: Teaching ≥ GL6.
- Do not use the exact EPFL terminal as the main superiority claim because exact Stage-2 terminal identity is resolution-sensitive in the existing K sensitivity audit.
- Main robust claim should remain at the conditional Stage-1 qualification structure: **Oxford 7 | 7/7/5 versus attainable 7 | 7/7/7**.
