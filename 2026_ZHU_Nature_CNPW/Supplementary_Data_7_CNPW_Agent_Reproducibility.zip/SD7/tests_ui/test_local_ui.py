from __future__ import annotations

import csv
import os
import tempfile
import unittest
from pathlib import Path

from streamlit.testing.v1 import AppTest

from app.streamlit_app import _full_report_download_filename
from app.ui_helpers import dataset_rows, semantic_messages, terminal_rows, user_error
from agent.input_guard import InputGuard
from app.ui_state import clear_temporary_upload, result_matches_current_input, store_uploaded_file


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app" / "streamlit_app.py"
FIXTURES = ROOT / "tests_agent" / "fixtures"


class LocalUiTests(unittest.TestCase):
    def app(self):
        return AppTest.from_file(str(APP)).run(timeout=30)

    def upload(self, filename: str, content: bytes, mime: str = "text/csv"):
        app = self.app()
        app.file_uploader[0].set_value((filename, content, mime)).run(timeout=30)
        return app

    def test_app_imports_and_initial_page_has_upload_and_blocked_run(self):
        app = self.app()
        self.assertFalse(app.exception)
        self.assertEqual(1, len(app.file_uploader))
        self.assertEqual("Run CNPW Analysis", app.button[0].label)
        self.assertTrue(app.button[0].disabled)

    def test_unsupported_file_is_rejected(self):
        app = self.app()
        self.assertEqual([".csv", ".xlsx"], list(app.file_uploader[0].proto.type))
        outcome = InputGuard().validate(ROOT / "README.md", "MODE_A")
        self.assertIn("Upload a CSV or XLSX", user_error(outcome.error))

    def test_valid_m3_m4_m5_uploads_display_structural_facts(self):
        for fixture, expected_m in (("small_m3.csv", 3), ("small_m4.csv", 4), ("small_m5.csv", 5)):
            with self.subTest(fixture=fixture):
                app = self.upload(fixture, (FIXTURES / fixture).read_bytes())
                self.assertFalse(app.exception)
                self.assertEqual("Input validation: PASS", app.success[0].value)
                rendered = "\n".join(str(item.value) for item in app.markdown) + "\n" + "\n".join(str(item.value) for item in app.text)
                self.assertIn(f"Active criteria: {expected_m}", rendered)
                self.assertEqual(expected_m, len(app.dataframe[0].value))
                self.assertEqual(0, len(app.text_area))

    def test_m2_and_m6_are_rejected(self):
        cases = [("m2.csv", b"Candidate_ID,A,B\nDirection,1,1\nx,1,2\ny,2,3\n"), ("m6.csv", b"Candidate_ID,A,B,C,D,E,F\nDirection,1,1,1,1,1,1\nx,1,2,3,4,5,6\ny,2,3,4,5,6,7\n")]
        for name, content in cases:
            with self.subTest(name=name):
                app = self.upload(name, content)
                self.assertIn("3–5 active Results", app.error[0].value)

    def test_xlsx_upload_is_accepted_by_existing_input_guard(self):
        source = FIXTURES / "xlsx_upload_fixture.xlsx"
        app = self.upload("technical.xlsx", source.read_bytes(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        self.assertEqual("Input validation: PASS", app.success[0].value)
        self.assertEqual(0, len(app.text_area))

    def test_mixed_directions_and_descriptors_are_displayed_from_guard(self):
        task = InputGuard().validate(FIXTURES / "small_m5.csv", "MODE_A").task
        rows = dataset_rows(task)
        self.assertEqual("↑ Maximize", rows[0]["Direction"])
        self.assertEqual("↓ Minimize", rows[1]["Direction"])
        self.assertEqual(("Descriptor",), task.input_summary.descriptors)
        self.assertNotIn("Descriptor", [row["Criterion"] for row in rows])

    def test_missing_live_credential_does_not_block_dual_analysis(self):
        original = os.environ.pop("OPENAI_API_KEY", None)
        try:
            app = self.upload("small_m3.csv", (FIXTURES / "small_m3.csv").read_bytes())
            self.assertFalse(app.button[0].disabled)
        finally:
            if original is not None:
                os.environ["OPENAI_API_KEY"] = original

    def test_terminal_and_semantic_presentation_helpers_preserve_sets(self):
        result = {"terminal": {"terminal_candidate_ids": ["A", "B"], "terminal_descriptors": {"A": ["d1"], "B": ["d2"]}}}
        rows = terminal_rows(result)
        self.assertEqual(["A", "B"], [row["Candidate_ID"] for row in rows])
        messages = semantic_messages(("SET_VALUED_TERMINAL", "RAW_DOMINANCE_ACTIVATED"))
        self.assertIn("do not justify further discrimination", messages[0])
        self.assertIn("raw-response dominance", messages[1])

    def test_integrity_error_card_suppresses_scientific_conclusion_wording(self):
        message = user_error(type("Error", (), {"code": "RESULT_CONTRACT_BUILD_FAILED", "message": "internal"})())
        self.assertIn("INTEGRITY CHECK FAILED", message)
        self.assertNotIn("terminal candidate", message.lower())

    def test_download_controls_are_defined_by_existing_renderer_calls(self):
        source = APP.read_text(encoding="utf-8")
        self.assertIn("render_presentation_markdown", source)
        self.assertIn("render_integrated_json", source)
        self.assertIn("Download Full Report", source)
        self.assertEqual("my_report_CNPW_Result.md", _full_report_download_filename('my:report.csv'))
        self.assertEqual("CNPW_Analysis_CNPW_Result.md", _full_report_download_filename('...'))

    def test_upload_replacement_invalidates_display_and_export_state(self):
        class Upload:
            def __init__(self, name, payload): self.name, self.payload = name, payload
            def getvalue(self): return self.payload
        state = {}
        store_uploaded_file(Upload("a.csv", b"A"), state)
        state.update({"dual_outcome": object(), "dual_outcome_input_hash": state["upload_hash"], "export_state": "ready", "verification_state": "pass"})
        self.assertTrue(result_matches_current_input(state, "dual_outcome"))
        store_uploaded_file(Upload("b.csv", b"B"), state)
        self.assertNotIn("dual_outcome", state)
        self.assertNotIn("export_state", state)
        self.assertFalse(result_matches_current_input(state, "dual_outcome"))
        clear_temporary_upload(state)

    def test_clear_invalidates_all_result_state(self):
        state = {"upload_path": None, "upload_hash": "a", "upload_name": "a.csv", "dual_outcome": object(), "dual_outcome_input_hash": "a", "pipeline_outcome": object(), "report_state": "ready", "export_state": "ready", "verification_state": "pass"}
        clear_temporary_upload(state)
        self.assertFalse(any(key in state for key in ("dual_outcome", "pipeline_outcome", "report_state", "export_state", "verification_state", "upload_hash")))


if __name__ == "__main__":
    unittest.main()
