#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Figure 11: two original GUI screenshots side by side.

(a) is on the LEFT, (b) is on the RIGHT. Both have equal physical height.
The screenshots are not cropped, stretched, or resampled in the PDF.

Windows dependencies: python -m pip install pymupdf pillow
Windows command:      python "D:\\soft\\1\\Figure11_SideBySide_Stable.py"
Input folder:          D:\\soft\\1\\1  (a.png and b.png)
Outputs:               Figure11_Horizontal_Final.pdf / .png / .svg / _QA.txt
"""
from pathlib import Path
from io import BytesIO
import hashlib
import os

import fitz
from PIL import Image, ImageChops

INPUT_DIR = Path(__file__).resolve().parent
FILE_A = "Figure11a.png"
FILE_B = "Figure11b.png"
OUTPUT_STEM = "Figure11_Horizontal_Final"
EXPECTED_A = (900, 975)
EXPECTED_B = (1450, 972)

PAGE_WIDTH_MM = 188.0
PANEL_HEIGHT_MM = 69.0
LEFT_RIGHT_MARGIN_MM = 8.0
TOP_MARGIN_MM = 10.0
BOTTOM_MARGIN_MM = 6.0
GAP_MM = 3.0
LABEL_SIZE_PT = 11.0
DPI = 600


def mm_to_pt(mm):
    return mm * 72.0 / 25.4


def read_size(file, expected):
    if not file.is_file():
        raise FileNotFoundError("Missing image: " + str(file))
    with Image.open(file) as im:
        im.verify()
    with Image.open(file) as im:
        found = im.size
    if found != expected:
        raise ValueError("Wrong image size for %s: %s, expected %s" % (file.name, found, expected))
    return found


def file_hash(file):
    h = hashlib.sha256()
    with file.open("rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def choose_font(page):
    folders = [
        Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts",
        Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts",
    ]
    for folder in folders:
        for filename in ("Roboto-Bold.ttf", "Roboto-Bold.otf"):
            file = folder / filename
            if file.is_file():
                page.insert_font(fontname="RobotoBoldGUI", fontfile=str(file))
                return "RobotoBoldGUI", "Roboto Bold"
    return "hebo", "Helvetica Bold"


def make_figure():
    img_a = INPUT_DIR / FILE_A
    img_b = INPUT_DIR / FILE_B
    aw, ah = read_size(img_a, EXPECTED_A)
    bw, bh = read_size(img_b, EXPECTED_B)

    wa = PANEL_HEIGHT_MM * aw / ah
    wb = PANEL_HEIGHT_MM * bw / bh
    block = wa + GAP_MM + wb
    available = PAGE_WIDTH_MM - 2 * LEFT_RIGHT_MARGIN_MM
    if block > available:
        max_height = (available - GAP_MM) / (aw / ah + bw / bh)
        raise ValueError("Images too wide; PANEL_HEIGHT_MM must be <= %.2f mm" % max_height)

    x_a = LEFT_RIGHT_MARGIN_MM + (available - block) / 2
    x_b = x_a + wa + GAP_MM
    y = TOP_MARGIN_MM
    page_height = TOP_MARGIN_MM + PANEL_HEIGHT_MM + BOTTOM_MARGIN_MM

    pdf_path = INPUT_DIR / (OUTPUT_STEM + ".pdf")
    png_path = INPUT_DIR / (OUTPUT_STEM + ".png")
    svg_path = INPUT_DIR / (OUTPUT_STEM + ".svg")
    qa_path = INPUT_DIR / (OUTPUT_STEM + "_QA.txt")

    doc = fitz.open()
    page = doc.new_page(width=mm_to_pt(PAGE_WIDTH_MM), height=mm_to_pt(page_height))
    font_name, font_description = choose_font(page)

    for label, file, x, width in (("(a)", img_a, x_a, wa), ("(b)", img_b, x_b, wb)):
        rect = fitz.Rect(mm_to_pt(x), mm_to_pt(y), mm_to_pt(x + width), mm_to_pt(y + PANEL_HEIGHT_MM))
        page.insert_image(rect, filename=str(file), keep_proportion=True)
        # Put labels in the TOP margin, not on the GUI title bars.
        page.insert_text(fitz.Point(mm_to_pt(x + 0.2), mm_to_pt(y - 1.7)), label,
                         fontname=font_name, fontsize=LABEL_SIZE_PT, color=(0.08, 0.10, 0.12))

    doc.save(str(pdf_path), garbage=4, deflate=True)
    doc.close()

    with fitz.open(str(pdf_path)) as pdf:
        result_page = pdf[0]
        embedded = result_page.get_images(full=True)
        if len(embedded) != 2:
            raise RuntimeError("Expected exactly two images in PDF, found %d" % len(embedded))
        for position, source in enumerate((img_a, img_b)):
            image_bytes = pdf.extract_image(embedded[position][0])["image"]
            with Image.open(BytesIO(image_bytes)) as in_pdf, Image.open(source) as original:
                a = in_pdf.convert("RGB")
                b = original.convert("RGB")
                if a.size != b.size or ImageChops.difference(a, b).getbbox() is not None:
                    raise RuntimeError("Pixel integrity check failed for " + source.name)
        result_page.get_pixmap(dpi=DPI, alpha=False).save(str(png_path))
        svg_path.write_text(result_page.get_svg_image(text_as_path=True), encoding="utf-8")

    lines = [
        "Figure 11: horizontal, equal-height GUI screenshots",
        "Source a.png: %s | SHA256: %s" % (EXPECTED_A, file_hash(img_a)),
        "Source b.png: %s | SHA256: %s" % (EXPECTED_B, file_hash(img_b)),
        "Panel (a) left width: %.3f mm" % wa,
        "Panel (b) right width: %.3f mm" % wb,
        "Both panels height: %.3f mm" % PANEL_HEIGHT_MM,
        "PDF canvas: %.3f x %.3f mm" % (PAGE_WIDTH_MM, page_height),
        "Font for panel labels: " + font_description,
        "Pixel comparison of PDF embedded images: PASS",
        "Saved PDF: " + str(pdf_path),
        "Saved PNG: " + str(png_path),
        "Saved SVG: " + str(svg_path),
    ]
    qa_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    make_figure()
