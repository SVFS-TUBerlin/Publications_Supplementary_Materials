import unittest

from src.input_loader import load_dataset
from src.mode_a import run_mode_a
from src.mode_b import run_mode_b
from src.models import ProtectionContract


class PlaMexGoldenTests(unittest.TestCase):
    def test_exact_packaged_csv_mode_a_golden(self):
        dataset = load_dataset("CNPW_PLA_MEX_7056_Core_Input_v0.2.csv")
        result = run_mode_a(dataset)
        actual = (result.stage1.q1, len(result.stage1.retained), result.stage2.q2, len(result.stage2.retained), [dataset.candidate_ids[i] for i in result.stage2.retained], [dataset.candidate_ids[i] for i in result.terminal])
        expected = (6, 65, 4, 3, ["PG5748", "PG6188", "PG6628"], ["PG6628"])
        self.assertEqual(expected, actual)
        self.assertEqual(0, result.stage1.joint_counts[7])
        self.assertEqual(65, result.stage1.joint_counts[6])
        self.assertEqual(643, result.stage1.joint_counts[5])

    def test_mode_b_explicit_singleton_contract_qualifies_residual_then_refines_all(self):
        dataset = load_dataset("CNPW_PLA_MEX_7056_Core_Input_v0.2.csv")
        result = run_mode_b(dataset, ProtectionContract("equal_count_global_qualification", (0,)))
        self.assertEqual("UTS_MPa", result.protected["criterion"])
        self.assertTrue(all(result.stage1.gl[index][0] >= result.protected["k_p"] for index in result.stage1.retained))
        self.assertEqual([c.name for c in dataset.criteria[1:]], result.protected["residual"])
        self.assertEqual([1, 2, 3], result.stage1.active_criteria)
        self.assertIn("UTS_MPa", result.stage2.local)
