from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .contracts import CanonicalTask, stable_json
from .intent_models import INTENT_SYSTEM_PROMPT_HASH, IntentProposal


AGENT_IMPLEMENTATION_IDENTITY = "cnpw-scientific-agent-v8-phase3"
REPORT_RENDERER_IDENTITY = "cnpw-agent-deterministic-renderer-v0.1"


def core_source_manifest(project_root: str | Path) -> dict[str, Any]:
    root = Path(project_root)
    entries = []
    for source in sorted((root / "src").glob("*.py"), key=lambda item: item.name):
        entries.append({"path": f"src/{source.name}", "sha256": hashlib.sha256(source.read_bytes()).hexdigest()})
    aggregate = hashlib.sha256(stable_json(entries).encode("utf-8")).hexdigest()
    return {"files": entries, "aggregate_sha256": aggregate}


def build_provenance_manifest(task: CanonicalTask, project_root: str | Path,
                              execution_timestamp: str | None = None) -> dict[str, Any]:
    timestamp = execution_timestamp or datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    source_manifest = core_source_manifest(project_root)
    configuration = task.core_configuration
    return {"input_filename": task.input_summary.identity.source_name, "input_file_sha256": task.input_summary.identity.source_hash_sha256, "canonical_task_sha256": task.task_hash_sha256, "core_identity": configuration.core_identity, "core_source_manifest": source_manifest, "agent_contract_version": task.canonical_task_version, "agent_implementation_identity": AGENT_IMPLEMENTATION_IDENTITY, "execution_mode": task.requested_mode.value, "protection_semantics": task.protection_semantics, "protected_indices": list(task.protected_indices), "response_order": [item.name for item in task.input_summary.active_criteria], "directions": [item.direction for item in task.input_summary.active_criteria], "kg": configuration.kg, "kl": configuration.kl, "tie_policy": configuration.tie_policy, "stage2_policy": configuration.stage2_policy, "terminal_policy": configuration.terminal_policy, "execution_timestamp": timestamp, "report_renderer_identity": REPORT_RENDERER_IDENTITY}


def build_ai_provenance(proposal: IntentProposal, user_text: str) -> dict[str, str]:
    return {"intent_contract_version": proposal.intent_contract_version, "provider_identity": proposal.provider_identity, "model_identity": proposal.model_identity, "system_prompt_hash_sha256": INTENT_SYSTEM_PROMPT_HASH, "user_request_hash_sha256": hashlib.sha256(user_text.encode("utf-8")).hexdigest(), "intent_proposal_hash_sha256": proposal.proposal_hash_sha256, "interpretation_timestamp": proposal.created_at, "raw_response_hash_sha256": proposal.raw_response_hash}
