# Weber ACIIS 2025 × CNPW Formal Head-to-Head

## Scope

This execution uses only the data, preference directions, equations, and published native RAS results reported in:

Thomas A. Weber, *Relatively Robust QoS and QoE Score Aggregation*, 2025 7th International Conference on Applied Computational Intelligence in Information Systems (ACIIS), DOI: 10.1109/ACIIS66255.2025.11402948.

No definitions or data from Weber's Management Science paper or any other paper are needed for the native-method reproduction.

## Native paper data

Five providers (A–E) are evaluated on 16 criteria:

- QoS: BR, SD, Buf, FPS, Res, PLR, RTT, Jit
- QoE: MOS, VMAF, SSIM, PSNR, AWR, EBVS, ER, QDR

Preference directions follow the paper's Table VI.

The paper explicitly states that the application data are synthetic, intended only as a realistic illustrative use case rather than actual measurements.

## Native RAS reproduction

For maximize criteria:
\[
\phi_i(j)=f_i(j)/f_i^*
\]

For minimize criteria:
\[
\phi_i(j)=f_i^\circ/f_i(j)
\]

The overall Robust Aggregate Score is the minimum criterion-specific performance ratio, equivalently the minimum of QoS-RAS and QoE-RAS.

Reproduced overall RAS:

| Provider | Overall RAS | Published Rank |
|---|---:|---:|
| A | 0.080000 | 4 |
| B | 0.066667 | 5 |
| C | 0.190476 | 3 |
| D | 0.285714 | 2 |
| E | 0.416667 | 1 |

Native winner:
\[
\boxed{E}
\]

The reproduction agrees with the paper's Table IX.

## CNPW baseline

Because the frozen candidate set contains only five alternatives, the formal baseline uses:

\[
K_g=5
\]

with Stage-1 population-balanced, tie-preserving/tie-upward qualification.

CNPW Stage-1 global-level profiles:

| Provider | 16-objective GL profile | \(Q^{(1)}\) |
|---|---|---:|
| A | 4/2/2/4/5/2/4/2/5/4/4/3/4/4/4/2 | **2** |
| B | 5/1/1/5/5/1/2/1/1/5/5/5/2/2/2/5 | 1 |
| C | 3/3/4/3/5/4/5/3/3/2/2/4/3/5/1/4 | 1 |
| D | 1/4/3/2/2/3/1/4/2/1/1/1/1/1/5/3 | 1 |
| E | 2/5/5/1/2/5/3/5/4/3/3/2/5/4/3/1 | 1 |

Thus:

\[
Q^{(1)*}=2
\]

and

\[
W^{(1)}=\{A\}.
\]

Because Stage 1 is already a singleton, Stage 2 is vacuous: no local discrimination is required and the formal CNPW terminal inherits the Stage-1 singleton.

CNPW terminal:
\[
\boxed{A}
\]

## Direct head-to-head

\[
\boxed{\text{Native RAS}=E\neq \text{CNPW}=A}
\]

The divergence is semantic rather than computational.

RAS protects ideal-relative worst-case performance. Provider E maximizes its minimum ratio to the criterion-wise best attainable value.

CNPW protects population-relative joint qualification. Provider A is the only candidate that avoids the lowest global qualification level on every one of the 16 criteria under the baseline resolution.

## Small-N resolution sensitivity

The Stage-1 calculation was repeated for:

\[
K_g=3,4,5.
\]

Results:

| \(K_g\) | \(Q^{(1)*}\) | \(|W^{(1)}|\) | Unique winner |
|---:|---:|---:|---|
| 3 | 2 | 1 | A |
| 4 | 2 | 1 | A |
| 5 | 2 | 1 | A |

Therefore, the RAS–CNPW divergence is not an artifact of choosing \(K_g=5\).

## Interpretation boundary

This case is a strong *canonical discriminating test* because:

1. the candidate-response matrix is fully reported in the same paper;
2. the paper reports preference directions;
3. the native RAS calculation and ranking are fully reproducible;
4. CNPW and RAS select different providers on the exact same frozen data.

However, it is not a large-scale empirical validation because the paper explicitly uses synthetic values and only five providers.

The supported claim is therefore:

> RAS and CNPW operationalize balance differently and can produce different decisions on the same published finite candidate set.

The case does **not** establish universal superiority of either method.
