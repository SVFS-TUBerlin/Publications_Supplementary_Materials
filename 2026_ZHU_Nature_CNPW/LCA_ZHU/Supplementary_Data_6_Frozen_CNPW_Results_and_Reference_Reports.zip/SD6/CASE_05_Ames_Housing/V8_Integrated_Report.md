# CNPW V8 Integrated Analysis Report

## 1. Input and scientific contract

- Filename: CNPW_Case05_Ames_Housing_M5_Input_v0.1.xlsx
- N: 2930 · M: 5
- Responses, declared order: SalePrice, Overall Qual, Gr Liv Area, Overall Cond, Lot Area
- One-click execution: Mode A plus every non-empty proper equal-count protected-response block.
- CNPW selects first; any percentages are reporting-only and never influence qualification, QCCA, recovery, or alternatives.

## 2. Mode A

### Mode A deterministic state

- Full-system Global capability: GL5 · |W¹|=10
- All-response Local state: local_qcca_required · K_L=7 · C_L=LL1
- Terminal/co-terminal candidates: 0903425110

## 3. Mode-B protected-domain contract landscape

Protection determines admissibility; residual responses determine Stage-1 conditional capability; all active responses re-enter Stage-2 Local refinement.
Rows follow protected-block cardinality and declared response order. They are not ranked. Ω_P is the protected admissible population; W_B¹ is the residual Stage-1 retained population.

| Contract | Protected block | k_P | Ω_P size | Residual Stage-1 capability | W_B¹ size | All-response Local state / C_L | Terminal/co-terminal | QCCA/action |
|---|---|---:|---:|---:|---:|---|---|---|
| 5e47494264bf | SalePrice | GL7 | 419 | GL5 | 1 | resolved_unique_highest_global | 0902103120 | NOT_REQUIRED |
| 4481f7990186 | Overall Qual | GL7 | 488 | GL5 | 1 | resolved_unique_highest_global | 0528431110 | NOT_REQUIRED |
| 3fccb27de5ae | Gr Liv Area | GL7 | 419 | GL5 | 1 | resolved_unique_highest_global | 0535126180 | NOT_REQUIRED |
| d56a979db368 | Overall Cond | GL7 | 575 | GL4 | 33 | local_qcca_required / LL2 | 0902408080 | COMPLETED |
| 222721c66e67 | Lot Area | GL7 | 420 | GL5 | 1 | resolved_unique_highest_global | 0535126180 | NOT_REQUIRED |
| f14190665671 | SalePrice + Overall Qual | GL6 | 20 | GL4 | 1 | resolved_unique_highest_global | 0527326040 | NOT_REQUIRED |
| f4eae6c42f72 | SalePrice + Gr Liv Area | GL7 | 6 | GL3 | 2 | resolved_unique_all_top_local | 0902302150 | NOT_REQUIRED |
| 962ad5903447 | SalePrice + Overall Cond | GL7 | 88 | GL3 | 4 | local_qcca_required / LL1 | 0903458110 | COMPLETED |
| 0293f705532c | SalePrice + Lot Area | GL7 | 17 | GL4 | 1 | resolved_unique_highest_global | 0535353190 | NOT_REQUIRED |
| b9a20ef3cb9b | Overall Qual + Gr Liv Area | GL7 | 196 | GL4 | 1 | resolved_unique_highest_global | 0908154235 | NOT_REQUIRED |
| cc49ab92c799 | Overall Qual + Overall Cond | GL7 | 22 | GL4 | 3 | local_qcca_required / LL1 | 0902330040 | COMPLETED |
| 541ff66f6678 | Overall Qual + Lot Area | GL7 | 130 | GL4 | 2 | local_qcca_required / LL1 | 0908154235 | COMPLETED |
| ee4234908c35 | Gr Liv Area + Overall Cond | GL7 | 75 | GL4 | 3 | local_qcca_required / LL5 | 0902408080 | COMPLETED |
| 63584f3859fd | Gr Liv Area + Lot Area | GL7 | 155 | GL5 | 1 | resolved_unique_highest_global | 0535126180 | NOT_REQUIRED |
| 6a9f76e1c0b4 | Overall Cond + Lot Area | GL7 | 73 | GL4 | 3 | local_qcca_required / LL1 | 0902330040 | COMPLETED |
| 0cc480a98348 | SalePrice + Overall Qual + Gr Liv Area | GL6 | 6 | GL2 | 1 | resolved_unique_highest_global | 0903234100 | NOT_REQUIRED |
| d6bf33578b28 | SalePrice + Overall Qual + Overall Cond | GL6 | 9 | GL2 | 2 | resolved_unique_all_top_local | 0903204010 | NOT_REQUIRED |
| c00d575a49b3 | SalePrice + Overall Qual + Lot Area | GL6 | 1 | GL4 | 1 | resolved_unique_highest_global | 0527326040 | NOT_REQUIRED |
| 95eb0febf923 | SalePrice + Gr Liv Area + Overall Cond | GL6 | 12 | GL3 | 7 | local_qcca_required / LL1 | 0906226060 | COMPLETED |
| e5444ed04abb | SalePrice + Gr Liv Area + Lot Area | GL7 | 1 | GL3 | 1 | resolved_unique_highest_global | 0902302150 | NOT_REQUIRED |
| 4b5c74ba8957 | SalePrice + Overall Cond + Lot Area | GL7 | 1 | GL3 | 1 | resolved_unique_highest_global | 0905226050 | NOT_REQUIRED |
| 132bf20e09e3 | Overall Qual + Gr Liv Area + Overall Cond | GL7 | 13 | GL2 | 1 | resolved_unique_highest_global | 0902329030 | NOT_REQUIRED |
| c091d1143cc9 | Overall Qual + Gr Liv Area + Lot Area | GL7 | 85 | GL4 | 1 | resolved_unique_highest_global | 0908154235 | NOT_REQUIRED |
| 3ed5e74c3b13 | Overall Qual + Overall Cond + Lot Area | GL7 | 10 | GL4 | 1 | resolved_unique_highest_global | 0902330040 | NOT_REQUIRED |
| 097ad7a3b171 | Gr Liv Area + Overall Cond + Lot Area | GL7 | 30 | GL3 | 2 | local_qcca_required / LL1 | 0902330090 | COMPLETED |
| da3036d611b7 | SalePrice + Overall Qual + Gr Liv Area + Overall Cond | GL5 | 56 | GL7 | 1 | resolved_unique_highest_global | 0535126180 | NOT_REQUIRED |
| 38efd41c00a4 | SalePrice + Overall Qual + Gr Liv Area + Lot Area | GL5 | 13 | GL6 | 3 | local_qcca_required / LL2 | 0903425110 | COMPLETED |
| 16ca70019d24 | SalePrice + Overall Qual + Overall Cond + Lot Area | GL5 | 60 | GL7 | 1 | resolved_unique_highest_global | 0535126180 | NOT_REQUIRED |
| 89ea01078cb1 | SalePrice + Gr Liv Area + Overall Cond + Lot Area | GL6 | 3 | GL3 | 2 | local_qcca_required / LL1 | 0906226060 | COMPLETED |
| a6d552a539c3 | Overall Qual + Gr Liv Area + Overall Cond + Lot Area | GL7 | 7 | GL1 | 7 | local_qcca_required / LL1 | 0902401120 | COMPLETED |

## 4. QCCA diagnosis and QCCA-guided alternatives

Global QCCA diagnoses (X, J, G) for Mode A and (Ω_P, J_res, G) for Mode B, excluding protected responses only from the residual Global system. Local QCCA uses all active responses J on frozen W¹, only for a Core-declared Local collapse. Recovery sets and targeted alternatives preserve all equal formal routes; none is preferred.

### Mode A Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Lot Area}; witnesses: 0903425110.
- Target LL3; recovery set {Overall Qual, Overall Cond}; witnesses: 0535126180.
- Target LL4; recovery set {Overall Qual, Overall Cond}; witnesses: 0535126180.
- Target LL5; recovery set {SalePrice, Overall Qual, Overall Cond}; witnesses: 0535126180.
- Target LL6; recovery set {SalePrice, Overall Qual, Overall Cond}; witnesses: 0535126180.
- Target LL7; recovery set {SalePrice, Overall Qual, Overall Cond}; witnesses: 0535126180.

### Mode B d56a979db368 Local QCCA

- Baseline C_L: LL2; targets: LL3, LL4, LL5, LL6, LL7.
- Target LL3; recovery set {SalePrice}; witnesses: 0902330040.
- Target LL4; recovery set {SalePrice, Gr Liv Area}; witnesses: 0902330040.
- Target LL4; recovery set {SalePrice, Lot Area}; witnesses: 0902408080.
- Target LL4; recovery set {Overall Qual, Gr Liv Area}; witnesses: 0533352170, 0906425045.
- Target LL4; recovery set {Overall Qual, Lot Area}; witnesses: 0902301120.
- Target LL4; recovery set {Gr Liv Area, Lot Area}; witnesses: 0902401130.
- Target LL5; recovery set {SalePrice, Gr Liv Area}; witnesses: 0902330040.
- Target LL6; recovery set {SalePrice, Gr Liv Area}; witnesses: 0902330040.
- Target LL7; recovery set {SalePrice, Gr Liv Area}; witnesses: 0902330040.

### Mode B 962ad5903447 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {SalePrice, Gr Liv Area}; witnesses: 0909101010.
- Target LL2; recovery set {Overall Cond, Lot Area}; witnesses: 0903458110.
- Target LL3; recovery set {Overall Cond, Lot Area}; witnesses: 0903458110.
- Target LL4; recovery set {Overall Cond, Lot Area}; witnesses: 0903458110.
- Target LL5; recovery set {Overall Cond, Lot Area}; witnesses: 0903458110.
- Target LL6; recovery set {Overall Cond, Lot Area}; witnesses: 0903458110.
- Target LL7; recovery set {Overall Cond, Lot Area}; witnesses: 0903458110.

### Mode B cc49ab92c799 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {SalePrice}; witnesses: 0902330040.
- Target LL2; recovery set {Overall Cond}; witnesses: 0527225035.
- Target LL3; recovery set {SalePrice}; witnesses: 0902330040.
- Target LL4; recovery set {SalePrice}; witnesses: 0902330040.
- Target LL5; recovery set {SalePrice}; witnesses: 0902330040.
- Target LL6; recovery set {SalePrice}; witnesses: 0902330040.
- Target LL7; recovery set {SalePrice}; witnesses: 0902330040.

### Mode B 541ff66f6678 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Overall Cond}; witnesses: 0908154235.
- Target LL3; recovery set {Overall Cond}; witnesses: 0908154235.
- Target LL4; recovery set {Overall Cond}; witnesses: 0908154235.
- Target LL5; recovery set {Overall Cond}; witnesses: 0908154235.
- Target LL6; recovery set {Overall Cond}; witnesses: 0908154235.
- Target LL7; recovery set {Overall Cond}; witnesses: 0908154235.

### Mode B ee4234908c35 Local QCCA

- Baseline C_L: LL5; targets: LL6, LL7.
- Target LL6; recovery set {Lot Area}; witnesses: 0902408080.
- Target LL7; recovery set {Lot Area}; witnesses: 0902408080.

### Mode B 6a9f76e1c0b4 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {SalePrice}; witnesses: 0902330040.
- Target LL3; recovery set {SalePrice}; witnesses: 0902330040.
- Target LL4; recovery set {SalePrice}; witnesses: 0902330040.
- Target LL5; recovery set {SalePrice}; witnesses: 0902330040.
- Target LL6; recovery set {SalePrice}; witnesses: 0902330040.
- Target LL7; recovery set {SalePrice}; witnesses: 0902330040.

### Mode B 95eb0febf923 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {SalePrice}; witnesses: 0906226060.
- Target LL3; recovery set {SalePrice}; witnesses: 0906226060.
- Target LL4; recovery set {SalePrice}; witnesses: 0906226060.
- Target LL5; recovery set {SalePrice}; witnesses: 0906226060.
- Target LL6; recovery set {SalePrice, Gr Liv Area}; witnesses: 0906226060.
- Target LL7; recovery set {SalePrice, Gr Liv Area}; witnesses: 0906226060.

### Mode B 097ad7a3b171 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {SalePrice, Lot Area}; witnesses: 0902330090.
- Target LL3; recovery set {SalePrice, Lot Area}; witnesses: 0902330090.
- Target LL4; recovery set {SalePrice, Lot Area}; witnesses: 0902330090.
- Target LL5; recovery set {SalePrice, Lot Area}; witnesses: 0902330090.
- Target LL6; recovery set {SalePrice, Lot Area}; witnesses: 0902330090.
- Target LL7; recovery set {SalePrice, Lot Area}; witnesses: 0902330090.

### Mode B 38efd41c00a4 Local QCCA

- Baseline C_L: LL2; targets: LL3, LL4, LL5, LL6, LL7.
- Target LL3; recovery set {Lot Area}; witnesses: 0903425110.
- Target LL4; recovery set {Lot Area}; witnesses: 0903425110.
- Target LL5; recovery set {SalePrice, Overall Qual}; witnesses: 0535450310.
- Target LL6; recovery set {SalePrice, Overall Qual}; witnesses: 0535450310.
- Target LL7; recovery set {SalePrice, Overall Qual}; witnesses: 0535450310.

### Mode B 89ea01078cb1 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {SalePrice}; witnesses: 0906226060.
- Target LL3; recovery set {SalePrice}; witnesses: 0906226060.
- Target LL4; recovery set {SalePrice}; witnesses: 0906226060.
- Target LL5; recovery set {SalePrice}; witnesses: 0906226060.
- Target LL6; recovery set {SalePrice}; witnesses: 0906226060.
- Target LL7; recovery set {SalePrice}; witnesses: 0906226060.

### Mode B a6d552a539c3 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {SalePrice}; witnesses: 0902400110.
- Target LL2; recovery set {Lot Area}; witnesses: 0902401120.
- Target LL3; recovery set {Lot Area}; witnesses: 0902401120.
- Target LL4; recovery set {Lot Area}; witnesses: 0902401120.
- Target LL5; recovery set {SalePrice, Lot Area}; witnesses: 0902400110.
- Target LL5; recovery set {Gr Liv Area, Lot Area}; witnesses: 0902401120.
- Target LL6; recovery set {SalePrice, Lot Area}; witnesses: 0902400110.
- Target LL6; recovery set {Gr Liv Area, Lot Area}; witnesses: 0902401120.
- Target LL7; recovery set {SalePrice, Lot Area}; witnesses: 0902400110.

## 5. Verification and provenance

- Complete public-run verification: PASS.
- Expected/actual Mode-B contracts: 30/30.
- Every Mode-B contract has a deterministic content-derived identity and reuses the frozen full-population Global matrix.

## 6. AI-assisted interpretation

AI-assisted interpretation: Unavailable in this execution.

## 7. Limitations

A protected response with a lower Local position remains inside its Stage-1 protected domain; this does not relax or invalidate the protection contract. No weights, scores, preferred contract, preferred recovery set, preferred alternative, SHAP, connectivity, boundary, or process interpretation is provided.