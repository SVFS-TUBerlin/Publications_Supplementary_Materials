from dataclasses import dataclass


@dataclass(frozen=True)
class TargetedAlternative:
    target: int
    recovery_set: tuple[str, ...]
    retained_responses: tuple[str, ...]
    candidate_id: str
    local_profile: tuple[int, ...]
    deficit_vector: tuple[int, ...]
    raw_values: tuple[object, ...] | None
    in_frozen_w1: bool
    in_mode_b_omega: bool | None


@dataclass(frozen=True)
class TargetedRelaxationResult:
    target: int
    recovery_set: tuple[str, ...]
    retained_responses: tuple[str, ...]
    alternatives: tuple[TargetedAlternative, ...]
    kind: str
