import unittest
from decimal import Decimal
from unittest.mock import patch

from src.mode_b import run_mode_b
from src.models import ProtectionContract
from src.stage1 import assign_stage1, qualify_frozen_global
from tests.helpers import make_dataset


class ResidualModeBTests(unittest.TestCase):
    def test_protected_pair_does_not_cap_residual_capability(self):
        # Actual rank-derived Global levels, not a mocked scientific matrix.
        data = make_dataset([f'x{i}' for i in range(7)], ['p1', 'p2', 'r'],
                            ['maximize'] * 3, [[i, 6-i, 1] for i in range(7)])
        frozen = assign_stage1(data)
        with patch('src.mode_b.assign_stage1', wraps=assign_stage1) as assign:
            result = run_mode_b(data, ProtectionContract('equal_count_global_qualification', (0, 1)))
        assign.assert_called_once_with(data)
        omega = [data.candidate_ids.index(x) for x in result.protected['omega_candidate_ids']]
        old = qualify_frozen_global(data, frozen.frozen_global, omega, [0, 1, 2])
        self.assertEqual((4, 4, 7), (result.protected['k_p'], old.q1, result.stage1.q1))
        self.assertEqual([2], result.stage1.active_criteria)
        self.assertEqual(frozen.gl, result.stage1.gl)
        self.assertEqual(frozen.frozen_global.identity, result.stage1.frozen_global.identity)
        self.assertEqual('resolved_unique_highest_global', result.stage2.local_status)
        self.assertEqual({'p1', 'p2', 'r'}, set(result.stage2.local))

    def test_gl7_singleton_protection_preserves_full_residual_equivalence(self):
        data = make_dataset([f'x{i}' for i in range(7)], ['p', 'r1', 'r2'],
                            ['maximize'] * 3, [[i, 6-i, i] for i in range(7)])
        result = run_mode_b(data, ProtectionContract('equal_count_global_qualification', (0,)))
        omega = [data.candidate_ids.index(x) for x in result.protected['omega_candidate_ids']]
        old = qualify_frozen_global(data, result.stage1.frozen_global, omega, [0, 1, 2])
        self.assertEqual(7, result.protected['k_p'])
        self.assertEqual(1, result.stage1.q1)
        self.assertEqual((old.q1, old.retained), (result.stage1.q1, result.stage1.retained))

    def test_explicit_raw_and_tolerance_protection_preserve_domain_and_residual(self):
        data = make_dataset([f'x{i}' for i in range(7)], ['p', 'r1', 'r2'],
                            ['minimize', 'maximize', 'maximize'], [[i, i, i] for i in range(7)])
        for contract in (ProtectionContract('explicit_raw_thresholds', (0,), raw_thresholds={0: Decimal(3)}),
                         ProtectionContract('normalized_operating_range_tolerances', (0,), tolerances={0: Decimal('0.5')})):
            result = run_mode_b(data, contract)
            self.assertEqual(['x0', 'x1', 'x2', 'x3'], result.protected['omega_candidate_ids'])
            self.assertEqual([1, 2], result.stage1.active_criteria)
            self.assertEqual(4, result.stage1.q1)
            self.assertEqual([3], result.stage1.retained)

    def test_empty_and_full_protected_blocks_fail_explicitly(self):
        data = make_dataset([str(i) for i in range(7)], ['a', 'b', 'c'], ['maximize']*3, [[i]*3 for i in range(7)])
        for block in ((), (0, 1, 2)):
            with self.assertRaises(ValueError):
                run_mode_b(data, ProtectionContract('equal_count_global_qualification', block))
