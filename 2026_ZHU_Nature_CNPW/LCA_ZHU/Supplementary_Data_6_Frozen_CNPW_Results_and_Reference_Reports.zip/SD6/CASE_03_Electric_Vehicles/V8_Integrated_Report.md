# CNPW V8 Integrated Analysis Report

## 1. Input and scientific contract

- Filename: CNPW_Electric_Vehicles_M5_Input_v0.1.xlsx
- N: 53 · M: 5
- Responses, declared order: Range (WLTP) [km], Minimal price (gross) [PLN], Engine power [KM], Maximum DC charging power [kW], Maximum speed [kph]
- One-click execution: Mode A plus every non-empty proper equal-count protected-response block.
- CNPW selects first; any percentages are reporting-only and never influence qualification, QCCA, recovery, or alternatives.

## 2. Mode A

### Mode A deterministic state

- Full-system Global capability: GL5 · |W¹|=1
- All-response Local state: resolved_unique_highest_global · K_L=7
- Terminal/co-terminal candidates: Kia e-Soul 64kWh

## 3. Mode-B protected-domain contract landscape

Protection determines admissibility; residual responses determine Stage-1 conditional capability; all active responses re-enter Stage-2 Local refinement.
Rows follow protected-block cardinality and declared response order. They are not ranked. Ω_P is the protected admissible population; W_B¹ is the residual Stage-1 retained population.

| Contract | Protected block | k_P | Ω_P size | Residual Stage-1 capability | W_B¹ size | All-response Local state / C_L | Terminal/co-terminal | QCCA/action |
|---|---|---:|---:|---:|---:|---|---|---|
| 55daa4723375 | Range (WLTP) [km] | GL7 | 8 | GL4 | 1 | resolved_unique_highest_global | Volkswagen ID.3 Pro S | NOT_REQUIRED |
| 11e42dbf1e90 | Minimal price (gross) [PLN] | GL7 | 8 | GL3 | 3 | resolved_unique_all_top_local | Citroën ë-C4 | NOT_REQUIRED |
| 8012a29aaaef | Engine power [KM] | GL7 | 8 | GL2 | 3 | resolved_unique_all_top_local | Tesla Model S Long Range Plus | NOT_REQUIRED |
| f22a9f279c1f | Maximum DC charging power [kW] | GL7 | 18 | GL4 | 1 | resolved_unique_highest_global | Tesla Model 3 Standard Range Plus | NOT_REQUIRED |
| ac1b6df0404c | Maximum speed [kph] | GL7 | 9 | GL3 | 1 | resolved_unique_highest_global | Tesla Model 3 Performance | NOT_REQUIRED |
| 7456cd771b83 | Range (WLTP) [km] + Minimal price (gross) [PLN] | GL5 | 4 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| 54f871d91821 | Range (WLTP) [km] + Engine power [KM] | GL7 | 4 | GL2 | 2 | resolved_unique_all_top_local | Tesla Model S Long Range Plus | NOT_REQUIRED |
| 5485e99f1209 | Range (WLTP) [km] + Maximum DC charging power [kW] | GL7 | 6 | GL3 | 2 | local_qcca_required / LL1 | Tesla Model 3 Long Range, Tesla Model 3 Performance | COMPLETED |
| b7271590440c | Range (WLTP) [km] + Maximum speed [kph] | GL7 | 5 | GL3 | 1 | resolved_unique_highest_global | Tesla Model 3 Performance | NOT_REQUIRED |
| 95605b675429 | Minimal price (gross) [PLN] + Engine power [KM] | GL5 | 3 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| cc7bb6fe7090 | Minimal price (gross) [PLN] + Maximum DC charging power [kW] | GL5 | 13 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| 8de8eaaecb45 | Minimal price (gross) [PLN] + Maximum speed [kph] | GL5 | 1 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| 91efb52b719b | Engine power [KM] + Maximum DC charging power [kW] | GL7 | 8 | GL2 | 3 | resolved_unique_all_top_local | Tesla Model S Long Range Plus | NOT_REQUIRED |
| 549b877d8005 | Engine power [KM] + Maximum speed [kph] | GL7 | 6 | GL2 | 2 | resolved_unique_all_top_local | Tesla Model S Long Range Plus | NOT_REQUIRED |
| 8f3c7c762f4b | Maximum DC charging power [kW] + Maximum speed [kph] | GL7 | 9 | GL3 | 1 | resolved_unique_highest_global | Tesla Model 3 Performance | NOT_REQUIRED |
| da3785fe0864 | Range (WLTP) [km] + Minimal price (gross) [PLN] + Engine power [KM] | GL5 | 2 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| 200b785dc4a5 | Range (WLTP) [km] + Minimal price (gross) [PLN] + Maximum DC charging power [kW] | GL5 | 2 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| e2b2188d391f | Range (WLTP) [km] + Minimal price (gross) [PLN] + Maximum speed [kph] | GL5 | 1 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| dd3b6d8a594f | Range (WLTP) [km] + Engine power [KM] + Maximum DC charging power [kW] | GL7 | 4 | GL2 | 2 | resolved_unique_all_top_local | Tesla Model S Long Range Plus | NOT_REQUIRED |
| 8ddc5bba5dba | Range (WLTP) [km] + Engine power [KM] + Maximum speed [kph] | GL7 | 4 | GL2 | 2 | resolved_unique_all_top_local | Tesla Model S Long Range Plus | NOT_REQUIRED |
| a7393ea6f40b | Range (WLTP) [km] + Maximum DC charging power [kW] + Maximum speed [kph] | GL7 | 5 | GL3 | 1 | resolved_unique_highest_global | Tesla Model 3 Performance | NOT_REQUIRED |
| 41b8f521be01 | Minimal price (gross) [PLN] + Engine power [KM] + Maximum DC charging power [kW] | GL5 | 3 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| 54ac60ff9fa0 | Minimal price (gross) [PLN] + Engine power [KM] + Maximum speed [kph] | GL5 | 1 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| 00df6716e774 | Minimal price (gross) [PLN] + Maximum DC charging power [kW] + Maximum speed [kph] | GL5 | 1 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| f2411b2521d1 | Engine power [KM] + Maximum DC charging power [kW] + Maximum speed [kph] | GL7 | 6 | GL2 | 2 | resolved_unique_all_top_local | Tesla Model S Long Range Plus | NOT_REQUIRED |
| 3507f05d159e | Range (WLTP) [km] + Minimal price (gross) [PLN] + Engine power [KM] + Maximum DC charging power [kW] | GL5 | 2 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| e1f493492d61 | Range (WLTP) [km] + Minimal price (gross) [PLN] + Engine power [KM] + Maximum speed [kph] | GL5 | 1 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| 9489565c666d | Range (WLTP) [km] + Minimal price (gross) [PLN] + Maximum DC charging power [kW] + Maximum speed [kph] | GL5 | 1 | GL5 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |
| f31605e7da2d | Range (WLTP) [km] + Engine power [KM] + Maximum DC charging power [kW] + Maximum speed [kph] | GL7 | 4 | GL2 | 2 | resolved_unique_all_top_local | Tesla Model S Long Range Plus | NOT_REQUIRED |
| 7a0052b23402 | Minimal price (gross) [PLN] + Engine power [KM] + Maximum DC charging power [kW] + Maximum speed [kph] | GL5 | 1 | GL6 | 1 | resolved_unique_highest_global | Kia e-Soul 64kWh | NOT_REQUIRED |

## 4. QCCA diagnosis and QCCA-guided alternatives

Global QCCA diagnoses (X, J, G) for Mode A and (Ω_P, J_res, G) for Mode B, excluding protected responses only from the residual Global system. Local QCCA uses all active responses J on frozen W¹, only for a Core-declared Local collapse. Recovery sets and targeted alternatives preserve all equal formal routes; none is preferred.

### Mode B 5485e99f1209 Local QCCA

- Baseline C_L: LL1; targets: LL2, LL3, LL4, LL5, LL6, LL7.
- Target LL2; recovery set {Range (WLTP) [km], Minimal price (gross) [PLN]}; witnesses: Tesla Model 3 Performance.
- Target LL2; recovery set {Engine power [KM], Maximum speed [kph]}; witnesses: Tesla Model 3 Long Range.
- Target LL3; recovery set {Range (WLTP) [km], Minimal price (gross) [PLN]}; witnesses: Tesla Model 3 Performance.
- Target LL3; recovery set {Engine power [KM], Maximum speed [kph]}; witnesses: Tesla Model 3 Long Range.
- Target LL4; recovery set {Range (WLTP) [km], Minimal price (gross) [PLN]}; witnesses: Tesla Model 3 Performance.
- Target LL4; recovery set {Engine power [KM], Maximum speed [kph]}; witnesses: Tesla Model 3 Long Range.
- Target LL5; recovery set {Range (WLTP) [km], Minimal price (gross) [PLN]}; witnesses: Tesla Model 3 Performance.
- Target LL5; recovery set {Engine power [KM], Maximum speed [kph]}; witnesses: Tesla Model 3 Long Range.
- Target LL6; recovery set {Range (WLTP) [km], Minimal price (gross) [PLN]}; witnesses: Tesla Model 3 Performance.
- Target LL6; recovery set {Engine power [KM], Maximum speed [kph]}; witnesses: Tesla Model 3 Long Range.
- Target LL7; recovery set {Range (WLTP) [km], Minimal price (gross) [PLN]}; witnesses: Tesla Model 3 Performance.
- Target LL7; recovery set {Engine power [KM], Maximum speed [kph]}; witnesses: Tesla Model 3 Long Range.

## 5. Verification and provenance

- Complete public-run verification: PASS.
- Expected/actual Mode-B contracts: 30/30.
- Every Mode-B contract has a deterministic content-derived identity and reuses the frozen full-population Global matrix.

## 6. AI-assisted interpretation

AI-assisted interpretation: Unavailable in this execution.

## 7. Limitations

A protected response with a lower Local position remains inside its Stage-1 protected domain; this does not relax or invalidate the protection contract. No weights, scores, preferred contract, preferred recovery set, preferred alternative, SHAP, connectivity, boundary, or process interpretation is provided.