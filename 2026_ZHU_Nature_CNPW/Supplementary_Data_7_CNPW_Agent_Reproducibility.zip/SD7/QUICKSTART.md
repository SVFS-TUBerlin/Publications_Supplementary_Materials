# Quickstart

This guide uses only the synthetic public example. It does not run a frozen cross-domain case.

1. Install Python 3.11.9 (or a compatible Python 3 release) and create an environment.
2. Install dependencies: `python -m pip install -r requirements.txt`.
3. `OPENAI_API_KEY` is not required for analysis; it is reserved for an optional bounded post-analysis narrative.
4. Start the local UI: `python -m streamlit run app/streamlit_app.py`.
5. Open the local address shown by Streamlit.
6. Upload [examples/example_m3.csv](examples/example_m3.csv).
7. Run the automatic full analysis: Mode A and every non-empty proper equal-count protected-response Mode-B block execute in formal order (`6` contracts for this M=3 example).
8. Review the verified Mode-A state and the unranked Mode-B contract landscape; QCCA/recovery/action evidence appears only where Core Local state requires it.
9. Save the generated report and provenance artifacts with your study records.

The example has three active synthetic criteria, seven synthetic candidates, one cost direction, and a descriptor column. It is not a dataset and supports no scientific conclusion.

Common stops are intentional: `M=2` or `M>5`, malformed direction rows, and requests outside the fixed public envelope. A missing API key never blocks deterministic analysis.
