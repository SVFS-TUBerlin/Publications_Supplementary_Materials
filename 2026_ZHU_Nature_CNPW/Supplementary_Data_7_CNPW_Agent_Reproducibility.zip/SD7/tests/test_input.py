import csv
import tempfile
import unittest
from pathlib import Path

from src.input_loader import InputError, load_dataset


class InputTests(unittest.TestCase):
    def write(self, rows):
        handle = tempfile.NamedTemporaryFile("w", suffix=".csv", newline="", delete=False, encoding="utf-8")
        with handle:
            csv.writer(handle).writerows(rows)
        self.addCleanup(lambda: Path(handle.name).unlink(missing_ok=True))
        return handle.name

    def test_duplicate_id_rejected(self):
        path = self.write([["Candidate_ID", "A", "B"], ["Direction", "1", "0"], ["x", "1", "2"], ["x", "2", "1"]])
        with self.assertRaises(InputError): load_dataset(path)

    def test_missing_result_rejected(self):
        path = self.write([["Candidate_ID", "A", "B"], ["Direction", "1", "0"], ["x", "", "2"], ["y", "2", "1"]])
        with self.assertRaises(InputError): load_dataset(path)

    def test_invalid_direction_rejected(self):
        path = self.write([["Candidate_ID", "A", "B"], ["Direction", "2", "0"], ["x", "", "2"], ["y", "2", "1"]])
        with self.assertRaises(InputError): load_dataset(path)

    def test_blank_result_slot_is_ignored(self):
        valid = self.write([["Candidate_ID", "A", "B", ""], ["Direction", "1", "0", ""], ["x", "1", "2", ""], ["y", "2", "1", ""]])
        self.assertEqual(2, len(load_dataset(valid).criteria))
    def test_blank_result_slot_with_hidden_data_rejected(self):
        invalid = self.write([["Candidate_ID", "A", "B", ""], ["Direction", "1", "0", ""], ["x", "1", "2", "secret"], ["y", "2", "1", ""]])
        with self.assertRaises(InputError): load_dataset(invalid)
