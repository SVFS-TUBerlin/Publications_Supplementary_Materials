import unittest
from decimal import Decimal

from src.mode_a import run_mode_a
from src.mode_b import run_mode_b
from src.models import ProtectionContract
from src.stage1 import assign_stage1
from src.stage2 import adaptive_stage2
from tests.helpers import make_dataset


class V8GlobalAndProtectionTests(unittest.TestCase):
    def setUp(self):
        # The first two responses trade off perfectly: their pair capability is
        # GL4, proving pair protection is not assumed to be GL7.
        self.data = make_dataset(
            [f"x{i}" for i in range(7)], ["a", "b", "c"],
            ["maximize", "maximize", "maximize"],
            [[i, 6 - i, 1] for i in range(7)],
        )

    def test_pair_equal_count_protection_uses_own_attainable_level(self):
        result = run_mode_b(self.data, ProtectionContract("equal_count_global_qualification", (0, 1)))
        self.assertEqual(4, result.protected["k_p"])
        self.assertEqual(["x3"], result.protected["omega_candidate_ids"])
        self.assertEqual([3], result.stage1.retained)
        self.assertIn("a", result.stage2.local)
        self.assertIn("b", result.stage2.local)
        self.assertIn("c", result.stage2.local)

    def test_full_protection_is_guarded_without_fabricated_residual_capability(self):
        with self.assertRaisesRegex(ValueError, "non-empty residual"):
            run_mode_b(self.data, ProtectionContract("equal_count_global_qualification", (0, 1, 2)))

    def test_mode_b_reuses_full_frozen_global_matrix_without_reranking(self):
        full = assign_stage1(self.data)
        result = run_mode_b(self.data, ProtectionContract("equal_count_global_qualification", (0, 1)))
        self.assertEqual(full.frozen_global.identity, result.stage1.frozen_global.identity)
        self.assertEqual(full.gl, result.stage1.gl)

    def test_raw_threshold_and_operating_tolerance_contracts(self):
        raw = run_mode_b(self.data, ProtectionContract("explicit_raw_thresholds", (0, 1), raw_thresholds={0: Decimal("3"), 1: Decimal("3")}))
        tol = run_mode_b(self.data, ProtectionContract("normalized_operating_range_tolerances", (0,), tolerances={0: Decimal("0.5")}))
        self.assertEqual(["x3"], raw.protected["omega_candidate_ids"])
        self.assertEqual(["x3", "x4", "x5", "x6"], tol.protected["omega_candidate_ids"])

    def test_empty_protection_domain_is_not_automatically_lowered(self):
        contract = ProtectionContract("explicit_raw_thresholds", (0,), raw_thresholds={0: Decimal("99")})
        with self.assertRaisesRegex(ValueError, "no automatic lowering"):
            run_mode_b(self.data, contract)

    def test_no_lower_global_backfill(self):
        result = run_mode_a(self.data)
        qualified = set(result.stage1.retained)
        self.assertTrue(set(result.stage2.retained).issubset(qualified))


class V8AdaptiveLocalTests(unittest.TestCase):
    def test_unique_w1_is_immediately_resolved(self):
        data = make_dataset(["a"], ["x", "y"], ["maximize", "maximize"], [[1, 1]])
        result = adaptive_stage2(data, [0], [0, 1])
        self.assertEqual("resolved_unique_highest_global", result.local_status)
        self.assertFalse(result.local_qcca_required)

    def test_unique_all_top_at_initial_resolution(self):
        data = make_dataset(["a", "b", "c"], ["x", "y"], ["maximize", "maximize"], [[100, 100], [0, 90], [90, 0]])
        result = adaptive_stage2(data, [0, 1, 2], [0, 1])
        self.assertEqual("resolved_unique_all_top_local", result.local_status)
        self.assertEqual(7, result.k_l)

    def test_event_sequence_jumps_to_first_no_all_top_resolution(self):
        data = make_dataset(["a", "b", "c", "d"], ["x", "y"], ["maximize", "maximize"], [[100, 90], [90, 100], [0, 0], [10, 10]])
        result = adaptive_stage2(data, [0, 1, 2, 3], [0, 1])
        self.assertEqual("local_qcca_required", result.local_status)
        self.assertEqual(11, result.k_l)
        self.assertTrue(result.local_qcca_required)
        self.assertEqual([7, 11], [item["k_l"] for item in result.adaptive_trace])
        top_sets = [set(item["all_top"]) for item in result.adaptive_trace]
        self.assertTrue(all(later.issubset(earlier) for earlier, later in zip(top_sets, top_sets[1:])))

    def test_raw_response_equivalent_candidates_remain_coterminal(self):
        data = make_dataset(["a", "b", "c"], ["x", "y"], ["maximize", "maximize"], [[100, 100], [100, 100], [0, 0]])
        result = adaptive_stage2(data, [0, 1, 2], [0, 1])
        self.assertEqual("co_terminal_response_equivalent", result.local_status)
        self.assertTrue(result.response_equivalent)
        self.assertEqual([0, 1], result.retained)
