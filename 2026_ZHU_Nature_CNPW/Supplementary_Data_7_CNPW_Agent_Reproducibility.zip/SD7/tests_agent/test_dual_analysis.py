import unittest
from pathlib import Path

from agent.dual_coordinator import DualAnalysisCoordinator
from agent.integrated_report import render_integrated_markdown


ROOT = Path(__file__).resolve().parents[1]


class DualAnalysisTests(unittest.TestCase):
    def test_single_validation_runs_mode_a_and_full_v8_contract_family(self):
        outcome = DualAnalysisCoordinator(ROOT).execute(ROOT / "tests_agent" / "fixtures" / "small_m3.csv")
        self.assertIsNone(outcome.error)
        dual = outcome.result
        self.assertEqual("completed", dual["overall_integrity_status"])
        self.assertEqual("MODE_A", dual["mode_a"]["verified_result"]["mode"])
        self.assertEqual(6, len(dual["mode_b_contracts"]))
        self.assertEqual("MODE_B_PROTECTED_DOMAIN", dual["mode_b_contracts"][0]["verified_result"]["mode"])
        self.assertTrue(dual["mode_a"]["verification"].passed)
        self.assertTrue(all(branch["verification"].passed for branch in dual["mode_b_contracts"]))
        self.assertEqual(dual["input_identity"].source_hash_sha256, dual["mode_b_contracts"][0]["canonical_task"].input_summary.identity.source_hash_sha256)
        self.assertIn("terminal_same", dual["comparison"])
        comparison = dual["comparison"]
        self.assertEqual(set(comparison['mode_a_terminal_ids']) == set(comparison['mode_b_terminal_ids']), comparison['terminal_same'])
        self.assertEqual(set(comparison['mode_a_terminal_ids']) & set(comparison['mode_b_terminal_ids']), set(comparison['terminal_overlap_ids']))
        self.assertNotIn("winner", dual["comparison"])
        report = render_integrated_markdown(dual)
        self.assertIn("## 2. Mode A", report)
        self.assertIn("Mode-B protected-domain contract landscape", report)
        self.assertIn("not ranked", report)


if __name__ == "__main__":
    unittest.main()
