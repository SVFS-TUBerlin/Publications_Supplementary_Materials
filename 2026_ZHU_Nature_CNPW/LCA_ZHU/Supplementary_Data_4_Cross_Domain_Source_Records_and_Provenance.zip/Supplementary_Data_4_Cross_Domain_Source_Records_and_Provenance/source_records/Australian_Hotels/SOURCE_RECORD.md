# Case 06 — Australian hotel observations source record

- **Local archived source:** `db24b7dwzp-1.zip`
- **Source locator:** Nested workbook `Aus_LGAs_WiFI_hotels_Custom_satisf_database.xlsx`, Sheet1
- **Source citation:** Grechyn, V. *Public Wi-Fi Provision by LGAs in Australia, Wi-Fi in Australian Hotels and the Level of Satisfaction of the Hotels' Customers*. Mendeley Data, V1 (2019). DOI: https://doi.org/10.17632/db24b7dwzp.1
- **Initial source population:** 312 hotel observations
- **Candidate filter / population rule:** Use Wi-Fi, Location, Value and Cleanliness for the frozen M4 analysis. Service has one missing value (311/312 complete) and is excluded from the M4 input rather than dropping one candidate.
- **Final CNPW population:** 312
- **Active responses:** 4
- **Local source SHA256:** `40caebc9486a7297ddf0272942c8166f850d7c0e2cccb3dce3af0e4fdb9f4976`
- **Local source size (bytes):** 110660
- **Redistribution status:** `PROVENANCE_ONLY_ORIGINAL_NOT_BUNDLED`
- **Frozen input:** `CNPW_Case06_Australian_Hotels_M4_Input_v0.1.xlsx`

The source dataset is CC BY 4.0, but SD4 remains provenance-first and does not duplicate the original archive. The Hotel_### identifier rule, retained LGA descriptor and four active responses are documented in `Source_to_Input_Mapping.xlsx`.
