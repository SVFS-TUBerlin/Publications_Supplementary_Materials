# Case 09 — ALEM land-conservation benchmark × CNPW final-formalism replay v1.6.0

## Status

**FINAL REPLACEMENT EVIDENCE.** This replay corrects the legacy residual-only Stage-2 treatment in the representative dual-GL7 Mode-B branch.

## Frozen candidate space

- 10 benchmark instances.
- First 200 lexicographically ordered nondominated solutions per instance.
- 2,000 candidates × 4 responses.
- Response directions: Saved Species ↑, Cost ↓, Compactness ↓, Population ↑.
- The stored Global labels were independently checked against the final positional/tie-upward `K_G=7` rule and matched exactly.

## Representative Mode-A result

For Instance 0, the final formalism reproduces:

- native lexicographic rank 1 Global profile: **(7,7,2,1)**;
- full four-response `C(J)=GL4`;
- final Mode-A terminal: lexicographic rank **89**, Global profile **(7,4,6,4)**.

The manuscript/Table-1 Mode-A comparison is unchanged.

## Corrected dual-GL7 Mode-B branch

Protected requirements:

- Saved Species ≥ GL7;
- Cost ≥ GL7.

This retains **30/200** Instance-0 candidates.

Residual Stage 1 over {Compactness, Population} gives:

- residual capability **GL3**;
- residual `W1` = lexicographic ranks **26** and **29**.

The legacy record then applied Stage 2 only to the residual responses and uniquely selected rank 29. That is not the final CNPW Mode-B rule.

Under the final formalism, **all four active responses re-enter Stage 2** within the residual Stage-1 population. At `K_L,0=7`:

- rank 26 Local profile = **(7,7,7,1)**;
- rank 29 Local profile = **(7,1,7,7)**;
- both have Local capability **LL1**;
- both have the same weakest-first ordered profile **(1,7,7,7)**.

Their raw-response vectors are:

- rank 26: `(15, 241, 17, 1481)`;
- rank 29: `(15, 242, 17, 1485)`.

Rank 26 has lower Cost, while rank 29 has higher Population; neither raw-response dominates the other. Therefore the final terminal result is:

**co-terminal = {lex-rank 26, lex-rank 29}**.

Both candidates have the same frozen Global profile:

**(7,7,4,3)**.

## Scientific impact

The central manuscript/Table-1 comparison is unchanged:

`(7,7,2,1) -> (7,7,4,3)` under dual-GL7 protection.

The correction affects only the Local Stage-2 state and terminal multiplicity:

- legacy: unique rank 29;
- final: co-terminal ranks 26 and 29.

The QCCA claim that removing Cost raises `C(J)` in **10/10** instances is independently reproduced and unchanged.

## Included files

- `ALEM_CNPW_FinalFormalism_v1.6.0.xlsx` — clean final evidence workbook without legacy residual-only Mode-B outputs.
- `DERIVED_AUDIT/ALEM_Cost_Removal_Audit.csv` — 10-instance Cost-removal audit.

## Replacement instruction

In SD8 Case09, supersede `ALEM_CNPW_data_and_results_LOCKED_v1.xlsx` with this final workbook and include this report as the authoritative interpretation of the representative dual-L7 Mode-B result.
