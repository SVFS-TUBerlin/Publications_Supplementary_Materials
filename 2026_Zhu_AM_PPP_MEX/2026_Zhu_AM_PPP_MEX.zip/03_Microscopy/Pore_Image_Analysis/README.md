# ZhuChen v3.3 — Sectional Porosity Analysis

Developed by Yanlong Zhu. This graphical tool supports the sectional porosity measurements described in Section 2.2 and Supplementary Figure S1 of the accompanying manuscript.

## Files

- `ZhuChen_v3_3.py` starts the application.
- `../ROI_Images/` contains the supplied microscopy images after you extract the separate microscopy ZIP into the same project folder.
- The ROI workbook in the parent folder contains the reported sectional porosity measurements.

## Run on Windows

Use Python 3.11 with Tkinter. Open Command Prompt in this folder and run:

```cmd
py -3.11 -m pip install Pillow openpyxl
py -3.11 ZhuChen_v3_3.py
```

Pillow is required for image processing. The application uses openpyxl for Excel export. Use the application's file or folder dialogs to select images in `../ROI_Images/`. Use a separate writable folder for generated project files and reports.

## Measurement workflow

1. Open an image and calibrate the pixel scale against its scale bar in **Scale calibration**.
2. Run automatic pore detection and inspect the mask overlaid on the source image. Use **Refinement** to correct the mask where needed before measuring the ROIs.
3. In **Fixed-template ROI**, select the specimen's line pitch and the ROI height from the table below. Generate and position the ROI using the sampling procedure in Section 2.2.
4. Record the measurements and export the report in **Data export**. Sectional porosity is the identified pore area divided by the ROI area, expressed as a percentage.

| Line pitch P (mm) | ROI width (mm) |
| ---: | ---: |
| 0.43 | 0.86 |
| 0.45 | 0.90 |
| 0.47 | 0.94 |

Use **0.40 mm** ROI height for specimens printed at **0.10 or 0.20 mm** layer height, and **0.50 mm** for specimens printed at **0.25 mm** layer height. The ROI height selector defaults to 0.40 mm. Check the setting before generating the ROI.
