# Supplementary Data 2 — Frozen 7,056-candidate PLA–MEX response space

## Scientific role

This package contains the canonical finite candidate–response population on which the controlled-system CNPW analyses were performed.

## Candidate grid

- layer height `h_mm`: 0.10–0.25 mm, step 0.01 mm (16 levels)
- parameter `P`: 0.430–0.470, step 0.002 (21 levels)
- printing speed `v_mm_s`: 20–120 mm s⁻¹, step 5 mm s⁻¹ (21 levels)
- total candidates: `16 × 21 × 21 = 7,056`

## Columns

`Candidate_ID, h_mm, P, v_mm_s, UTS_MPa, E_MPa, GWP_kgCO2eq, FRS_kgoileq`

Favourable directions used by CNPW are: maximize UTS and E; minimize GWP and FRS.

The file is the frozen response table reproduced from Supplementary Data 1. No CNPW qualification, Pareto label, scalar score or terminal designation is embedded in this dataset.
