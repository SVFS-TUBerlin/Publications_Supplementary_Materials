import unittest
from pathlib import Path
from agent.qcca_analyzer import analyze_qcca
from agent.qcca_verifier import verify_qcca
from src.input_loader import load_dataset
from src.mode_a import run_mode_a
class QccaTests(unittest.TestCase):
 def test_counts_and_no_collapse(self):
  for m,count in ((3,4),(4,11),(5,26)):
   r=analyze_qcca(tuple('ABCDE'[:m]),[[7]*m,[6]*m],7);self.assertEqual(count,len(r.subset_ceilings));self.assertEqual('NO_DETECTED_QUALIFICATION_BOTTLENECK',r.bottleneck_state);self.assertTrue(verify_qcca(r,7).passed)
 def test_recovery_and_tamper(self):
  r=analyze_qcca(('A','B','C'),[[7,7,4],[7,4,7],[4,7,7]],4);self.assertEqual('SINGLE_RESPONSE_LIMITATION',r.bottleneck_state);object.__setattr__(r,'full_system_ceiling',7);self.assertFalse(verify_qcca(r,4).passed)
 def test_public_gl_path(self):
  d=load_dataset('examples/example_m3.csv');a=run_mode_a(d);r=analyze_qcca(tuple(x.name for x in d.criteria),a.stage1.gl,a.stage1.q1,candidate_ids=d.candidate_ids);self.assertEqual(4,len(r.subset_ceilings));self.assertTrue(verify_qcca(r,a.stage1.q1).passed)
if __name__=='__main__':unittest.main()
