#!/usr/bin/env sh
cd "$(dirname "$0")"
python -m streamlit run app/streamlit_app.py
